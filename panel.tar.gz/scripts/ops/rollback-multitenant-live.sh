#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'USAGE'
Usage:
  bash scripts/ops/rollback-multitenant-live.sh \
    --panel-dir /var/www/wammucore \
    --db-host 127.0.0.1 \
    --db-port 3306 \
    --db-name wammucore \
    --db-user wammucore \
    --db-pass 'secret' \
    --backup-dir /var/backups/wammucore/20260506-123000 \
    --panel-domain panel.wammuhost.com \
    --admin-domain admin.yourplatform.com

Notes:
  - Restores DB dump from db-pre-rollout.sql.gz.
  - Restores code from panel-pre-rollout.tar.gz.
  - Disables tenancy in .env.
USAGE
}

PANEL_DIR=""
DB_HOST=""
DB_PORT="3306"
DB_NAME=""
DB_USER=""
DB_PASS=""
BACKUP_DIR=""
PANEL_DOMAIN=""
ADMIN_DOMAIN=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --panel-dir) PANEL_DIR="$2"; shift 2 ;;
    --db-host) DB_HOST="$2"; shift 2 ;;
    --db-port) DB_PORT="$2"; shift 2 ;;
    --db-name) DB_NAME="$2"; shift 2 ;;
    --db-user) DB_USER="$2"; shift 2 ;;
    --db-pass) DB_PASS="$2"; shift 2 ;;
    --backup-dir) BACKUP_DIR="$2"; shift 2 ;;
    --panel-domain) PANEL_DOMAIN="$2"; shift 2 ;;
    --admin-domain) ADMIN_DOMAIN="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage; exit 1 ;;
  esac
done

required=(PANEL_DIR DB_HOST DB_PORT DB_NAME DB_USER DB_PASS BACKUP_DIR PANEL_DOMAIN ADMIN_DOMAIN)
for key in "${required[@]}"; do
  if [[ -z "${!key}" ]]; then
    echo "Missing required option: --$(echo "$key" | tr '[:upper:]' '[:lower:]' | tr '_' '-')" >&2
    usage
    exit 1
  fi
done

if [[ ! -f "$BACKUP_DIR/db-pre-rollout.sql.gz" ]]; then
  echo "Missing DB backup: $BACKUP_DIR/db-pre-rollout.sql.gz" >&2
  exit 1
fi

if [[ ! -f "$BACKUP_DIR/panel-pre-rollout.tar.gz" ]]; then
  echo "Missing code backup: $BACKUP_DIR/panel-pre-rollout.tar.gz" >&2
  exit 1
fi

set_env_value() {
  local file="$1"
  local key="$2"
  local value="$3"
  if grep -qE "^${key}=" "$file"; then
    sed -i "s|^${key}=.*|${key}=${value}|" "$file"
  else
    printf "\n%s=%s\n" "$key" "$value" >>"$file"
  fi
}

echo "[1/5] Entering maintenance mode"
php "$PANEL_DIR/artisan" down --retry=60 || true

echo "[2/5] Restoring code snapshot"
TMP_DIR="$(mktemp -d)"
tar -xzf "$BACKUP_DIR/panel-pre-rollout.tar.gz" -C "$TMP_DIR"
rsync -a --delete "$TMP_DIR/" "$PANEL_DIR/"
rm -rf "$TMP_DIR"

echo "[3/5] Restoring database snapshot"
gunzip -c "$BACKUP_DIR/db-pre-rollout.sql.gz" | MYSQL_PWD="$DB_PASS" mysql \
  --host="$DB_HOST" \
  --port="$DB_PORT" \
  --user="$DB_USER" \
  "$DB_NAME"

echo "[4/5] Disabling tenancy and restarting workers"
ENV_FILE="$PANEL_DIR/.env"
set_env_value "$ENV_FILE" "TENANCY_ENABLED" "false"
set_env_value "$ENV_FILE" "TENANCY_MASTER_ADMIN_HOSTS" "$ADMIN_DOMAIN"
php "$PANEL_DIR/artisan" optimize:clear
php "$PANEL_DIR/artisan" config:cache
php "$PANEL_DIR/artisan" horizon:terminate || true
php "$PANEL_DIR/artisan" queue:restart || true

echo "[5/5] Bringing panel online"
php "$PANEL_DIR/artisan" up

cat <<EOF

Rollback completed.

DNS rollback checklist:
1) Point ${PANEL_DOMAIN} back to previous panel endpoint.
2) Remove or disable ${ADMIN_DOMAIN} entry from reverse proxy if not needed.
3) Flush CDN cache if any.
EOF
