#!/usr/bin/env bash
set -euo pipefail

if [[ "$(id -u)" -ne 0 ]]; then
    if command -v systemd-run >/dev/null 2>&1; then
        exec sudo -n systemd-run --quiet --wait --pipe --collect --unit "wammucore-ssl-provision-$$" /usr/bin/env bash "$0" "$@"
    fi

    exec sudo -n /usr/bin/env bash "$0" "$@"
fi

DOMAIN="${1:-}"
EMAIL="${2:-}"
PANEL_ROOT="${WAMMUCORE_PANEL_ROOT:-/var/www/wammucore/public}"
PHP_FPM_SOCKET="${WAMMUCORE_PHP_FPM_SOCKET:-unix:/run/php/php8.3-fpm.sock}"
NGINX_AVAILABLE_DIR="${WAMMUCORE_SSL_NGINX_AVAILABLE_DIR:-/etc/nginx/sites-available}"
NGINX_ENABLED_DIR="${WAMMUCORE_SSL_NGINX_ENABLED_DIR:-/etc/nginx/sites-enabled}"
CONFIG_NAME="wammucore-reseller-${DOMAIN}.conf"
AVAILABLE_PATH="${NGINX_AVAILABLE_DIR}/${CONFIG_NAME}"
ENABLED_PATH="${NGINX_ENABLED_DIR}/${CONFIG_NAME}"

if [[ ! "${DOMAIN}" =~ ^[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$ ]]; then
    echo "Invalid domain: ${DOMAIN}" >&2
    exit 2
fi

if [[ ! "${EMAIL}" =~ ^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$ ]]; then
    echo "Invalid ACME email: ${EMAIL}" >&2
    exit 2
fi

install -d "${NGINX_AVAILABLE_DIR}" "${NGINX_ENABLED_DIR}"

cat > "${AVAILABLE_PATH}" <<NGINX
server {
    listen 80;
    server_name ${DOMAIN};

    root ${PANEL_ROOT};
    index index.php;

    client_max_body_size 100m;
    sendfile off;

    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass ${PHP_FPM_SOCKET};
        fastcgi_param SCRIPT_FILENAME \$realpath_root\$fastcgi_script_name;
        fastcgi_read_timeout 300;
    }

    location ~ /\.(?!well-known).* {
        deny all;
    }
}
NGINX

ln -sfn "${AVAILABLE_PATH}" "${ENABLED_PATH}"
nginx -t
systemctl reload nginx

certbot certonly \
    --nginx \
    --non-interactive \
    --agree-tos \
    --email "${EMAIL}" \
    --cert-name "${DOMAIN}" \
    -d "${DOMAIN}"

cat > "${AVAILABLE_PATH}" <<NGINX
server {
    listen 80;
    server_name ${DOMAIN};
    return 301 https://\$host\$request_uri;
}

server {
    listen 443 ssl http2;
    server_name ${DOMAIN};

    root ${PANEL_ROOT};
    index index.php;

    access_log /var/log/nginx/${DOMAIN}-access.log;
    error_log /var/log/nginx/${DOMAIN}-error.log warn;

    client_max_body_size 100m;
    sendfile off;

    ssl_certificate /etc/letsencrypt/live/${DOMAIN}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${DOMAIN}/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;

    add_header X-Content-Type-Options nosniff;
    add_header X-Frame-Options SAMEORIGIN;
    add_header Referrer-Policy same-origin;

    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass ${PHP_FPM_SOCKET};
        fastcgi_param SCRIPT_FILENAME \$realpath_root\$fastcgi_script_name;
        fastcgi_read_timeout 300;
    }

    location ~ /\.(?!well-known).* {
        deny all;
    }
}
NGINX

nginx -t
systemctl reload nginx
