#!/usr/bin/env bash
set -euo pipefail

if [[ "$(id -u)" -ne 0 ]]; then
    if command -v systemd-run >/dev/null 2>&1; then
        exec sudo -n systemd-run --quiet --wait --pipe --collect --unit "wammucore-ssl-cleanup-$$" /usr/bin/env bash "$0" "$@"
    fi

    exec sudo -n /usr/bin/env bash "$0" "$@"
fi

DOMAIN="${1:-}"
NGINX_AVAILABLE_DIR="${WAMMUCORE_SSL_NGINX_AVAILABLE_DIR:-/etc/nginx/sites-available}"
NGINX_ENABLED_DIR="${WAMMUCORE_SSL_NGINX_ENABLED_DIR:-/etc/nginx/sites-enabled}"
CONFIG_NAME="wammucore-reseller-${DOMAIN}.conf"

if [[ ! "${DOMAIN}" =~ ^[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$ ]]; then
    echo "Invalid domain: ${DOMAIN}" >&2
    exit 2
fi

rm -f "${NGINX_ENABLED_DIR}/${CONFIG_NAME}" "${NGINX_AVAILABLE_DIR}/${CONFIG_NAME}"

certbot delete --cert-name "${DOMAIN}" --non-interactive || true

nginx -t
systemctl reload nginx
