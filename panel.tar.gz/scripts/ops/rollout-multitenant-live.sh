#!/usr/bin/env bash
set -euo pipefail

usage() {
  cat <<'USAGE'
Usage:
  bash scripts/ops/rollout-multitenant-live.sh \
    --panel-dir /var/www/wammucore \
    --db-host 127.0.0.1 \
    --db-port 3306 \
    --db-name wammucore \
    --db-user wammucore \
    --db-pass 'secret' \
    --panel-domain panel.wammuhost.com \
    --admin-domain admin.yourplatform.com \
    --brand-name "WammuHost Direct" \
    --public-ip 194.15.36.245 \
    [--release-tar /root/panel.tar.gz] \
    [--backup-root /var/backups/wammucore] \
    [--max-ram-mb 262144] \
    [--max-cpu-cores 128] \
    [--max-disk-gb 4096] \
    [--max-vms 10000]

Notes:
  - Idempotent: safe to rerun (migrations + reseller init are guarded).
  - This script keeps existing .env and storage content.
  - If --release-tar is omitted, it only runs migration/init on current code.
USAGE
}

PANEL_DIR=""
DB_HOST=""
DB_PORT="3306"
DB_NAME=""
DB_USER=""
DB_PASS=""
PANEL_DOMAIN=""
ADMIN_DOMAIN=""
BRAND_NAME="WammuHost Direct"
PUBLIC_IP=""
RELEASE_TAR=""
BACKUP_ROOT="/var/backups/wammucore"
MAX_RAM_MB=""
MAX_CPU_CORES=""
MAX_DISK_GB=""
MAX_VMS=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --panel-dir) PANEL_DIR="$2"; shift 2 ;;
    --db-host) DB_HOST="$2"; shift 2 ;;
    --db-port) DB_PORT="$2"; shift 2 ;;
    --db-name) DB_NAME="$2"; shift 2 ;;
    --db-user) DB_USER="$2"; shift 2 ;;
    --db-pass) DB_PASS="$2"; shift 2 ;;
    --panel-domain) PANEL_DOMAIN="$2"; shift 2 ;;
    --admin-domain) ADMIN_DOMAIN="$2"; shift 2 ;;
    --brand-name) BRAND_NAME="$2"; shift 2 ;;
    --public-ip) PUBLIC_IP="$2"; shift 2 ;;
    --release-tar) RELEASE_TAR="$2"; shift 2 ;;
    --backup-root) BACKUP_ROOT="$2"; shift 2 ;;
    --max-ram-mb) MAX_RAM_MB="$2"; shift 2 ;;
    --max-cpu-cores) MAX_CPU_CORES="$2"; shift 2 ;;
    --max-disk-gb) MAX_DISK_GB="$2"; shift 2 ;;
    --max-vms) MAX_VMS="$2"; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage; exit 1 ;;
  esac
done

required=(PANEL_DIR DB_HOST DB_PORT DB_NAME DB_USER DB_PASS PANEL_DOMAIN ADMIN_DOMAIN BRAND_NAME PUBLIC_IP)
for key in "${required[@]}"; do
  if [[ -z "${!key}" ]]; then
    echo "Missing required option: --$(echo "$key" | tr '[:upper:]' '[:lower:]' | tr '_' '-')" >&2
    usage
    exit 1
  fi
done

for bin in php mysqldump mysql tar gzip sed awk; do
  if ! command -v "$bin" >/dev/null 2>&1; then
    echo "Missing required binary: $bin" >&2
    exit 1
  fi
done

if [[ ! -f "$PANEL_DIR/artisan" ]]; then
  echo "artisan not found in panel dir: $PANEL_DIR" >&2
  exit 1
fi

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="${BACKUP_ROOT}/${STAMP}"
mkdir -p "$BACKUP_DIR"

set_env_value() {
  local file="$1"
  local key="$2"
  local value="$3"
  if grep -qE "^${key}=" "$file"; then
    sed -i "s|^${key}=.*|${key}=${value}|" "$file"
  else
    printf "\n%s=%s\n" "$key" "$value" >>"$file"
  fi
}

echo "[1/8] Creating pre-rollout backups in: $BACKUP_DIR"
cp "$PANEL_DIR/.env" "$BACKUP_DIR/.env.pre-rollout"

MYSQL_PWD="$DB_PASS" mysqldump \
  --host="$DB_HOST" \
  --port="$DB_PORT" \
  --user="$DB_USER" \
  --single-transaction \
  --quick \
  --routines \
  --triggers \
  "$DB_NAME" > "$BACKUP_DIR/db-pre-rollout.sql"
gzip -f "$BACKUP_DIR/db-pre-rollout.sql"

tar -C "$PANEL_DIR" \
  --exclude='node_modules' \
  --exclude='storage/logs/*' \
  -czf "$BACKUP_DIR/panel-pre-rollout.tar.gz" .

if [[ -d /etc/pve ]]; then
  tar -C / -czf "$BACKUP_DIR/proxmox-etc-pve-pre-rollout.tar.gz" etc/pve
else
  echo "Skipping /etc/pve backup on this host (directory not found)."
fi

if [[ -n "$RELEASE_TAR" ]]; then
  if [[ ! -f "$RELEASE_TAR" ]]; then
    echo "Release tar not found: $RELEASE_TAR" >&2
    exit 1
  fi
fi

echo "[2/8] Enabling maintenance mode"
php "$PANEL_DIR/artisan" down --retry=60 || true

echo "[3/8] Deploying release code (non-destructive)"
if [[ -n "$RELEASE_TAR" ]]; then
  TMP_DIR="$(mktemp -d)"
  tar -xzf "$RELEASE_TAR" -C "$TMP_DIR"

  SOURCE_DIR="$TMP_DIR"
  if [[ -d "$TMP_DIR/panel" ]]; then
    SOURCE_DIR="$TMP_DIR/panel"
  fi

  rsync -a \
    --exclude='.env' \
    --exclude='storage/*' \
    --exclude='node_modules' \
    "$SOURCE_DIR/" "$PANEL_DIR/"

  rm -rf "$TMP_DIR"
fi

echo "[4/8] Installing backend dependencies"
composer install \
  --working-dir="$PANEL_DIR" \
  --no-dev \
  --prefer-dist \
  --no-interaction \
  --optimize-autoloader

echo "[5/8] Running migrations"
php "$PANEL_DIR/artisan" migrate --force

echo "[6/8] Initializing default reseller and backfilling ownership"
INIT_ARGS=(
  tenancy:initialize-default-reseller
  "--name=${BRAND_NAME}"
  "--domain=${PANEL_DOMAIN}"
  "--enforce-not-null"
)
if [[ -n "$MAX_RAM_MB" ]]; then INIT_ARGS+=("--max-ram-mb=${MAX_RAM_MB}"); fi
if [[ -n "$MAX_CPU_CORES" ]]; then INIT_ARGS+=("--max-cpu-cores=${MAX_CPU_CORES}"); fi
if [[ -n "$MAX_DISK_GB" ]]; then INIT_ARGS+=("--max-disk-gb=${MAX_DISK_GB}"); fi
if [[ -n "$MAX_VMS" ]]; then INIT_ARGS+=("--max-vms=${MAX_VMS}"); fi
php "$PANEL_DIR/artisan" "${INIT_ARGS[@]}"

php "$PANEL_DIR/artisan" tenancy:seed-default-catalog-plans --force || true

echo "[7/8] Enabling tenancy + master admin host in .env"
ENV_FILE="$PANEL_DIR/.env"
set_env_value "$ENV_FILE" "TENANCY_ENABLED" "true"
set_env_value "$ENV_FILE" "TENANCY_STRICT_HOST_MATCHING" "true"
set_env_value "$ENV_FILE" "TENANCY_MASTER_ADMIN_HOSTS" "$ADMIN_DOMAIN"
set_env_value "$ENV_FILE" "TENANCY_A_RECORD_TARGET" "$PUBLIC_IP"
set_env_value "$ENV_FILE" "QUEUE_CONNECTION" "redis"

php "$PANEL_DIR/artisan" optimize:clear
php "$PANEL_DIR/artisan" config:cache
php "$PANEL_DIR/artisan" horizon:terminate || true
php "$PANEL_DIR/artisan" queue:restart || true

echo "[8/8] Bringing panel back online"
php "$PANEL_DIR/artisan" up

cat <<EOF

Rollout completed.
Backup directory: $BACKUP_DIR

Next actions:
1) Point DNS:
   - ${PANEL_DOMAIN} -> ${PUBLIC_IP}
   - ${ADMIN_DOMAIN} -> ${PUBLIC_IP}
2) Verify login as legacy user and root admin.
3) Create test reseller and verify isolation.

If needed, rollback:
  bash scripts/ops/rollback-multitenant-live.sh \\
    --panel-dir "$PANEL_DIR" \\
    --db-host "$DB_HOST" --db-port "$DB_PORT" --db-name "$DB_NAME" \\
    --db-user "$DB_USER" --db-pass '***' \\
    --backup-dir "$BACKUP_DIR" \\
    --panel-domain "$PANEL_DOMAIN" --admin-domain "$ADMIN_DOMAIN"
EOF
