# WammuCore Proprietary Software License

Copyright (c) 2026 WammuHost. All rights reserved.

## 1. Ownership
WammuCore and all related source code, assets, branding, and documentation are the exclusive property of WammuHost.

## 2. License Grant
Subject to this license, WammuHost grants you a limited, non-exclusive, non-transferable, revocable license to install and use WammuCore for your own internal operations.

## 3. Restrictions
You may not, without prior written permission from WammuHost:

- Redistribute, resell, lease, sublicense, or publicly host this software for third parties.
- Publish source code or provide access to the source code to unauthorized parties.
- Remove or alter copyright, trademark, or ownership notices.
- Reverse engineer or bypass licensing, access control, or security mechanisms.

## 4. Modifications
You may modify this software only for your own internal use. Modified versions remain subject to this license and ownership terms.

## 5. No Warranty
This software is provided "AS IS", without warranties of any kind, express or implied, including merchantability, fitness for a particular purpose, and non-infringement.

## 6. Limitation of Liability
To the maximum extent permitted by law, WammuHost is not liable for any indirect, incidental, special, consequential, or punitive damages, or any loss of data, profit, revenue, or business interruption.

## 7. Termination
This license terminates automatically if you violate any term. Upon termination, you must stop using the software and delete all copies under your control.

## 8. Governing Terms
This file is the complete license governing WammuCore unless a separate written agreement signed by WammuHost explicitly states otherwise.

## 9. Contact
For licensing permissions, contact WammuHost.

