<?php

use WammuCore\Http\Controllers\Base;
use WammuCore\Http\Controllers\Auth\ResellerImpersonationController;
use Illuminate\Support\Facades\Route;

Route::get('/favicon.ico', [Base\IndexController::class, 'favicon'])->name('favicon');
Route::get('/apple-touch-icon.png', [Base\IndexController::class, 'favicon'])->name('apple-touch-icon');
Route::get('/apple-touch-icon-precomposed.png', [Base\IndexController::class, 'favicon'])->name('apple-touch-icon-precomposed');

Route::get('/', [Base\IndexController::class, 'index'])->name('index')->fallback();

Route::get('/locales/locale.json', Base\LocaleController::class)
    ->where('namespace', '.*');

Route::middleware(['auth', 'signed:relative'])->get(
    '/auth/impersonate-reseller/{resellerId}/{nonce}',
    [ResellerImpersonationController::class, 'consume'],
)->name('auth.reseller-impersonate.consume');

Route::get('/{any}', [Base\IndexController::class, 'index'])
    ->where('any', '^(?!(\/)?(api|authorize)).+');
