<?php

use Illuminate\Support\Facades\Route;
use WammuCore\Http\Controllers\Billing\PaymenterWebhookController;

Route::post('/paymenter/{publicKey}', PaymenterWebhookController::class)
    ->middleware('throttle:paymenter-webhooks')
    ->name('paymenter.webhook');
