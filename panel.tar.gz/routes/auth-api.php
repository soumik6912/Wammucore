<?php

use Illuminate\Support\Facades\Route;
use WammuCore\Http\Controllers\Client\AuthController;

Route::prefix('/api/client/auth')->middleware(['throttle:public-auth', 'public.shield:0.35'])->group(function () {
    Route::get('/meta', [AuthController::class, 'meta']);
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/login/email-2fa', [AuthController::class, 'verifyEmailTwoFactor']);
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/forgot-password', [AuthController::class, 'forgotPassword']);
    Route::post('/reset-password', [AuthController::class, 'resetPassword']);
    Route::post('/verify-email', [AuthController::class, 'verifyEmail']);
    Route::post('/verify-email/resend', [AuthController::class, 'resendEmailVerification']);
    Route::post('/refresh', [AuthController::class, 'refreshToken']);

    Route::middleware('auth')->group(function () {
        Route::get('/session', [AuthController::class, 'session']);
        Route::post('/logout', [AuthController::class, 'logout']);
    });
});
