<?php

use Illuminate\Support\Facades\Route;
use WammuCore\Http\Controllers\CentralApi\V1\DocumentationController;
use WammuCore\Http\Controllers\CentralApi\V1\DedicatedIpOrdersController;
use WammuCore\Http\Controllers\CentralApi\V1\DedicatedServicesController;
use WammuCore\Http\Controllers\CentralApi\V1\IpOrdersController;
use WammuCore\Http\Controllers\CentralApi\V1\PlansController;
use WammuCore\Http\Controllers\CentralApi\V1\PoolController;
use WammuCore\Http\Controllers\CentralApi\V1\ServicesController;
use WammuCore\Http\Controllers\CentralApi\V1\TemplatesController;
use WammuCore\Http\Controllers\CentralApi\V1\UsersController;

Route::get('/docs', [DocumentationController::class, 'markdown']);
Route::get('/openapi', [DocumentationController::class, 'openapi']);

Route::middleware([
    'central-api.https',
    'central-api.auth',
    'throttle:central-api',
    'central-api.audit',
])->group(function () {
    Route::prefix('/users')->group(function () {
        Route::get('/', [UsersController::class, 'index'])->middleware('central-api.scope:users.read');
        Route::post('/', [UsersController::class, 'store'])->middleware('central-api.scope:users.write');
        Route::get('/{id}', [UsersController::class, 'show'])->middleware('central-api.scope:users.read');
        Route::patch('/{id}', [UsersController::class, 'update'])->middleware('central-api.scope:users.write');
        Route::post('/{id}/sso', [UsersController::class, 'sso'])->middleware('central-api.scope:users.read');
    });

    Route::prefix('/services')->group(function () {
        Route::get('/', [ServicesController::class, 'index'])->middleware('central-api.scope:services.read');
        Route::post('/', [ServicesController::class, 'store'])->middleware('central-api.scope:services.write');
        Route::get('/{id}', [ServicesController::class, 'show'])->middleware('central-api.scope:services.read');
        Route::patch('/{id}', [ServicesController::class, 'update'])->middleware('central-api.scope:services.write');
        Route::get('/{id}/usage', [ServicesController::class, 'usage'])->middleware('central-api.scope:services.read');
        Route::delete('/{id}', [ServicesController::class, 'destroy'])->middleware('central-api.scope:services.write');
        Route::post('/{id}/start', [ServicesController::class, 'start'])->middleware('central-api.scope:services.write');
        Route::post('/{id}/stop', [ServicesController::class, 'stop'])->middleware('central-api.scope:services.write');
        Route::post('/{id}/restart', [ServicesController::class, 'restart'])->middleware('central-api.scope:services.write');
        Route::post('/{id}/unsuspend', [ServicesController::class, 'unsuspend'])->middleware('central-api.scope:services.write');
        Route::post('/{id}/reinstall', [ServicesController::class, 'reinstall'])->middleware('central-api.scope:services.write');
        Route::post('/{id}/vnc', [ServicesController::class, 'vnc'])->middleware('central-api.scope:services.read');
    });

    Route::prefix('/ip-orders')->group(function () {
        Route::post('/', [IpOrdersController::class, 'store'])->middleware('central-api.scope:services.write');
        Route::delete('/{id}', [IpOrdersController::class, 'destroy'])->middleware('central-api.scope:services.write');
    });

    Route::prefix('/dedicated-services')->group(function () {
        Route::get('/plans', [DedicatedServicesController::class, 'plans'])->middleware('central-api.scope:plans.read');
        Route::post('/', [DedicatedServicesController::class, 'store'])->middleware('central-api.scope:services.write');
        Route::get('/{id}', [DedicatedServicesController::class, 'show'])->middleware('central-api.scope:services.read');
    });

    Route::prefix('/dedicated-ip-orders')->group(function () {
        Route::post('/', [DedicatedIpOrdersController::class, 'store'])->middleware('central-api.scope:services.write');
    });

    Route::prefix('/plans')->group(function () {
        Route::get('/', [PlansController::class, 'index'])->middleware('central-api.scope:plans.read');
        Route::post('/', [PlansController::class, 'store'])->middleware('central-api.scope:plans.write');
        Route::patch('/{id}', [PlansController::class, 'update'])->middleware('central-api.scope:plans.write');
        Route::delete('/{id}', [PlansController::class, 'destroy'])->middleware('central-api.scope:plans.write');
    });

    Route::get('/pool', [PoolController::class, 'show'])->middleware('central-api.scope:pool.read');
    Route::get('/resources', [PoolController::class, 'resources'])->middleware('central-api.scope:pool.read');
    Route::get('/templates', [TemplatesController::class, 'index'])->middleware('central-api.scope:plans.read');
});
