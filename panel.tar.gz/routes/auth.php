<?php

use WammuCore\Http\Controllers\Auth;
use WammuCore\Http\Controllers\Auth\LoginController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Authentication Controller Routes
|--------------------------------------------------------------------------
|
| Endpoint: /auth
|
*/

Route::get('/authenticate', [LoginController::class, 'authorizeToken'])
    ->middleware('throttle:public-auth');

Route::get('/auth/return-admin/{token}', [LoginController::class, 'returnAdmin'])
    ->where('token', '[A-Za-z0-9]{40,120}')
    ->middleware('throttle:public-auth');

Route::get('/auth/csrf-token', function (Request $request) {
    return response()->json([
        'data' => [
            'csrf_token' => $request->session()->token(),
        ],
    ]);
})
    ->name('auth.csrf-token')
    ->middleware('throttle:public-auth');

Route::prefix('/auth/reseller/register')->group(function () {
    Route::get('/meta', [Auth\ResellerRegistrationController::class, 'meta'])
        ->middleware('throttle:public-auth');
    Route::post('/', [Auth\ResellerRegistrationController::class, 'store'])
        ->middleware(['guest', 'throttle:reseller-register', 'public.shield:0.35']);
});
