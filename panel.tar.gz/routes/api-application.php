<?php

use WammuCore\Http\Controllers\Admin;
use WammuCore\Http\Controllers\CentralApi\V1\DedicatedIpOrdersController;
use WammuCore\Http\Controllers\CentralApi\V1\DedicatedServicesController;
use WammuCore\Http\Middleware\Admin\Server\ValidateServerStatusMiddleware;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Location Controller Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/application/locations
|
*/
Route::prefix('/locations')->group(function () {
    Route::get('/', [Admin\LocationController::class, 'index']);
    Route::post('/', [Admin\LocationController::class, 'store']);

    Route::prefix('/{location}')->group(function () {
        Route::put('/', [Admin\LocationController::class, 'update']);
        Route::delete('/', [Admin\LocationController::class, 'destroy']);
    });
});

/*
|--------------------------------------------------------------------------
| Node Controller Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/application/nodes
|
*/
Route::prefix('/nodes')->group(function () {
    Route::get('/', [Admin\Nodes\NodeController::class, 'index']);
    Route::post('/', [Admin\Nodes\NodeController::class, 'store']);

    Route::prefix('/{node}')->group(function () {
        Route::get('/', [Admin\Nodes\NodeController::class, 'show']);
        Route::put('/', [Admin\Nodes\NodeController::class, 'update']);
        Route::delete('/', [Admin\Nodes\NodeController::class, 'destroy']);
        Route::post('/test-connection', [Admin\Nodes\NodeController::class, 'testConnection']);

        /*
        |--------------------------------------------------------------------------
        | Node ISOs Controller Routes
        |--------------------------------------------------------------------------
        |
        | Endpoint: /api/application/nodes/{node}/isos
        |
        */
        Route::apiResource('/isos', Admin\Nodes\IsoController::class)
             ->only(['index', 'store', 'update', 'destroy']);

        /*
        |--------------------------------------------------------------------------
        | Node Templates Controller Routes
        |--------------------------------------------------------------------------
        |
        | Endpoint: /api/application/nodes/{node}/template-groups
        |
        */
        Route::prefix('/template-groups')->group(function () {
            Route::get('/', [Admin\Nodes\TemplateGroupController::class, 'index']);
            Route::post('/', [Admin\Nodes\TemplateGroupController::class, 'store']);
            Route::post(
                '/reorder', [Admin\Nodes\TemplateGroupController::class, 'updateOrder'],
            );

            Route::prefix('/{template_group}')->group(function () {
                Route::put('/', [Admin\Nodes\TemplateGroupController::class, 'update']);
                Route::delete('/', [Admin\Nodes\TemplateGroupController::class, 'destroy']);
                Route::prefix('/templates')->group(function () {
                    Route::get('/', [Admin\Nodes\TemplateController::class, 'index']);
                    Route::post('/', [Admin\Nodes\TemplateController::class, 'store']);
                    Route::post(
                        '/reorder',
                        [Admin\Nodes\TemplateController::class, 'updateOrder'],
                    );

                    Route::get('/{template}', [Admin\Nodes\TemplateController::class, 'show']);
                    Route::delete('/{template}', [Admin\Nodes\TemplateController::class, 'destroy'],
                    );
                });

                Route::apiResource('templates', Admin\Nodes\TemplateController::class)
                     ->only(['index', 'store', 'update', 'destroy']);
            });
        });

        /*
        |--------------------------------------------------------------------------
        | Node Addresses Controller Routes
        |--------------------------------------------------------------------------
        |
        | Endpoint: /api/application/nodes/{node}/addresses
        |
        */
        Route::get('/addresses', [Admin\Nodes\AddressController::class, 'index']);

        /*
         |--------------------------------------------------------------------------
         | Node Helpers Routes
         |--------------------------------------------------------------------------
         */
        Route::get('/tools/query-remote-file', [Admin\Nodes\IsoController::class, 'queryLink']);
    });
});

/*
|--------------------------------------------------------------------------
| Server Controller Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/application/servers
|
*/
Route::prefix('/servers')->group(function () {
    Route::get('/', [Admin\ServerController::class, 'index']);
    Route::post('/', [Admin\ServerController::class, 'store']);

    Route::group(['prefix' => '/{server}', 'middleware' => ValidateServerStatusMiddleware::class],
        function () {
            Route::get('/', [Admin\ServerController::class, 'show'])->withoutMiddleware(
                ValidateServerStatusMiddleware::class,
            );
            Route::patch('/', [Admin\ServerController::class, 'update'])->withoutMiddleware(
                ValidateServerStatusMiddleware::class,
            );
            Route::delete('/', [Admin\ServerController::class, 'destroy']);
            Route::post('/create-console-session', [Admin\ServerController::class, 'createConsoleSession']);
            Route::post('/transfer', [Admin\ServerController::class, 'transfer']);
            Route::post('/fix-stuck', [Admin\ServerController::class, 'fixStuck']);
            Route::get('/management', [Admin\ServerController::class, 'management']);
            Route::post('/management/{action}', [Admin\ServerController::class, 'managementAction']);
            Route::get('/usage', [Admin\ServerController::class, 'usage']);

            Route::prefix('/settings')->group(function () {
                Route::patch('/build', [Admin\ServerController::class, 'updateBuild']);
                Route::get('/os-options', [Admin\ServerController::class, 'osOptions']);
                Route::post('/reinstall', [Admin\ServerController::class, 'reinstall']);

                Route::post('/suspend', [Admin\ServerController::class, 'suspend']);
                Route::post('/unsuspend', [Admin\ServerController::class, 'unsuspend']);
            });
        });
});

/*
|--------------------------------------------------------------------------
| Address Pool Controller Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/application/address-pools
|
*/
Route::prefix('/address-pools')->group(function () {
    Route::get('/', [Admin\AddressPools\AddressPoolController::class, 'index']);
    Route::post('/', [Admin\AddressPools\AddressPoolController::class, 'store']);

    Route::prefix('/{address_pool}')->group(function () {
        Route::get('/', [Admin\AddressPools\AddressPoolController::class, 'show']);
        Route::put('/', [Admin\AddressPools\AddressPoolController::class, 'update']);
        Route::delete('/', [Admin\AddressPools\AddressPoolController::class, 'destroy']);
        Route::get(
            '/attached-nodes',
            [Admin\AddressPools\AddressPoolController::class, 'getAttachedNodes'],
        );

        Route::prefix('/addresses')->group(function () {
            Route::get('/', [Admin\AddressPools\AddressController::class, 'index']);
            Route::post('/', [Admin\AddressPools\AddressController::class, 'store']);
            Route::delete('/', [Admin\AddressPools\AddressController::class, 'destroyMany']);
            Route::get('/export', [Admin\AddressPools\AddressController::class, 'export']);
            Route::post('/bulk-fetch-mac', [Admin\AddressPools\AddressController::class, 'bulkFetchMacs']);
            Route::post('/bulk-generate-random-mac', [Admin\AddressPools\AddressController::class, 'bulkGenerateRandomMacs']);
            Route::post('/bulk-fetch-or-generate-mac', [Admin\AddressPools\AddressController::class, 'bulkFetchOrGenerateMacs']);
            Route::post('/{address}/fetch-mac', [Admin\AddressPools\AddressController::class, 'fetchMacFromProxmox']);
            Route::post('/{address}/generate-random-mac', [Admin\AddressPools\AddressController::class, 'generateRandomMac']);
            Route::put('/{address}', [Admin\AddressPools\AddressController::class, 'update']);
            Route::delete('/{address}', [Admin\AddressPools\AddressController::class, 'destroy']);
        });
    });
});

/*
|--------------------------------------------------------------------------
| User Controller Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/application/users
|
*/

Route::pattern('user', '[0-9]+');
Route::get('/users/lookup-by-email', [Admin\UserController::class, 'lookupByEmail']);
Route::apiResource('users', Admin\UserController::class)
     ->only(['index', 'show', 'store', 'update', 'destroy']);
Route::post('/users/{user}/generate-sso-token', [Admin\UserController::class, 'getSSOToken']);

/*
|--------------------------------------------------------------------------
| Reseller Wholesale Resource Controller Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/application/reseller-market
|
*/
Route::prefix('/reseller-market')->group(function () {
    Route::get('/catalog', [Admin\ResellerResourceController::class, 'catalog']);
    Route::get('/plans', [Admin\ResellerResourceController::class, 'plans']);
    Route::get('/ip-pools', [Admin\ResellerResourceController::class, 'ipPools']);
    Route::get('/resellers/{resellerId}/resources', [Admin\ResellerResourceController::class, 'show']);
    Route::post('/purchases', [Admin\ResellerResourceController::class, 'purchase']);
    Route::post('/purchases/{paymenterServiceId}/suspend', [Admin\ResellerResourceController::class, 'suspend']);
    Route::post('/purchases/{paymenterServiceId}/unsuspend', [Admin\ResellerResourceController::class, 'unsuspend']);
    Route::delete('/purchases/{paymenterServiceId}', [Admin\ResellerResourceController::class, 'cancel']);
});

/*
|--------------------------------------------------------------------------
| Dedicated Server Billing Controller Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/application/dedicated-services
|
*/
Route::prefix('/dedicated-services')->group(function () {
    Route::get('/plans', [DedicatedServicesController::class, 'plans']);
    Route::post('/', [DedicatedServicesController::class, 'store']);
    Route::get('/{id}', [DedicatedServicesController::class, 'show']);
});

Route::prefix('/dedicated-ip-orders')->group(function () {
    Route::post('/', [DedicatedIpOrdersController::class, 'store']);
});

/*
|--------------------------------------------------------------------------
| Coterm Controller Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/application/coterms
|
*/

Route::prefix('/coterms')->group(function () {
    Route::get('/', [Admin\CotermController::class, 'index']);
    Route::post('/', [Admin\CotermController::class, 'store']);

    Route::prefix('/{coterm}')->group(function () {
        Route::get('/', [Admin\CotermController::class, 'show']);
        Route::put('/', [Admin\CotermController::class, 'update']);
        Route::post('/reset-coterm-token', [Admin\CotermController::class, 'resetCotermToken']);
        Route::delete('/', [Admin\CotermController::class, 'destroy']);
        Route::get('/nodes', [Admin\CotermController::class, 'getAttachedNodes']);
        Route::put('/nodes', [Admin\CotermController::class, 'updateAttachedNodes']);
    });
});
