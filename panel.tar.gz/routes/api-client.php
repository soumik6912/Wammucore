<?php

use WammuCore\Http\Controllers\Client;
use WammuCore\Http\Middleware\Activity\AccountSubject;
use WammuCore\Http\Middleware\Activity\ServerSubject;
use WammuCore\Http\Middleware\Client\Server\EnsureServerSecurityUnlocked;
use WammuCore\Http\Middleware\Client\Server\AuthenticateServerAccess;
use Illuminate\Support\Facades\Route;

Route::get('/servers', [Client\IndexController::class, 'index']);
Route::get('/store/plans', [Client\StoreController::class, 'index']);
Route::get('/dedicated', [Client\DedicatedController::class, 'index']);
Route::get('/dedicated/purchased-ips', [Client\DedicatedController::class, 'purchasedIps']);
Route::get('/dedicated/{serviceId}', [Client\DedicatedController::class, 'show']);
Route::post('/dedicated/{serviceId}/onboarding', [Client\DedicatedController::class, 'submitOnboarding']);
Route::put('/dedicated/{serviceId}/proxmox-api-token', [Client\DedicatedController::class, 'updateProxmoxApiToken']);
Route::get('/dedicated/{serviceId}/eligible-ip-pools', [Client\DedicatedController::class, 'eligibleIpPools']);
Route::post('/review-prompt/tick', [Client\ReviewPromptController::class, 'tick']);
Route::post('/review-prompt/complete', [Client\ReviewPromptController::class, 'complete']);

Route::prefix('/account')->middleware([AccountSubject::class])->group(function () {
    Route::get('/profile', [Client\AccountProfileController::class, 'show']);
    Route::get('/device-sessions', [Client\AccountProfileController::class, 'deviceSessions']);
    Route::delete('/device-sessions/{sessionId}', [Client\AccountProfileController::class, 'revokeDeviceSession']);
    Route::put('/password', [Client\AccountController::class, 'updatePassword']);
    Route::put('/panel-theme', [Client\AccountController::class, 'updatePanelTheme']);
});

Route::prefix('/servers/{server}')->middleware(
    [ServerSubject::class, AuthenticateServerAccess::class, EnsureServerSecurityUnlocked::class],
)->group(function () {
    Route::get('/', [Client\Servers\ServerController::class, 'index'])->name('servers.show');
    Route::get('/details', [Client\Servers\ServerController::class, 'details']);

    Route::get('/state', [Client\Servers\ServerController::class, 'getState']);
    Route::get('/install-progress', [Client\Servers\ServerController::class, 'installProgress']);
    Route::patch('/state', [Client\Servers\ServerController::class, 'updateState']);
    Route::get('/management', [Client\Servers\ServerController::class, 'management']);
    Route::post('/management/{action}', [Client\Servers\ServerController::class, 'managementAction']);
    Route::post('/security/ddos-lock/acknowledge', [Client\Servers\ServerController::class, 'acknowledgeSecurityLock']);
    Route::get('/usage', [Client\Servers\ServerController::class, 'usage']);
    Route::get('/actions', [Client\Servers\ServerController::class, 'actions']);
    Route::get('/activity', Client\Servers\ActivityController::class);

    Route::post(
        '/create-console-session', [Client\Servers\ServerController::class, 'createConsoleSession'],
    );

    Route::prefix('/backups')->group(function () {
        Route::get('/', [Client\Servers\BackupController::class, 'index']);
        Route::post('/', [Client\Servers\BackupController::class, 'store']);
        Route::post('/{backup}/restore', [Client\Servers\BackupController::class, 'restore']);
        Route::delete('/{backup}', [Client\Servers\BackupController::class, 'destroy']);
        Route::get('/snapshots', [Client\Servers\BackupController::class, 'snapshots']);
        Route::post('/snapshots', [Client\Servers\BackupController::class, 'storeSnapshot']);
        Route::post('/snapshots/{snapshot}/restore', [Client\Servers\BackupController::class, 'restoreSnapshot']);
        Route::delete('/snapshots/{snapshot}', [Client\Servers\BackupController::class, 'destroySnapshot']);
    });

    Route::prefix('/settings')->group(function () {
        Route::post('/rename', [Client\Servers\SettingsController::class, 'rename']);
        Route::get(
            '/template-groups', [Client\Servers\SettingsController::class, 'getTemplateGroups'],
        );
        Route::get('/os-options', [Client\Servers\SettingsController::class, 'osOptions']);
        Route::get('/windows-provisioning-script', [Client\Servers\SettingsController::class, 'windowsProvisioningScript']);
        Route::post('/reinstall', [Client\Servers\SettingsController::class, 'reinstall']);

        Route::get(
            '/hardware/boot-order', [Client\Servers\SettingsController::class, 'getBootOrder'],
        );
        Route::put(
            '/hardware/boot-order', [Client\Servers\SettingsController::class, 'updateBootOrder'],
        );

        Route::get('/hardware/isos', [Client\Servers\SettingsController::class, 'getMedia']);
        Route::post(
            '/hardware/isos/{iso}/mount', [Client\Servers\SettingsController::class, 'mountMedia'],
        )->withoutScopedBindings();
        Route::post(
            '/hardware/isos/{iso}/unmount',
            [Client\Servers\SettingsController::class, 'unmountMedia'],
        )->withoutScopedBindings();

        Route::get('/network', [Client\Servers\SettingsController::class, 'getNetworkSettings']);
        Route::put('/network', [Client\Servers\SettingsController::class, 'updateNetworkSettings']);

        Route::get('/auth', [Client\Servers\SettingsController::class, 'getAuthSettings']);
        Route::put('/auth', [Client\Servers\SettingsController::class, 'updateAuthSettings']);

        Route::get('/docker', [Client\Servers\SettingsController::class, 'getDockerStatus']);
        Route::post('/docker/install', [Client\Servers\SettingsController::class, 'installDockerManager']);
        Route::post('/docker/uninstall', [Client\Servers\SettingsController::class, 'uninstallDockerManager']);
        Route::post('/docker/service/{action}', [Client\Servers\SettingsController::class, 'dockerServiceAction']);
        Route::post('/docker/containers/{container}/{action}', [Client\Servers\SettingsController::class, 'dockerContainerAction']);

        Route::post('/system/reset-firewall', [Client\Servers\SettingsController::class, 'resetFirewallConfiguration']);
        Route::post('/system/reset-ssh', [Client\Servers\SettingsController::class, 'resetSshConfiguration']);
        Route::post('/system/cleanup-logs', [Client\Servers\SettingsController::class, 'cleanupLogs']);

        Route::get('/security/malware', [Client\Servers\SettingsController::class, 'getMalwareStatus']);
        Route::post('/security/malware/install', [Client\Servers\SettingsController::class, 'installMalware']);
        Route::post('/security/malware/uninstall', [Client\Servers\SettingsController::class, 'uninstallMalware']);
        Route::post('/security/malware/scan', [Client\Servers\SettingsController::class, 'runMalwareScan']);

        Route::get('/security/firewall', [Client\Servers\SettingsController::class, 'getFirewallStatus']);
        Route::put('/security/firewall', [Client\Servers\SettingsController::class, 'updateFirewallStatus']);
        Route::post('/security/firewall/rules', [Client\Servers\SettingsController::class, 'addFirewallRule']);
        Route::delete('/security/firewall/rules', [Client\Servers\SettingsController::class, 'deleteFirewallRule']);

    });
});
