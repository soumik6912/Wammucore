<?php

use WammuCore\Http\Controllers\Admin;
use WammuCore\Http\Middleware\Admin\Server\ValidateServerStatusMiddleware;
use WammuCore\Http\Middleware\Admin\RequireMasterAdminView;
use WammuCore\Http\Middleware\Admin\RequireRootAdminOnly;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Root Admin Security Gate Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/admin/root-admin-security
|
*/
Route::prefix('/root-admin-security')
    ->middleware([RequireRootAdminOnly::class])
    ->as('root-admin-security.')
    ->group(function () {
        Route::get('/status', [Admin\RootAdminSecurityGateController::class, 'status'])
            ->name('status');
        Route::post('/verify', [Admin\RootAdminSecurityGateController::class, 'verify'])
            ->name('verify');
        Route::post('/revoke', [Admin\RootAdminSecurityGateController::class, 'revoke'])
            ->name('revoke');
        Route::get('/two-factor', [Admin\RootAdminSecurityGateController::class, 'twoFactorStatus'])
            ->name('two-factor.status');
        Route::post('/two-factor/setup', [Admin\RootAdminSecurityGateController::class, 'beginTwoFactorSetup'])
            ->name('two-factor.setup');
        Route::post('/two-factor/confirm', [Admin\RootAdminSecurityGateController::class, 'confirmTwoFactor'])
            ->name('two-factor.confirm');
        Route::post('/two-factor/recovery-codes', [Admin\RootAdminSecurityGateController::class, 'regenerateRecoveryCodes'])
            ->name('two-factor.recovery-codes');
        Route::delete('/two-factor', [Admin\RootAdminSecurityGateController::class, 'disableTwoFactor'])
            ->name('two-factor.disable');
    });

/*
|--------------------------------------------------------------------------
| Root Control Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/admin/root-control
|
*/
Route::prefix('/root-control')->middleware([RequireMasterAdminView::class])->group(function () {
    Route::get('/overview', [Admin\RootAdminControlController::class, 'overview']);
    Route::get('/logs', [Admin\RootAdminControlController::class, 'logs'])
        ->middleware([RequireRootAdminOnly::class]);
    Route::get('/audit-logs', [Admin\RootAdminControlController::class, 'auditLogs']);
    Route::get('/activity', [Admin\RootAdminControlController::class, 'activity']);
    Route::get('/ip-logs', [Admin\RootAdminControlController::class, 'ipLogs']);
    Route::get('/alerts', [Admin\RootAdminControlController::class, 'alerts']);
    Route::patch('/alerts/{alert}/acknowledge', [Admin\RootAdminControlController::class, 'acknowledgeAlert']);
    Route::get('/permissions', [Admin\RootAdminControlController::class, 'permissions']);
    Route::get('/roles', [Admin\RootAdminControlController::class, 'roles']);
    Route::post('/roles', [Admin\RootAdminControlController::class, 'storeRole']);
    Route::put('/roles/{role}', [Admin\RootAdminControlController::class, 'updateRole']);
    Route::delete('/roles/{role}', [Admin\RootAdminControlController::class, 'destroyRole']);
    Route::get('/staff', [Admin\RootAdminControlController::class, 'staff']);
    Route::put('/staff/{user}/roles', [Admin\RootAdminControlController::class, 'syncUserRoles']);
    Route::get('/billing/paymenter', [Admin\PaymenterIntegrationController::class, 'overview']);
    Route::get('/billing/paymenter/logs', [Admin\PaymenterIntegrationController::class, 'logs']);
    Route::patch('/billing/paymenter/{integrationId}', [Admin\PaymenterIntegrationController::class, 'updateOverride']);
});

/*
|--------------------------------------------------------------------------
| Location Controller Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/admin/locations
|
*/
Route::prefix('/locations')->middleware([RequireMasterAdminView::class])->group(function () {
    Route::get('/', [Admin\LocationController::class, 'index']);
    Route::post('/', [Admin\LocationController::class, 'store']);

    Route::prefix('/{location}')->group(function () {
        Route::put('/', [Admin\LocationController::class, 'update']);
        Route::delete('/', [Admin\LocationController::class, 'destroy']);
    });
});

/*
|--------------------------------------------------------------------------
| Node Controller Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/admin/nodes
|
*/
Route::prefix('/nodes')->middleware([RequireMasterAdminView::class])->group(function () {
    Route::get('/', [Admin\Nodes\NodeController::class, 'index']);
    Route::post('/', [Admin\Nodes\NodeController::class, 'store']);

    Route::prefix('/{node}')->group(function () {
        Route::get('/', [Admin\Nodes\NodeController::class, 'show']);
        Route::put('/', [Admin\Nodes\NodeController::class, 'update']);
        Route::delete('/', [Admin\Nodes\NodeController::class, 'destroy']);
        Route::post('/test-connection', [Admin\Nodes\NodeController::class, 'testConnection']);

        /*
        |--------------------------------------------------------------------------
        | Node ISOs Controller Routes
        |--------------------------------------------------------------------------
        |
        | Endpoint: /api/admin/nodes/{node}/isos
        |
        */
        Route::resource('/isos', Admin\Nodes\IsoController::class)
             ->only(['index', 'store', 'update', 'destroy']);

        /*
        |--------------------------------------------------------------------------
        | Node Templates Controller Routes
        |--------------------------------------------------------------------------
        |
        | Endpoint: /api/admin/nodes/{node}/template-groups
        |
        */
        Route::prefix('/template-groups')->group(function () {
            Route::get('/', [Admin\Nodes\TemplateGroupController::class, 'index']);
            Route::post('/', [Admin\Nodes\TemplateGroupController::class, 'store']);
            Route::post(
                '/reorder', [Admin\Nodes\TemplateGroupController::class, 'updateOrder'],
            );

            Route::prefix('/{template_group}')->group(function () {
                Route::put('/', [Admin\Nodes\TemplateGroupController::class, 'update']);
                Route::delete('/', [Admin\Nodes\TemplateGroupController::class, 'destroy']);
                Route::prefix('/templates')->group(function () {
                    Route::get('/', [Admin\Nodes\TemplateController::class, 'index']);
                    Route::post('/', [Admin\Nodes\TemplateController::class, 'store']);
                    Route::post(
                        '/reorder',
                        [Admin\Nodes\TemplateController::class, 'updateOrder'],
                    );

                    Route::get('/{template}', [Admin\Nodes\TemplateController::class, 'show']);
                    Route::delete('/{template}', [Admin\Nodes\TemplateController::class, 'destroy'],
                    );
                });

                Route::resource('templates', Admin\Nodes\TemplateController::class)
                     ->only(['index', 'store', 'update', 'destroy']);
            });
        });

        /*
        |--------------------------------------------------------------------------
        | Node Addresses Controller Routes
        |--------------------------------------------------------------------------
        |
        | Endpoint: /api/admin/nodes/{node}/addresses
        |
        */
        Route::get('/addresses', [Admin\Nodes\AddressController::class, 'index']);
        Route::get('/resources', [Admin\Nodes\NodeController::class, 'resources']);

        /*
         |--------------------------------------------------------------------------
         | Node Helpers Routes
         |--------------------------------------------------------------------------
         */
        Route::get('/tools/query-remote-file', [Admin\Nodes\IsoController::class, 'queryLink']);
    });
});

/*
|--------------------------------------------------------------------------
| Server Controller Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/admin/servers
|
*/
Route::prefix('/servers')->middleware([RequireMasterAdminView::class])->group(function () {
    Route::get('/', [Admin\ServerController::class, 'index']);
    Route::post('/', [Admin\ServerController::class, 'store']);

    Route::group(['prefix' => '/{server}', 'middleware' => ValidateServerStatusMiddleware::class],
        function () {
            Route::get('/', [Admin\ServerController::class, 'show'])->withoutMiddleware(
                ValidateServerStatusMiddleware::class,
            );
            Route::patch('/', [Admin\ServerController::class, 'update'])->withoutMiddleware(
                ValidateServerStatusMiddleware::class,
            );
            Route::delete('/', [Admin\ServerController::class, 'destroy']);
            Route::post('/create-console-session', [Admin\ServerController::class, 'createConsoleSession']);
            Route::post('/transfer', [Admin\ServerController::class, 'transfer']);
            Route::post('/fix-stuck', [Admin\ServerController::class, 'fixStuck']);
            Route::get('/management', [Admin\ServerController::class, 'management']);
            Route::get('/activity', [Admin\ServerController::class, 'activity'])->withoutMiddleware(
                ValidateServerStatusMiddleware::class,
            );
            Route::post('/management/{action}', [Admin\ServerController::class, 'managementAction']);

            Route::prefix('/settings')->group(function () {
                Route::patch('/build', [Admin\ServerController::class, 'updateBuild']);
                Route::get('/os-options', [Admin\ServerController::class, 'osOptions']);
                Route::post('/reinstall', [Admin\ServerController::class, 'reinstall']);

                Route::post('/suspend', [Admin\ServerController::class, 'suspend']);
                Route::post('/unsuspend', [Admin\ServerController::class, 'unsuspend']);
            });
        });
});

/*
|--------------------------------------------------------------------------
| Dedicated Services Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/admin/dedicated
|
*/
Route::prefix('/dedicated')->middleware([RequireMasterAdminView::class])->group(function () {
    Route::get('/services', [Admin\DedicatedController::class, 'services']);
    Route::get('/services/{serviceId}', [Admin\DedicatedController::class, 'service']);
    Route::get('/plans', [Admin\DedicatedController::class, 'plans']);
    Route::post('/plans', [Admin\DedicatedController::class, 'storePlan']);
    Route::put('/plans/{planId}', [Admin\DedicatedController::class, 'updatePlan']);
    Route::delete('/plans/{planId}', [Admin\DedicatedController::class, 'destroyPlan']);
    Route::get('/inventory', [Admin\DedicatedController::class, 'inventory']);
    Route::post('/inventory', [Admin\DedicatedController::class, 'storeInventory']);
    Route::put('/inventory/{inventoryId}', [Admin\DedicatedController::class, 'updateInventory']);
    Route::get('/requests', [Admin\DedicatedController::class, 'provisioningRequests']);
    Route::get('/provisioning-requests', [Admin\DedicatedController::class, 'provisioningRequests']);
    Route::post('/provisioning-requests/{requestId}/complete', [Admin\DedicatedController::class, 'completeProvisioning']);
    Route::post('/services/{serviceId}/credentials/{type}/reveal', [Admin\DedicatedController::class, 'revealCredential']);
    Route::get('/ip-requests', [Admin\DedicatedController::class, 'ipRequests']);
    Route::post('/ip-requests/{requestId}/allocate', [Admin\DedicatedController::class, 'allocateIps']);
});

/*
|--------------------------------------------------------------------------
| Address Pool Controller Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/admin/address-pools
|
*/
Route::prefix('/address-pools')->middleware([RequireMasterAdminView::class])->group(function () {
    Route::get('/', [Admin\AddressPools\AddressPoolController::class, 'index']);
    Route::post('/', [Admin\AddressPools\AddressPoolController::class, 'store']);

    Route::prefix('/{address_pool}')->group(function () {
        Route::get('/', [Admin\AddressPools\AddressPoolController::class, 'show']);
        Route::put('/', [Admin\AddressPools\AddressPoolController::class, 'update']);
        Route::delete('/', [Admin\AddressPools\AddressPoolController::class, 'destroy']);
        Route::get(
            '/attached-nodes',
            [Admin\AddressPools\AddressPoolController::class, 'getAttachedNodes'],
        );

        Route::prefix('/addresses')->group(function () {
            Route::get('/', [Admin\AddressPools\AddressController::class, 'index']);
            Route::post('/', [Admin\AddressPools\AddressController::class, 'store']);
            Route::delete('/', [Admin\AddressPools\AddressController::class, 'destroyMany']);
            Route::get('/export', [Admin\AddressPools\AddressController::class, 'export']);
            Route::post('/bulk-fetch-mac', [Admin\AddressPools\AddressController::class, 'bulkFetchMacs']);
            Route::post('/bulk-generate-random-mac', [Admin\AddressPools\AddressController::class, 'bulkGenerateRandomMacs']);
            Route::post('/bulk-fetch-or-generate-mac', [Admin\AddressPools\AddressController::class, 'bulkFetchOrGenerateMacs']);
            Route::post('/{address}/fetch-mac', [Admin\AddressPools\AddressController::class, 'fetchMacFromProxmox']);
            Route::post('/{address}/generate-random-mac', [Admin\AddressPools\AddressController::class, 'generateRandomMac']);
            Route::put('/{address}', [Admin\AddressPools\AddressController::class, 'update']);
            Route::delete('/{address}', [Admin\AddressPools\AddressController::class, 'destroy']);
        });
    });
});

/*
|--------------------------------------------------------------------------
| User Controller Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/admin/users
|
*/
Route::pattern('user', '[0-9]+');
Route::post('/users/{user}/sso-link', [Admin\UserController::class, 'getSSOToken'])
    ->middleware([RequireMasterAdminView::class]);
Route::get('/users/lookup-by-email', [Admin\UserController::class, 'lookupByEmail'])
    ->middleware([RequireMasterAdminView::class]);

Route::resource('users', Admin\UserController::class)
     ->middleware([RequireMasterAdminView::class])
     ->only(['index', 'show', 'store', 'update', 'destroy']);

/*
|--------------------------------------------------------------------------
| Reseller Controller Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/admin/resellers
|
*/
Route::prefix('/resellers')->middleware([RequireMasterAdminView::class])->group(function () {
    Route::get('/', [Admin\ResellerController::class, 'index']);
    Route::get('/verification-summary', [Admin\ResellerController::class, 'verificationSummary'])
        ->middleware([RequireMasterAdminView::class]);
    Route::get('/verification-queue', [Admin\ResellerController::class, 'verificationQueue'])
        ->middleware([RequireMasterAdminView::class]);
    Route::post('/', [Admin\ResellerController::class, 'store'])
        ->middleware([RequireMasterAdminView::class]);
    Route::get('/registration/status', [Admin\ResellerController::class, 'registrationStatus'])
        ->middleware([RequireMasterAdminView::class]);
    Route::post('/register', [Admin\ResellerController::class, 'registerViaPublicApi'])
        ->middleware([RequireMasterAdminView::class]);

    Route::prefix('/{resellerId}')->group(function () {
        Route::get('/', [Admin\ResellerController::class, 'show']);
        Route::put('/', [Admin\ResellerController::class, 'update']);
        Route::get('/onboarding', [Admin\ResellerController::class, 'onboarding'])
            ->middleware([RequireMasterAdminView::class]);
        Route::post('/approve', [Admin\ResellerController::class, 'approve'])
            ->middleware([RequireMasterAdminView::class]);
        Route::get('/verification', [Admin\ResellerController::class, 'verification'])
            ->middleware([RequireMasterAdminView::class]);
        Route::put('/owner-profile', [Admin\ResellerController::class, 'updateOwnerProfile'])
            ->middleware([RequireMasterAdminView::class]);
        Route::post('/verification/approve', [Admin\ResellerController::class, 'approveVerification'])
            ->middleware([RequireMasterAdminView::class]);
        Route::post('/verification/reject', [Admin\ResellerController::class, 'rejectVerification'])
            ->middleware([RequireMasterAdminView::class]);
        Route::post('/verification/request-reverification', [Admin\ResellerController::class, 'requestReverification'])
            ->middleware([RequireMasterAdminView::class]);
        Route::post('/verification/reveal-aadhaar', [Admin\ResellerController::class, 'revealVerificationAadhaar'])
            ->middleware([RequireMasterAdminView::class]);
        Route::get('/verification/documents/{documentType}', [Admin\ResellerController::class, 'verificationDocument'])
            ->middleware([RequireMasterAdminView::class, 'signed'])
            ->name('resellers.verification.document');
        Route::post('/onboarding/manual-override', [Admin\ResellerController::class, 'manualOverride'])
            ->middleware([RequireMasterAdminView::class]);
        Route::post('/onboarding/suspend', [Admin\ResellerController::class, 'suspendOnboarding'])
            ->middleware([RequireMasterAdminView::class]);
        Route::post('/suspend', [Admin\ResellerController::class, 'suspend'])
            ->middleware([RequireMasterAdminView::class]);
        Route::get('/pool', [Admin\ResellerController::class, 'pool'])
            ->middleware([RequireMasterAdminView::class]);
        Route::put('/pool', [Admin\ResellerController::class, 'updatePool'])
            ->middleware([RequireMasterAdminView::class]);
        Route::post('/usage/refresh', [Admin\ResellerController::class, 'refreshUsage'])
            ->middleware([RequireMasterAdminView::class]);
        Route::post('/impersonation-link', [Admin\ResellerController::class, 'impersonationLink'])
            ->middleware([RequireMasterAdminView::class]);
        Route::delete('/', [Admin\ResellerController::class, 'destroy'])
            ->middleware([RequireMasterAdminView::class]);
    });
});

Route::prefix('/resellers/onboarding')->middleware([RequireMasterAdminView::class])->group(function () {
    Route::get('/meta', [Admin\ResellerOnboardingController::class, 'meta']);
    Route::post('/', [Admin\ResellerOnboardingController::class, 'store']);
    Route::post('/register', [Admin\ResellerOnboardingController::class, 'register']);
});

/*
|--------------------------------------------------------------------------
| Plan Catalog Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/admin/plan-catalog
|
*/
Route::prefix('/plan-catalog')->middleware([RequireMasterAdminView::class])->group(function () {
    Route::get('/', [Admin\CatalogPlanController::class, 'index']);
    Route::post('/', [Admin\CatalogPlanController::class, 'store'])
        ->middleware([RequireMasterAdminView::class]);
    Route::put('/{catalogPlanId}', [Admin\CatalogPlanController::class, 'update'])
        ->middleware([RequireMasterAdminView::class]);
    Route::delete('/{catalogPlanId}', [Admin\CatalogPlanController::class, 'destroy'])
        ->middleware([RequireMasterAdminView::class]);
});

/*
|--------------------------------------------------------------------------
| Reseller Plan Pricing Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/admin/reseller-plans
|
*/
Route::prefix('/reseller-plans')->middleware([RequireMasterAdminView::class])->group(function () {
    Route::get('/', [Admin\ResellerPlanPricingController::class, 'index']);
    Route::put('/{catalogPlanId}', [Admin\ResellerPlanPricingController::class, 'update']);
});

/*
|--------------------------------------------------------------------------
| Reseller Panel Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/admin/reseller-panel
|
*/
Route::prefix('/reseller-panel')->group(function () {
    Route::get('/overview', [Admin\ResellerPanel\ResellerOverviewController::class, '__invoke']);
    Route::get('/onboarding', [Admin\ResellerPanel\ResellerOnboardingController::class, 'show']);
    Route::post('/onboarding/email-verification/resend', [Admin\ResellerPanel\ResellerOnboardingController::class, 'resendEmailVerification']);
    Route::post('/onboarding/personal-details', [Admin\ResellerPanel\ResellerOnboardingController::class, 'submitPersonalDetails']);
    Route::post('/onboarding/kyc', [Admin\ResellerPanel\ResellerOnboardingController::class, 'submitKyc']);
    Route::patch('/onboarding/branding', [Admin\ResellerPanel\ResellerOnboardingController::class, 'saveBranding']);
    Route::patch('/onboarding/domains', [Admin\ResellerPanel\ResellerOnboardingController::class, 'saveDomains']);
    Route::post('/onboarding/dns/verify', [Admin\ResellerPanel\ResellerOnboardingController::class, 'verifyDns']);
    Route::post('/onboarding/ssl/request', [Admin\ResellerPanel\ResellerOnboardingController::class, 'requestSslProvisioning']);
    Route::post('/verification', [Admin\ResellerPanel\ResellerVerificationController::class, 'store']);
    Route::get('/settings', [Admin\ResellerPanel\ResellerSettingsController::class, 'show']);
    Route::patch('/settings', [Admin\ResellerPanel\ResellerSettingsController::class, 'update']);
    Route::post('/settings/domains', [Admin\ResellerPanel\ResellerSettingsController::class, 'storeDomain']);
    Route::post('/settings/domains/sync', [Admin\ResellerPanel\ResellerSettingsController::class, 'syncDomains']);
    Route::put('/settings/domains/{domainId}', [Admin\ResellerPanel\ResellerSettingsController::class, 'updateDomain']);
    Route::post('/settings/domains/{domainId}/verify', [Admin\ResellerPanel\ResellerSettingsController::class, 'verifyDomain']);
    Route::post('/settings/domains/{domainId}/regenerate-token', [Admin\ResellerPanel\ResellerSettingsController::class, 'regenerateDomainToken']);
    Route::delete('/settings/domains/{domainId}', [Admin\ResellerPanel\ResellerSettingsController::class, 'destroyDomain']);

    Route::prefix('/users')->group(function () {
        Route::get('/', [Admin\ResellerPanel\ResellerUserController::class, 'index']);
        Route::post('/', [Admin\ResellerPanel\ResellerUserController::class, 'store']);
        Route::get('/{userId}', [Admin\ResellerPanel\ResellerUserController::class, 'show']);
        Route::put('/{userId}', [Admin\ResellerPanel\ResellerUserController::class, 'update']);
        Route::delete('/{userId}', [Admin\ResellerPanel\ResellerUserController::class, 'destroy']);
        Route::post('/{userId}/reset-password', [Admin\ResellerPanel\ResellerUserController::class, 'resetPassword']);
        Route::get('/{userId}/services', [Admin\ResellerPanel\ResellerUserController::class, 'services']);
    });

    Route::prefix('/services')->group(function () {
        Route::get('/', [Admin\ResellerPanel\ResellerServiceController::class, 'index']);
        Route::get('/{serverId}', [Admin\ResellerPanel\ResellerServiceController::class, 'show']);
        Route::post('/{serverId}/power/{action}', [Admin\ResellerPanel\ResellerServiceController::class, 'power']);
        Route::post('/{serverId}/suspend', [Admin\ResellerPanel\ResellerServiceController::class, 'suspend']);
        Route::post('/{serverId}/unsuspend', [Admin\ResellerPanel\ResellerServiceController::class, 'unsuspend']);
        Route::post('/{serverId}/reassign', [Admin\ResellerPanel\ResellerServiceController::class, 'reassign']);
        Route::post('/{serverId}/reinstall', [Admin\ResellerPanel\ResellerServiceController::class, 'reinstall']);
        Route::post('/{serverId}/vnc', [Admin\ResellerPanel\ResellerServiceController::class, 'vnc']);
    });

    Route::prefix('/dedicated-hardware')->group(function () {
        Route::get('/', [Admin\ResellerPanel\ResellerDedicatedHardwareController::class, 'index']);
        Route::post('/', [Admin\ResellerPanel\ResellerDedicatedHardwareController::class, 'store']);
        Route::patch('/plans', [Admin\ResellerPanel\ResellerDedicatedHardwareController::class, 'updatePlans']);
        Route::patch('/{hardwareId}', [Admin\ResellerPanel\ResellerDedicatedHardwareController::class, 'update']);
        Route::post('/{hardwareId}/configure-node', [Admin\ResellerPanel\ResellerDedicatedHardwareController::class, 'configureNode']);
    });

    Route::get('/ipam', [Admin\ResellerPanel\ResellerIpamController::class, 'index']);

    Route::prefix('/resources')->group(function () {
        Route::get('/', [Admin\ResellerPanel\ResellerResourceController::class, 'index']);
        Route::get('/catalog', [Admin\ResellerPanel\ResellerResourceController::class, 'catalog']);
    });

    Route::prefix('/plans')->group(function () {
        Route::get('/', [Admin\ResellerPanel\ResellerPlanController::class, 'index']);
        Route::post('/', [Admin\ResellerPanel\ResellerPlanController::class, 'store']);
        Route::put('/{planId}', [Admin\ResellerPanel\ResellerPlanController::class, 'update']);
        Route::delete('/{planId}', [Admin\ResellerPanel\ResellerPlanController::class, 'destroy']);
        Route::get('/catalog/default', [Admin\ResellerPanel\ResellerPlanController::class, 'catalog']);
    });

    Route::prefix('/sub-resellers')->group(function () {
        Route::get('/', [Admin\ResellerPanel\ResellerSubResellerController::class, 'index']);
        Route::post('/', [Admin\ResellerPanel\ResellerSubResellerController::class, 'store']);
        Route::put('/{subResellerId}', [Admin\ResellerPanel\ResellerSubResellerController::class, 'update']);
        Route::delete('/{subResellerId}', [Admin\ResellerPanel\ResellerSubResellerController::class, 'destroy']);
    });

    Route::prefix('/api-keys')->group(function () {
        Route::get('/', [Admin\ResellerPanel\ResellerApiCredentialController::class, 'index']);
        Route::post('/', [Admin\ResellerPanel\ResellerApiCredentialController::class, 'store']);
        Route::post('/{credentialId}/revoke', [Admin\ResellerPanel\ResellerApiCredentialController::class, 'revoke']);
    });

    Route::prefix('/orders')->group(function () {
        Route::get('/', [Admin\ResellerPanel\ResellerOrderController::class, 'index']);
        Route::get('/export.csv', [Admin\ResellerPanel\ResellerOrderController::class, 'exportCsv']);
        Route::patch('/manual-settings', [Admin\ResellerPanel\ResellerOrderController::class, 'updateManualSettings']);
        Route::post('/manual', [Admin\ResellerPanel\ResellerOrderController::class, 'storeManual']);
        Route::post('/{orderId}/mark-paid', [Admin\ResellerPanel\ResellerOrderController::class, 'markPaid']);
        Route::post('/{orderId}/suspend', [Admin\ResellerPanel\ResellerOrderController::class, 'suspend']);
        Route::post('/{orderId}/unsuspend', [Admin\ResellerPanel\ResellerOrderController::class, 'unsuspend']);
        Route::post('/{orderId}/cancel', [Admin\ResellerPanel\ResellerOrderController::class, 'cancel']);
    });

    Route::prefix('/tickets')->group(function () {
        Route::get('/', [Admin\ResellerPanel\ResellerTicketController::class, 'index']);
        Route::post('/', [Admin\ResellerPanel\ResellerTicketController::class, 'store']);
        Route::get('/{ticketId}', [Admin\ResellerPanel\ResellerTicketController::class, 'show']);
        Route::patch('/{ticketId}', [Admin\ResellerPanel\ResellerTicketController::class, 'update']);
        Route::post('/{ticketId}/reply', [Admin\ResellerPanel\ResellerTicketController::class, 'reply']);
    });

    Route::get('/alerts', [Admin\ResellerPanel\ResellerAlertController::class, 'index']);
    Route::get('/logs', [Admin\ResellerPanel\ResellerLogController::class, '__invoke']);
    Route::get('/statistics', [Admin\ResellerPanel\ResellerStatisticsController::class, '__invoke']);
});

/*
|--------------------------------------------------------------------------
| Coterm Controller Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/admin/coterms
|
*/

Route::prefix('/coterms')->middleware([RequireMasterAdminView::class])->group(function () {
    Route::get('/', [Admin\CotermController::class, 'index']);
    Route::post('/', [Admin\CotermController::class, 'store']);

    Route::prefix('/{coterm}')->group(function () {
        Route::get('/', [Admin\CotermController::class, 'show']);
        Route::put('/', [Admin\CotermController::class, 'update']);
        Route::post('/reset-coterm-token', [Admin\CotermController::class, 'resetCotermToken']);
        Route::delete('/', [Admin\CotermController::class, 'destroy']);
        Route::get('/nodes', [Admin\CotermController::class, 'getAttachedNodes']);
        Route::put('/nodes', [Admin\CotermController::class, 'updateAttachedNodes']);
    });
});

/*
|--------------------------------------------------------------------------
| API Token Controller Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/admin/tokens
|
*/
Route::resource('tokens', Admin\TokenController::class)
     ->middleware([RequireMasterAdminView::class])
     ->only(['index', 'store', 'destroy']);

/*
|--------------------------------------------------------------------------
| Panel Settings Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/admin/settings/panel
|
*/
Route::prefix('/settings')->middleware([RequireMasterAdminView::class])->group(function () {
    Route::get('/panel', [Admin\PanelSettingsController::class, 'show']);
    Route::patch('/panel', [Admin\PanelSettingsController::class, 'update']);
    Route::post('/panel/test-mail', [Admin\PanelSettingsController::class, 'sendTestMail']);
});

/*
|--------------------------------------------------------------------------
| Tenancy Context Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/admin/tenancy
|
*/
Route::prefix('/tenancy')->group(function () {
    Route::get('/context', [Admin\TenancyController::class, 'context']);
    Route::patch('/context', [Admin\TenancyController::class, 'updateContext']);
});

/*
|--------------------------------------------------------------------------
| Security Engine Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/admin/security
|
*/
Route::prefix('/security')->middleware([RequireMasterAdminView::class])->group(function () {
    Route::get('/overview', [Admin\SecurityController::class, 'overview']);
    Route::get('/settings', [Admin\SecurityController::class, 'settings'])
        ->middleware([RequireMasterAdminView::class]);
    Route::patch('/settings', [Admin\SecurityController::class, 'updateSettings'])
        ->middleware([RequireMasterAdminView::class]);
    Route::get('/traffic', [Admin\SecurityController::class, 'traffic']);
    Route::get('/scores', [Admin\SecurityController::class, 'scores']);
    Route::get('/alerts', [Admin\SecurityController::class, 'alerts']);
    Route::get('/ip-lookup', [Admin\SecurityController::class, 'ipLookup'])
        ->middleware([RequireMasterAdminView::class]);
    Route::patch('/alerts/{alert}/resolve', [Admin\SecurityController::class, 'resolveAlert']);
    Route::post('/servers/{server}/suspend', [Admin\SecurityController::class, 'suspend']);
    Route::post('/servers/{server}/terminate', [Admin\SecurityController::class, 'terminate']);
});

/*
|--------------------------------------------------------------------------
| Diagnostics Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/admin/diagnostics
|
*/
Route::prefix('/diagnostics')->middleware([RequireMasterAdminView::class])->group(function () {
    Route::get('/', [Admin\DiagnosticsController::class, 'index']);
});

/*
|--------------------------------------------------------------------------
| Core Routes
|--------------------------------------------------------------------------
|
| Endpoint: /api/admin/core
|
*/
Route::prefix('/core')->middleware([RequireRootAdminOnly::class])->group(function () {
    Route::get('/', [Admin\HorizonController::class, 'index']);
    Route::post('/actions/{action}', [Admin\HorizonController::class, 'action']);
    Route::post('/bulk-power/{scope}', [Admin\HorizonController::class, 'bulkPowerAction']);
});

Route::prefix('/horizon')->middleware([RequireRootAdminOnly::class])->group(function () {
    Route::get('/', [Admin\HorizonController::class, 'index']);
    Route::post('/actions/{action}', [Admin\HorizonController::class, 'action']);
});
