<?php

use Illuminate\Support\Facades\Route;
use WammuCore\Http\Controllers\Security\DataCenterDdosWebhookController;

Route::post('/dc-ddos-alerts/{token?}', DataCenterDdosWebhookController::class)
    ->where('token', '.*')
    ->name('dc-ddos-alerts');
