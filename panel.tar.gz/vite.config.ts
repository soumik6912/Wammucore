import react from '@vitejs/plugin-react-swc'
import laravel from 'laravel-vite-plugin'
import { visualizer } from 'rollup-plugin-visualizer'
import { defineConfig } from 'vite'
import macrosPlugin from 'vite-plugin-babel-macros'

export default defineConfig({
    plugins: [
        react(),
        laravel(['resources/scripts/main.tsx']),
        macrosPlugin(),
        ...(process.env.BUNDLE_ANALYZE === 'true'
            ? [
                  visualizer({
                      filename: './storage/app/build-stats.html',
                  }),
              ]
            : []),
    ],
    build: {
        target: ['es2020'],
        cssCodeSplit: true,
        // Keep previous chunks to avoid hard failures for clients with older cached entry files.
        emptyOutDir: false,
        modulePreload: {
            polyfill: false,
        },
        // Keep Rollup's default chunking here. The previous manual chunk strategy
        // introduced a circular startup dependency between shared runtime chunks,
        // which caused a white-screen boot failure in production builds.
    },
    optimizeDeps: {
        esbuildOptions: {
            target: 'es2020',
        },
    },
    server: {
        port: 1234,
        hmr: {
            host: 'localhost',
        },
    },
    resolve: {
        alias: {
            '@': '/resources/scripts',
        },
    },
})
