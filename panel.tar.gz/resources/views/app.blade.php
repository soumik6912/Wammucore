<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ $siteConfiguration['panel_name'] ?? config('app.name', 'WammuHost') }}</title>

    @php
        $faviconRawHref = trim((string) ($siteConfiguration['favicon_url'] ?? ''));
        $faviconRawHref = $faviconRawHref !== '' ? $faviconRawHref : '/favicon.svg';
        $faviconVersion = substr(sha1($faviconRawHref . '|' . ($siteConfiguration['panel_name'] ?? '') . '|' . config('app.version')), 0, 12);
        if (str_starts_with($faviconRawHref, '/')) {
            $faviconPath = parse_url($faviconRawHref, PHP_URL_PATH);
            $faviconFile = public_path(ltrim((string) ($faviconPath ?: 'favicon.svg'), '/'));
            if (is_file($faviconFile)) {
                $faviconVersion = (string) filemtime($faviconFile);
            }
        }
        $faviconHref = $faviconRawHref . (str_contains($faviconRawHref, '?') ? '&' : '?') . 'wm_favicon=' . $faviconVersion;
    @endphp
    <link id="app-favicon" rel="icon" href="{{ $faviconHref }}">
    <link rel="shortcut icon" href="{{ $faviconHref }}">
    <link rel="apple-touch-icon" href="{{ $faviconHref }}">
    <meta name="msapplication-TileImage" content="{{ $faviconHref }}">

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap">

    <!-- Inject Data -->
    @if(!is_null(Auth::user()))
        <script>
            window.WammuCoreUser = {{ \Illuminate\Support\Js::from(Auth::user()->toReactObject()) }};
        </script>
    @endif

    @if(!empty($siteConfiguration))
        <script>
            window.SiteConfiguration = {{ \Illuminate\Support\Js::from($siteConfiguration) }};
        </script>
        <style>
            :root {
                --tenant-brand-primary: {{ $siteConfiguration['brand_primary_color'] ?? '#16a34a' }};
                --tenant-brand-secondary: {{ $siteConfiguration['brand_secondary_color'] ?? '#0f172a' }};
                --tenant-brand-accent: {{ $siteConfiguration['brand_accent_color'] ?? '#38bdf8' }};
            }
        </style>
        @if(!empty($siteConfiguration['custom_css']))
            <style>
                {!! $siteConfiguration['custom_css'] !!}
            </style>
        @endif
    @endif

    <!-- Scripts -->
    @if(app()->environment('local'))
        @viteReactRefresh
    @endif
    @vite('resources/scripts/main.tsx')

    <!-- Analytics intentionally disabled in this distribution -->
</head>
<body
    class="font-sans antialiased"
    data-tenant-theme="{{ $siteConfiguration['tenant_theme_key'] ?? 'wammuhost' }}"
    data-tenant-host="{{ $siteConfiguration['tenant_hostname'] ?? '' }}"
>
<div id="root"></div>
</body>
</html>
