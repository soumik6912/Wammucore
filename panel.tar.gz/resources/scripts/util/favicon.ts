const DEFAULT_FAVICON_HREF = '/favicon.svg'
const FAVICON_CACHE_BUSTER = '20260529'

const withFaviconCacheBuster = (href: string): string => {
    try {
        const url = new URL(href, window.location.origin)
        url.searchParams.set('wm_favicon', FAVICON_CACHE_BUSTER)

        return url.origin === window.location.origin
            ? `${url.pathname}${url.search}${url.hash}`
            : url.toString()
    } catch {
        return DEFAULT_FAVICON_HREF
    }
}

export const resolveFaviconHref = (href?: string | null): string =>
    withFaviconCacheBuster(href?.trim() || DEFAULT_FAVICON_HREF)

export const applyDocumentFavicon = (href?: string | null): void => {
    const nextHref = resolveFaviconHref(href)

    document
        .querySelectorAll<HTMLLinkElement>(
            'link[rel~="icon"], link[rel="shortcut icon"], link[rel="apple-touch-icon"], link[rel="mask-icon"]'
        )
        .forEach(link => link.remove())

    const links: Array<{ id?: string; rel: string; href: string }> = [
        { id: 'app-favicon', rel: 'icon', href: nextHref },
        { rel: 'shortcut icon', href: nextHref },
        { rel: 'apple-touch-icon', href: nextHref },
    ]

    links.forEach(item => {
        const link = document.createElement('link')
        if (item.id) {
            link.id = item.id
        }
        link.rel = item.rel
        link.href = item.href
        document.head.appendChild(link)
    })
}
