export const appendStorefrontParams = (
    baseUrl: string,
    params: Record<string, string | number | null | undefined>
): string => {
    try {
        const target = new URL(baseUrl)

        Object.entries(params).forEach(([key, value]) => {
            if (value === null || value === undefined || value === '') {
                return
            }

            target.searchParams.set(key, String(value))
        })

        return target.toString()
    } catch {
        const query = Object.entries(params)
            .filter(([, value]) => value !== null && value !== undefined && value !== '')
            .map(
                ([key, value]) =>
                    `${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`
            )
            .join('&')

        if (!query) {
            return baseUrl
        }

        const joiner = baseUrl.includes('?') ? '&' : '?'

        return `${baseUrl}${joiner}${query}`
    }
}

export const normalizeExternalUrl = (
    rawUrl: string | null | undefined,
    currentProtocol: string = typeof window !== 'undefined' ? window.location.protocol : 'https:'
): string | null => {
    const value = String(rawUrl || '').trim()
    if (!value) {
        return null
    }

    if (/^https?:\/\//i.test(value)) {
        return value
    }

    if (value.startsWith('//')) {
        return `${currentProtocol}${value}`
    }

    const looksLocal =
        value.startsWith('localhost') ||
        value.startsWith('127.0.0.1') ||
        value.endsWith('.local') ||
        /^\d{1,3}(?:\.\d{1,3}){3}(?::\d+)?(?:\/.*)?$/i.test(value)

    const looksDomainLike =
        looksLocal ||
        /^[a-z0-9-]+(?:\.[a-z0-9-]+)+(?:[:/].*)?$/i.test(value)

    if (looksDomainLike) {
        const protocol = looksLocal ? currentProtocol : 'https:'

        return `${protocol}//${value}`
    }

    return value
}
