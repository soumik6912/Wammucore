export interface TenantThemePreset {
    key: string
    name: string
    description: string
    primary: string
    secondary: string
    accent: string
    background: string
    card: string
    glow: string
}

export const THEME_PRESETS: TenantThemePreset[] = [
    {
        key: 'main_default',
        name: 'Main Default',
        description: 'Classic Wammu purple panel with soft blue accents.',
        primary: '#6257d9',
        secondary: '#100b2d',
        accent: '#38bdf8',
        background: '#07031d',
        card: '#171333',
        glow: 'rgba(56, 189, 248, 0.14)',
    },
    {
        key: 'wammuhost',
        name: 'Wammu Neon',
        description: 'Brighter violet cloud panel with crisp cyan highlights.',
        primary: '#8b5cf6',
        secondary: '#08021f',
        accent: '#06e9ff',
        background: '#030011',
        card: '#160f3f',
        glow: 'rgba(6, 233, 255, 0.24)',
    },
    {
        key: 'obsidian_cloud',
        name: 'Obsidian Cloud',
        description: 'Dark enterprise slate with soft sky-blue actions.',
        primary: '#38bdf8',
        secondary: '#020617',
        accent: '#a78bfa',
        background: '#020617',
        card: '#0f172a',
        glow: 'rgba(56, 189, 248, 0.2)',
    },
    {
        key: 'aurora_edge',
        name: 'Aurora Edge',
        description: 'Green aurora tones for clean infra dashboards.',
        primary: '#10b981',
        secondary: '#052e2b',
        accent: '#f59e0b',
        background: '#021714',
        card: '#092f2d',
        glow: 'rgba(16, 185, 129, 0.22)',
    },
    {
        key: 'ocean_grid',
        name: 'Ocean Grid',
        description: 'Blue data-center mood with electric cyan accents.',
        primary: '#0ea5e9',
        secondary: '#082f49',
        accent: '#67e8f9',
        background: '#02111f',
        card: '#0b2545',
        glow: 'rgba(14, 165, 233, 0.22)',
    },
    {
        key: 'ember_core',
        name: 'Ember Core',
        description: 'Warm premium orange for bold commercial panels.',
        primary: '#f97316',
        secondary: '#1c0f0a',
        accent: '#f43f5e',
        background: '#120807',
        card: '#28130d',
        glow: 'rgba(249, 115, 22, 0.2)',
    },
    {
        key: 'forest_node',
        name: 'Forest Node',
        description: 'Calm green hosting theme with high readability.',
        primary: '#22c55e',
        secondary: '#052e16',
        accent: '#84cc16',
        background: '#03150a',
        card: '#0b2d16',
        glow: 'rgba(34, 197, 94, 0.22)',
    },
    {
        key: 'cyber_lime',
        name: 'Cyber Lime',
        description: 'Sharp lime and teal for futuristic reseller brands.',
        primary: '#a3e635',
        secondary: '#111827',
        accent: '#06b6d4',
        background: '#050b10',
        card: '#101923',
        glow: 'rgba(163, 230, 53, 0.2)',
    },
    {
        key: 'arctic_blue',
        name: 'Arctic Blue',
        description: 'Cool blue-gray SaaS theme with bright frost accents.',
        primary: '#60a5fa',
        secondary: '#0f172a',
        accent: '#e0f2fe',
        background: '#050b17',
        card: '#111c31',
        glow: 'rgba(96, 165, 250, 0.22)',
    },
]

export const resolveThemePreset = (key?: string | null): TenantThemePreset =>
    THEME_PRESETS.find(theme => theme.key === key) || THEME_PRESETS[0]
