const CHUNK_RELOAD_ATTEMPT_KEY = 'wammucore_chunk_reload_attempt'
const MAX_RECOVERY_ATTEMPTS = 2

const DYNAMIC_IMPORT_PATTERNS = [
    'failed to fetch dynamically imported module',
    'loading chunk',
    'chunkloaderror',
]

const OFFLINE_RECOVERY_EVENT = 'wammucore:offline-recovery-blocked'

const errorToMessage = (error: unknown): string => {
    if (error instanceof Error) {
        return error.message.toLowerCase()
    }

    if (typeof error === 'string') {
        return error.toLowerCase()
    }

    return ''
}

export const isDynamicImportError = (error: unknown): boolean => {
    const message = errorToMessage(error)

    return DYNAMIC_IMPORT_PATTERNS.some(pattern => message.includes(pattern))
}

export const isBrowserOffline = (): boolean =>
    typeof navigator !== 'undefined' && navigator.onLine === false

export const tryRecoverFromChunkError = (): boolean => {
    try {
        if (isBrowserOffline()) {
            window.dispatchEvent(new CustomEvent(OFFLINE_RECOVERY_EVENT))
            return false
        }

        const attempts = Number(sessionStorage.getItem(CHUNK_RELOAD_ATTEMPT_KEY) || '0')
        if (attempts >= MAX_RECOVERY_ATTEMPTS) {
            sessionStorage.removeItem(CHUNK_RELOAD_ATTEMPT_KEY)
            return false
        }

        sessionStorage.setItem(CHUNK_RELOAD_ATTEMPT_KEY, String(attempts + 1))

        // Attempt to clear browser caches before forcing a cache-busted reload.
        if ('caches' in window) {
            void caches
                .keys()
                .then(keys => Promise.all(keys.map(key => caches.delete(key))))
                .catch(() => null)
        }

        const url = new URL(window.location.href)
        url.searchParams.set('__chunk_reload', String(Date.now()))
        window.location.replace(url.toString())
        return true
    } catch {
        return false
    }
}

export const installChunkLoadRecovery = () => {
    window.addEventListener('error', event => {
        if (isDynamicImportError(event.error ?? event.message)) {
            tryRecoverFromChunkError()
        }
    })

    window.addEventListener('unhandledrejection', event => {
        if (isDynamicImportError(event.reason)) {
            tryRecoverFromChunkError()
        }
    })
}
