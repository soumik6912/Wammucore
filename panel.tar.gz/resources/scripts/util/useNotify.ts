import {
    CheckCircleIcon,
    ExclamationTriangleIcon,
    InformationCircleIcon,
    XCircleIcon,
} from '@heroicons/react/24/solid'
import { createElement } from 'react'
import { NotificationProps, showNotification } from '@mantine/notifications'

const useNotify = () => {
    return (props: Omit<NotificationProps, 'style'> & { style?: NotificationProps['style'] }) =>
        showNotification({
            radius: 'lg',
            autoClose: props.autoClose ?? 3800,
            disallowClose: false,
            title:
                props.title ??
                (props.color === 'green'
                    ? 'Success'
                    : props.color === 'red'
                      ? 'Action failed'
                      : props.color === 'yellow'
                        ? 'Attention'
                        : 'Notice'),
            icon:
                props.icon ??
                createElement(
                    props.color === 'green'
                        ? CheckCircleIcon
                        : props.color === 'red'
                          ? XCircleIcon
                          : props.color === 'yellow'
                            ? ExclamationTriangleIcon
                            : InformationCircleIcon,
                    { className: 'h-6 w-6' }
                ),
            className: `wammucore-notification ${props.className || ''}`.trim(),
            ...props,
            style: {
                transitionTimingFunction: 'cubic-bezier(0.22, 1, 0.36, 1)',
                ...props.style,
            },
        })
}

export default useNotify
