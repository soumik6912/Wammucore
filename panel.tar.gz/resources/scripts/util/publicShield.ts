export interface PublicShieldInput {
    startedAt: number
    honeypot?: string
}

export const toPublicShieldPayload = ({
    startedAt,
    honeypot = '',
}: PublicShieldInput) => ({
    form_started_at: new Date(startedAt).toISOString(),
    form_elapsed_ms: Math.min(Math.max(Date.now() - startedAt, 1000), 15 * 60 * 1000),
    company_website: honeypot,
})
