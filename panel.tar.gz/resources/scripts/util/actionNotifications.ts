import {
    CheckCircleIcon,
    ExclamationTriangleIcon,
    InformationCircleIcon,
    XCircleIcon,
} from '@heroicons/react/24/solid'
import { showNotification } from '@mantine/notifications'
import { createElement } from 'react'

type NotificationColor = 'green' | 'red' | 'yellow' | 'blue'

let lastNotificationKey = ''
let lastNotificationAt = 0

const iconFor = (color: NotificationColor) =>
    createElement(
        color === 'green'
            ? CheckCircleIcon
            : color === 'red'
              ? XCircleIcon
              : color === 'yellow'
                ? ExclamationTriangleIcon
                : InformationCircleIcon,
        { className: 'h-6 w-6' }
    )

export const showActionNotification = ({
    title,
    message,
    color = 'green',
    autoClose = 3800,
}: {
    title: string
    message: string
    color?: NotificationColor
    autoClose?: number
}) => {
    const key = `${color}:${title}:${message}`
    const now = Date.now()

    if (lastNotificationKey === key && now - lastNotificationAt < 1400) {
        return
    }

    lastNotificationKey = key
    lastNotificationAt = now

    showNotification({
        title,
        message,
        color,
        autoClose,
        radius: 'lg',
        disallowClose: false,
        className: 'wammucore-notification wammucore-action-notification',
        icon: iconFor(color),
        style: {
            transitionTimingFunction: 'cubic-bezier(0.22, 1, 0.36, 1)',
        },
    })
}

const extractMessage = (data: unknown): string | null => {
    if (!data || typeof data !== 'object') {
        return null
    }

    const source = data as Record<string, unknown>
    if (typeof source.message === 'string' && source.message.trim() !== '') {
        return source.message.trim()
    }

    if (source.data && typeof source.data === 'object') {
        return extractMessage(source.data)
    }

    return null
}

const inferTitle = (method: string, url: string): string => {
    const normalizedUrl = url.toLowerCase()

    if (normalizedUrl.includes('/tenancy/context')) {
        return 'Workspace switched'
    }

    if (normalizedUrl.includes('/login')) {
        return 'Signed in'
    }

    if (normalizedUrl.includes('/logout')) {
        return 'Signed out'
    }

    if (method === 'delete') {
        return 'Deleted successfully'
    }

    if (normalizedUrl.includes('/reseller-panel/dedicated-hardware')) {
        return method === 'post' ? 'Hardware assigned' : 'Hardware updated'
    }

    if (normalizedUrl.includes('/reseller-panel/resources')) {
        return 'Stock checkout started'
    }

    if (normalizedUrl.includes('/reseller-panel/plans')) {
        return 'Plan saved'
    }

    if (method === 'post') {
        return 'Request completed'
    }

    return 'Changes saved'
}

const inferMessage = (method: string, url: string, data: unknown): string => {
    const apiMessage = extractMessage(data)

    if (apiMessage) {
        return apiMessage
    }

    const normalizedUrl = url.toLowerCase()

    if (normalizedUrl.includes('/tenancy/context')) {
        return 'Your admin workspace was updated.'
    }

    if (normalizedUrl.includes('/reseller-panel/domains') || normalizedUrl.includes('/custom-domain')) {
        return 'Reseller domain settings were saved.'
    }

    if (normalizedUrl.includes('/reseller-panel/dedicated-hardware')) {
        return method === 'post'
            ? 'Dedicated hardware was assigned to this reseller.'
            : 'Dedicated hardware settings were updated.'
    }

    if (normalizedUrl.includes('/reseller-panel/resources')) {
        return 'The checkout flow is ready for this resource.'
    }

    if (normalizedUrl.includes('/reseller-panel/plans')) {
        return 'The reseller plan settings were saved.'
    }

    if (normalizedUrl.includes('/theme')) {
        return 'Your panel theme was updated.'
    }

    if (normalizedUrl.includes('/settings')) {
        return 'This settings section was saved.'
    }

    if (normalizedUrl.includes('/login')) {
        return 'Access verified successfully.'
    }

    if (method === 'delete') {
        return 'The selected item was removed successfully.'
    }

    if (method === 'post') {
        return 'The action finished successfully.'
    }

    return 'Your changes were saved successfully.'
}

export const showMutationSuccessNotification = (
    method: string,
    url: string,
    data: unknown,
    override?: string | boolean
) => {
    if (override === false) {
        return
    }

    const title =
        typeof override === 'string' && override.trim() !== ''
            ? override.trim()
            : inferTitle(method, url)

    showActionNotification({
        title,
        message: inferMessage(method, url, data),
        color: 'green',
    })
}
