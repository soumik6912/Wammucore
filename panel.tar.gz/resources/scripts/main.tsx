import '@/assets/css/preflight.css';
import '@/assets/css/tailwind.css';
import '@/lib/i18n';
import ReactDOM from 'react-dom/client';

import App from '@/components/App';
import { installChunkLoadRecovery } from '@/util/chunkLoadRecovery';

declare global {
    interface Window {
        __wammucoreAppReady?: boolean
        __wammucoreBootErrorShown?: boolean
    }
}

const renderBootError = (title: string, message: string) => {
    if (window.__wammucoreBootErrorShown) {
        return
    }

    const root = document.getElementById('root')
    if (!root) {
        return
    }

    window.__wammucoreBootErrorShown = true

    root.innerHTML = `
        <div style="min-height:100vh;display:flex;align-items:center;justify-content:center;padding:16px;background:#05000f;color:#fff;font-family:Inter,system-ui,sans-serif;">
            <div style="width:100%;max-width:760px;border:1px solid rgba(255,255,255,.2);border-radius:14px;padding:20px;background:rgba(0,0,0,.55);">
                <h1 style="margin:0 0 8px;font-size:20px;font-weight:700;">${title}</h1>
                <p style="margin:0 0 12px;font-size:14px;line-height:1.5;color:rgba(255,255,255,.9);">${message}</p>
                <button type="button" onclick="window.location.reload()" style="border:1px solid rgba(129,140,248,.5);background:rgba(99,102,241,.2);color:#e0e7ff;padding:8px 12px;border-radius:8px;cursor:pointer;">
                    Reload
                </button>
            </div>
        </div>
    `
}

const errorToMessage = (error: unknown) => {
    if (error instanceof Error) {
        return error.message
    }

    return typeof error === 'string' ? error : 'Unknown startup error.'
}

const reportBootError = (error: unknown) => {
    console.error('[boot-error]', error)
    renderBootError('Panel failed to initialize', errorToMessage(error))
}

const installBootGuards = () => {
    window.addEventListener('error', event => {
        if (!window.__wammucoreAppReady) {
            reportBootError(event.error ?? event.message)
        }
    })

    window.addEventListener('unhandledrejection', event => {
        if (!window.__wammucoreAppReady) {
            reportBootError(event.reason)
        }
    })
}

// do not remove the parentheses because they are what lazy-loads these imports
installBootGuards()
installChunkLoadRecovery()
import('@/util/registerCustomYupValidationRules').catch(reportBootError)

const root = document.getElementById('root')

if (!root) {
    throw new Error('Missing #root container.')
}

window.setTimeout(() => {
    const hasRenderedContent =
        root.childElementCount > 0 || (root.textContent || '').trim().length > 0

    if (!hasRenderedContent) {
        renderBootError(
            'Panel failed to initialize',
            'The frontend did not mount in time. Try a hard refresh (Ctrl + Shift + R).'
        )
    }
}, 12000)

try {
    ReactDOM.createRoot(root).render(<App />)
} catch (error) {
    reportBootError(error)
}
