import { LoadingOverlay } from '@mantine/core';
import { ReactNode } from 'react';
import { useResolvedImageUrl } from '@/components/elements/SafeImage';

interface Props {
    title: string;
    description: string;
    logo?: ReactNode;
    panelName?: string;
    footerText?: string;
    footerUrl?: string | null;
    backgroundImage?: string | null;
    bannerImage?: string | null;
    children?: ReactNode;
    submitting?: boolean;
}

const LoginFormContainer = ({
    title,
    description,
    logo,
    panelName = 'WammuCore',
    footerText = 'WammuCore',
    footerUrl = 'https://wammuhost.com',
    backgroundImage,
    bannerImage,
    children,
    submitting,
}: Props) => {
    const safeBackgroundImage = useResolvedImageUrl(backgroundImage);
    const safeBannerImage = useResolvedImageUrl(bannerImage);
    const imageBackground = (url: string) => ({
        backgroundImage: `url("${url.replace(/"/g, '%22')}")`,
    });

    return (
        <div className="min-h-screen w-full flex items-center justify-center p-4 bg-[var(--tenant-bg)] relative overflow-hidden">
            <style>
                {`
                    @keyframes wammu-auth-glow-a {
                        0%, 100% { opacity: .3; transform: scale(1); }
                        50% { opacity: .5; transform: scale(1.2); }
                    }
                    @keyframes wammu-auth-glow-b {
                        0%, 100% { opacity: .2; transform: scale(1); }
                        50% { opacity: .4; transform: scale(1.3); }
                    }
                    @keyframes wammu-auth-orb-a {
                        0%, 100% { transform: translate(0, 0) scale(1); }
                        50% { transform: translate(20px, -20px) scale(1.3); }
                    }
                    @keyframes wammu-auth-orb-b {
                        0%, 100% { transform: translate(0, 0) scale(1); }
                        50% { transform: translate(-20px, 20px) scale(1.4); }
                    }
                    @keyframes wammu-auth-pop {
                        from { opacity: 0; transform: scale(.97); }
                        to { opacity: 1; transform: scale(1); }
                    }
                    @keyframes wammu-auth-slide-left {
                        from { opacity: 0; transform: translateX(-24px); }
                        to { opacity: 1; transform: translateX(0); }
                    }
                    @keyframes wammu-auth-slide-right {
                        from { opacity: 0; transform: translateX(24px); }
                        to { opacity: 1; transform: translateX(0); }
                    }
                    @keyframes wammu-auth-dot {
                        0%, 100% { opacity: .5; transform: scale(1); }
                        50% { opacity: 1; transform: scale(1.4); }
                    }
                `}
            </style>
            {safeBackgroundImage && (
                <div
                    className="absolute inset-0 bg-center bg-cover opacity-35"
                    style={imageBackground(safeBackgroundImage)}
                />
            )}
            <div className="absolute inset-0 bg-[var(--tenant-bg)] opacity-85" />
            {/* Animated background elements */}
            <div className="hidden lg:block absolute top-20 left-20 w-96 h-96 rounded-full bg-[var(--tenant-brand-primary)] opacity-20 blur-3xl motion-safe:animate-[wammu-auth-glow-a_8s_ease-in-out_infinite]" />
            <div className="hidden lg:block absolute bottom-20 right-20 w-96 h-96 rounded-full bg-[var(--tenant-brand-accent)] opacity-20 blur-3xl motion-safe:animate-[wammu-auth-glow-b_10s_ease-in-out_2s_infinite]" />

            <div className="relative w-full max-w-6xl z-10">
                <div className="grid md:grid-cols-2 bg-[var(--glass-bg-strong)] backdrop-blur-2xl rounded-3xl shadow-2xl border border-[var(--border-soft)] overflow-hidden motion-safe:animate-[wammu-auth-pop_.32s_ease-out]">
                    {/* Left Panel - Welcome Section */}
                    <div className="hidden md:flex flex-col justify-center p-12 lg:p-16 bg-gradient-to-br from-[var(--surface-raised)] via-[var(--surface-active)] to-[var(--tenant-card)] relative overflow-hidden">
                        {safeBannerImage && (
                            <div
                                className="absolute inset-0 bg-center bg-cover opacity-20"
                                style={imageBackground(safeBannerImage)}
                            />
                        )}
                        <div className="absolute inset-0 bg-[var(--tenant-bg)] opacity-60" />
                        {/* Animated orbs */}
                        <div className="absolute top-10 right-10 w-40 h-40 bg-[var(--tenant-brand-primary)] opacity-30 rounded-full blur-2xl motion-safe:animate-[wammu-auth-orb-a_6s_ease-in-out_infinite]" />
                        <div className="absolute bottom-10 left-10 w-48 h-48 bg-[var(--tenant-brand-accent)] opacity-20 rounded-full blur-2xl motion-safe:animate-[wammu-auth-orb-b_7s_ease-in-out_1s_infinite]" />

                        <div className="relative z-10">
                            {/* Logo */}
                            {logo && (
                                <div className="mb-10 motion-safe:animate-[wammu-auth-slide-left_.45s_ease-out_both]">
                                    {logo}
                                </div>
                            )}
                            
                            {/* Welcome Text */}
                            <div
                                className="motion-safe:animate-[wammu-auth-slide-left_.45s_ease-out_both]"
                                style={{ animationDelay: '80ms' }}
                            >
                                <h1 className="text-5xl lg:text-6xl font-bold text-white mb-4 leading-tight">
                                    Hello,<br />
                                    <span className="bg-gradient-to-r from-[var(--tenant-brand-primary)] to-[var(--tenant-brand-accent)] bg-clip-text text-transparent">
                                        welcome!
                                    </span>
                                </h1>
                            </div>
                            
                            {/* Description */}
                            <p
                                className="text-[var(--text-muted)] text-lg mb-10 leading-relaxed max-w-md motion-safe:animate-[wammu-auth-slide-left_.45s_ease-out_both]"
                                style={{ animationDelay: '140ms' }}
                            >
                                {description}
                            </p>

                            {/* Learn More Button */}
                            <div
                                className="motion-safe:animate-[wammu-auth-slide-left_.45s_ease-out_both]"
                                style={{ animationDelay: '200ms' }}
                            >
                                <a 
                                    href="https://wammuhost.com" 
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="inline-flex items-center gap-3 px-8 py-3.5 bg-[var(--button-glass)] hover:bg-[var(--surface-hover)] border border-[var(--border-soft)] rounded-full text-white font-medium transition-all duration-300 backdrop-blur-sm hover:scale-105 group"
                                >
                                    <span>Learn More</span>
                                    <svg className="w-5 h-5 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                                    </svg>
                                </a>
                            </div>

                            {/* Decorative dots */}
                            <div className="mt-16 flex gap-3">
                                {[0, 1, 2].map((i) => (
                                    <div
                                        key={i}
                                        className="w-2.5 h-2.5 bg-[var(--tenant-brand-accent)] rounded-full motion-safe:animate-[wammu-auth-dot_2s_ease-in-out_infinite]"
                                        style={{ animationDelay: `${i * 0.3}s` }}
                                    />
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* Right Panel - Login Form */}
                    <div 
                        className="p-8 md:p-12 lg:p-16 flex flex-col justify-center relative bg-[var(--surface-soft)] motion-safe:animate-[wammu-auth-slide-right_.45s_ease-out_both]"
                        style={{ animationDelay: '80ms' }}
                    >
                        <LoadingOverlay
                            visible={submitting || false}
                            loaderProps={{ color: 'var(--tenant-brand-accent)' }}
                        />

                        {/* Mobile Logo */}
                        <div className="md:hidden flex justify-center mb-8">
                            {logo}
                        </div>

                        {/* Form Header */}
                        <div className="mb-8">
                            <h2 className="text-3xl md:text-4xl font-bold text-white mb-3">
                                {title}
                            </h2>
                            <p className="text-[var(--text-muted)] text-sm md:hidden">
                                {description}
                            </p>
                        </div>

                        {/* Form Content */}
                        <div>
                            {children}
                        </div>
{/* Footer */}
<div className="mt-8 pt-6 border-t border-[var(--border-soft)]">
    <p className="text-xs text-center text-[var(--text-muted)]">
        &copy; 2023 - {new Date().getFullYear()}{' '}
        <a
            href={footerUrl || 'https://wammuhost.com'}
            target="_blank"
            rel="noopener noreferrer"
            className="text-[var(--tenant-brand-accent)] transition-colors font-medium hover:brightness-125"
        >
            {footerText || panelName}
        </a>
        . All rights reserved.
    </p>
</div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default LoginFormContainer;


