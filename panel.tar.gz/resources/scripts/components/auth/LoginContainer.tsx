import login from '@/api/auth/login'
import getClientAuthMeta from '@/api/auth/getClientAuthMeta'
import verifyEmailTwoFactor from '@/api/auth/verifyEmailTwoFactor'
import LoginFormContainer from '@/components/auth/LoginFormContainer'
import SafeImage from '@/components/elements/SafeImage'
import FlashMessageRender from '@/components/elements/FlashMessageRenderer'
import { useStoreState } from '@/state'
import { useFlashKey } from '@/util/useFlash'
import { zodResolver } from '@hookform/resolvers/zod'
import {
    AtSymbolIcon,
    EyeIcon,
    EyeSlashIcon,
    KeyIcon,
    LockClosedIcon,
} from '@heroicons/react/24/outline'
import { useEffect, useState } from 'react'
import { FormProvider, useForm } from 'react-hook-form'
import { Link, useLocation } from 'react-router-dom'
import { z } from 'zod'

const reservedTenantSegments = new Set([
    'admin',
    'api',
    'auth',
    'authorize',
    'assets',
    'build',
    'favicon.ico',
    'locales',
    'login',
    'register',
    'reseller',
    'servers',
    'store',
    'account',
    'forgot-password',
    'verify-email',
])

const tenantRouteFromPath = (pathname: string): { prefix: string; reference: string | null } => {
    const legacyMatch = pathname.match(/^\/r\/([^/]+)/)
    if (legacyMatch?.[1]) {
        return {
            prefix: legacyMatch[0],
            reference: decodeURIComponent(legacyMatch[1]).trim(),
        }
    }

    const directMatch = pathname.match(/^\/([^/?#]+)/)
    const segment = directMatch?.[1] ? decodeURIComponent(directMatch[1]).trim() : ''
    if (!segment || reservedTenantSegments.has(segment.toLowerCase())) {
        return { prefix: '', reference: null }
    }

    return {
        prefix: `/${encodeURIComponent(segment)}`,
        reference: segment,
    }
}

const LoginContainer = () => {
    const { clearFlashes, clearAndAddHttpError } = useFlashKey('auth:sign_in')
    const location = useLocation()
    const isResellerLogin = location.pathname === '/reseller/login'
    const tenantRoute = tenantRouteFromPath(location.pathname)
    const tenantRoutePrefix = tenantRoute.prefix
    const isTenantRoute = tenantRoutePrefix !== ''
    const tenantPath = (path: string) => (tenantRoutePrefix ? `${tenantRoutePrefix}${path}` : path)
    const [showPassword, setShowPassword] = useState(false)
    const [showTwoFactor, setShowTwoFactor] = useState(false)
    const [challengeId, setChallengeId] = useState<string | null>(null)
    const [formStartedAt] = useState(() => Date.now())
    const [companyWebsite, setCompanyWebsite] = useState('')
    const [meta, setMeta] = useState<{
        allowSelfRegistration: boolean
        enableEmail2fa: boolean
        passwordResetEnabled: boolean
    } | null>(null)
    const bootAuthMeta = useStoreState(state => state.settings.data?.clientAuth)

    const panelName = useStoreState(state => state.settings.data?.panelName || 'WammuCore')
    const panelLogoUrl = useStoreState(
        state => state.settings.data?.logoUrl || 'https://i.postimg.cc/wjVWzbcZ/hl.png'
    )
    const loginBackgroundImage = useStoreState(state => state.settings.data?.loginBackgroundImage || null)
    const bannerImageUrl = useStoreState(state => state.settings.data?.bannerImageUrl || null)
    const footerText = useStoreState(state => state.settings.data?.footerText || 'WammuCore')
    const footerUrl = useStoreState(state => state.settings.data?.footerUrl || 'https://wammuhost.com')
    const tenantId = useStoreState(state => state.settings.data?.tenantId ?? null)
    const resellerId = useStoreState(state => state.settings.data?.resellerId ?? null)
    const tenantSlug = useStoreState(state => state.settings.data?.tenantSlug || null)
    const tenantUuid = useStoreState(state => state.settings.data?.tenantUuid || null)
    const tenantHostname = useStoreState(state => state.settings.data?.tenantHostname || null)
    const tenantReference = tenantRoute.reference
    const tenantReferenceHint = tenantUuid || tenantSlug || resellerId || tenantId || null
    const isTenantHost = Boolean(tenantReference || isTenantRoute)
    const isBareTenantHost = Boolean(tenantHostname && tenantReferenceHint && !tenantRoutePrefix)

    useEffect(() => {
        document.title = `${isResellerLogin ? 'Reseller Login' : 'Login'} | ${panelName}`
        if (bootAuthMeta) {
            setMeta({
                allowSelfRegistration: bootAuthMeta.allowSelfRegistration,
                enableEmail2fa: bootAuthMeta.enableEmail2fa,
                passwordResetEnabled: bootAuthMeta.passwordResetEnabled,
            })

            return
        }

        void getClientAuthMeta()
            .then(data =>
                setMeta({
                    allowSelfRegistration: data.allowSelfRegistration,
                    enableEmail2fa: data.enableEmail2fa,
                    passwordResetEnabled: data.passwordResetEnabled,
                })
            )
            .catch(() =>
                setMeta({
                    allowSelfRegistration: false,
                    enableEmail2fa: false,
                    passwordResetEnabled: false,
                })
            )
    }, [panelName, bootAuthMeta, isResellerLogin])

    const emailSchema = z.preprocess(
        value => (typeof value === 'string' ? value.trim().toLowerCase() : value),
        z.string().nonempty('Email is required.').email('Please enter a valid email.')
    )

    const schema = z.object({
        email: emailSchema,
        password: z.string().nonempty('Password is required.'),
        remember: z.boolean().optional(),
        code: z.string().optional(),
    })

    const methods = useForm<z.infer<typeof schema>>({
        resolver: zodResolver(schema),
        mode: 'onTouched',
        defaultValues: { email: '', password: '', remember: true, code: '' },
    })

    const submit = async (data: z.infer<typeof schema>) => {
        clearFlashes()

        if (isBareTenantHost && !isResellerLogin) {
            clearAndAddHttpError(
                new Error(
                    'Reseller URL is incorrect. Please contact your seller for the correct reseller panel URL.'
                )
            )
            return
        }

        try {
            let authResult: any = null

            if (showTwoFactor && challengeId) {
                authResult = await verifyEmailTwoFactor({
                    challengeId,
                    code: data.code || '',
                })
            } else {
                const response = await login({
                    ...data,
                    loginContext: isResellerLogin
                        ? 'reseller_admin'
                        : isTenantHost
                        ? 'tenant_customer'
                        : 'platform',
                    security: {
                        startedAt: formStartedAt,
                        honeypot: companyWebsite,
                    },
                })
                if (response.requires_2fa) {
                    setShowTwoFactor(true)
                    setChallengeId(response.challenge_id)
                    return
                }

                authResult = response
            }

            const role = String(authResult?.user?.role || '')
            const isAdminRole = ['root_admin', 'admin'].includes(role)
            const apiRedirect =
                typeof authResult?.redirect_url === 'string' && authResult.redirect_url.trim() !== ''
                    ? authResult.redirect_url.trim()
                    : null
            const from = (location.state as any)?.from
            const fromPath = typeof from?.pathname === 'string' ? from.pathname : ''
            const fromSearch = typeof from?.search === 'string' ? from.search : ''
            const stateRedirect =
                fromPath && !/\/auth\/(login|register|forgot-password)$/.test(fromPath)
                    ? `${fromPath}${fromSearch}`
                    : null
            const defaultRedirect = isResellerLogin
                ? apiRedirect || '/admin/reseller-panel'
                : isAdminRole
                ? '/admin'
                : tenantRoutePrefix || (tenantReferenceHint ? `/${tenantReferenceHint}` : '/')

            window.location.assign(stateRedirect || defaultRedirect)
        } catch (e) {
            clearAndAddHttpError(e as Error)
        }
    }

    const fieldClass =
        'block h-12 w-full rounded-xl border border-[var(--border-soft)] bg-[var(--surface-soft)] py-3 text-white placeholder:text-white/45 outline-none transition-colors focus:border-[var(--tenant-brand-accent)] focus:ring-2 focus:ring-[var(--focus-ring)]'
    const errorClass = 'mt-2 text-sm font-medium text-rose-300'

    return (
        <LoginFormContainer
            title={
                showTwoFactor
                    ? isResellerLogin
                        ? 'Verify reseller access'
                        : 'Verify your login'
                    : isResellerLogin
                    ? 'Reseller Admin Login'
                    : 'Sign in to your account'
            }
            description={
                isResellerLogin
                    ? 'Sign in with your reseller owner account to manage your branded VPS panel, customers, plans, and settings.'
                    : isTenantHost
                    ? `Customer access for ${panelName}.`
                    : 'Sign in to manage your WammuCore VPS services.'
            }
            submitting={methods.formState.isSubmitting}
            panelName={panelName}
            footerText={footerText}
            footerUrl={footerUrl}
            backgroundImage={loginBackgroundImage}
            bannerImage={bannerImageUrl}
            logo={
                <SafeImage
                    src={panelLogoUrl}
                    alt={`${panelName} Logo`}
                    className='h-16 w-auto object-contain'
                    fallbackClassName='h-16 w-16'
                    fallbackText={panelName}
                />
            }
        >
            <FormProvider {...methods}>
                <form
                    noValidate
                    autoComplete='on'
                    onSubmit={methods.handleSubmit(submit)}
                    className='space-y-5'
                >
                    <FlashMessageRender byKey='auth:sign_in' />

                    <div className='hidden' aria-hidden='true'>
                        <input
                            type='text'
                            tabIndex={-1}
                            autoComplete='off'
                            value={companyWebsite}
                            onChange={event => setCompanyWebsite(event.currentTarget.value)}
                        />
                    </div>

                    {!showTwoFactor ? (
                        <>
                            <div>
                                <label className='mb-2.5 block text-sm font-medium text-white'>
                                    Email Address
                                </label>
                                <div className='relative'>
                                    <div className='pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4'>
                                        <AtSymbolIcon className='h-5 w-5 text-[var(--tenant-brand-accent)]' />
                                    </div>
                                    <input
                                        type='email'
                                        autoComplete='username'
                                        placeholder='name@example.com'
                                        autoFocus
                                        {...methods.register('email')}
                                        className={`${fieldClass} pl-12 pr-4`}
                                    />
                                </div>
                                {methods.formState.errors.email?.message ? (
                                    <p className={errorClass}>{methods.formState.errors.email.message}</p>
                                ) : null}
                            </div>

                            <div>
                                <label className='mb-2.5 block text-sm font-medium text-white'>
                                    Password
                                </label>
                                <div className='relative flex flex-col'>
                                    <div className='pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4'>
                                        <LockClosedIcon className='h-5 w-5 text-[var(--tenant-brand-accent)]' />
                                    </div>
                                    <input
                                        type={showPassword ? 'text' : 'password'}
                                        autoComplete='current-password'
                                        placeholder='Enter your password'
                                        {...methods.register('password')}
                                        className={`${fieldClass} pl-12 pr-14`}
                                    />
                                    <button
                                        type='button'
                                        onClick={() => setShowPassword(s => !s)}
                                        className='absolute right-2 top-1/2 grid h-9 w-9 -translate-y-1/2 place-items-center rounded-lg border border-[var(--border-soft)] bg-[var(--surface-raised)] text-[var(--tenant-brand-accent)] transition hover:bg-[var(--surface-hover)] hover:text-white'
                                        aria-label={showPassword ? 'Hide password' : 'Show password'}
                                    >
                                        {showPassword ? (
                                            <EyeSlashIcon className='h-5 w-5' strokeWidth={1.6} />
                                        ) : (
                                            <EyeIcon className='h-5 w-5' strokeWidth={1.6} />
                                        )}
                                    </button>
                                </div>
                                {methods.formState.errors.password?.message ? (
                                    <p className={errorClass}>{methods.formState.errors.password.message}</p>
                                ) : null}
                            </div>

                            <div className='flex items-center justify-between pt-1'>
                                <label className='flex items-center text-sm text-white'>
                                    <input
                                        id='remember-me'
                                        type='checkbox'
                                        {...methods.register('remember')}
                                        className='h-4 w-4 rounded border border-[var(--border-soft)] bg-transparent text-[var(--tenant-brand-primary)] focus:ring-1 focus:ring-[var(--tenant-brand-accent)]'
                                    />
                                    <span className='ml-2.5'>Remember me</span>
                                </label>

                                {meta?.passwordResetEnabled ? (
                                    <Link to={tenantPath('/auth/forgot-password')} className='text-sm text-[var(--tenant-brand-accent)] hover:brightness-125'>
                                        Forgot password?
                                    </Link>
                                ) : null}
                            </div>
                        </>
                    ) : (
                        <div className='space-y-4'>
                            <div className='rounded-lg border border-indigo-400/30 bg-indigo-500/10 px-3 py-3 text-sm text-indigo-100'>
                                We sent a 6-digit email verification code for this login.
                            </div>
                            <div>
                                <label className='mb-2.5 block text-sm font-medium text-white'>
                                    Verification Code
                                </label>
                                <div className='relative'>
                                    <div className='pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4'>
                                        <KeyIcon className='h-5 w-5 text-[var(--tenant-brand-accent)]' />
                                    </div>
                                    <input
                                        type='text'
                                        inputMode='numeric'
                                        placeholder='123456'
                                        maxLength={6}
                                        {...methods.register('code')}
                                        className={`${fieldClass} pl-12 pr-4 tracking-[0.35em]`}
                                    />
                                </div>
                            </div>
                            <button
                                type='button'
                                onClick={() => {
                                    setShowTwoFactor(false)
                                    setChallengeId(null)
                                    methods.setValue('code', '')
                                }}
                                className='text-sm text-white/70 hover:text-white'
                            >
                                Back to login details
                            </button>
                        </div>
                    )}

                    <div className='pt-2'>
                        <button
                            type='submit'
                            disabled={methods.formState.isSubmitting}
                            className='btn-primary w-full rounded-lg py-3.5 disabled:cursor-not-allowed disabled:opacity-50'
                        >
                            {methods.formState.isSubmitting
                                ? showTwoFactor
                                    ? 'Verifying...'
                                    : 'Signing in...'
                                : showTwoFactor
                                ? 'Verify & Continue'
                                : 'Login'}
                        </button>
                    </div>

                    <div className='space-y-1 text-center text-xs text-[var(--text-muted)]'>
                        {!isTenantHost && !isResellerLogin && meta?.allowSelfRegistration ? (
                            <p>
                                Need an account?{' '}
                                <Link to='/register' className='text-[var(--tenant-brand-accent)] hover:brightness-125'>
                                    Create one
                                </Link>
                            </p>
                        ) : null}
                        {isResellerLogin ? (
                            <>
                                {!isTenantHost ? (
                                    <p>
                                        Need a reseller workspace?{' '}
                                        <Link to='/reseller/register' className='text-[var(--tenant-brand-accent)] hover:brightness-125'>
                                            Register as reseller
                                        </Link>
                                    </p>
                                ) : null}
                                {!isTenantHost ? (
                                    <p>
                                        Looking for the customer login?{' '}
                                        <Link to={tenantPath('/auth/login')} className='text-[var(--tenant-brand-accent)] hover:brightness-125'>
                                            Open user login
                                        </Link>
                                    </p>
                                ) : null}
                            </>
                        ) : !isTenantHost ? (
                            <p>
                                Already a reseller partner?{' '}
                                <Link to='/reseller/login' className='text-[var(--tenant-brand-accent)] hover:brightness-125'>
                                    Reseller admin login
                                </Link>
                            </p>
                        ) : null}
                        {meta?.enableEmail2fa ? (
                            <p className='text-[11px] text-white/55'>
                                Email 2FA is enabled for this tenant.
                            </p>
                        ) : null}
                    </div>
                </form>
            </FormProvider>
        </LoginFormContainer>
    )
}

export default LoginContainer
