import resendVerification from '@/api/auth/resendVerification'
import verifyEmail from '@/api/auth/verifyEmail'
import LoginFormContainer from '@/components/auth/LoginFormContainer'
import SafeImage from '@/components/elements/SafeImage'
import { useStoreState } from '@/state'
import { useEffect, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'

const VerifyEmailContainer = () => {
    const [params] = useSearchParams()
    const token = params.get('token') || ''
    const email = params.get('email') || ''

    const panelName = useStoreState(state => state.settings.data?.panelName || 'WammuCore')
    const panelLogoUrl = useStoreState(
        state => state.settings.data?.logoUrl || 'https://i.postimg.cc/wjVWzbcZ/hl.png'
    )
    const loginBackgroundImage = useStoreState(state => state.settings.data?.loginBackgroundImage || null)
    const bannerImageUrl = useStoreState(state => state.settings.data?.bannerImageUrl || null)
    const footerText = useStoreState(state => state.settings.data?.footerText || 'WammuCore')
    const footerUrl = useStoreState(state => state.settings.data?.footerUrl || 'https://wammuhost.com')
    const [busy, setBusy] = useState(false)
    const [message, setMessage] = useState<string | null>(null)
    const [error, setError] = useState<string | null>(null)

    useEffect(() => {
        document.title = `Verify Email | ${panelName}`

        if (!token) {
            return
        }

        setBusy(true)
        void verifyEmail(token)
            .then(response => setMessage(response.message || 'Email verified successfully.'))
            .catch((e: any) => setError(e?.response?.data?.message || 'Verification failed.'))
            .finally(() => setBusy(false))
    }, [token, panelName])

    const onResend = async () => {
        if (!email) {
            setError('Email address missing from the verification link.')
            return
        }

        setBusy(true)
        setError(null)
        setMessage(null)

        try {
            const response = await resendVerification(email)
            setMessage(response.message || 'Verification email resent.')
        } catch (e: any) {
            setError(e?.response?.data?.message || 'Unable to resend verification email.')
        } finally {
            setBusy(false)
        }
    }

    return (
        <LoginFormContainer
            title='Verify your email'
            description='Tenant-aware email verification for secure onboarding and account recovery.'
            panelName={panelName}
            footerText={footerText}
            footerUrl={footerUrl}
            backgroundImage={loginBackgroundImage}
            bannerImage={bannerImageUrl}
            logo={
                <SafeImage
                    src={panelLogoUrl}
                    alt={`${panelName} Logo`}
                    className='h-16 w-auto object-contain'
                    fallbackClassName='h-16 w-16'
                    fallbackText={panelName}
                />
            }
            submitting={busy}
        >
            <div className='space-y-4'>
                {message ? (
                    <div className='rounded-lg border border-emerald-400/30 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-100'>
                        {message}
                    </div>
                ) : null}
                {error ? (
                    <div className='rounded-lg border border-rose-400/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-100'>
                        {error}
                    </div>
                ) : null}

                {!token ? (
                    <div className='rounded-lg border border-indigo-400/25 bg-indigo-500/10 px-4 py-3 text-sm text-indigo-100'>
                        Open the verification link from your email to complete this step.
                    </div>
                ) : null}

                {email ? (
                    <button
                        type='button'
                        onClick={onResend}
                        disabled={busy}
                        className='w-full rounded-lg border border-white/20 bg-white/5 py-3 text-sm font-semibold text-white transition hover:bg-white/10 disabled:cursor-not-allowed disabled:opacity-55'
                    >
                        Resend verification email
                    </button>
                ) : null}

                <p className='text-center text-xs text-white/70'>
                    <Link to='/login' className='text-indigo-300 hover:text-indigo-200'>
                        Back to login
                    </Link>
                </p>
            </div>
        </LoginFormContainer>
    )
}

export default VerifyEmailContainer
