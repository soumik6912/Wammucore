import forgotPassword from '@/api/auth/forgotPassword'
import getClientAuthMeta from '@/api/auth/getClientAuthMeta'
import resetPassword from '@/api/auth/resetPassword'
import LoginFormContainer from '@/components/auth/LoginFormContainer'
import SafeImage from '@/components/elements/SafeImage'
import { useStoreState } from '@/state'
import { zodResolver } from '@hookform/resolvers/zod'
import { useEffect, useMemo, useState } from 'react'
import { useForm } from 'react-hook-form'
import { Link, useSearchParams } from 'react-router-dom'
import { z } from 'zod'

const ForgotPasswordContainer = () => {
    const [params] = useSearchParams()
    const token = params.get('token') || ''
    const emailFromLink = params.get('email') || ''
    const isResetFlow = token !== '' && emailFromLink !== ''

    const panelName = useStoreState(state => state.settings.data?.panelName || 'WammuCore')
    const panelLogoUrl = useStoreState(
        state => state.settings.data?.logoUrl || 'https://i.postimg.cc/wjVWzbcZ/hl.png'
    )
    const loginBackgroundImage = useStoreState(state => state.settings.data?.loginBackgroundImage || null)
    const bannerImageUrl = useStoreState(state => state.settings.data?.bannerImageUrl || null)
    const footerText = useStoreState(state => state.settings.data?.footerText || 'WammuCore')
    const footerUrl = useStoreState(state => state.settings.data?.footerUrl || 'https://wammuhost.com')
    const bootAuthMeta = useStoreState(state => state.settings.data?.clientAuth)
    const [passwordResetEnabled, setPasswordResetEnabled] = useState<boolean | null>(
        bootAuthMeta ? bootAuthMeta.passwordResetEnabled : null
    )
    const [message, setMessage] = useState<string | null>(null)
    const [error, setError] = useState<string | null>(null)
    const [formStartedAt] = useState(() => Date.now())
    const [companyWebsite, setCompanyWebsite] = useState('')

    useEffect(() => {
        document.title = `${isResetFlow ? 'Reset Password' : 'Forgot Password'} | ${panelName}`
    }, [isResetFlow, panelName])

    useEffect(() => {
        if (bootAuthMeta) {
            setPasswordResetEnabled(Boolean(bootAuthMeta.passwordResetEnabled))

            return
        }

        void getClientAuthMeta()
            .then(data => setPasswordResetEnabled(data.passwordResetEnabled))
            .catch(() => setPasswordResetEnabled(false))
    }, [bootAuthMeta])

    const emailSchema = z.preprocess(
        value => (typeof value === 'string' ? value.trim().toLowerCase() : value),
        z.string().email('Valid email required.')
    )

    const schema = useMemo(
        () =>
            isResetFlow
                ? z
                      .object({
                          email: emailSchema,
                          password: z.string().min(8, 'Password must be at least 8 characters.'),
                          passwordConfirmation: z.string().min(8, 'Confirm your password.'),
                      })
                      .refine(data => data.password === data.passwordConfirmation, {
                          message: 'Passwords do not match.',
                          path: ['passwordConfirmation'],
                      })
                : z.object({
                      email: emailSchema,
                  }),
        [isResetFlow]
    )

    const form = useForm<any>({
        resolver: zodResolver(schema),
        defaultValues: {
            email: emailFromLink,
            password: '',
            passwordConfirmation: '',
        },
    })

    const submit = async (values: any) => {
        setMessage(null)
        setError(null)

        try {
            if (isResetFlow) {
                const response = await resetPassword({
                    token,
                    email: values.email,
                    password: values.password,
                    passwordConfirmation: values.passwordConfirmation,
                    security: {
                        startedAt: formStartedAt,
                        honeypot: companyWebsite,
                    },
                })
                setMessage(response.message || 'Password reset successfully.')
            } else {
                const response = await forgotPassword(values.email, {
                    startedAt: formStartedAt,
                    honeypot: companyWebsite,
                })
                setMessage(response.message || 'If the account exists, an email has been sent.')
            }
        } catch (e: any) {
            setError(e?.response?.data?.message || 'Request failed.')
        }
    }

    return (
        <LoginFormContainer
            title={
                passwordResetEnabled === false
                    ? 'Password reset unavailable'
                    : isResetFlow
                    ? 'Reset your password'
                    : 'Forgot your password?'
            }
            description={
                passwordResetEnabled === false
                    ? 'Password reset is not enabled for this panel.'
                    : 'Secure account recovery with tenant-aware reset links and audit logging.'
            }
            panelName={panelName}
            footerText={footerText}
            footerUrl={footerUrl}
            backgroundImage={loginBackgroundImage}
            bannerImage={bannerImageUrl}
            logo={
                <SafeImage
                    src={panelLogoUrl}
                    alt={`${panelName} Logo`}
                    className='h-16 w-auto object-contain'
                    fallbackClassName='h-16 w-16'
                    fallbackText={panelName}
                />
            }
            submitting={form.formState.isSubmitting}
        >
            {passwordResetEnabled === null ? (
                <div className='rounded-lg border border-white/10 bg-white/5 px-4 py-3 text-sm text-white/75'>
                    Checking recovery settings...
                </div>
            ) : passwordResetEnabled === false ? (
                <div className='space-y-4'>
                    <div className='rounded-lg border border-amber-300/25 bg-amber-500/10 px-4 py-3 text-sm text-amber-100'>
                        Contact your provider if you need help accessing this account.
                    </div>
                    <p className='text-center text-xs text-white/70'>
                        <Link to='/login' className='text-indigo-300 hover:text-indigo-200'>
                            Back to login
                        </Link>
                    </p>
                </div>
            ) : (
            <form onSubmit={form.handleSubmit(submit)} className='space-y-4'>
                <div className='hidden' aria-hidden='true'>
                    <input
                        type='text'
                        tabIndex={-1}
                        autoComplete='off'
                        value={companyWebsite}
                        onChange={event => setCompanyWebsite(event.currentTarget.value)}
                    />
                </div>

                {message ? (
                    <div className='rounded-lg border border-emerald-400/30 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-100'>
                        {message}
                    </div>
                ) : null}
                {error ? (
                    <div className='rounded-lg border border-rose-400/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-100'>
                        {error}
                    </div>
                ) : null}

                <input
                    {...form.register('email')}
                    type='email'
                    placeholder='Email address'
                    disabled={isResetFlow}
                    className='h-11 w-full rounded-lg border border-purple-400/30 bg-[#0f0728]/95 px-3 text-sm text-white placeholder:text-purple-300/60 disabled:opacity-70'
                />

                {isResetFlow ? (
                    <>
                        <input
                            {...form.register('password')}
                            type='password'
                            placeholder='New password'
                            className='h-11 w-full rounded-lg border border-purple-400/30 bg-[#0f0728]/95 px-3 text-sm text-white placeholder:text-purple-300/60'
                        />
                        <input
                            {...form.register('passwordConfirmation')}
                            type='password'
                            placeholder='Confirm new password'
                            className='h-11 w-full rounded-lg border border-purple-400/30 bg-[#0f0728]/95 px-3 text-sm text-white placeholder:text-purple-300/60'
                        />
                    </>
                ) : null}

                <button
                    type='submit'
                    disabled={form.formState.isSubmitting}
                    className='w-full rounded-lg bg-[#2563eb] py-3 text-sm font-semibold text-white transition hover:bg-[#1d4ed8] disabled:cursor-not-allowed disabled:opacity-55'
                >
                    {form.formState.isSubmitting
                        ? isResetFlow
                            ? 'Resetting...'
                            : 'Sending...'
                        : isResetFlow
                        ? 'Reset Password'
                        : 'Send Reset Link'}
                </button>

                <p className='text-center text-xs text-white/70'>
                    <Link to='/login' className='text-indigo-300 hover:text-indigo-200'>
                        Back to login
                    </Link>
                </p>
            </form>
            )}
        </LoginFormContainer>
    )
}

export default ForgotPasswordContainer
