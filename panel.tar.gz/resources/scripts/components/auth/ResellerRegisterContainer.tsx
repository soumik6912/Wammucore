import getResellerRegistrationMeta from '@/api/auth/getResellerRegistrationMeta'
import registerReseller from '@/api/auth/registerReseller'
import LoginFormContainer from '@/components/auth/LoginFormContainer'
import SafeImage from '@/components/elements/SafeImage'
import { useStoreState } from '@/state'
import { FormEvent, useCallback, useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'

const HOSTNAME_PATTERN =
    /^(?:\*\.)?(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/i
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

const normalizeEmail = (value: string): string => value.trim().toLowerCase()

type FieldErrors = Partial<
    Record<
        | 'displayName'
        | 'domain'
        | 'adminName'
        | 'adminEmail'
        | 'adminPassword'
        | 'adminPasswordConfirmation'
        | 'agreeTerms',
        string
    >
>

const normalizeDomain = (value: string): string => {
    const trimmed = value.trim().toLowerCase()
    const withoutProtocol = trimmed.replace(/^https?:\/\//, '')

    return withoutProtocol
        .replace(/[?#].*$/, '')
        .split('/')[0]
        .replace(/\.+$/g, '')
        .replace(/^\/+|\/+$/g, '')
}

const inputClass = (hasError: boolean): string =>
    `h-11 w-full rounded-lg border px-3 text-sm text-white placeholder:text-purple-300/60 outline-none transition-colors ${
        hasError
            ? 'border-rose-400/70 bg-rose-500/10 focus:border-rose-300'
            : 'border-purple-400/30 bg-[#0f0728]/95 focus:border-indigo-300'
    }`

const labelClass = 'mb-2 block text-sm font-medium text-white/85'
const hintClass = 'mt-1.5 text-xs leading-5 text-white/50'
const errorClass = 'mt-1.5 text-xs leading-5 text-rose-200'
const REGISTRATION_DRAFT_KEY = 'wammucore.reseller-registration.draft.v1'
const REGISTRATION_CONTEXT_KEY = 'wammucore.reseller-registration.context.v1'

interface RegistrationDraft {
    displayName: string
    domain: string
    adminName: string
    adminEmail: string
    agreeTerms: boolean
}

const defaultKycPolicy = () => ({
    allowedProofTypes: ['aadhaar', 'pan'] as Array<'aadhaar' | 'pan'>,
    aadhaarEnabled: true,
    panEnabled: true,
    digilockerEnabled: false,
    digilockerUrl: null,
})

let resellerExperienceWarmup: Promise<unknown> | null = null

const emptyRegistrationDraft = (): RegistrationDraft => ({
    displayName: '',
    domain: '',
    adminName: '',
    adminEmail: '',
    agreeTerms: false,
})

const readRegistrationDraft = (): RegistrationDraft => {
    if (typeof window === 'undefined') {
        return emptyRegistrationDraft()
    }

    try {
        const parsed = JSON.parse(
            window.localStorage.getItem(REGISTRATION_DRAFT_KEY) || '{}'
        ) as Partial<RegistrationDraft>

        return {
            displayName: String(parsed.displayName ?? ''),
            domain: String(parsed.domain ?? ''),
            adminName: String(parsed.adminName ?? ''),
            adminEmail: String(parsed.adminEmail ?? ''),
            agreeTerms: Boolean(parsed.agreeTerms),
        }
    } catch {
        return emptyRegistrationDraft()
    }
}

const writeRegistrationDraft = (draft: RegistrationDraft) => {
    if (typeof window === 'undefined') {
        return
    }

    try {
        const hasDraft = [
            draft.displayName,
            draft.domain,
            draft.adminName,
            draft.adminEmail,
        ].some(value => value.trim() !== '') || draft.agreeTerms

        if (!hasDraft) {
            window.localStorage.removeItem(REGISTRATION_DRAFT_KEY)
            return
        }

        window.localStorage.setItem(
            REGISTRATION_DRAFT_KEY,
            JSON.stringify({
                ...draft,
                savedAt: new Date().toISOString(),
            })
        )
    } catch {
        // Ignore storage errors; registration still works normally.
    }
}

const clearRegistrationDraft = () => {
    if (typeof window === 'undefined') {
        return
    }

    try {
        window.localStorage.removeItem(REGISTRATION_DRAFT_KEY)
    } catch {
        // Ignore storage errors.
    }
}

const writeRegistrationContext = (context: {
    resellerId: number
    tenantUuid: string | null
    slug: string | null
    panelDomain: string
    adminEmail: string
}) => {
    if (typeof window === 'undefined') {
        return
    }

    try {
        window.localStorage.setItem(
            REGISTRATION_CONTEXT_KEY,
            JSON.stringify({
                ...context,
                savedAt: new Date().toISOString(),
            })
        )
    } catch {
        // Ignore storage errors; the server session still carries context.
    }
}

const warmResellerExperience = (): Promise<unknown> => {
    if (resellerExperienceWarmup) {
        return resellerExperienceWarmup
    }

    resellerExperienceWarmup = Promise.all([
        import('@/routers/AdminDashboardRouter'),
        import('@/components/admin/resellerPanel/ResellerOnboardingContainer'),
        import('@/components/admin/resellerPanel/ResellerAdminPanelContainer'),
    ]).catch(() => undefined)

    return resellerExperienceWarmup
}

const extractFieldErrors = (err: any): FieldErrors => {
    const source = err?.response?.data?.errors
    if (!source || typeof source !== 'object') {
        return {}
    }

    const map: Record<string, keyof FieldErrors> = {
        name: 'displayName',
        display_name: 'displayName',
        domain: 'domain',
        admin_name: 'adminName',
        admin_email: 'adminEmail',
        admin_password: 'adminPassword',
        admin_password_confirmation: 'adminPasswordConfirmation',
        agree_terms: 'agreeTerms',
    }

    return Object.entries(source).reduce((carry, [key, value]) => {
        const target = map[key]
        const message = Array.isArray(value) ? value[0] : value
        if (target && typeof message === 'string' && message.trim() !== '') {
            carry[target] = message
        }

        return carry
    }, {} as FieldErrors)
}

const ResellerRegisterContainer = () => {
    const panelName = useStoreState(
        state => state.settings.data?.panelName || 'WammuHost'
    )
    const panelLogoUrl = useStoreState(
        state =>
            state.settings.data?.logoUrl ||
            'https://i.postimg.cc/wjVWzbcZ/hl.png'
    )
    const loginBackgroundImage = useStoreState(
        state => state.settings.data?.loginBackgroundImage || null
    )
    const bannerImageUrl = useStoreState(
        state => state.settings.data?.bannerImageUrl || null
    )
    const footerText = useStoreState(
        state => state.settings.data?.footerText || panelName
    )
    const footerUrl = useStoreState(
        state => state.settings.data?.footerUrl || 'https://wammuhost.com'
    )
    const bootResellerMeta = useStoreState(
        state => state.settings.data?.resellerRegistrationMeta
    )
    const initialDraft = useMemo(() => readRegistrationDraft(), [])

    const [displayName, setDisplayName] = useState(initialDraft.displayName)
    const [domain, setDomain] = useState(initialDraft.domain)
    const [adminName, setAdminName] = useState(initialDraft.adminName)
    const [adminEmail, setAdminEmail] = useState(initialDraft.adminEmail)
    const [adminPassword, setAdminPassword] = useState('')
    const [adminPasswordConfirmation, setAdminPasswordConfirmation] =
        useState('')
    const [agreeTerms, setAgreeTerms] = useState(initialDraft.agreeTerms)
    const [formStartedAt] = useState(() => Date.now())
    const [companyWebsite, setCompanyWebsite] = useState('')

    const [isLoadingMeta, setIsLoadingMeta] = useState(() => !bootResellerMeta)
    const [isRegistrationEnabled, setIsRegistrationEnabled] = useState(
        () => bootResellerMeta?.enabled ?? false
    )
    const [registrationDisabledMessage, setRegistrationDisabledMessage] =
        useState(
            () =>
                bootResellerMeta?.hostMessage ||
                'Reseller registration is disabled by root admin.'
        )
    const [termsUrl, setTermsUrl] = useState<string | null>(
        () => bootResellerMeta?.termsUrl ?? null
    )
    const [privacyUrl, setPrivacyUrl] = useState<string | null>(
        () => bootResellerMeta?.privacyUrl ?? null
    )
    const [kycPolicy, setKycPolicy] = useState(
        () => bootResellerMeta?.kycPolicy ?? defaultKycPolicy()
    )
    const [fieldErrors, setFieldErrors] = useState<FieldErrors>({})
    const [error, setError] = useState<string | null>(null)
    const [success, setSuccess] = useState<string | null>(null)
    const [isSubmitting, setIsSubmitting] = useState(false)

    useEffect(() => {
        document.title = `Reseller Register | ${panelName}`
    }, [panelName])

    useEffect(() => {
        writeRegistrationDraft({
            displayName,
            domain,
            adminName,
            adminEmail,
            agreeTerms,
        })
    }, [displayName, domain, adminName, adminEmail, agreeTerms])

    const prefetchResellerExperience = useCallback(() => {
        void warmResellerExperience()
    }, [])

    useEffect(() => {
        if (bootResellerMeta) {
            setIsRegistrationEnabled(bootResellerMeta.enabled)
            setRegistrationDisabledMessage(
                bootResellerMeta.hostMessage ||
                    'Reseller registration is disabled by root admin.'
            )
            setTermsUrl(bootResellerMeta.termsUrl)
            setPrivacyUrl(bootResellerMeta.privacyUrl)
            setKycPolicy(bootResellerMeta.kycPolicy ?? defaultKycPolicy())
            setIsLoadingMeta(false)

            return
        }

        getResellerRegistrationMeta()
            .then(meta => {
                setIsRegistrationEnabled(meta.enabled)
                setRegistrationDisabledMessage(
                    meta.hostMessage ||
                        'Reseller registration is disabled by root admin.'
                )
                setTermsUrl(meta.termsUrl)
                setPrivacyUrl(meta.privacyUrl)
                setKycPolicy(meta.kycPolicy)
            })
            .catch(() => {
                setError('Unable to load registration configuration.')
            })
            .finally(() => setIsLoadingMeta(false))
    }, [bootResellerMeta])

    const passwordChecks = useMemo(
        () => [
            {
                label: 'At least 8 characters',
                ok: adminPassword.length >= 8,
            },
            {
                label: 'One uppercase letter',
                ok: /[A-Z]/.test(adminPassword),
            },
            {
                label: 'One lowercase letter',
                ok: /[a-z]/.test(adminPassword),
            },
            {
                label: 'One number',
                ok: /[0-9]/.test(adminPassword),
            },
            {
                label: 'One special character',
                ok: /[!@#$%^&*]/.test(adminPassword),
            },
        ],
        [adminPassword]
    )

    const validate = (): FieldErrors => {
        const next: FieldErrors = {}
        const normalizedDomain = normalizeDomain(domain)

        if (displayName.trim().length < 2) {
            next.displayName =
                'Enter your hosting brand or reseller business name.'
        }

        if (normalizedDomain === '') {
            next.domain = 'Enter the VPS panel hostname you want to use.'
        } else if (!HOSTNAME_PATTERN.test(normalizedDomain)) {
            next.domain =
                'Use a hostname only, like vps.yourdomain.com. Do not include http:// or https://.'
        }

        const normalizedAdminEmail = normalizeEmail(adminEmail)

        if (normalizedAdminEmail === '') {
            next.adminEmail =
                'Enter the email address for the reseller admin account.'
        } else if (!EMAIL_PATTERN.test(normalizedAdminEmail)) {
            next.adminEmail = 'Enter a valid admin email address.'
        }

        if (adminName.trim() !== '' && adminName.trim().length < 2) {
            next.adminName = 'Admin name should be at least 2 characters long.'
        }

        if (adminPassword.length < 8) {
            next.adminPassword = 'Password must be at least 8 characters long.'
        } else if (!passwordChecks.every(item => item.ok)) {
            next.adminPassword =
                'Use at least 8 characters with uppercase, lowercase, number, and special character.'
        }

        if (adminPasswordConfirmation === '') {
            next.adminPasswordConfirmation =
                'Confirm the reseller admin password.'
        } else if (adminPassword !== adminPasswordConfirmation) {
            next.adminPasswordConfirmation =
                'Password confirmation does not match.'
        }

        if (!agreeTerms) {
            next.agreeTerms =
                'You must accept the terms and privacy policy before continuing.'
        }

        return next
    }

    const liveFieldErrors = validate()
    const hasLiveFieldErrors = Object.keys(liveFieldErrors).length > 0
    const canAttemptSubmit =
        isRegistrationEnabled && !isLoadingMeta && !isSubmitting

    const scrollToRegistrationStatus = () => {
        if (typeof window === 'undefined') {
            return
        }

        window.requestAnimationFrame(() => {
            window.document
                .getElementById('reseller-register-status')
                ?.scrollIntoView({ behavior: 'smooth', block: 'center' })
        })
    }

    useEffect(() => {
        if (Object.keys(fieldErrors).length > 0) {
            setFieldErrors(validate())
        }
        // Keep visible errors fresh after a failed submit without showing errors before the user tries.
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        displayName,
        domain,
        adminName,
        adminEmail,
        adminPassword,
        adminPasswordConfirmation,
        agreeTerms,
    ])

    const submit = async (event: FormEvent<HTMLFormElement>) => {
        event.preventDefault()
        setError(null)
        setSuccess(null)
        prefetchResellerExperience()

        if (!isRegistrationEnabled) {
            setError(registrationDisabledMessage)
            scrollToRegistrationStatus()
            return
        }

        const nextFieldErrors = validate()
        setFieldErrors(nextFieldErrors)
        if (Object.keys(nextFieldErrors).length > 0) {
            setError('Please fix the highlighted fields and try again.')
            scrollToRegistrationStatus()
            return
        }

        setIsSubmitting(true)
        try {
            const response = await registerReseller({
                displayName,
                domain: normalizeDomain(domain),
                adminName: adminName.trim() || null,
                adminEmail: normalizeEmail(adminEmail),
                adminPassword,
                adminPasswordConfirmation,
                agreeTerms,
                security: {
                    startedAt: formStartedAt,
                    honeypot: companyWebsite,
                },
            })

            writeRegistrationContext({
                resellerId: response.resellerId,
                tenantUuid: response.tenantUuid,
                slug: response.slug,
                panelDomain: response.panelDomain,
                adminEmail: normalizeEmail(adminEmail),
            })

            if (response.autoLoggedIn && response.redirectPath) {
                clearRegistrationDraft()
                window.location.assign(response.redirectPath)
                return
            }

            setSuccess(
                `${response.message} Request ID #${response.resellerId} created for ${response.panelDomain}.`
            )
            setFieldErrors({})
            clearRegistrationDraft()
            setDisplayName('')
            setDomain('')
            setAdminName('')
            setAdminEmail('')
            setAdminPassword('')
            setAdminPasswordConfirmation('')
            setAgreeTerms(false)
        } catch (err: any) {
            const apiFieldErrors = extractFieldErrors(err)
            if (Object.keys(apiFieldErrors).length > 0) {
                setFieldErrors(apiFieldErrors)
                setError('Please review the highlighted fields and try again.')
            } else {
                setError(
                    err?.response?.data?.message || 'Registration failed.'
                )
            }
            scrollToRegistrationStatus()
        } finally {
            setIsSubmitting(false)
        }
    }

    return (
        <LoginFormContainer
            title='Register as Reseller'
            description='Create your reseller owner account and reserve your branded VPS panel workspace.'
            submitting={isSubmitting || isLoadingMeta}
            panelName={panelName}
            footerText={footerText}
            footerUrl={footerUrl}
            backgroundImage={loginBackgroundImage}
            bannerImage={bannerImageUrl}
            logo={
                <SafeImage
                    src={panelLogoUrl}
                    alt={`${panelName} Logo`}
                    className='h-16 w-auto object-contain'
                    fallbackClassName='h-16 w-16'
                    fallbackText={panelName}
                />
            }
        >
            <form
                noValidate
                autoComplete='on'
                onSubmit={submit}
                onFocusCapture={prefetchResellerExperience}
                onPointerEnter={prefetchResellerExperience}
                className='space-y-3.5'
            >
                <div className='hidden' aria-hidden='true'>
                    <input
                        type='text'
                        tabIndex={-1}
                        autoComplete='off'
                        value={companyWebsite}
                        onChange={event =>
                            setCompanyWebsite(event.currentTarget.value)
                        }
                    />
                </div>

                <div id='reseller-register-status' className='scroll-mt-24' aria-live='polite'>
                {success ? (
                    <div className='rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-3 py-2 text-sm text-emerald-200'>
                        {success}
                    </div>
                ) : null}
                {error ? (
                    <div className='rounded-lg border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-200'>
                        {error}
                    </div>
                ) : null}
                </div>

                {!isRegistrationEnabled && !isLoadingMeta ? (
                    <div className='rounded-lg border border-amber-400/40 bg-amber-500/10 px-3 py-2 text-sm text-amber-100'>
                        {registrationDisabledMessage}
                    </div>
                ) : null}

                <div className='rounded-xl border border-white/10 bg-white/[0.03] p-4'>
                    <div className='flex flex-wrap items-start justify-between gap-3'>
                        <div>
                            <h3 className='text-sm font-semibold text-white'>
                                Reseller brand
                            </h3>
                            <p className='mt-1 text-xs leading-5 text-white/50'>
                                Set the name, logo, and VPS hostname your customers will recognize.
                            </p>
                        </div>
                        <div className='rounded-full border border-indigo-400/25 bg-indigo-500/10 px-3 py-1 text-[11px] font-medium text-indigo-100/90'>
                            VPS panel setup
                        </div>
                    </div>

                    <div className='mt-4 grid gap-3 sm:grid-cols-2'>
                        <div>
                            <label className={labelClass}>
                                Hosting / reseller name
                            </label>
                            <input
                                type='text'
                                placeholder='WammuHost'
                                autoComplete='organization'
                                value={displayName}
                                onChange={event =>
                                    setDisplayName(event.currentTarget.value)
                                }
                                className={inputClass(Boolean(fieldErrors.displayName))}
                            />
                            <p className={fieldErrors.displayName ? errorClass : hintClass}>
                                {fieldErrors.displayName ||
                                    'This name appears on your reseller dashboard and branding.'}
                            </p>
                        </div>

                        <div className='sm:col-span-2'>
                            <label className={labelClass}>
                                Preferred VPS panel domain
                            </label>
                            <input
                                type='text'
                                placeholder='vps.yourdomain.com'
                                autoComplete='url'
                                value={domain}
                                onChange={event =>
                                    setDomain(event.currentTarget.value)
                                }
                                className={inputClass(Boolean(fieldErrors.domain))}
                            />
                            <p className={fieldErrors.domain ? errorClass : hintClass}>
                                {fieldErrors.domain ||
                                    'Use hostname only, like vps.yourdomain.com. Final DNS/CNAME setup happens later during onboarding.'}
                            </p>
                        </div>
                    </div>
                </div>

                <div className='rounded-xl border border-white/10 bg-white/[0.03] p-4'>
                    <div className='flex flex-wrap items-start justify-between gap-3'>
                        <div>
                            <h3 className='text-sm font-semibold text-white'>
                                Owner access
                            </h3>
                            <p className='mt-1 text-xs leading-5 text-white/50'>
                                These details create the first reseller admin login.
                            </p>
                        </div>
                        <div className='rounded-full border border-emerald-400/25 bg-emerald-500/10 px-3 py-1 text-[11px] font-medium text-emerald-100/90'>
                            Secure admin account
                        </div>
                    </div>

                    <div className='mt-4 grid gap-3 sm:grid-cols-2'>
                        <div>
                            <label className={labelClass}>Admin name</label>
                            <input
                                type='text'
                                placeholder='Soumik'
                                autoComplete='name'
                                value={adminName}
                                onChange={event =>
                                    setAdminName(event.currentTarget.value)
                                }
                                className={inputClass(Boolean(fieldErrors.adminName))}
                            />
                            <p className={fieldErrors.adminName ? errorClass : hintClass}>
                                {fieldErrors.adminName ||
                                    'Optional. If you leave this empty, we will create a default admin name for you.'}
                            </p>
                        </div>

                        <div>
                            <label className={labelClass}>Admin email</label>
                            <input
                                type='email'
                                placeholder='admin@yourdomain.com'
                                autoComplete='username'
                                value={adminEmail}
                                onChange={event =>
                                    setAdminEmail(event.currentTarget.value)
                                }
                                onBlur={event =>
                                    setAdminEmail(normalizeEmail(event.currentTarget.value))
                                }
                                className={inputClass(Boolean(fieldErrors.adminEmail))}
                            />
                            <p className={fieldErrors.adminEmail ? errorClass : hintClass}>
                                {fieldErrors.adminEmail ||
                                    'This email will be used for reseller login, approval notices, and security checks.'}
                            </p>
                        </div>

                        <div className='sm:col-span-2 grid gap-3 sm:grid-cols-2'>
                            <div>
                            <label className={labelClass}>Admin password</label>
                            <input
                                type='password'
                                placeholder='Create a strong password'
                                autoComplete='new-password'
                                value={adminPassword}
                                onChange={event =>
                                    setAdminPassword(event.currentTarget.value)
                                }
                                className={inputClass(Boolean(fieldErrors.adminPassword))}
                            />
                            <p className={fieldErrors.adminPassword ? errorClass : hintClass}>
                                {fieldErrors.adminPassword ||
                                    'Use uppercase, lowercase, number, and special character.'}
                            </p>
                            </div>

                            <div>
                            <label className={labelClass}>
                                Confirm admin password
                            </label>
                            <input
                                type='password'
                                placeholder='Repeat the same password'
                                autoComplete='new-password'
                                value={adminPasswordConfirmation}
                                onChange={event =>
                                    setAdminPasswordConfirmation(
                                        event.currentTarget.value
                                    )
                                }
                                className={inputClass(
                                    Boolean(fieldErrors.adminPasswordConfirmation)
                                )}
                            />
                            <p
                                className={
                                    fieldErrors.adminPasswordConfirmation
                                        ? errorClass
                                        : hintClass
                                }
                            >
                                {fieldErrors.adminPasswordConfirmation ||
                                    'Make sure this matches the password above exactly.'}
                            </p>
                            </div>
                        </div>
                    </div>

                    <div className='mt-3 flex flex-wrap gap-2'>
                        {passwordChecks.map(item => (
                            <div
                                key={item.label}
                                className={`rounded-full px-2.5 py-1 text-[11px] ${
                                    item.ok
                                        ? 'border border-emerald-400/30 bg-emerald-500/10 text-emerald-200'
                                        : 'border border-white/10 bg-white/5 text-white/55'
                                }`}
                            >
                                {item.label}
                            </div>
                        ))}
                    </div>
                </div>

                <div className='rounded-xl border border-cyan-300/20 bg-cyan-500/10 p-4 text-sm text-cyan-50'>
                    <div className='flex flex-wrap items-start justify-between gap-3'>
                        <div>
                            <h3 className='text-sm font-semibold text-white'>
                                KYC after registration
                            </h3>
                            <p className='mt-1 text-xs leading-5 text-cyan-50/65'>
                                After your reseller account is created, choose one enabled proof during onboarding.
                            </p>
                        </div>
                        {kycPolicy.digilockerEnabled ? (
                            <span className='rounded-full border border-sky-200/25 bg-sky-400/15 px-3 py-1 text-[11px] font-medium text-sky-50'>
                                DigiLocker available
                            </span>
                        ) : null}
                    </div>
                    <div className='mt-3 flex flex-wrap gap-2'>
                        {kycPolicy.allowedProofTypes.includes('aadhaar') ? (
                            <span className='rounded-full border border-white/10 bg-black/20 px-3 py-1 text-xs text-white/80'>
                                Aadhaar: front + back upload
                            </span>
                        ) : null}
                        {kycPolicy.allowedProofTypes.includes('pan') ? (
                            <span className='rounded-full border border-white/10 bg-black/20 px-3 py-1 text-xs text-white/80'>
                                PAN: document upload
                            </span>
                        ) : null}
                    </div>
                </div>

                <div className='rounded-xl border border-white/10 bg-white/[0.03] p-4'>
                    <div className='flex items-start gap-3'>
                        <input
                            id='reseller-terms-consent'
                            type='checkbox'
                            checked={agreeTerms}
                            onChange={event =>
                                setAgreeTerms(event.currentTarget.checked)
                            }
                            className='mt-0.5 h-4 w-4 rounded border border-purple-500/40 bg-transparent'
                        />
                        <div className='flex-1'>
                            <label
                                htmlFor='reseller-terms-consent'
                                className='block cursor-pointer text-sm font-medium text-white'
                            >
                                I agree to the terms and privacy policy
                            </label>
                            <p className='mt-1 text-xs leading-5 text-white/50'>
                                You can review both documents before submitting.
                            </p>
                            {(termsUrl || privacyUrl) && (
                                <div className='mt-2 flex flex-wrap gap-x-3 gap-y-1 text-xs'>
                                    {termsUrl ? (
                                        <a
                                            href={termsUrl}
                                            target='_blank'
                                            rel='noreferrer'
                                            className='text-indigo-300 hover:text-indigo-200 underline underline-offset-2'
                                        >
                                            Open Terms
                                        </a>
                                    ) : null}
                                    {privacyUrl ? (
                                        <a
                                            href={privacyUrl}
                                            target='_blank'
                                            rel='noreferrer'
                                            className='text-indigo-300 hover:text-indigo-200 underline underline-offset-2'
                                        >
                                            Open Privacy Policy
                                        </a>
                                    ) : null}
                                </div>
                            )}
                            {fieldErrors.agreeTerms ? (
                                <span className='mt-1.5 block text-xs text-rose-200'>
                                    {fieldErrors.agreeTerms}
                                </span>
                            ) : null}
                        </div>
                    </div>
                </div>

                <button
                    type='submit'
                    disabled={!canAttemptSubmit}
                    className={`w-full rounded-lg py-3 text-sm font-semibold text-white transition ${
                        canAttemptSubmit
                            ? 'bg-[#2563eb] shadow-[0_0_28px_rgba(37,99,235,0.32)] hover:bg-[#1d4ed8]'
                            : 'cursor-not-allowed bg-white/10 text-white/45'
                    }`}
                    title={
                        canAttemptSubmit
                            ? hasLiveFieldErrors
                                ? 'Submit to show the fields that need attention.'
                                : 'Submit reseller registration'
                            : isLoadingMeta
                              ? 'Loading reseller registration settings.'
                              : !isRegistrationEnabled
                                ? registrationDisabledMessage
                                : 'Please wait while the request is submitting.'
                    }
                >
                    {isSubmitting
                        ? 'Submitting...'
                        : hasLiveFieldErrors
                          ? 'Check & Submit'
                          : 'Submit Registration'}
                </button>

                <div className='text-center text-xs text-white/70'>
                    Already have access?{' '}
                    <Link
                        to='/reseller/login'
                        className='text-indigo-300 hover:text-indigo-200'
                    >
                        Reseller login
                    </Link>
                </div>
            </form>
        </LoginFormContainer>
    )
}

export default ResellerRegisterContainer
