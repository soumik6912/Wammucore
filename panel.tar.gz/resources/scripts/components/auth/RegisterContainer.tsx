import getClientAuthMeta from '@/api/auth/getClientAuthMeta'
import register from '@/api/auth/register'
import LoginFormContainer from '@/components/auth/LoginFormContainer'
import SafeImage from '@/components/elements/SafeImage'
import { useStoreState } from '@/state'
import { zodResolver } from '@hookform/resolvers/zod'
import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { Link } from 'react-router-dom'
import { z } from 'zod'

const RegisterContainer = () => {
    const panelName = useStoreState(state => state.settings.data?.panelName || 'WammuCore')
    const panelLogoUrl = useStoreState(
        state => state.settings.data?.logoUrl || 'https://i.postimg.cc/wjVWzbcZ/hl.png'
    )
    const loginBackgroundImage = useStoreState(state => state.settings.data?.loginBackgroundImage || null)
    const bannerImageUrl = useStoreState(state => state.settings.data?.bannerImageUrl || null)
    const footerText = useStoreState(state => state.settings.data?.footerText || 'WammuCore')
    const footerUrl = useStoreState(state => state.settings.data?.footerUrl || 'https://wammuhost.com')
    const bootAuthMeta = useStoreState(state => state.settings.data?.clientAuth)
    const [allowed, setAllowed] = useState<boolean | null>(null)
    const [emailVerification, setEmailVerification] = useState(false)
    const [error, setError] = useState<string | null>(null)
    const [message, setMessage] = useState<string | null>(null)
    const [formStartedAt] = useState(() => Date.now())
    const [companyWebsite, setCompanyWebsite] = useState('')

    useEffect(() => {
        document.title = `Register | ${panelName}`
        if (bootAuthMeta) {
            setAllowed(bootAuthMeta.allowSelfRegistration)
            setEmailVerification(bootAuthMeta.enableEmailVerification)

            return
        }

        void getClientAuthMeta()
            .then(meta => {
                setAllowed(meta.allowSelfRegistration)
                setEmailVerification(meta.enableEmailVerification)
            })
            .catch(() => setAllowed(false))
    }, [panelName, bootAuthMeta])

    const emailSchema = z.preprocess(
        value => (typeof value === 'string' ? value.trim().toLowerCase() : value),
        z.string().email('Valid email required.')
    )

    const schema = z
        .object({
            name: z.string().min(2, 'Name is required.'),
            email: emailSchema,
            password: z.string().min(8, 'Password must be at least 8 characters.'),
            passwordConfirmation: z.string().min(8, 'Confirm your password.'),
        })
        .refine(data => data.password === data.passwordConfirmation, {
            message: 'Passwords do not match.',
            path: ['passwordConfirmation'],
        })

    const form = useForm<z.infer<typeof schema>>({
        resolver: zodResolver(schema),
        defaultValues: {
            name: '',
            email: '',
            password: '',
            passwordConfirmation: '',
        },
    })

    const submit = async (values: z.infer<typeof schema>) => {
        setError(null)
        setMessage(null)

        try {
            const response = await register({
                ...values,
                security: {
                    startedAt: formStartedAt,
                    honeypot: companyWebsite,
                },
            })
            if (response.requires_email_verification) {
                setMessage(response.message || 'Please verify your email address.')
                return
            }

            window.location.assign('/')
        } catch (e: any) {
            setError(e?.response?.data?.message || 'Registration failed.')
        }
    }

    return (
        <LoginFormContainer
            title='Create your account'
            description='Secure tenant-aware sign-up for customers buying and managing VPS services.'
            panelName={panelName}
            footerText={footerText}
            footerUrl={footerUrl}
            backgroundImage={loginBackgroundImage}
            bannerImage={bannerImageUrl}
            logo={
                <SafeImage
                    src={panelLogoUrl}
                    alt={`${panelName} Logo`}
                    className='h-16 w-auto object-contain'
                    fallbackClassName='h-16 w-16'
                    fallbackText={panelName}
                />
            }
            submitting={form.formState.isSubmitting}
        >
            {!allowed ? (
                <div className='rounded-lg border border-amber-400/30 bg-amber-500/10 px-4 py-3 text-sm text-amber-100'>
                    Customer self-registration is disabled on this tenant.
                </div>
            ) : (
                <form onSubmit={form.handleSubmit(submit)} className='space-y-4'>
                    <div className='hidden' aria-hidden='true'>
                        <input
                            type='text'
                            tabIndex={-1}
                            autoComplete='off'
                            value={companyWebsite}
                            onChange={event => setCompanyWebsite(event.currentTarget.value)}
                        />
                    </div>

                    {message ? (
                        <div className='rounded-lg border border-emerald-400/30 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-100'>
                            {message}
                        </div>
                    ) : null}
                    {error ? (
                        <div className='rounded-lg border border-rose-400/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-100'>
                            {error}
                        </div>
                    ) : null}

                    <input
                        {...form.register('name')}
                        placeholder='Full name'
                        className='h-11 w-full rounded-lg border border-purple-400/30 bg-[#0f0728]/95 px-3 text-sm text-white placeholder:text-purple-300/60'
                    />
                    <input
                        {...form.register('email')}
                        type='email'
                        placeholder='Email address'
                        className='h-11 w-full rounded-lg border border-purple-400/30 bg-[#0f0728]/95 px-3 text-sm text-white placeholder:text-purple-300/60'
                    />
                    <input
                        {...form.register('password')}
                        type='password'
                        placeholder='Password'
                        className='h-11 w-full rounded-lg border border-purple-400/30 bg-[#0f0728]/95 px-3 text-sm text-white placeholder:text-purple-300/60'
                    />
                    <input
                        {...form.register('passwordConfirmation')}
                        type='password'
                        placeholder='Confirm password'
                        className='h-11 w-full rounded-lg border border-purple-400/30 bg-[#0f0728]/95 px-3 text-sm text-white placeholder:text-purple-300/60'
                    />

                    <div className='rounded-lg border border-indigo-400/25 bg-indigo-500/10 px-3 py-2 text-xs text-indigo-100/90'>
                        {emailVerification
                            ? 'Email verification is enabled for new customer accounts on this tenant.'
                            : 'Email verification is currently skipped for new customer accounts on this tenant.'}
                    </div>

                    <button
                        type='submit'
                        disabled={form.formState.isSubmitting}
                        className='w-full rounded-lg bg-[#2563eb] py-3 text-sm font-semibold text-white transition hover:bg-[#1d4ed8] disabled:cursor-not-allowed disabled:opacity-55'
                    >
                        {form.formState.isSubmitting ? 'Creating account...' : 'Register'}
                    </button>

                    <p className='text-center text-xs text-white/70'>
                        Already have an account?{' '}
                        <Link to='/login' className='text-indigo-300 hover:text-indigo-200'>
                            Login
                        </Link>
                    </p>
                </form>
            )}
        </LoginFormContainer>
    )
}

export default RegisterContainer
