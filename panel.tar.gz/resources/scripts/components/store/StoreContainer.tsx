import getServers from '@/api/getServers'
import { ServerBuild } from '@/api/server/getServer'
import getStorePlans, {
    StoreLocationOption,
    StorePlan,
} from '@/api/store/getStorePlans'
import PageContentBlock from '@/components/elements/PageContentBlock'
import Spinner from '@/components/elements/Spinner'
import { useStoreState } from '@/state'
import { formatBytes } from '@/util/helpers'
import { normalizeExternalUrl } from '@/util/storefront'
import useNotify from '@/util/useNotify'
import { useEffect, useState } from 'react'
import { Link, Navigate } from 'react-router-dom'

const toGb = (mb: number): string => `${(mb / 1024).toFixed(1)} GB`
const toSizeLabel = (bytes: number | null | undefined): string => {
    if (!bytes || bytes <= 0) {
        return 'Unlimited'
    }

    const formatted = formatBytes(bytes)

    return `${formatted.size} ${formatted.unit}`
}

const setupStatuses = [
    'installing',
    'restoring_backup',
    'restoring_snapshot',
    'deleting',
]

const blockedSetupStatuses = ['install_failed', 'deletion_failed']

const serverSetupState = (status: string | null | undefined) => {
    const value = String(status || '').toLowerCase()

    if (setupStatuses.includes(value)) {
        return {
            locked: true,
            label: value === 'restoring_backup' || value === 'restoring_snapshot'
                ? 'Restoring'
                : value === 'deleting'
                  ? 'Deleting'
                  : 'Installing',
            message: 'VPS setup is still running. Panel access and upgrades unlock after setup completes.',
        }
    }

    if (blockedSetupStatuses.includes(value)) {
        return {
            locked: true,
            label: value === 'deletion_failed' ? 'Delete Failed' : 'Install Failed',
            message: 'VPS setup needs provider review before panel access can be opened.',
        }
    }

    return {
        locked: false,
        label: value ? value.replace(/_/g, ' ') : 'active',
        message: null,
    }
}

const buildCheckoutUrl = (
    baseUrl: string,
    plan: StorePlan,
    location: StoreLocationOption | null
): string => {
    try {
        const target = new URL(baseUrl)
        target.searchParams.set('wammu_plan_id', String(plan.id))

        if (location) {
            target.searchParams.set('wammu_location_id', String(location.id))
            target.searchParams.set('wammu_location_code', location.shortCode)
            if (location.description) {
                target.searchParams.set('wammu_location_name', location.description)
            }
        }

        return target.toString()
    } catch {
        const joiner = baseUrl.includes('?') ? '&' : '?'
        const base = `${baseUrl}${joiner}wammu_plan_id=${encodeURIComponent(String(plan.id))}`
        if (!location) {
            return base
        }

        return `${base}&wammu_location_id=${encodeURIComponent(
            String(location.id)
        )}&wammu_location_code=${encodeURIComponent(location.shortCode)}`
    }
}

const StoreContainer = () => {
    const settings = useStoreState(state => state.settings.data)
    const notify = useNotify()
    const [isLoading, setIsLoading] = useState(true)
    const [plans, setPlans] = useState<StorePlan[]>([])
    const [services, setServices] = useState<ServerBuild[]>([])
    const [locations, setLocations] = useState<StoreLocationOption[]>([])
    const [selectedLocationId, setSelectedLocationId] = useState<number | null>(
        null
    )
    const [error, setError] = useState<string | null>(null)

    const isPlatformCustomerStore = settings?.tenantId === null
    const isTenantCustomerStore = typeof settings?.tenantId === 'number'
    const platformBillingStoreUrl = settings?.platformStoreRedirectUrl || settings?.billingUrl || null
    const resolvedPlatformBillingStoreUrl = normalizeExternalUrl(platformBillingStoreUrl)

    useEffect(() => {
        let active = true

        setIsLoading(true)
        setError(null)

        if (isTenantCustomerStore) {
            setIsLoading(false)
            return () => {
                active = false
            }
        }

        if (isPlatformCustomerStore) {
            getServers({ perPage: 100 })
                .then(data => {
                    if (!active) {
                        return
                    }

                    setServices(data.items)
                })
                .catch(() => {
                    if (!active) {
                        return
                    }

                    setError('Failed to load your VPS services.')
                })
                .finally(() => {
                    if (active) {
                        setIsLoading(false)
                    }
                })
        } else {
            Promise.allSettled([
                getStorePlans(),
                getServers({ perPage: 100 }),
            ])
                .then(([plansResult, servicesResult]) => {
                    if (!active) {
                        return
                    }

                    if (plansResult.status === 'fulfilled') {
                        setPlans(plansResult.value.items)
                        setLocations(plansResult.value.locations)
                        if (plansResult.value.locations.length > 0) {
                            setSelectedLocationId(plansResult.value.locations[0].id)
                        } else {
                            setSelectedLocationId(null)
                        }
                    } else {
                        setPlans([])
                        setLocations([])
                        setSelectedLocationId(null)
                    }

                    if (servicesResult.status === 'fulfilled') {
                        setServices(servicesResult.value.items)
                    } else {
                        setServices([])
                    }

                    if (
                        plansResult.status === 'rejected' &&
                        servicesResult.status === 'rejected'
                    ) {
                        setError('Failed to load store data.')
                    }
                })
                .finally(() => {
                    if (active) {
                        setIsLoading(false)
                    }
                })
        }

        return () => {
            active = false
        }
    }, [isPlatformCustomerStore, isTenantCustomerStore])

    const selectedLocation = locations.find(
        location => location.id === selectedLocationId
    )

    if (isTenantCustomerStore) {
        return <Navigate to='/' replace />
    }

    const renderServiceCard = (service: ServerBuild) => {
        const setup = serverSetupState(service.status)
        const upgradeCanOpen = !setup.locked && service.billing?.upgradeAvailable

        return (
            <div
                key={service.uuid}
                className='rounded-xl border border-[var(--border-soft)] bg-[var(--surface-raised)] p-5 transition hover:border-[var(--tenant-brand-accent)]/40 hover:bg-[var(--surface-hover)]'
            >
            <div className='flex items-start justify-between gap-3'>
                <div>
                    <h3 className='text-lg font-semibold text-white'>
                        {service.name}
                    </h3>
                    <p className='mt-1 text-xs text-white/60'>
                        {service.hostname}
                    </p>
                </div>
                <span className='rounded-full border border-[var(--border-soft)] bg-[var(--surface-active)] px-2.5 py-1 text-xs font-semibold text-white'>
                    {setup.label}
                </span>
            </div>

            {setup.locked ? (
                <div className='mt-4 rounded-lg border border-cyan-300/20 bg-cyan-400/10 px-3 py-2 text-sm text-cyan-100'>
                    {setup.message}
                </div>
            ) : null}

            <div className='mt-4 grid grid-cols-2 gap-2 text-sm text-white/80'>
                <p className='rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2'>
                    {service.limits.cpu} vCPU
                </p>
                <p className='rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2'>
                    {toSizeLabel(service.limits.memory)} RAM
                </p>
                <p className='rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2'>
                    {toSizeLabel(service.limits.disk)} Disk
                </p>
                <p className='rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2'>
                    {toSizeLabel(service.limits.bandwidth)} BW
                </p>
            </div>

            <div className='mt-4 flex flex-wrap gap-2'>
                {service.billing?.upgradeVisible !== false ? (
                    <button
                        type='button'
                        onClick={() => {
                            if (setup.locked) {
                                notify({
                                    color: 'yellow',
                                    message: setup.message || 'VPS setup is still running.',
                                })
                                return
                            }

                            if (!service.billing?.upgradeUrl) {
                                notify({
                                    color: 'yellow',
                                    message:
                                        service.billing?.upgradeMessage ||
                                        'Upgrade link is not configured for this VPS yet.',
                                })
                                return
                            }

                            window.location.assign(service.billing.upgradeUrl)
                        }}
                        className={`rounded-lg px-4 py-2 text-sm font-semibold transition ${
                            upgradeCanOpen
                                ? 'btn-primary'
                                : 'border border-amber-400/30 bg-amber-500/10 text-amber-100 hover:bg-amber-500/15'
                        }`}
                    >
                        {setup.locked
                            ? 'Setup In Progress'
                            : service.billing?.upgradeAvailable
                            ? 'Upgrade This VPS'
                            : service.billing?.upgradeReason === 'manual_or_unlinked'
                              ? 'Contact Provider'
                              : 'Upgrade Unavailable'}
                    </button>
                ) : null}
                {setup.locked ? (
                    <span className='rounded-lg border border-white/10 bg-white/[0.03] px-4 py-2 text-sm font-semibold text-white/55'>
                        Panel locked
                    </span>
                ) : (
                    <Link
                        to={`/servers/${service.id}`}
                        className='rounded-lg border border-white/15 bg-white/5 px-4 py-2 text-sm font-semibold text-white transition hover:bg-white/10'
                    >
                        Manage VPS
                    </Link>
                )}
            </div>

            {service.billing?.upgradeVisible !== false &&
            !service.billing?.upgradeAvailable &&
            !setup.locked ? (
                <p className='mt-3 text-xs text-amber-200/80'>
                    {service.billing?.upgradeMessage ||
                        'Billing upgrade mapping is not set yet for this VPS.'}
                </p>
            ) : null}
        </div>
        )
    }

    return (
        <PageContentBlock title='Store'>
            <div className='space-y-5'>
                <div className='overflow-hidden rounded-xl border border-[var(--border-soft)] bg-gradient-to-br from-[var(--surface-raised)] via-[var(--surface-active)] to-[var(--tenant-card)] p-6'>
                    <p className='text-xs font-semibold uppercase tracking-[0.16em] text-[var(--tenant-brand-accent)]'>
                        WammuHost Store
                    </p>
                    <h2 className='mt-2 text-2xl font-semibold text-white'>
                        {isPlatformCustomerStore
                            ? 'Manage and Upgrade Your VPS Plans'
                            : 'Buy or Upgrade Your VPS'}
                    </h2>
                    <p className='mt-2 max-w-3xl text-sm text-[var(--text-muted)]'>
                        {isPlatformCustomerStore
                            ? 'See every active VPS on your account and jump straight into the exact upgrade page for that service.'
                            : 'Your reseller services use this domain for billing. Existing VPS upgrades open the exact reseller Paymenter service, and new VPS checkout keeps your selected location metadata.'}
                    </p>
                    {isPlatformCustomerStore && resolvedPlatformBillingStoreUrl ? (
                        <div className='mt-4'>
                            <button
                                type='button'
                                onClick={() => window.location.assign(resolvedPlatformBillingStoreUrl)}
                                className='btn-primary rounded-lg px-4 py-2 text-sm'
                            >
                                Buy New VPS
                            </button>
                        </div>
                    ) : null}
                </div>

                {isLoading ? (
                    <Spinner />
                ) : error ? (
                    <div className='rounded-lg border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm text-red-200'>
                        {error}
                    </div>
                ) : isPlatformCustomerStore ? (
                    services.length === 0 ? (
                        <div className='rounded-lg border border-[var(--border-soft)] bg-[var(--surface-raised)] px-4 py-3 text-sm text-[var(--text-muted)]'>
                            No VPS is linked to this account in WammuCore yet. If a VPS was created manually
                            outside billing or directly on infrastructure, it still needs to be assigned to
                            your account inside the panel before it can appear here.
                        </div>
                    ) : (
                        <div className='grid gap-4 lg:grid-cols-2'>
                            {services.map(renderServiceCard)}
                        </div>
                    )
                ) : (
                    <div className='space-y-4'>
                        {services.length > 0 ? (
                            <div className='space-y-3'>
                                <div className='flex flex-wrap items-end justify-between gap-3'>
                                    <div>
                                        <p className='text-xs font-semibold uppercase tracking-[0.16em] text-emerald-200/80'>
                                            Existing VPS
                                        </p>
                                        <h3 className='text-xl font-semibold text-white'>
                                            Upgrade through your reseller billing account
                                        </h3>
                                    </div>
                                </div>
                                <div className='grid gap-4 lg:grid-cols-2'>
                                    {services.map(renderServiceCard)}
                                </div>
                            </div>
                        ) : null}

                        {plans.length === 0 ? (
                            <div className='rounded-lg border border-[var(--border-soft)] bg-[var(--surface-raised)] px-4 py-3 text-sm text-[var(--text-muted)]'>
                                No plans are available right now.
                            </div>
                        ) : (
                            <>
                        <div className='rounded-xl border border-[var(--border-soft)] bg-[var(--surface-raised)] p-4'>
                            <div className='grid gap-4 lg:grid-cols-3'>
                                <div className='lg:col-span-2'>
                                    <label className='mb-2 block text-xs font-semibold uppercase tracking-wide text-white/70'>
                                        Preferred Node Location
                                    </label>
                                    <select
                                        className='h-11 w-full rounded-lg border border-[var(--border-soft)] bg-[var(--surface-soft)] px-3 text-sm text-white outline-none transition focus:border-[var(--tenant-brand-accent)] focus:ring-2 focus:ring-[var(--focus-ring)]'
                                        value={selectedLocationId ?? ''}
                                        onChange={event =>
                                            setSelectedLocationId(
                                                event.currentTarget.value
                                                    ? Number(
                                                          event.currentTarget.value
                                                      )
                                                    : null
                                            )
                                        }
                                        disabled={locations.length === 0}
                                    >
                                        {locations.length === 0 ? (
                                            <option value=''>
                                                No locations available
                                            </option>
                                        ) : (
                                            locations.map(location => (
                                                <option
                                                    key={location.id}
                                                    value={location.id}
                                                >
                                                    {location.shortCode}
                                                    {location.description
                                                        ? ` - ${location.description}`
                                                        : ''}
                                                </option>
                                            ))
                                        )}
                                    </select>
                                </div>
                                <div className='rounded-lg border border-white/10 bg-white/[0.03] p-3 text-sm text-white/80'>
                                    <p className='text-xs uppercase tracking-wide text-white/60'>
                                        Location Status
                                    </p>
                                    <p className='mt-2 font-semibold text-white'>
                                        {selectedLocation
                                            ? `${selectedLocation.shortCode}${
                                                  selectedLocation.description
                                                      ? ` (${selectedLocation.description})`
                                                      : ''
                                              }`
                                            : 'Auto selection'}
                                    </p>
                                    <p className='mt-1 text-xs text-white/65'>
                                        {selectedLocation
                                            ? `${selectedLocation.availableNodes} node(s) ready`
                                            : 'Location will be auto-picked from available capacity.'}
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className='grid gap-4 lg:grid-cols-2'>
                        {plans.map(plan => (
                            <div
                                key={plan.id}
                                className='rounded-xl border border-[var(--border-soft)] bg-[var(--surface-raised)] p-5 transition hover:border-[var(--tenant-brand-accent)]/40 hover:bg-[var(--surface-hover)]'
                            >
                                <div className='flex items-start justify-between gap-3'>
                                    <div>
                                        <h3 className='text-lg font-semibold text-white'>
                                            {plan.name}
                                        </h3>
                                        <p className='mt-1 text-xs uppercase tracking-wide text-white/55'>
                                            Plan ID: {plan.id} · {plan.slug}
                                        </p>
                                    </div>
                                    <span className='rounded-full border border-[var(--border-soft)] bg-[var(--surface-active)] px-2.5 py-1 text-xs font-semibold text-white'>
                                        Fixed Specs
                                    </span>
                                </div>

                                <p className='mt-3 text-sm text-white/65'>
                                    {plan.description ||
                                        'High-performance VPS plan tuned for reliability.'}
                                </p>

                                <div className='mt-4 grid grid-cols-2 gap-2 text-sm text-white/80'>
                                    <p className='rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2'>
                                        {plan.cpuCores} vCPU
                                    </p>
                                    <p className='rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2'>
                                        {toGb(plan.ramMb)} RAM
                                    </p>
                                    <p className='rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2'>
                                        {plan.diskGb} GB NVMe
                                    </p>
                                    <p className='rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2'>
                                        {plan.bandwidthGb === null
                                            ? 'Unlimited BW'
                                            : `${plan.bandwidthGb} GB BW`}
                                    </p>
                                </div>

                                <div className='mt-3 flex flex-wrap gap-2 text-xs text-white/75'>
                                    <span className='rounded-full border border-emerald-300/35 bg-emerald-500/10 px-2.5 py-1'>
                                        Included IPs: {plan.ipQuantity}
                                    </span>
                                    <span className='rounded-full border border-[var(--border-soft)] bg-[var(--surface-active)] px-2.5 py-1'>
                                        Extra IP: {plan.currency} {plan.ipPriceEach}
                                    </span>
                                    <span className='rounded-full border border-sky-300/35 bg-sky-500/10 px-2.5 py-1'>
                                        Backups: {plan.backupLimit}
                                    </span>
                                </div>

                                <p className='mt-4 text-2xl font-bold text-white'>
                                    {plan.monthlyPrice === null
                                        ? 'Contact Sales'
                                        : `${plan.currency} ${plan.monthlyPrice}/mo`}
                                </p>
                                <div className='mt-4'>
                                    <button
                                        type='button'
                                        disabled={!plan.checkoutEnabled}
                                        onClick={() => {
                                            if (!plan.paymenterCheckoutUrl) {
                                                return
                                            }

                                            window.open(
                                                buildCheckoutUrl(
                                                    plan.paymenterCheckoutUrl,
                                                    plan,
                                                    selectedLocation ?? null
                                                ),
                                                '_blank',
                                                'noopener,noreferrer'
                                            )
                                        }}
                                        className='btn-primary w-full rounded-lg px-4 py-2 text-sm disabled:cursor-not-allowed disabled:opacity-50'
                                    >
                                        {plan.checkoutEnabled
                                            ? 'Checkout in Paymenter'
                                            : 'Checkout Unavailable'}
                                    </button>
                                    <p className='mt-2 text-xs text-white/55'>
                                        Checkout carries your selected location as secure
                                        query metadata for billing automation.
                                    </p>
                                </div>
                            </div>
                        ))}
                    </div>
                            </>
                        )}
                    </div>
                )}
            </div>
        </PageContentBlock>
    )
}

export default StoreContainer
