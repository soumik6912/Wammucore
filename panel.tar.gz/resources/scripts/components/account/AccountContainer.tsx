import { getAccountProfile } from '@/api/account/profile'
import updatePanelThemePreference from '@/api/account/updatePanelThemePreference'
import updatePassword from '@/api/account/updatePassword'
import Button from '@/components/elements/Button'
import TextInputForm from '@/components/elements/forms/TextInputForm'
import Switch from '@/components/elements/inputs/Switch'
import PageContentBlock from '@/components/elements/PageContentBlock'
import { NavigationBarContext } from '@/components/elements/navigation/NavigationBar'
import { useStoreActions, useStoreState } from '@/state'
import { getInitials } from '@/util/helpers'
import { THEME_PRESETS, resolveThemePreset } from '@/util/themePresets'
import { Avatar } from '@mantine/core'
import { zodResolver } from '@hookform/resolvers/zod'
import { useContext, useEffect, useState } from 'react'
import { FormProvider, useForm } from 'react-hook-form'
import { z } from 'zod'

const schema = z
    .object({
        password: z.string().min(8, 'Password must be at least 8 characters.'),
        passwordConfirmation: z.string().min(1, 'Confirm your new password.'),
    })
    .refine(values => values.password === values.passwordConfirmation, {
        message: 'Passwords do not match.',
        path: ['passwordConfirmation'],
    })

const AccountContainer = () => {
    const { setRoutes } = useContext(NavigationBarContext)
    const user = useStoreState(state => state.user.data!)
    const tenantId = useStoreState(state => state.settings.data?.tenantId ?? null)
    const privacyMode = useStoreState(state => state.settings.privacyMode)
    const providerThemeKey = useStoreState(
        state => state.settings.data?.tenantThemeKey || 'wammuhost'
    )
    const panelThemeKey = useStoreState(
        state => state.user.data?.panelThemeKey ?? null
    )
    const setPrivacyMode = useStoreActions(actions => actions.settings.setPrivacyMode)
    const setPanelThemeKey = useStoreActions(actions => actions.user.setPanelThemeKey)
    const [message, setMessage] = useState<string | null>(null)
    const [error, setError] = useState<string | null>(null)
    const [themeMessage, setThemeMessage] = useState<string | null>(null)
    const [themeError, setThemeError] = useState<string | null>(null)
    const [themeSaving, setThemeSaving] = useState(false)
    const [profile, setProfile] = useState<any>(null)
    const providerTheme = resolveThemePreset(providerThemeKey)
    const followsProviderTheme = !panelThemeKey || panelThemeKey === providerTheme.key
    const selectableThemes = THEME_PRESETS.filter(
        theme => theme.key !== providerTheme.key
    )

    const methods = useForm<z.infer<typeof schema>>({
        resolver: zodResolver(schema),
        mode: 'onTouched',
        defaultValues: {
            password: '',
            passwordConfirmation: '',
        },
    })

    const loadSecurityData = async () => {
        const profileData = await getAccountProfile()
        setProfile(profileData)
        setPanelThemeKey(profileData.panelThemeKey)
    }

    const savePanelTheme = async (nextThemeKey: string | null) => {
        setThemeSaving(true)
        setThemeMessage(null)
        setThemeError(null)

        try {
            const savedThemeKey = await updatePanelThemePreference(nextThemeKey)
            setPanelThemeKey(savedThemeKey)
            setProfile((current: any) =>
                current
                    ? {
                        ...current,
                        panelThemeKey: savedThemeKey,
                    }
                    : current
            )
            setThemeMessage(
                savedThemeKey
                    ? `Panel theme changed to ${resolveThemePreset(savedThemeKey).name}.`
                    : 'Panel theme now follows the provider default.'
            )
        } catch (e: any) {
            setThemeError(e?.response?.data?.message || 'Failed to update panel theme.')
        } finally {
            setThemeSaving(false)
        }
    }

    const onSubmit = async (values: z.infer<typeof schema>) => {
        setMessage(null)
        setError(null)

        try {
            await updatePassword(values)
            methods.reset()
            setMessage('Password updated successfully.')
            await loadSecurityData()
        } catch (e: any) {
            setError(e?.response?.data?.message || 'Failed to update password.')
        }
    }

    const onReset = () => {
        methods.reset()
        setMessage(null)
        setError(null)
    }

    useEffect(() => {
        setRoutes([
            { name: 'Overview', path: '/' },
            ...(tenantId === null
                ? [
                    { name: 'VPS Plans', path: '/store' },
                    { name: 'Buy Dedicated', path: '/dedicated' },
                ]
                : [{ name: 'VPS Plans', path: '/store' }]),
            { name: 'Account', path: '/account' },
        ])

        void loadSecurityData()

        return () => setRoutes([])
    }, [setRoutes, tenantId])

    return (
        <PageContentBlock title='Account'>
            <div className='mx-auto max-w-5xl space-y-5'>
                <div className='grid gap-5 xl:grid-cols-[1.2fr_0.8fr]'>
                    <div className='rounded-xl border border-[#3f329d] bg-[#0b0733]/70 p-5'>
                        <h1 className='text-2xl font-semibold text-[#f0ecff]'>Account & Security</h1>
                        <p className='mt-1 text-sm text-[#b8acf0]'>
                            Manage password, verification state, and login visibility.
                        </p>

                        <div className='mt-5 flex items-center gap-4 rounded-xl border border-[#40308f] bg-[#100b3b] p-4'>
                            <Avatar
                                src={profile?.avatarUrl || user.avatarUrl || undefined}
                                color='indigo'
                                size='xl'
                                radius='xl'
                                className='ring-2 ring-indigo-500/50 shadow-md shrink-0'
                            >
                                {getInitials(user.name, ' ', 2)}
                            </Avatar>
                            <div className='min-w-0 flex-1'>
                                <p className='text-base font-semibold text-[#f0ecff] truncate'>{user.name}</p>
                                <p className='text-xs text-[#b8acf0] truncate'>{profile?.email || user.email}</p>
                                <div className='mt-1.5 flex items-center gap-2 text-[11px] text-[#8fe7d8]'>
                                    <span>Profile picture from Gravatar</span>
                                    <span>•</span>
                                    <a
                                        href='https://gravatar.com'
                                        target='_blank'
                                        rel='noreferrer'
                                        className='text-[#a495e5] hover:text-white underline transition'
                                    >
                                        Change on gravatar.com
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div className='mt-5'>
                            <div>
                                <label className='mb-1 block text-xs font-medium text-[#a495e5]'>
                                    Email
                                </label>
                                <input
                                    type='text'
                                    value={profile?.email || user.email}
                                    disabled
                                    className='w-full rounded-md border border-[#40308f] bg-[#100b3b] px-3 py-2 text-sm text-[#c8beff] disabled:opacity-90'
                                />
                            </div>
                        </div>

                        <div className='mt-5 rounded-lg border border-[#40308f] bg-[#100b3b] p-4'>
                            <div className='flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between'>
                                <div className='min-w-0 flex-1'>
                                    <p className='text-sm font-semibold text-[#f0ecff]'>Privacy mode</p>
                                    <p className='mt-1 text-xs text-[#b8acf0]'>
                                        Blur IP, hostname, username, password, and port values across user pages.
                                    </p>
                                    <p className='mt-2 text-[11px] font-medium text-[#8fe7d8]'>
                                        {privacyMode
                                            ? 'Sensitive values are currently blurred by default.'
                                            : 'Sensitive values are currently shown normally.'}
                                    </p>
                                </div>
                                <div
                                    className={`flex w-full items-center justify-between gap-3 rounded-full border px-3 py-2 shadow-inner sm:w-auto sm:justify-start ${
                                        privacyMode
                                            ? 'border-emerald-300/25 bg-emerald-400/10'
                                            : 'border-slate-300/25 bg-slate-950/70'
                                    }`}
                                >
                                    <span
                                        className={`min-w-[78px] text-left text-xs font-semibold ${
                                            privacyMode
                                                ? 'text-emerald-200'
                                                : 'text-slate-100'
                                        }`}
                                    >
                                        {privacyMode ? 'Enabled' : 'Disabled'}
                                    </span>
                                    <Switch
                                        className='account-privacy-switch'
                                        checked={privacyMode}
                                        onChange={event =>
                                            setPrivacyMode(event.currentTarget.checked)
                                        }
                                        aria-label='Toggle privacy mode'
                                        size='md'
                                    />
                                </div>
                            </div>
                        </div>

                        <div className='mt-5 overflow-hidden rounded-2xl border border-white/10 bg-[#0b0733]/75 shadow-[0_20px_70px_rgba(3,2,20,0.35)]'>
                            <div className='border-b border-white/10 bg-white/[0.03] p-5'>
                                <div>
                                    <p className='text-xs font-bold uppercase tracking-[0.24em] text-[#8fe7d8]'>
                                        Panel theme
                                    </p>
                                    <p className='mt-2 text-lg font-semibold text-[#f0ecff]'>
                                        Choose your workspace look
                                    </p>
                                    <p className='mt-1 max-w-2xl text-sm leading-6 text-[#b8acf0]'>
                                        Choose your own look, or follow the provider brand.
                                    </p>
                                </div>
                            </div>

                            <div className='grid gap-4 p-5 lg:grid-cols-2 2xl:grid-cols-3'>
                                <button
                                    type='button'
                                    disabled={themeSaving}
                                    aria-pressed={followsProviderTheme}
                                    onClick={() => void savePanelTheme(null)}
                                    className={`group min-h-[178px] rounded-2xl border p-4 text-left transition duration-200 hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-60 ${
                                        followsProviderTheme
                                            ? 'border-cyan-300/70 bg-cyan-400/10 shadow-[0_0_28px_rgba(34,211,238,0.18)]'
                                            : 'border-white/10 bg-white/[0.03] hover:border-white/25 hover:bg-white/[0.06]'
                                    }`}
                                >
                                    <div
                                        className='h-16 rounded-xl border border-white/10 shadow-inner'
                                        style={{
                                            background: `radial-gradient(circle at top left, ${providerTheme.accent}55, transparent 34%), linear-gradient(135deg, ${providerTheme.secondary}, ${providerTheme.background})`,
                                        }}
                                    />
                                    <div className='mt-3 flex min-h-[42px] items-start justify-between gap-3'>
                                        <span className='min-w-0 break-words text-sm font-semibold leading-5 text-white'>
                                            Provider Theme
                                        </span>
                                        <span
                                            className='h-4 w-4 shrink-0 rounded-full border border-white/30'
                                            style={{ backgroundColor: providerTheme.primary }}
                                        />
                                    </div>
                                    {followsProviderTheme ? (
                                        <span className='mt-2 inline-flex whitespace-nowrap rounded-full border border-cyan-200/40 bg-cyan-300/20 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-[0.12em] text-cyan-100'>
                                            Active
                                        </span>
                                    ) : null}
                                    <p className='mt-1 text-xs leading-5 text-white/50'>
                                        Uses {providerTheme.name} from your provider.
                                    </p>
                                </button>

                                {selectableThemes.map(theme => {
                                    const selected = panelThemeKey === theme.key

                                    return (
                                        <button
                                            key={theme.key}
                                            type='button'
                                            disabled={themeSaving}
                                            aria-pressed={selected}
                                            onClick={() => void savePanelTheme(theme.key)}
                                            className={`group min-h-[178px] rounded-2xl border p-4 text-left transition duration-200 hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-60 ${
                                                selected
                                                    ? 'border-cyan-300/70 bg-cyan-400/10 shadow-[0_0_28px_rgba(34,211,238,0.18)]'
                                                    : 'border-white/10 bg-white/[0.03] hover:border-white/25 hover:bg-white/[0.06]'
                                            }`}
                                        >
                                            <div
                                                className='h-16 rounded-xl border border-white/10 shadow-inner'
                                                style={{
                                                    background: `radial-gradient(circle at top left, ${theme.accent}55, transparent 34%), linear-gradient(135deg, ${theme.secondary}, ${theme.background})`,
                                                }}
                                            />
                                            <div className='mt-3 flex min-h-[42px] items-start justify-between gap-3'>
                                                <span className='min-w-0 break-words text-sm font-semibold leading-5 text-white'>
                                                    {theme.name}
                                                </span>
                                                <span
                                                    className={`h-4 w-4 shrink-0 rounded-full border ${
                                                        selected ? 'border-cyan-100 shadow-[0_0_16px_rgba(34,211,238,0.45)]' : 'border-white/30'
                                                    }`}
                                                    style={{ backgroundColor: theme.primary }}
                                                />
                                            </div>
                                            {selected ? (
                                                <span className='mt-2 inline-flex whitespace-nowrap rounded-full border border-cyan-200/40 bg-cyan-300/20 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-[0.12em] text-cyan-100'>
                                                    Active
                                                </span>
                                            ) : null}
                                            <p className='mt-1 text-xs leading-5 text-white/50'>
                                                {theme.description}
                                            </p>
                                        </button>
                                    )
                                })}
                            </div>

                            {(themeMessage || themeError) ? (
                                <p
                                    className={`px-5 pb-5 text-sm ${
                                        themeError ? 'text-red-300' : 'text-emerald-300'
                                    }`}
                                >
                                    {themeError || themeMessage}
                                </p>
                            ) : null}
                        </div>

                        <FormProvider {...methods}>
                            <form onSubmit={methods.handleSubmit(onSubmit)} className='mt-5 space-y-4'>
                                <TextInputForm name='password' type='password' label='New Password' />
                                <TextInputForm
                                    name='passwordConfirmation'
                                    type='password'
                                    label='Confirm New Password'
                                />

                                {(message || error) && (
                                    <p className={`text-sm ${error ? 'text-red-400' : 'text-emerald-300'}`}>
                                        {error || message}
                                    </p>
                                )}

                                <div className='flex items-center gap-3 pt-1'>
                                    <Button
                                        type='submit'
                                        variant='filled'
                                        color='accent'
                                        loading={methods.formState.isSubmitting}
                                    >
                                        Change Password
                                    </Button>
                                    <Button type='button' onClick={onReset}>
                                        Reset
                                    </Button>
                                </div>
                            </form>
                        </FormProvider>
                    </div>

                    <div className='rounded-xl border border-[#3f329d] bg-[#0b0733]/70 p-5'>
                        <h2 className='text-lg font-semibold text-[#f0ecff]'>Auth posture</h2>
                        <div className='mt-4 space-y-3'>
                            <div className='rounded-lg border border-white/10 bg-white/5 px-4 py-3'>
                                <p className='text-xs uppercase tracking-wide text-white/50'>Role</p>
                                <p className='mt-1 text-sm font-semibold text-white'>
                                    {user.rootAdmin
                                        ? 'root_admin'
                                        : user.platformAdmin
                                        ? 'admin'
                                        : user.resellerAdmin
                                        ? 'reseller_owner'
                                        : 'customer'}
                                </p>
                            </div>
                            <div className='rounded-lg border border-white/10 bg-white/5 px-4 py-3'>
                                <p className='text-xs uppercase tracking-wide text-white/50'>Email verification</p>
                                <p className='mt-1 text-sm font-semibold text-white'>
                                    {profile?.mustChangePassword ? 'Password change required' : 'Security checks active'}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </PageContentBlock>
    )
}

export default AccountContainer
