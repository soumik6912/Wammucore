import { createAccountToken, deleteAccountToken, getAccountTokens } from '@/api/account/tokens'
import { useStoreState } from '@/state'
import useNotify from '@/util/useNotify'
import { formatDistanceToNow } from 'date-fns'
import { useContext, useEffect, useMemo, useState } from 'react'
import useSWR from 'swr'

import Modal from '@/components/elements/Modal'
import PageContentBlock from '@/components/elements/PageContentBlock'
import { NavigationBarContext } from '@/components/elements/navigation/NavigationBar'

const AccountTokensContainer = () => {
    const { setRoutes } = useContext(NavigationBarContext)
    const notify = useNotify()
    const apiDocsUrl = useStoreState(state => state.settings.data?.apiDocsUrl || null)
    const tenantId = useStoreState(state => state.settings.data?.tenantId ?? null)
    const normalizedApiDocsUrl = useMemo(() => apiDocsUrl?.trim() || '', [apiDocsUrl])
    const [tokenName, setTokenName] = useState('')
    const [plainTextToken, setPlainTextToken] = useState<string | null>(null)
    const [creating, setCreating] = useState(false)
    const [deletingId, setDeletingId] = useState<number | null>(null)

    const { data, error, isLoading, mutate } = useSWR(['account:tokens'], getAccountTokens)

    const mcpJson = useMemo(() => {
        if (!plainTextToken) {
            return ''
        }

        return JSON.stringify(
            {
                servers: {
                    wammucore: {
                        url: 'https://panel.example.com/api/client',
                        headers: {
                            Authorization: `Bearer ${plainTextToken}`,
                        },
                    },
                },
            },
            null,
            2
        )
    }, [plainTextToken])

    const onCreate = async () => {
        if (!tokenName.trim()) {
            notify({ color: 'red', message: 'Token name is required.' })
            return
        }

        try {
            setCreating(true)
            const token = await createAccountToken(tokenName.trim())
            setTokenName('')
            setPlainTextToken(token.plainTextToken || null)
            await mutate()
            notify({ color: 'green', message: 'API token created.' })
        } catch {
            notify({ color: 'red', message: 'Failed to create API token.' })
        } finally {
            setCreating(false)
        }
    }

    const onDelete = async (id: number) => {
        if (!window.confirm('Delete this API token? Existing integrations will stop working.')) {
            return
        }

        try {
            setDeletingId(id)
            await deleteAccountToken(id)
            await mutate()
            notify({ color: 'green', message: 'API token deleted.' })
        } catch {
            notify({ color: 'red', message: 'Failed to delete API token.' })
        } finally {
            setDeletingId(null)
        }
    }

    useEffect(() => {
        setRoutes([
            { name: 'Overview', path: '/' },
            ...(tenantId === null
                ? [
                    { name: 'VPS Plans', path: '/store' },
                    { name: 'Buy Dedicated', path: '/dedicated' },
                ]
                : [{ name: 'VPS Plans', path: '/store' }]),
            { name: 'Account', path: '/account' },
            { name: 'API', path: '/account/tokens' },
        ])

        return () => setRoutes([])
    }, [setRoutes, tenantId])

    return (
        <PageContentBlock title='API'>
            <Modal open={!!plainTextToken} onClose={() => setPlainTextToken(null)}>
                <Modal.Header>
                    <Modal.Title>Copy your API token now</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Modal.Description bottomMargin>
                        This token is shown only once. Save it securely.
                    </Modal.Description>
                    <div className='rounded-lg border border-white/15 bg-[#111a31] p-3 text-sm text-white break-all'>
                        {plainTextToken}
                    </div>
                    {mcpJson && (
                        <div className='mt-3 rounded-lg border border-white/15 bg-[#111a31] p-3 text-xs text-white/80'>
                            <pre className='whitespace-pre-wrap'>{mcpJson}</pre>
                        </div>
                    )}
                </Modal.Body>
                <Modal.Actions>
                    <Modal.Action type='button' onClick={() => setPlainTextToken(null)}>
                        Close
                    </Modal.Action>
                </Modal.Actions>
            </Modal>

            <div className='space-y-4'>
                <section className='overflow-hidden rounded-3xl border border-cyan-300/15 bg-[radial-gradient(circle_at_top_left,rgba(34,211,238,.22),transparent_34%),linear-gradient(135deg,rgba(8,13,32,.96),rgba(22,20,68,.94)_58%,rgba(8,47,73,.82))] p-6 shadow-[0_30px_90px_rgba(8,145,178,.12)]'>
                    <div className='grid gap-6 xl:grid-cols-[1.05fr_0.95fr] xl:items-center'>
                        <div>
                            <p className='text-xs font-bold uppercase tracking-[0.34em] text-cyan-200/80'>
                                Developer access
                            </p>
                            <h2 className='mt-3 text-3xl font-semibold text-white'>
                                Build securely with your VPS panel API
                            </h2>
                            <p className='mt-3 max-w-2xl text-sm leading-6 text-white/65'>
                                Create scoped tokens for automations, billing bridges, and private tooling. Tokens are shown once and can be revoked anytime.
                            </p>
                            <div className='mt-5 flex flex-col gap-2 sm:flex-row'>
                                <input
                                    value={tokenName}
                                    onChange={event => setTokenName(event.target.value)}
                                    placeholder='Token name, like automation-bot'
                                    className='w-full rounded-xl border border-white/15 bg-black/25 px-4 py-3 text-sm text-white placeholder:text-white/35 outline-none transition focus:border-cyan-300'
                                />
                                <button
                                    type='button'
                                    onClick={onCreate}
                                    disabled={creating}
                                    className='rounded-xl bg-cyan-300 px-5 py-3 text-sm font-bold text-slate-950 shadow-[0_14px_40px_rgba(34,211,238,.18)] transition hover:-translate-y-0.5 hover:bg-cyan-200 disabled:cursor-not-allowed disabled:opacity-60'
                                >
                                    {creating ? 'Creating...' : 'Generate token'}
                                </button>
                            </div>
                            <div className='mt-4 flex flex-wrap gap-2'>
                                {normalizedApiDocsUrl ? (
                                    <a
                                        href={normalizedApiDocsUrl}
                                        target='_blank'
                                        rel='noreferrer'
                                        className='inline-flex items-center rounded-xl border border-cyan-200/25 bg-cyan-200/10 px-4 py-2 text-sm font-semibold text-cyan-100 transition hover:bg-cyan-200/15'
                                    >
                                        Open developer API docs
                                    </a>
                                ) : (
                                    <span className='inline-flex items-center rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-sm font-semibold text-white/50'>
                                        Developer docs not configured yet
                                    </span>
                                )}
                            </div>
                        </div>

                        <div className='grid gap-3 sm:grid-cols-2'>
                            <div className='rounded-2xl border border-emerald-300/20 bg-emerald-300/10 p-4 backdrop-blur'>
                                <p className='text-xs font-bold uppercase tracking-[0.24em] text-emerald-200/80'>
                                    Ready
                                </p>
                                <h3 className='mt-2 text-lg font-semibold text-white'>
                                    Paymenter integrations
                                </h3>
                                <p className='mt-2 text-sm leading-6 text-white/62'>
                                    Use tokens for secure automation and reseller billing workflows.
                                </p>
                            </div>
                            <div className='rounded-2xl border border-amber-300/20 bg-amber-300/10 p-4 backdrop-blur'>
                                <p className='text-xs font-bold uppercase tracking-[0.24em] text-amber-200/80'>
                                    Coming soon
                                </p>
                                <h3 className='mt-2 text-lg font-semibold text-white'>
                                    WHMCS module
                                </h3>
                                <p className='mt-2 text-sm leading-6 text-white/62'>
                                    WHMCS support is planned as a separate install flow.
                                </p>
                            </div>
                        </div>
                    </div>
                </section>

                <section className='rounded-2xl border border-white/10 bg-[#1a1441] p-5'>
                    <h3 className='text-xl font-semibold text-white'>Active Tokens</h3>
                    <div className='mt-3 overflow-x-auto'>
                        <table className='w-full min-w-[680px] text-left text-sm'>
                            <thead>
                                <tr className='border-b border-white/10 text-white/60'>
                                    <th className='py-2 pr-4 font-medium'>Name</th>
                                    <th className='py-2 pr-4 font-medium'>Created</th>
                                    <th className='py-2 pr-4 font-medium'>Last used</th>
                                    <th className='py-2 pr-4 font-medium'>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                {isLoading && (
                                    <tr>
                                        <td colSpan={4} className='py-8 text-center text-white/55'>
                                            Loading tokens...
                                        </td>
                                    </tr>
                                )}
                                {!isLoading && error && (
                                    <tr>
                                        <td colSpan={4} className='py-8 text-center text-rose-300'>
                                            Failed to load tokens.
                                        </td>
                                    </tr>
                                )}
                                {!isLoading &&
                                    !error &&
                                    (data || []).map(token => (
                                        <tr key={token.id} className='border-b border-white/5 text-white/85'>
                                            <td className='py-3 pr-4'>{token.name}</td>
                                            <td className='py-3 pr-4'>
                                                {token.createdAt
                                                    ? formatDistanceToNow(new Date(token.createdAt), {
                                                          addSuffix: true,
                                                      })
                                                    : '-'}
                                            </td>
                                            <td className='py-3 pr-4'>
                                                {token.lastUsedAt
                                                    ? formatDistanceToNow(new Date(token.lastUsedAt), {
                                                          addSuffix: true,
                                                      })
                                                    : 'Never'}
                                            </td>
                                            <td className='py-3 pr-4'>
                                                <button
                                                    type='button'
                                                    onClick={() => onDelete(token.id)}
                                                    disabled={deletingId === token.id}
                                                    className='rounded-lg border border-rose-400/30 bg-rose-500/10 px-3 py-1 text-xs font-semibold text-rose-200 hover:bg-rose-500/20 disabled:cursor-not-allowed disabled:opacity-60'
                                                >
                                                    {deletingId === token.id ? 'Deleting...' : 'Delete'}
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                {!isLoading && !error && !(data || []).length && (
                                    <tr>
                                        <td colSpan={4} className='py-8 text-center text-white/55'>
                                            No API tokens created yet.
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
        </PageContentBlock>
    )
}

export default AccountTokensContainer
