import { NavLink } from 'react-router-dom'
import { ServerContext } from '@/state/server'

const BackupsTabs = () => {
    const server = ServerContext.useStoreState(state => state.server.data!)

    const tabs = [
        {
            label: 'Backups',
            to: `/servers/${server.id}/backups`,
        },
        {
            label: 'Server Usage',
            to: `/servers/${server.id}/usage`,
        },
        {
            label: 'Latest Actions',
            to: `/servers/${server.id}/actions`,
        },
    ]

    return (
        <div className='mb-4 flex flex-wrap gap-2'>
            {tabs.map(tab => (
                <NavLink
                    key={tab.to}
                    to={tab.to}
                    end={tab.to.endsWith('/backups')}
                    className={({ isActive }) =>
                        `rounded-full px-3 py-1.5 text-sm font-medium transition-colors ${
                            isActive
                                ? 'bg-indigo-600/30 text-white'
                                : 'border border-white/15 text-white/60 hover:text-white'
                        }`
                    }
                >
                    {tab.label}
                </NavLink>
            ))}
        </div>
    )
}

export default BackupsTabs
