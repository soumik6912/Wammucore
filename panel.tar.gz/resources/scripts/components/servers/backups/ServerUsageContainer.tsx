import getState from '@/api/server/getState'
import getUsage, { UsagePoint, UsageTimeframe } from '@/api/server/usage/getUsage'
import ServerContentBlock from '@/components/servers/ServerContentBlock'
import ServerPageHeader from '@/components/servers/common/ServerPageHeader'
import { ServerContext } from '@/state/server'
import { formatBytes } from '@/util/helpers'
import { format, formatDistanceToNowStrict } from 'date-fns'
import { useMemo, useState } from 'react'
import useSWR from 'swr'

const timeframes: Array<{ id: UsageTimeframe; label: string; detail: string }> = [
    { id: 'hour', label: 'Live', detail: '1 hour' },
    { id: 'day', label: '24H', detail: 'Today' },
    { id: 'week', label: '7D', detail: 'Week' },
]

const chartDimensions = {
    width: 1000,
    height: 300,
    left: 42,
    right: 20,
    top: 24,
    bottom: 44,
}

type SeriesConfig = {
    label: string
    color: string
    value: (point: UsagePoint) => number
    format: (value: number) => string
}

type SeriesStats = {
    label: string
    color: string
    latest: number
    average: number
    peak: number
    low: number
    trend: number
    format: (value: number) => string
}

const clamp = (value: number, min: number, max: number): number =>
    Math.max(min, Math.min(max, value))

const safeNumber = (value: number): number =>
    Number.isFinite(value) ? value : 0

const compactNumber = (value: number): string => {
    if (!Number.isFinite(value)) {
        return '0'
    }

    if (value >= 1000) {
        return value.toLocaleString(undefined, { maximumFractionDigits: 0 })
    }

    if (value >= 100) {
        return value.toFixed(0)
    }

    if (value >= 10) {
        return value.toFixed(1)
    }

    return value.toFixed(2)
}

const formatPercent = (value: number): string =>
    `${compactNumber(clamp(value, 0, 100))}%`

const formatByteValue = (value: number): string => {
    const bytes = formatBytes(Math.max(0, value), 2)

    return `${bytes.size} ${bytes.unit}`
}

const formatRate = (value: number): string => {
    const bytes = formatBytes(Math.max(0, value), 2)

    return `${bytes.size} ${bytes.unit}/s`
}

const formatDuration = (seconds: number): string => {
    if (!Number.isFinite(seconds) || seconds <= 0) {
        return '0s'
    }

    const days = Math.floor(seconds / 86400)
    const hours = Math.floor((seconds % 86400) / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)

    if (days > 0) {
        return `${days}d ${hours}h`
    }

    if (hours > 0) {
        return `${hours}h ${minutes}m`
    }

    return `${minutes}m`
}

const formatSampleInterval = (seconds: number | null | undefined): string => {
    if (!seconds || seconds <= 0) {
        return 'Auto'
    }

    if (seconds < 60) {
        return `${seconds}s`
    }

    if (seconds < 3600) {
        return `${Math.round(seconds / 60)}m`
    }

    return `${Math.round(seconds / 3600)}h`
}

const formatDateTime = (value: string | null | undefined): string => {
    if (!value) {
        return '-'
    }

    try {
        return format(new Date(value), 'MMM d, HH:mm')
    } catch {
        return '-'
    }
}

const relativeTime = (value: string | null | undefined): string => {
    if (!value) {
        return 'No sample yet'
    }

    try {
        return `${formatDistanceToNowStrict(new Date(value))} ago`
    } catch {
        return 'No sample yet'
    }
}

const downsample = <T,>(items: T[], maxPoints: number): T[] => {
    if (items.length <= maxPoints) {
        return items
    }

    const stride = Math.ceil(items.length / maxPoints)
    const sampled = items.filter((_, index) => index % stride === 0)
    const last = items[items.length - 1]

    return sampled[sampled.length - 1] === last ? sampled : [...sampled, last]
}

const metricStats = (
    points: UsagePoint[],
    config: SeriesConfig
): SeriesStats => {
    const values = points.map(point => safeNumber(config.value(point)))
    const latest = values.length ? values[values.length - 1] : 0
    const average = values.length
        ? values.reduce((total, value) => total + value, 0) / values.length
        : 0
    const peak = values.length ? Math.max(...values) : 0
    const low = values.length ? Math.min(...values) : 0
    const previous = values.length > 1 ? values[values.length - 2] : latest

    return {
        label: config.label,
        color: config.color,
        latest,
        average,
        peak,
        low,
        trend: latest - previous,
        format: config.format,
    }
}

const buildChartPath = (
    points: UsagePoint[],
    config: SeriesConfig,
    yMax: number
): string => {
    if (points.length === 0) {
        return ''
    }

    const plotWidth = chartDimensions.width - chartDimensions.left - chartDimensions.right
    const plotHeight = chartDimensions.height - chartDimensions.top - chartDimensions.bottom
    const denominator = Math.max(points.length - 1, 1)

    return points
        .map((point, index) => {
            const x = chartDimensions.left + (index / denominator) * plotWidth
            const normalized = clamp(safeNumber(config.value(point)) / Math.max(yMax, 1), 0, 1)
            const y = chartDimensions.top + plotHeight - normalized * plotHeight

            return `${index === 0 ? 'M' : 'L'} ${x.toFixed(2)} ${y.toFixed(2)}`
        })
        .join(' ')
}

const buildAreaPath = (
    linePath: string,
    points: UsagePoint[]
): string => {
    if (!linePath || points.length === 0) {
        return ''
    }

    const plotWidth = chartDimensions.width - chartDimensions.left - chartDimensions.right
    const baseline = chartDimensions.height - chartDimensions.bottom
    const firstX = chartDimensions.left
    const lastX = points.length > 1
        ? chartDimensions.left + plotWidth
        : chartDimensions.left + 8

    return `${linePath} L ${lastX.toFixed(2)} ${baseline} L ${firstX} ${baseline} Z`
}

const MetricCard = ({
    label,
    value,
    detail,
    tone,
    progress,
}: {
    label: string
    value: string
    detail: string
    tone: string
    progress?: number
}) => (
    <div className='group relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.055] p-5 shadow-2xl shadow-black/20 backdrop-blur-xl'>
        <div className={`absolute -right-12 -top-12 h-28 w-28 rounded-full blur-2xl ${tone}`} />
        <div className='relative'>
            <p className='text-xs font-semibold uppercase tracking-[0.24em] text-white/45'>
                {label}
            </p>
            <p className='mt-3 text-3xl font-black tracking-tight text-white'>
                {value}
            </p>
            <p className='mt-1 text-sm text-white/55'>{detail}</p>
            {typeof progress === 'number' && (
                <div className='mt-4 h-2 overflow-hidden rounded-full bg-white/10'>
                    <div
                        className='h-full rounded-full bg-gradient-to-r from-cyan-300 via-blue-400 to-emerald-300 transition-all duration-700'
                        style={{ width: `${clamp(progress, 0, 100)}%` }}
                    />
                </div>
            )}
        </div>
    </div>
)

const DataPill = ({ label, value }: { label: string; value: string }) => (
    <div className='rounded-2xl border border-white/10 bg-black/20 px-4 py-3'>
        <p className='text-[11px] font-semibold uppercase tracking-[0.22em] text-white/40'>
            {label}
        </p>
        <p className='mt-1 text-sm font-semibold text-white'>{value}</p>
    </div>
)

const UsageChart = ({
    title,
    subtitle,
    points,
    series,
    yMax,
    yLabel,
}: {
    title: string
    subtitle: string
    points: UsagePoint[]
    series: SeriesConfig[]
    yMax?: number
    yLabel: string
}) => {
    const chartPoints = useMemo(() => downsample(points, 420), [points])
    const stats = useMemo(
        () => series.map(config => metricStats(points, config)),
        [points, series]
    )
    const computedMax = useMemo(() => {
        const values = points.flatMap(point =>
            series.map(config => safeNumber(config.value(point)))
        )
        const rawMax = values.length ? Math.max(...values, 1) : 1

        return yMax ?? rawMax * 1.12
    }, [points, series, yMax])
    const gridLines = [0, 0.25, 0.5, 0.75, 1]
    const firstPoint = chartPoints[0]
    const lastPoint = chartPoints[chartPoints.length - 1]

    return (
        <section className='relative overflow-hidden rounded-[1.75rem] border border-white/10 bg-[#071223]/85 p-5 shadow-2xl shadow-black/25 backdrop-blur-xl'>
            <div className='absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-cyan-300/50 to-transparent' />
            <div className='mb-5 flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between'>
                <div>
                    <p className='text-xs font-semibold uppercase tracking-[0.28em] text-cyan-200/60'>
                        {subtitle}
                    </p>
                    <h3 className='mt-2 text-2xl font-black tracking-tight text-white'>
                        {title}
                    </h3>
                </div>
                <div className='grid grid-cols-1 gap-2 sm:grid-cols-2 xl:min-w-[520px]'>
                    {stats.map(item => (
                        <div
                            key={item.label}
                            className='rounded-2xl border border-white/10 bg-white/[0.045] p-3'
                        >
                            <div className='flex items-center justify-between gap-3'>
                                <span className='flex items-center gap-2 text-xs font-semibold text-white/70'>
                                    <span
                                        className='h-2.5 w-2.5 rounded-full shadow-lg'
                                        style={{
                                            backgroundColor: item.color,
                                            boxShadow: `0 0 18px ${item.color}`,
                                        }}
                                    />
                                    {item.label}
                                </span>
                                <span
                                    className={`text-[11px] font-bold ${
                                        item.trend >= 0 ? 'text-emerald-200' : 'text-rose-200'
                                    }`}
                                >
                                    {item.trend >= 0 ? '+' : ''}
                                    {item.format(item.trend)}
                                </span>
                            </div>
                            <div className='mt-3 grid grid-cols-3 gap-2 text-xs'>
                                <span className='text-white/45'>Now</span>
                                <span className='text-white/45'>Avg</span>
                                <span className='text-white/45'>Peak</span>
                                <strong className='text-white'>{item.format(item.latest)}</strong>
                                <strong className='text-white'>{item.format(item.average)}</strong>
                                <strong className='text-white'>{item.format(item.peak)}</strong>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {chartPoints.length === 0 ? (
                <div className='flex min-h-[320px] items-center justify-center rounded-2xl border border-dashed border-white/15 bg-white/[0.025] text-center'>
                    <div>
                        <p className='text-lg font-semibold text-white'>No usage samples yet</p>
                        <p className='mt-2 text-sm text-white/50'>
                            The node has not returned telemetry for this range.
                        </p>
                    </div>
                </div>
            ) : (
                <div className='rounded-2xl border border-white/10 bg-[#08172c] p-3'>
                    <svg
                        className='h-[320px] w-full overflow-visible'
                        preserveAspectRatio='none'
                        viewBox={`0 0 ${chartDimensions.width} ${chartDimensions.height}`}
                    >
                        <defs>
                            {series.map((config, index) => (
                                <filter
                                    key={`filter-${config.label}`}
                                    id={`usage-glow-${title.replace(/\W+/g, '-')}-${index}`}
                                    x='-20%'
                                    y='-20%'
                                    width='140%'
                                    height='140%'
                                >
                                    <feGaussianBlur stdDeviation='3' result='blur' />
                                    <feMerge>
                                        <feMergeNode in='blur' />
                                        <feMergeNode in='SourceGraphic' />
                                    </feMerge>
                                </filter>
                            ))}
                        </defs>
                        {gridLines.map(line => {
                            const y =
                                chartDimensions.top +
                                (1 - line) *
                                    (chartDimensions.height -
                                        chartDimensions.top -
                                        chartDimensions.bottom)
                            const labelValue = computedMax * line

                            return (
                                <g key={line}>
                                    <line
                                        x1={chartDimensions.left}
                                        x2={chartDimensions.width - chartDimensions.right}
                                        y1={y}
                                        y2={y}
                                        stroke='rgba(255,255,255,0.08)'
                                        strokeDasharray={line === 0 ? '0' : '7 10'}
                                    />
                                    <text
                                        x='0'
                                        y={y + 4}
                                        fill='rgba(255,255,255,0.45)'
                                        fontSize='16'
                                    >
                                        {yMax === 100 ? `${Math.round(labelValue)}%` : compactNumber(labelValue)}
                                    </text>
                                </g>
                            )
                        })}
                        {series.map((config, index) => {
                            const path = buildChartPath(chartPoints, config, computedMax)
                            const areaPath = buildAreaPath(path, chartPoints)

                            return (
                                <g key={config.label}>
                                    <path
                                        d={areaPath}
                                        fill={config.color}
                                        fillOpacity={index === 0 ? 0.16 : 0.08}
                                    />
                                    <path
                                        d={path}
                                        fill='none'
                                        filter={`url(#usage-glow-${title.replace(/\W+/g, '-')}-${index})`}
                                        stroke={config.color}
                                        strokeLinecap='round'
                                        strokeLinejoin='round'
                                        strokeWidth='4'
                                    />
                                    {chartPoints.length > 0 && (
                                        <circle
                                            cx={
                                                chartDimensions.left +
                                                (chartDimensions.width -
                                                    chartDimensions.left -
                                                    chartDimensions.right)
                                            }
                                            cy={
                                                chartDimensions.top +
                                                (chartDimensions.height -
                                                    chartDimensions.top -
                                                    chartDimensions.bottom) -
                                                (clamp(
                                                    safeNumber(config.value(chartPoints[chartPoints.length - 1])) /
                                                        Math.max(computedMax, 1),
                                                    0,
                                                    1
                                                ) *
                                                    (chartDimensions.height -
                                                        chartDimensions.top -
                                                        chartDimensions.bottom))
                                            }
                                            fill={config.color}
                                            r='6'
                                            stroke='#071223'
                                            strokeWidth='4'
                                        />
                                    )}
                                </g>
                            )
                        })}
                    </svg>
                    <div className='mt-1 flex flex-wrap items-center justify-between gap-3 px-1 text-xs text-white/55'>
                        <span>{formatDateTime(firstPoint?.at)}</span>
                        <span className='rounded-full border border-white/10 bg-white/5 px-3 py-1 font-semibold text-white/65'>
                            {chartPoints.length.toLocaleString()} plotted / {points.length.toLocaleString()} raw
                        </span>
                        <span>{formatDateTime(lastPoint?.at)}</span>
                    </div>
                    <p className='mt-2 px-1 text-[11px] uppercase tracking-[0.24em] text-white/35'>
                        {yLabel}
                    </p>
                </div>
            )}
        </section>
    )
}

const ServerUsageContainer = () => {
    const server = ServerContext.useStoreState(state => state.server.data!)
    const [timeframe, setTimeframe] = useState<UsageTimeframe>('hour')
    const [upgradeNotice, setUpgradeNotice] = useState<string | null>(null)

    const {
        data,
        isLoading,
        error,
        isValidating,
        mutate,
    } = useSWR(['server:usage', server.uuid, timeframe], () =>
        getUsage(server.uuid, timeframe, { showProgress: false }), {
            refreshInterval: latest =>
                Math.max(5000, Math.min(30000, (latest?.cacheTtlSeconds ?? 10) * 1000)),
            revalidateOnFocus: true,
            dedupingInterval: 3000,
        }
    )
    const { data: liveState, isValidating: isStateRefreshing } = useSWR(
        ['server:usage-live-state', server.uuid],
        () => getState(server.uuid, { showProgress: false }),
        {
            refreshInterval: 5000,
            revalidateOnFocus: true,
            dedupingInterval: 2500,
        }
    )

    const points = data?.points || []
    const latest = points.length ? points[points.length - 1] : undefined

    const summary = useMemo(() => {
        const liveCpuPercent = liveState ? clamp(liveState.cpuUsed * 100, 0, 100) : null
        const liveMemoryTotal = liveState?.memoryTotal || latest?.memoryTotal || server.limits.memory
        const liveMemoryUsed = liveState?.memoryUsed || latest?.memoryUsed || 0
        const memoryPercent = liveMemoryTotal > 0
            ? clamp((liveMemoryUsed / liveMemoryTotal) * 100, 0, 100)
            : latest?.memoryPercent || 0
        const diskPercent = latest?.diskPercent ?? (
            server.limits.disk > 0 ? clamp(((latest?.diskUsed || 0) / server.limits.disk) * 100, 0, 100) : 0
        )
        const bandwidthPercent = server.limits.bandwidth && server.limits.bandwidth > 0
            ? clamp((server.usages.bandwidth / server.limits.bandwidth) * 100, 0, 100)
            : 0
        const bandwidthUsed = data?.bandwidth.used ?? server.usages.bandwidth
        const bandwidthLimit = data?.bandwidth.limit ?? server.limits.bandwidth
        const liveBandwidthPercent = data?.bandwidth.percent ??
            (bandwidthLimit && bandwidthLimit > 0
                ? clamp((bandwidthUsed / bandwidthLimit) * 100, 0, 100)
                : null)
        const networkIn = latest?.netIn || 0
        const networkOut = latest?.netOut || 0

        return {
            cpuPercent: liveCpuPercent ?? latest?.cpuPercent ?? 0,
            memoryUsed: liveMemoryUsed,
            memoryTotal: liveMemoryTotal,
            memoryPercent,
            diskUsed: latest?.diskUsed || 0,
            diskTotal: latest?.diskTotal || server.limits.disk,
            diskPercent,
            networkIn,
            networkOut,
            bandwidthUsed,
            bandwidthLimit,
            bandwidthRemaining: data?.bandwidth.remaining ?? null,
            bandwidthPercent: liveBandwidthPercent ?? bandwidthPercent,
            bandwidthLimitReached: Boolean(
                data?.bandwidth.limitReached ||
                    (bandwidthLimit && bandwidthLimit > 0 && bandwidthUsed >= bandwidthLimit)
            ),
            suspendedForBandwidth: Boolean(data?.bandwidth.suspendedForBandwidth),
        }
    }, [data?.bandwidth, latest, liveState, server])

    const pressure = Math.round(
        (summary.cpuPercent + summary.memoryPercent + summary.diskPercent) / 3
    )
    const statusLabel = liveState?.state
        ? liveState.state.replace(/_/g, ' ')
        : 'checking'
    const statusTone = liveState?.state === 'running'
        ? 'bg-emerald-400 shadow-emerald-400/70'
        : liveState?.state === 'stopped'
            ? 'bg-rose-400 shadow-rose-400/70'
            : 'bg-amber-300 shadow-amber-300/70'

    const cpuSeries = useMemo<SeriesConfig[]>(
        () => [
            {
                label: 'CPU',
                color: '#22d3ee',
                value: point => point.cpuPercent,
                format: formatPercent,
            },
        ],
        []
    )
    const memoryDiskSeries = useMemo<SeriesConfig[]>(
        () => [
            {
                label: 'RAM',
                color: '#8b5cf6',
                value: point => point.memoryPercent,
                format: formatPercent,
            },
            {
                label: 'Disk',
                color: '#f59e0b',
                value: point => point.diskPercent,
                format: formatPercent,
            },
        ],
        []
    )
    const networkSeries = useMemo<SeriesConfig[]>(
        () => [
            {
                label: 'Inbound',
                color: '#14b8a6',
                value: point => point.netIn,
                format: formatRate,
            },
            {
                label: 'Outbound',
                color: '#fb7185',
                value: point => point.netOut,
                format: formatRate,
            },
        ],
        []
    )
    const upgradeVisible = server.billing.upgradeVisible !== false
    const upgradeConfigured = upgradeVisible && server.billing.upgradeAvailable
    const openUpgradePortal = () => {
        if (!server.billing.upgradeUrl) {
            setUpgradeNotice(
                server.billing.upgradeMessage ||
                    'Upgrade link is not configured for this VPS yet. Contact your provider.'
            )

            return
        }

        window.location.assign(server.billing.upgradeUrl)
    }

    return (
        <ServerContentBlock title='Server Usage'>
            <ServerPageHeader title='Server Usage' />

            <div className='mb-6 overflow-hidden rounded-[2rem] border border-white/10 bg-[radial-gradient(circle_at_top_left,rgba(34,211,238,0.20),transparent_34%),radial-gradient(circle_at_top_right,rgba(139,92,246,0.24),transparent_32%),linear-gradient(135deg,rgba(3,7,18,0.96),rgba(15,23,42,0.92))] p-5 shadow-2xl shadow-black/30'>
                <div className='flex flex-col gap-5 xl:flex-row xl:items-center xl:justify-between'>
                    <div>
                        <div className='flex flex-wrap items-center gap-3'>
                            <span className='inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/10 px-3 py-1 text-xs font-bold uppercase tracking-[0.22em] text-cyan-100'>
                                <span className={`h-2.5 w-2.5 rounded-full shadow-lg ${statusTone}`} />
                                {statusLabel}
                            </span>
                            <span className='rounded-full border border-emerald-300/20 bg-emerald-300/10 px-3 py-1 text-xs font-semibold text-emerald-100'>
                                Live refresh 5s
                            </span>
                            {isValidating || isStateRefreshing ? (
                                <span className='rounded-full border border-cyan-300/20 bg-cyan-300/10 px-3 py-1 text-xs font-semibold text-cyan-100'>
                                    Syncing live data
                                </span>
                            ) : null}
                        </div>
                        <h2 className='mt-5 text-3xl font-black tracking-tight text-white md:text-5xl'>
                            Real-time VPS telemetry
                        </h2>
                        <p className='mt-3 max-w-3xl text-sm leading-6 text-white/60'>
                            Live node state plus Proxmox RRD history for CPU, RAM, disk, and network throughput.
                        </p>
                    </div>

                    <div className='grid min-w-full grid-cols-2 gap-3 sm:grid-cols-4 xl:min-w-[560px]'>
                        <DataPill label='Node' value={server.node?.name || `Node #${server.nodeId}`} />
                        <DataPill label='Location' value={server.node?.locationName || 'Default'} />
                        <DataPill label='Uptime' value={formatDuration(liveState?.uptime || 0)} />
                        <DataPill label='Pressure' value={`${pressure}%`} />
                    </div>
                </div>
            </div>

            <div className='mb-5 flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between'>
                <div className='flex flex-wrap gap-2'>
                    {timeframes.map(item => (
                        <button
                            key={item.id}
                            type='button'
                            onClick={() => setTimeframe(item.id)}
                            className={`rounded-2xl border px-4 py-2 text-left transition ${
                                timeframe === item.id
                                    ? 'border-cyan-300/50 bg-cyan-300/15 text-white shadow-lg shadow-cyan-500/10'
                                    : 'border-white/10 bg-white/[0.04] text-white/60 hover:border-white/20 hover:bg-white/[0.08] hover:text-white'
                            }`}
                        >
                            <span className='block text-sm font-black'>{item.label}</span>
                            <span className='block text-[11px] uppercase tracking-[0.16em]'>
                                {item.detail}
                            </span>
                        </button>
                    ))}
                </div>
                <button
                    type='button'
                    onClick={() => void mutate()}
                    className='rounded-2xl border border-white/10 bg-white/[0.06] px-4 py-3 text-sm font-bold text-white transition hover:border-cyan-300/40 hover:bg-cyan-300/10'
                >
                    Refresh now
                </button>
            </div>

            <div className='mb-5 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-5'>
                <MetricCard
                    label='Live CPU'
                    value={formatPercent(summary.cpuPercent)}
                    detail={`${server.limits.cpu} vCPU assigned`}
                    tone='bg-cyan-400/25'
                    progress={summary.cpuPercent}
                />
                <MetricCard
                    label='Live RAM'
                    value={`${formatByteValue(summary.memoryUsed)} / ${formatByteValue(summary.memoryTotal)}`}
                    detail={formatPercent(summary.memoryPercent)}
                    tone='bg-violet-400/25'
                    progress={summary.memoryPercent}
                />
                <MetricCard
                    label='Disk space'
                    value={`${formatByteValue(summary.diskUsed)} / ${formatByteValue(summary.diskTotal)}`}
                    detail={formatPercent(summary.diskPercent)}
                    tone='bg-amber-400/25'
                    progress={summary.diskPercent}
                />
                <MetricCard
                    label='Network rate'
                    value={`${formatRate(summary.networkIn)} / ${formatRate(summary.networkOut)}`}
                    detail='Inbound / outbound'
                    tone='bg-emerald-400/25'
                />
                <MetricCard
                    label='Bandwidth Usage'
                    value={
                        summary.bandwidthLimit
                            ? `${formatByteValue(summary.bandwidthUsed)} / ${formatByteValue(summary.bandwidthLimit)}`
                            : `${formatByteValue(summary.bandwidthUsed)} used`
                    }
                    detail={
                        summary.bandwidthLimit
                            ? `${formatPercent(summary.bandwidthPercent)} of monthly quota`
                            : 'No fixed quota'
                    }
                    tone={summary.bandwidthLimitReached ? 'bg-rose-400/25' : 'bg-blue-400/25'}
                    progress={summary.bandwidthLimit ? summary.bandwidthPercent : undefined}
                />
            </div>

            {summary.bandwidthLimitReached ? (
                <div className='mb-5 overflow-hidden rounded-[1.5rem] border border-rose-300/30 bg-rose-500/10 p-4 shadow-2xl shadow-rose-950/20'>
                    <div className='flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between'>
                        <div>
                            <p className='text-sm font-black uppercase tracking-[0.24em] text-rose-100'>
                                Bandwidth limit reached
                            </p>
                            <p className='mt-2 text-sm leading-6 text-rose-50/80'>
                                This VPS has used its bandwidth quota. Upgrade bandwidth to restore stable service.
                            </p>
                        </div>
                        {upgradeVisible ? (
                            <button
                                type='button'
                                onClick={openUpgradePortal}
                                className={`rounded-2xl px-5 py-3 text-sm font-black transition ${
                                    upgradeConfigured
                                        ? 'border border-emerald-300/40 bg-emerald-400/15 text-emerald-50 hover:bg-emerald-400/25'
                                        : 'border border-amber-300/40 bg-amber-400/15 text-amber-50 hover:bg-amber-400/25'
                                }`}
                            >
                                {upgradeConfigured ? 'Upgrade Bandwidth' : 'Contact Provider'}
                            </button>
                        ) : null}
                    </div>
                </div>
            ) : null}

            {upgradeNotice ? (
                <div className='mb-5 rounded-2xl border border-amber-300/30 bg-amber-400/10 px-4 py-3 text-sm text-amber-50'>
                    {upgradeNotice}
                </div>
            ) : null}

            <div className='mb-6 grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-6'>
                <DataPill label='Samples' value={(data?.pointCount ?? points.length).toLocaleString()} />
                <DataPill label='Optimized from' value={(data?.rawPointCount ?? points.length).toLocaleString()} />
                <DataPill label='Interval' value={formatSampleInterval(data?.sampleIntervalSeconds)} />
                <DataPill label='First sample' value={formatDateTime(data?.firstAt)} />
                <DataPill label='Latest sample' value={relativeTime(data?.lastAt)} />
                <DataPill
                    label='Bandwidth used'
                    value={
                        summary.bandwidthLimit
                            ? `${formatByteValue(summary.bandwidthUsed)} / ${formatByteValue(summary.bandwidthLimit)}`
                            : `${formatByteValue(summary.bandwidthUsed)} used`
                    }
                />
            </div>

            {isLoading ? (
                <div className='rounded-[1.75rem] border border-white/10 bg-white/[0.045] p-10 text-center text-white/60'>
                    Loading live usage telemetry...
                </div>
            ) : error ? (
                <div className='rounded-[1.75rem] border border-rose-500/30 bg-rose-500/10 p-10 text-center text-rose-100'>
                    Failed to load real usage metrics from the node. Check Proxmox connectivity and Laravel logs.
                </div>
            ) : (
                <div className='space-y-5'>
                    <UsageChart
                        title='CPU activity'
                        subtitle='Compute pressure'
                        points={points}
                        series={cpuSeries}
                        yMax={100}
                        yLabel='CPU percentage'
                    />
                    <UsageChart
                        title='Memory and disk pressure'
                        subtitle='Capacity health'
                        points={points}
                        series={memoryDiskSeries}
                        yMax={100}
                        yLabel='Usage percentage'
                    />
                    <UsageChart
                        title='Network throughput'
                        subtitle='Traffic rate'
                        points={points}
                        series={networkSeries}
                        yLabel='Bytes per second'
                    />
                </div>
            )}
        </ServerContentBlock>
    )
}

export default ServerUsageContainer
