import deleteBackup from '@/api/server/backups/deleteBackup'
import getBackups from '@/api/server/backups/getBackups'
import restoreBackup from '@/api/server/backups/restoreBackup'
import {
    createSnapshot,
    deleteSnapshot,
    getSnapshots,
    restoreSnapshot,
} from '@/api/server/backups/snapshots'
import { ServerContext } from '@/state/server'
import useNotify from '@/util/useNotify'
import { formatBytes } from '@/util/helpers'
import { format } from 'date-fns'
import { useState } from 'react'
import useSWR from 'swr'

import CreateBackupButton from '@/components/servers/backups/CreateBackupButton'
import Modal from '@/components/elements/Modal'
import ServerPageHeader from '@/components/servers/common/ServerPageHeader'
import ServerContentBlock from '@/components/servers/ServerContentBlock'

const BackupsContainer = () => {
    const server = ServerContext.useStoreState(state => state.server.data!)
    const setServer = ServerContext.useStoreActions(actions => actions.server.setServer)
    const notify = useNotify()
    const [snapshotModalOpen, setSnapshotModalOpen] = useState(false)
    const [snapshotName, setSnapshotName] = useState('')
    const [creatingSnapshot, setCreatingSnapshot] = useState(false)

    const backupsSWR = useSWR(['server:backups:snapshots-page', server.uuid], () =>
        getBackups(server.uuid, { page: 1, perPage: 10 })
    )
    const snapshotsSWR = useSWR(['server:snapshots', server.uuid], () =>
        getSnapshots(server.uuid)
    )

    const backups = backupsSWR.data?.items || []
    const snapshots = snapshotsSWR.data || []
    const canCreateSnapshots =
        server.limits.snapshots === null || Number(server.limits.snapshots) >= 1

    const createSnapshotAction = async () => {
        if (!canCreateSnapshots) {
            notify({ color: 'red', message: 'Snapshots are not available on your current plan.' })
            return
        }

        const name = snapshotName.trim()
        if (!name) {
            notify({ color: 'red', message: 'Snapshot name is required.' })
            return
        }

        if (!/^[A-Za-z0-9._-]+$/.test(name)) {
            notify({
                color: 'red',
                message: 'Snapshot name can only contain letters, numbers, dot, underscore and dash.',
            })
            return
        }

        try {
            setCreatingSnapshot(true)
            await createSnapshot(server.uuid, name)
            await snapshotsSWR.mutate()
            setSnapshotModalOpen(false)
            setSnapshotName('')
            notify({ color: 'green', message: `Snapshot "${name}" creation started.` })
        } catch {
            notify({ color: 'red', message: 'Failed to create snapshot.' })
        } finally {
            setCreatingSnapshot(false)
        }
    }

    const restoreBackupAction = async (backupUuid: string, backupName: string) => {
        if (!window.confirm(`Restore backup "${backupName}"? This will overwrite VPS data.`)) {
            return
        }

        try {
            await restoreBackup(server.uuid, backupUuid)
            setServer({ ...server, status: 'restoring_backup' })
            notify({ color: 'green', message: 'Backup restore started.' })
        } catch {
            notify({ color: 'red', message: 'Failed to restore backup.' })
        }
    }

    const deleteBackupAction = async (backupUuid: string, backupName: string) => {
        if (!window.confirm(`Delete backup "${backupName}"?`)) {
            return
        }

        try {
            await deleteBackup(server.uuid, backupUuid)
            await backupsSWR.mutate()
            notify({ color: 'green', message: 'Backup deleted.' })
        } catch {
            notify({ color: 'red', message: 'Failed to delete backup.' })
        }
    }

    const restoreSnapshotAction = async (snapshotName: string) => {
        if (!window.confirm(`Restore snapshot "${snapshotName}"?`)) {
            return
        }

        try {
            await restoreSnapshot(server.uuid, snapshotName)
            setServer({ ...server, status: 'restoring_snapshot' })
            notify({ color: 'green', message: 'Snapshot restore started.' })
        } catch {
            notify({ color: 'red', message: 'Failed to restore snapshot.' })
        }
    }

    const deleteSnapshotAction = async (snapshotName: string) => {
        if (!window.confirm(`Delete snapshot "${snapshotName}"?`)) {
            return
        }

        try {
            await deleteSnapshot(server.uuid, snapshotName)
            await snapshotsSWR.mutate()
            notify({ color: 'green', message: 'Snapshot deleted.' })
        } catch {
            notify({ color: 'red', message: 'Failed to delete snapshot.' })
        }
    }

    return (
        <ServerContentBlock title='Backups'>
            <ServerPageHeader title='Backups' />
            <Modal open={snapshotModalOpen} onClose={() => !creatingSnapshot && setSnapshotModalOpen(false)}>
                <Modal.Header>
                    <Modal.Title>Create snapshot</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Modal.Description bottomMargin>
                        Enter a snapshot name. Allowed characters: letters, numbers, dot, underscore, dash.
                    </Modal.Description>
                    <input
                        value={snapshotName}
                        onChange={event => setSnapshotName(event.target.value)}
                        placeholder='e.g. pre-update-2026-03-08'
                        className='w-full rounded-lg border border-white/15 bg-[#111a31] px-3 py-2 text-sm text-white placeholder:text-white/35 outline-none focus:border-indigo-400'
                        maxLength={40}
                    />
                </Modal.Body>
                <Modal.Actions>
                    <Modal.Action
                        type='button'
                        disabled={creatingSnapshot}
                        onClick={() => setSnapshotModalOpen(false)}
                    >
                        Cancel
                    </Modal.Action>
                    <Modal.Action
                        type='button'
                        loading={creatingSnapshot}
                        onClick={createSnapshotAction}
                    >
                        Create snapshot
                    </Modal.Action>
                </Modal.Actions>
            </Modal>

            <div className='space-y-5'>
                <section className='rounded-2xl border border-white/10 bg-[#1a1441] p-5'>
                    <div className='mb-3 flex flex-wrap items-center justify-between gap-3'>
                        <h3 className='text-xl font-semibold text-white'>Auto-backups</h3>
                        <div className='flex items-center gap-2'>
                            <CreateBackupButton
                                backupCount={backupsSWR.data?.backupCount}
                                swr={{ mutate: backupsSWR.mutate }}
                            />
                        </div>
                    </div>

                    <div className='overflow-x-auto'>
                        <table className='w-full min-w-[640px] text-left text-sm'>
                            <thead>
                                <tr className='border-b border-white/10 text-white/60'>
                                    <th className='py-2 pr-4 font-medium'>Created date</th>
                                    <th className='py-2 pr-4 font-medium'>Name</th>
                                    <th className='py-2 pr-4 font-medium'>Size</th>
                                    <th className='py-2 pr-4 font-medium'>Status</th>
                                    <th className='py-2 pr-4 font-medium'>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {(backupsSWR.isLoading || backupsSWR.isValidating) && !backups.length && (
                                    <tr>
                                        <td colSpan={5} className='py-6 text-center text-white/55'>
                                            Loading backups...
                                        </td>
                                    </tr>
                                )}

                                {backupsSWR.error && !backups.length && (
                                    <tr>
                                        <td colSpan={5} className='py-6 text-center text-rose-300'>
                                            Failed to load backups.
                                        </td>
                                    </tr>
                                )}

                                {backups.map(backup => (
                                    <tr key={backup.uuid} className='border-b border-white/5 text-white/85'>
                                        <td className='py-3 pr-4'>
                                            {format(backup.createdAt, 'yyyy-MM-dd HH:mm')}
                                        </td>
                                        <td className='py-3 pr-4'>{backup.name}</td>
                                        <td className='py-3 pr-4'>
                                            {formatBytes(backup.size).size} {formatBytes(backup.size).unit}
                                        </td>
                                        <td className='py-3 pr-4'>
                                            {backup.isSuccessful ? 'Success' : 'In progress'}
                                        </td>
                                        <td className='py-3 pr-4'>
                                            <div className='flex flex-wrap items-center gap-2'>
                                                <button
                                                    type='button'
                                                    onClick={() => restoreBackupAction(backup.uuid, backup.name)}
                                                    className='rounded-lg border border-white/20 bg-white/5 px-3 py-1 text-xs font-semibold text-white hover:bg-white/10'
                                                >
                                                    Restore
                                                </button>
                                                <button
                                                    type='button'
                                                    onClick={() => deleteBackupAction(backup.uuid, backup.name)}
                                                    className='rounded-lg border border-rose-400/30 bg-rose-500/10 px-3 py-1 text-xs font-semibold text-rose-200 hover:bg-rose-500/20'
                                                >
                                                    Delete
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                                {!backups.length && (
                                    <tr>
                                        <td colSpan={5} className='py-6 text-center text-white/55'>
                                            No backups found.
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </section>

                <section className='rounded-2xl border border-white/10 bg-[#1a1441] p-6'>
                    <div className='mb-4 text-center'>
                        {canCreateSnapshots ? (
                            <>
                                <h3 className='text-2xl font-semibold text-white'>Create a snapshot</h3>
                                <p className='mt-2 text-sm text-white/60'>
                                    Snapshots capture the current VPS state and can be restored quickly.
                                </p>
                                <button
                                    type='button'
                                    onClick={() => setSnapshotModalOpen(true)}
                                    className='mt-4 rounded-lg bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-indigo-500'
                                >
                                    + Create snapshot
                                </button>
                            </>
                        ) : (
                            <p className='text-sm text-white/60'>
                                Snapshot creation is not included in your current plan.
                            </p>
                        )}
                    </div>

                    <div className='mt-6 overflow-x-auto'>
                        <table className='w-full min-w-[640px] text-left text-sm'>
                            <thead>
                                <tr className='border-b border-white/10 text-white/60'>
                                    <th className='py-2 pr-4 font-medium'>Snapshot</th>
                                    <th className='py-2 pr-4 font-medium'>Created</th>
                                    <th className='py-2 pr-4 font-medium'>VM state</th>
                                    <th className='py-2 pr-4 font-medium'>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {(snapshotsSWR.isLoading || snapshotsSWR.isValidating) && !snapshots.length && (
                                    <tr>
                                        <td colSpan={4} className='py-6 text-center text-white/55'>
                                            Loading snapshots...
                                        </td>
                                    </tr>
                                )}

                                {snapshotsSWR.error && !snapshots.length && (
                                    <tr>
                                        <td colSpan={4} className='py-6 text-center text-rose-300'>
                                            Failed to load snapshots.
                                        </td>
                                    </tr>
                                )}

                                {snapshots.map(snapshot => (
                                    <tr key={snapshot.name} className='border-b border-white/5 text-white/85'>
                                        <td className='py-3 pr-4'>
                                            <div>
                                                <p className='font-semibold'>
                                                    {snapshot.name}
                                                    {snapshot.isCurrent ? ' (current)' : ''}
                                                </p>
                                                {snapshot.description && (
                                                    <p className='text-xs text-white/50'>
                                                        {snapshot.description}
                                                    </p>
                                                )}
                                            </div>
                                        </td>
                                        <td className='py-3 pr-4'>
                                            {snapshot.createdAt
                                                ? format(new Date(snapshot.createdAt), 'yyyy-MM-dd HH:mm')
                                                : '-'}
                                        </td>
                                        <td className='py-3 pr-4'>
                                            {snapshot.vmState ? 'Included' : 'No'}
                                        </td>
                                        <td className='py-3 pr-4'>
                                            <div className='flex flex-wrap items-center gap-2'>
                                                <button
                                                    type='button'
                                                    onClick={() => restoreSnapshotAction(snapshot.name)}
                                                    className='rounded-lg border border-white/20 bg-white/5 px-3 py-1 text-xs font-semibold text-white hover:bg-white/10'
                                                >
                                                    Restore
                                                </button>
                                                <button
                                                    type='button'
                                                    onClick={() => deleteSnapshotAction(snapshot.name)}
                                                    className='rounded-lg border border-rose-400/30 bg-rose-500/10 px-3 py-1 text-xs font-semibold text-rose-200 hover:bg-rose-500/20'
                                                >
                                                    Delete
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                                {!snapshots.length && (
                                    <tr>
                                        <td colSpan={4} className='py-6 text-center text-white/55'>
                                            No snapshots found.
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
        </ServerContentBlock>
    )
}

export default BackupsContainer
