import getActions from '@/api/server/actions/getActions'
import getActivityLogs from '@/api/server/actions/getActivityLogs'
import { ServerContext } from '@/state/server'
import { format } from 'date-fns'
import { useState } from 'react'
import useSWR from 'swr'

import ServerPageHeader from '@/components/servers/common/ServerPageHeader'
import ServerContentBlock from '@/components/servers/ServerContentBlock'

const LatestActionsContainer = () => {
    const server = ServerContext.useStoreState(state => state.server.data!)
    const [limit, setLimit] = useState(10)
    const [activityQuery, setActivityQuery] = useState('')
    const [activityEvent, setActivityEvent] = useState('')
    const [activityPage, setActivityPage] = useState(1)
    const [activityPerPage, setActivityPerPage] = useState(25)

    const { data, isLoading, error, mutate, isValidating } = useSWR(
        ['server:actions', server.uuid, limit],
        () => getActions(server.uuid, { limit })
    )
    const activitySWR = useSWR(
        ['server:activity', server.uuid, activityQuery, activityEvent, activityPage, activityPerPage],
        () =>
            getActivityLogs(server.uuid, {
                query: activityQuery,
                event: activityEvent,
                page: activityPage,
                perPage: activityPerPage,
            }),
        {
            keepPreviousData: true,
        }
    )

    const updateActivityQuery = (value: string) => {
        setActivityPage(1)
        setActivityQuery(value)
    }

    const updateActivityEvent = (value: string) => {
        setActivityPage(1)
        setActivityEvent(value)
    }

    const safeFormat = (value?: string | null) => {
        if (!value) return '-'

        const date = new Date(value)
        return Number.isNaN(date.getTime()) ? '-' : format(date, 'yyyy-MM-dd HH:mm:ss')
    }

    const eventLabel = (event: string) =>
        event === 'security.network_alert' ? 'Network traffic alert' : event.replaceAll('_', ' ')

    return (
        <ServerContentBlock title='Latest Actions'>
            <ServerPageHeader title='Latest Actions' />

            <section className='mb-5 rounded-2xl border border-cyan-300/15 bg-[#111a31] p-5 shadow-[0_18px_60px_rgba(8,145,178,0.10)]'>
                <div className='mb-4 flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between'>
                    <div>
                        <p className='text-xs font-bold uppercase tracking-[0.28em] text-cyan-200/70'>
                            VPS audit trail
                        </p>
                        <h3 className='mt-1 text-xl font-semibold text-white'>VPS Event Logs</h3>
                        <p className='mt-1 text-sm text-white/55'>
                            Usage warnings, access locks, power actions, reinstall actions, and panel events for this VPS.
                        </p>
                    </div>
                    <div className='flex flex-col gap-2 sm:flex-row'>
                        <input
                            value={activityQuery}
                            onChange={event => updateActivityQuery(event.target.value)}
                            placeholder='Search event, IP, reason...'
                            className='h-10 min-w-[220px] rounded-lg border border-white/15 bg-slate-950/60 px-3 text-sm text-white placeholder:text-white/35 outline-none focus:border-cyan-300/50'
                        />
                        <select
                            value={activityEvent}
                            onChange={event => updateActivityEvent(event.target.value)}
                            className='h-10 rounded-lg border border-white/15 bg-slate-950/60 px-3 text-sm text-white outline-none focus:border-cyan-300/50'
                        >
                            <option value=''>All events</option>
                            <option value='server:resource_guard_warning'>Usage warnings</option>
                            <option value='server:reinstall'>Reinstall</option>
                        </select>
                        <button
                            type='button'
                            onClick={() => activitySWR.mutate()}
                            className='h-10 rounded-lg border border-white/15 bg-white/5 px-4 text-sm font-semibold text-white hover:bg-white/10'
                        >
                            {activitySWR.isValidating ? 'Refreshing...' : 'Refresh'}
                        </button>
                    </div>
                </div>

                <div className='overflow-x-auto'>
                    <table className='w-full min-w-[860px] text-left text-sm'>
                        <thead>
                            <tr className='border-b border-white/10 text-white/55'>
                                <th className='py-2 pr-4 font-medium'>Event</th>
                                <th className='py-2 pr-4 font-medium'>Reason / details</th>
                                <th className='py-2 pr-4 font-medium'>Actor</th>
                                <th className='py-2 pr-4 font-medium'>IP</th>
                                <th className='py-2 pr-4 font-medium'>Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            {activitySWR.isLoading && (
                                <tr>
                                    <td colSpan={5} className='py-8 text-center text-white/55'>
                                        Loading event logs...
                                    </td>
                                </tr>
                            )}

                            {!activitySWR.isLoading && activitySWR.error && (
                                <tr>
                                    <td colSpan={5} className='py-8 text-center text-rose-300'>
                                        Failed to load event logs.
                                    </td>
                                </tr>
                            )}

                            {!activitySWR.isLoading &&
                                !activitySWR.error &&
                                (activitySWR.data?.items || []).map(row => (
                                    <tr key={`${row.id}-${row.timestamp}`} className='border-b border-white/5 text-white/85'>
                                        <td className='py-3 pr-4'>
                                            <span
                                                className={`inline-flex rounded-full px-2.5 py-1 text-xs font-bold ${
                                                    row.blocked || row.event.includes('locked')
                                                        ? 'border border-rose-300/25 bg-rose-400/10 text-rose-100'
                                                        : row.event.includes('resource_guard')
                                                          ? 'border border-amber-300/25 bg-amber-400/10 text-amber-100'
                                                          : 'border border-cyan-300/20 bg-cyan-400/10 text-cyan-100'
                                                }`}
                                            >
                                                {eventLabel(row.event)}
                                            </span>
                                        </td>
                                        <td className='max-w-[420px] py-3 pr-4'>
                                            <p className='line-clamp-2 text-white/85'>
                                                {row.description || 'No description recorded.'}
                                            </p>
                                            {row.resources.length > 0 && (
                                                <p className='mt-1 text-xs text-white/45'>
                                                    Resources: {row.resources.join(', ')}
                                                </p>
                                            )}
                                        </td>
                                        <td className='py-3 pr-4 text-white/70'>
                                            {row.actorName || row.actorEmail || 'System'}
                                        </td>
                                        <td className='py-3 pr-4 text-white/60'>{row.ip || '-'}</td>
                                        <td className='py-3 pr-4 text-white/70'>{safeFormat(row.timestamp)}</td>
                                    </tr>
                                ))}

                            {!activitySWR.isLoading && !activitySWR.error && !(activitySWR.data?.items || []).length && (
                                <tr>
                                    <td colSpan={5} className='py-8 text-center text-white/55'>
                                        No panel events were recorded for this VPS in the last 90 days.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>

                <div className='mt-4 flex flex-wrap items-center justify-between gap-3 text-sm text-white/60'>
                    <span>
                        Showing {activitySWR.data?.pagination.count || 0} of {activitySWR.data?.pagination.total || 0} logs
                    </span>
                    <div className='flex items-center gap-2'>
                        <select
                            value={activityPerPage}
                            onChange={event => {
                                setActivityPage(1)
                                setActivityPerPage(Number(event.target.value))
                            }}
                            className='h-9 rounded-lg border border-white/15 bg-slate-950/60 px-2 text-sm text-white'
                        >
                            <option value={10}>10</option>
                            <option value={25}>25</option>
                            <option value={50}>50</option>
                            <option value={100}>100</option>
                        </select>
                        <button
                            type='button'
                            disabled={activityPage <= 1}
                            onClick={() => setActivityPage(page => Math.max(1, page - 1))}
                            className='h-9 rounded-lg border border-white/15 bg-white/5 px-3 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:opacity-40'
                        >
                            Prev
                        </button>
                        <span>
                            Page {activitySWR.data?.pagination.currentPage || activityPage} / {activitySWR.data?.pagination.totalPages || 1}
                        </span>
                        <button
                            type='button'
                            disabled={activityPage >= (activitySWR.data?.pagination.totalPages || 1)}
                            onClick={() => setActivityPage(page => page + 1)}
                            className='h-9 rounded-lg border border-white/15 bg-white/5 px-3 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:opacity-40'
                        >
                            Next
                        </button>
                    </div>
                </div>
            </section>

            <section className='rounded-2xl border border-white/10 bg-[#1a1441] p-5'>
                <div className='mb-4 flex items-center justify-between'>
                    <h3 className='text-xl font-semibold text-white'>Action Logs</h3>
                    <div className='flex items-center gap-2'>
                        <button
                            type='button'
                            onClick={() => mutate()}
                            className='rounded-lg border border-white/20 bg-white/5 px-3 py-1.5 text-xs font-semibold text-white hover:bg-white/10'
                        >
                            {isValidating ? 'Refreshing...' : 'Refresh'}
                        </button>
                        <select
                            value={limit}
                            onChange={event => setLimit(Number(event.target.value))}
                            className='rounded-lg border border-white/15 bg-[#111a31] px-3 py-1.5 text-sm text-white'
                        >
                            <option value={10}>10</option>
                            <option value={25}>25</option>
                            <option value={50}>50</option>
                        </select>
                    </div>
                </div>

                <div className='overflow-x-auto'>
                    <table className='w-full min-w-[720px] text-left text-sm'>
                        <thead>
                            <tr className='border-b border-white/10 text-white/60'>
                                <th className='py-2 pr-4 font-medium'>Action name</th>
                                <th className='py-2 pr-4 font-medium'>Status</th>
                                <th className='py-2 pr-4 font-medium'>Triggered on</th>
                                <th className='py-2 pr-4 font-medium'>Completed on</th>
                            </tr>
                        </thead>
                        <tbody>
                            {isLoading && (
                                <tr>
                                    <td colSpan={4} className='py-8 text-center text-white/55'>
                                        Loading actions...
                                    </td>
                                </tr>
                            )}

                            {!isLoading && error && (
                                <tr>
                                    <td colSpan={4} className='py-8 text-center text-rose-300'>
                                        Failed to load actions.
                                    </td>
                                </tr>
                            )}

                            {!isLoading &&
                                (data?.items || []).map(row => (
                                    <tr key={row.upid || `${row.actionName}-${row.triggeredOn}`} className='border-b border-white/5 text-white/85'>
                                        <td className='py-3 pr-4'>{row.actionName}</td>
                                        <td className='py-3 pr-4'>
                                            <span
                                                className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium ${
                                                    row.status === 'success'
                                                        ? 'bg-emerald-500/20 text-emerald-300'
                                                        : row.status === 'running'
                                                          ? 'bg-amber-500/20 text-amber-300'
                                                          : 'bg-rose-500/20 text-rose-300'
                                                }`}
                                            >
                                                {row.statusLabel}
                                            </span>
                                        </td>
                                        <td className='py-3 pr-4'>
                                            {row.triggeredOn
                                                ? format(new Date(row.triggeredOn), 'yyyy-MM-dd HH:mm:ss')
                                                : '-'}
                                        </td>
                                        <td className='py-3 pr-4'>
                                            {row.completedOn
                                                ? format(new Date(row.completedOn), 'yyyy-MM-dd HH:mm:ss')
                                                : row.status === 'running'
                                                  ? 'In progress'
                                                  : '-'}
                                        </td>
                                    </tr>
                                ))}

                            {!isLoading && !error && !(data?.items || []).length && (
                                <tr>
                                    <td colSpan={4} className='py-8 text-center text-white/55'>
                                        No actions found.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </section>
        </ServerContentBlock>
    )
}

export default LatestActionsContainer
