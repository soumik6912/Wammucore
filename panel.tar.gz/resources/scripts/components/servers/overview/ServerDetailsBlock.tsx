import { ServerContext } from '@/state/server'
import { useChartTickLabel } from '@/util/chart'
import { Sizes, convertTimeToSmallest, formatBytes } from '@/util/helpers'
import useNotify from '@/util/useNotify'
import { Skeleton } from '@mantine/core'
import { useEffect, useMemo, useRef, useState } from 'react'
import { Line } from 'react-chartjs-2'
import { useTranslation } from 'react-i18next'

const ServerDetailsBlock = () => {
    const { t } = useTranslation('server.overview')
    const { t: tStrings } = useTranslation('strings')
    const uuid = ServerContext.useStoreState(state => state.server.data!.uuid)
    const server = ServerContext.useStoreState(state => state.server.data!)
    const status = ServerContext.useStoreState(state => state.status.data)
    const getStatus = ServerContext.useStoreActions(
        actions => actions.status.getStatus
    )
    const isUpdating = useRef(true)
    const timerRef = useRef<number | null>(null)
    const errorShownRef = useRef(false)
    const notify = useNotify()
    const [isMobile, setIsMobile] = useState(window.innerWidth < 768)

    useEffect(() => {
        isUpdating.current = true
        errorShownRef.current = false

        const onResize = () => setIsMobile(window.innerWidth < 768)
        window.addEventListener('resize', onResize)

        const update = async () => {
            if (!isUpdating.current) return
            if (document.visibilityState === 'hidden') {
                timerRef.current = window.setTimeout(update, 5000)
                return
            }

            try {
                await getStatus({ uuid, silent: true })
                errorShownRef.current = false
            } catch {
                if (!errorShownRef.current) {
                    notify({
                        title: tStrings('error'),
                        message: t('poll_status_error'),
                        color: 'red',
                    })
                    errorShownRef.current = true
                }

                timerRef.current = window.setTimeout(update, 6000)

                return
            }

            timerRef.current = window.setTimeout(update, isMobile ? 9000 : 6000)
        }

        update()

        return () => {
            isUpdating.current = false
            if (timerRef.current) {
                window.clearTimeout(timerRef.current)
                timerRef.current = null
            }
            window.removeEventListener('resize', onResize)
        }
    }, [uuid, isMobile])

    const memory = {
        used: formatBytes(status?.memoryUsed || 0),
        total: formatBytes(server.limits.memory),
    }

    const uptime = convertTimeToSmallest(status?.uptime || 0)

    const bandwidth = useMemo(() => {
        const total = server.limits.bandwidth
            ? formatBytes(server.limits.bandwidth)
            : undefined
        const percentage = server.limits.bandwidth
            ? Math.floor(
                  (server.usages.bandwidth / server.limits.bandwidth) * 10000
              ) / 100
            : 0
        const used = formatBytes(
            server.usages.bandwidth,
            undefined,
            total?.unit ? total.unit : undefined
        )

        return { used, total, percentage }
    }, [server])

    const cpuGraph = useChartTickLabel('CPU', 100, '%', 2)
    const memoryGraph = useChartTickLabel(
        'Memory',
        memory.total.size,
        memory.total.unit,
        2
    )

    useEffect(() => {
        if (status) {
            cpuGraph.push(Math.floor(status.cpuUsed * 10000) / 100)
            memoryGraph.push(
                formatBytes(status.memoryUsed, 2, memory.total.unit as Sizes)
                    .size
            )
        }
    }, [status])

    const enhancedCpuGraph = {
        ...cpuGraph.props,
        options: {
            ...cpuGraph.props.options,
            plugins: {
                ...cpuGraph.props.options?.plugins,
                legend: {
                    display: false
                }
            },
            scales: {
                ...cpuGraph.props.options?.scales,
                x: {
                    ...cpuGraph.props.options?.scales?.x,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.05)',
                        drawBorder: false
                    },
                    ticks: {
                        color: 'rgba(255, 255, 255, 0.5)',
                        font: {
                            size: 11
                        }
                    }
                },
                y: {
                    ...cpuGraph.props.options?.scales?.y,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.05)',
                        drawBorder: false
                    },
                    ticks: {
                        color: 'rgba(255, 255, 255, 0.5)',
                        font: {
                            size: 11
                        }
                    }
                }
            }
        },
        data: {
            ...cpuGraph.props.data,
            datasets: cpuGraph.props.data.datasets.map(dataset => ({
                ...dataset,
                borderColor: 'rgb(59, 130, 246)',
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4,
                pointRadius: 0,
                pointHoverRadius: 4,
                pointBackgroundColor: 'rgb(59, 130, 246)',
                pointBorderColor: '#fff',
                pointBorderWidth: 2
            }))
        }
    }

    const enhancedMemoryGraph = {
        ...memoryGraph.props,
        options: {
            ...memoryGraph.props.options,
            plugins: {
                ...memoryGraph.props.options?.plugins,
                legend: {
                    display: false
                }
            },
            scales: {
                ...memoryGraph.props.options?.scales,
                x: {
                    ...memoryGraph.props.options?.scales?.x,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.05)',
                        drawBorder: false
                    },
                    ticks: {
                        color: 'rgba(255, 255, 255, 0.5)',
                        font: {
                            size: 11
                        }
                    }
                },
                y: {
                    ...memoryGraph.props.options?.scales?.y,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.05)',
                        drawBorder: false
                    },
                    ticks: {
                        color: 'rgba(255, 255, 255, 0.5)',
                        font: {
                            size: 11
                        }
                    }
                }
            }
        },
        data: {
            ...memoryGraph.props.data,
            datasets: memoryGraph.props.data.datasets.map(dataset => ({
                ...dataset,
                borderColor: 'rgb(168, 85, 247)',
                backgroundColor: 'rgba(168, 85, 247, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4,
                pointRadius: 0,
                pointHoverRadius: 4,
                pointBackgroundColor: 'rgb(168, 85, 247)',
                pointBorderColor: '#fff',
                pointBorderWidth: 2
            }))
        }
    }

    const cpuPercentage = Math.floor(status?.cpuUsed ? status.cpuUsed * 100 : 0)
    const memoryPercentage = Math.floor((memory.used.size / memory.total.size) * 100)

    return (
        <>
            {!status ? (
                <Skeleton className='w-full col-span-10 !h-[200px] rounded-lg' />
            ) : (
                <div className='col-span-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4'>
                    {/* Status Card */}
                    <div className='bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-xl p-5 relative overflow-hidden'>
                        <div className='absolute top-0 right-0 w-20 h-20 bg-blue-500/10 rounded-full -mr-10 -mt-10' />
                        <div className='relative'>
                            <div className='flex items-center gap-2 mb-3'>
                                <svg className='w-4 h-4 text-gray-400' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                    <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z' />
                                </svg>
                                <p className='text-xs font-medium text-gray-400 uppercase tracking-wider'>{t('state')}</p>
                            </div>
                            <div className='flex items-center gap-2.5'>
                                <div className={`w-2.5 h-2.5 rounded-full ${
                                    status.state === 'running' ? 'bg-green-400 shadow-lg shadow-green-400/50' : 'bg-red-400 shadow-lg shadow-red-400/50'
                                }`} />
                                <p className='text-2xl font-bold text-white'>
                                    {t(`states.${status.state}`)}
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* CPU Card */}
                    <div className='bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-xl p-5 relative overflow-hidden'>
                        <div className='absolute top-0 right-0 w-20 h-20 bg-blue-500/10 rounded-full -mr-10 -mt-10' />
                        <div className='relative'>
                            <div className='flex items-center gap-2 mb-3'>
                                <svg className='w-4 h-4 text-gray-400' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                    <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z' />
                                </svg>
                                <p className='text-xs font-medium text-gray-400 uppercase tracking-wider'>{tStrings('cpu')}</p>
                            </div>
                            <div className='flex items-baseline gap-1.5 mb-3'>
                                <p className='text-3xl font-bold text-white'>
                                    {cpuPercentage}
                                </p>
                                <span className='text-sm font-medium text-gray-400'>%</span>
                            </div>
                            <div className='relative bg-gray-700/50 rounded-full h-2 overflow-hidden'>
                                <div 
                                    className='absolute h-full bg-gradient-to-r from-blue-500 to-blue-400 transition-all duration-500 rounded-full'
                                    style={{ width: `${cpuPercentage}%` }}
                                />
                            </div>
                        </div>
                    </div>

                    {/* Memory Card */}
                    <div className='bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-xl p-5 relative overflow-hidden'>
                        <div className='absolute top-0 right-0 w-20 h-20 bg-purple-500/10 rounded-full -mr-10 -mt-10' />
                        <div className='relative'>
                            <div className='flex items-center gap-2 mb-3'>
                                <svg className='w-4 h-4 text-gray-400' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                    <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4' />
                                </svg>
                                <p className='text-xs font-medium text-gray-400 uppercase tracking-wider'>{tStrings('memory')}</p>
                            </div>
                            <div className='flex items-baseline gap-1.5 mb-1'>
                                <p className='text-3xl font-bold text-white'>
                                    {memory.used.size}
                                </p>
                                <span className='text-sm font-medium text-gray-400'>{memory.used.unit}</span>
                            </div>
                            <p className='text-xs text-gray-500 mb-3'>
                                of {memory.total.size} {memory.total.unit}
                            </p>
                            <div className='relative bg-gray-700/50 rounded-full h-2 overflow-hidden'>
                                <div 
                                    className='absolute h-full bg-gradient-to-r from-purple-500 to-purple-400 transition-all duration-500 rounded-full'
                                    style={{ width: `${memoryPercentage}%` }}
                                />
                            </div>
                        </div>
                    </div>

                    {/* Uptime Card */}
                    <div className='bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-xl p-5 relative overflow-hidden'>
                        <div className='absolute top-0 right-0 w-20 h-20 bg-green-500/10 rounded-full -mr-10 -mt-10' />
                        <div className='relative'>
                            <div className='flex items-center gap-2 mb-3'>
                                <svg className='w-4 h-4 text-gray-400' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                    <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z' />
                                </svg>
                                <p className='text-xs font-medium text-gray-400 uppercase tracking-wider'>{t('uptime')}</p>
                            </div>
                            <div className='flex items-baseline gap-2'>
                                <p className='text-3xl font-bold text-white'>
                                    {Math.floor(uptime.time)}
                                </p>
                                <span className='text-sm font-medium text-gray-400'>
                                    {uptime.unit}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Bandwidth Card - New Compact Design */}
            <div className='col-span-10 lg:col-span-2 bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-xl p-5'>
                <div className='flex items-center gap-2 mb-4'>
                    <svg className='w-4 h-4 text-gray-400' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                        <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4' />
                    </svg>
                    <p className='text-xs font-medium text-gray-400 uppercase tracking-wider'>{tStrings('bandwidth_usage')}</p>
                </div>
                
                <div className='space-y-4'>
                    <div>
                        <div className='flex items-baseline gap-1.5 mb-1'>
                            <p className='text-3xl font-bold text-white'>
                                {bandwidth.used.size}
                            </p>
                            <span className='text-sm font-medium text-gray-400'>{bandwidth.used.unit}</span>
                        </div>
                        <p className='text-xs text-gray-500'>
                            of {bandwidth.total ? `${bandwidth.total.size} ${bandwidth.total.unit}` : tStrings('unlimited')}
                        </p>
                    </div>

                    <div>
                        <div className='flex justify-between items-center mb-2'>
                            <span className='text-xs font-medium text-gray-500'>Usage</span>
                            <span className='text-xs font-bold text-white'>{Math.floor(bandwidth.percentage)}%</span>
                        </div>
                        <div className='relative bg-gray-700/50 rounded-full h-2.5 overflow-hidden'>
                            <div 
                                className={`absolute h-full transition-all duration-700 rounded-full ${
                                    bandwidth.percentage < 70 ? 'bg-gradient-to-r from-green-500 to-emerald-400' : 
                                    bandwidth.percentage < 90 ? 'bg-gradient-to-r from-yellow-500 to-amber-400' : 
                                    'bg-gradient-to-r from-red-500 to-orange-400'
                                }`}
                                style={{ width: `${bandwidth.percentage}%` }}
                            />
                        </div>
                    </div>

                    <div className='grid grid-cols-3 gap-2 pt-2 border-t border-gray-700/50'>
                        <div className='text-center'>
                            <div className='w-2 h-2 rounded-full bg-green-500 mx-auto mb-1' />
                            <p className='text-[10px] text-gray-500'>Good</p>
                        </div>
                        <div className='text-center'>
                            <div className='w-2 h-2 rounded-full bg-yellow-500 mx-auto mb-1' />
                            <p className='text-[10px] text-gray-500'>Warning</p>
                        </div>
                        <div className='text-center'>
                            <div className='w-2 h-2 rounded-full bg-red-500 mx-auto mb-1' />
                            <p className='text-[10px] text-gray-500'>Critical</p>
                        </div>
                    </div>
                </div>
            </div>

            {/* CPU Graph */}
            <div className='hidden md:block col-span-10 md:col-span-5 lg:col-span-4 bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-xl p-6'>
                <div className='flex items-center justify-between mb-5'>
                    <div className='flex items-center gap-2'>
                        <div className='w-3 h-3 rounded-full bg-blue-500' />
                        <h3 className='text-sm font-semibold text-gray-200 uppercase tracking-wider'>{tStrings('cpu')} Usage</h3>
                    </div>
                    <span className='text-xs font-medium text-gray-500 px-2 py-1 bg-gray-700/50 rounded'>Live</span>
                </div>
                <div className='h-52'>
                    <Line {...enhancedCpuGraph} />
                </div>
            </div>

            {/* Memory Graph */}
            <div className='hidden md:block col-span-10 md:col-span-5 lg:col-span-4 bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-xl p-6'>
                <div className='flex items-center justify-between mb-5'>
                    <div className='flex items-center gap-2'>
                        <div className='w-3 h-3 rounded-full bg-purple-500' />
                        <h3 className='text-sm font-semibold text-gray-200 uppercase tracking-wider'>{tStrings('memory')} Usage</h3>
                    </div>
                    <span className='text-xs font-medium text-gray-500 px-2 py-1 bg-gray-700/50 rounded'>Live</span>
                </div>
                <div className='h-52'>
                    <Line {...enhancedMemoryGraph} />
                </div>
            </div>
        </>
    )
}

export default ServerDetailsBlock
