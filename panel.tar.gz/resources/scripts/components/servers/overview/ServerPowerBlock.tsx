import { ServerContext } from '@/state/server'
import useNotify from '@/util/useNotify'
import { useTranslation } from 'react-i18next'
import { sendManagementAction } from '@/api/server/management'

import updateStatus, { PowerAction } from '@/api/server/updateState'
import { formatResourceGuardWarning } from '@/api/server/resourceGuard'

import Button from '@/components/elements/Button'


const ServerPowerBlock = () => {
    const { t } = useTranslation('server.overview')
    const { t: tStrings } = useTranslation('strings')
    const server = ServerContext.useStoreState(state => state.server.data)
    const uuid = server?.uuid
    const serverStatus = server?.status
    const state = ServerContext.useStoreState(state => state.status.data?.state)
    const notify = useNotify()
    const stateKey = String(state || '').toLowerCase()
    const stateUnavailable = stateKey === '' || stateKey === 'unknown'

    const isInstalling = ['installing', 'restoring_backup', 'restoring_snapshot'].includes(
        String(serverStatus || '').toLowerCase()
    )
    const isSuspended = String(serverStatus || '').toLowerCase() === 'suspended'
    const guardMessage = formatResourceGuardWarning(server?.resourceGuard)
    const accessLocked = isSuspended
    const accessLockedMessage = 'This VPS is suspended. Power controls are locked until the service is restored.'

    const notifyInstalling = () =>
        notify({
            message: 'Server is currently installing. Please wait until installation is complete.',
            color: 'yellow',
        })

    const update = (action: PowerAction) => {
        if (accessLocked) {
            notify({
                message: accessLockedMessage,
                color: 'yellow',
            })
            return
        }

        if (isInstalling) {
            notifyInstalling()
            return
        }

        updateStatus(uuid!, action)
            .then(response => {
                const guardMessage = formatResourceGuardWarning(
                    response.resourceGuardWarning
                )

                notify({
                    message: guardMessage || t('notices.power_action_sent_success'),
                    color: guardMessage ? 'yellow' : 'green',
                })
            })
            .catch(error =>
                notify({
                    message:
                        error?.response?.data?.message ||
                        t('notices.power_action_sent_fail'),
                    color: 'red',
                })
            )
    }

    const management = (action: 'suspend' | 'resume') => {
        if (accessLocked) {
            notify({
                message: accessLockedMessage,
                color: 'yellow',
            })
            return
        }

        if (isInstalling) {
            notifyInstalling()
            return
        }

        sendManagementAction(uuid!, action)
            .then(response => {
                const guardMessage = formatResourceGuardWarning(
                    response.resourceGuardWarning
                )

                notify({
                    message:
                        guardMessage ||
                        `${action === 'suspend' ? 'Suspend' : 'Resume'} signal sent.`,
                    color: guardMessage ? 'yellow' : 'green',
                })
            })
            .catch(error =>
                notify({
                    message:
                        error?.response?.data?.message ||
                        `${action === 'suspend' ? 'Suspend' : 'Resume'} action failed.`,
                    color: 'red',
                })
            )
    }

    return (
        <div className='mb-4'>
            <div className='flex items-center gap-2 mb-3 px-3 py-2 bg-gray-900/50 rounded-md border border-gray-800'>
                <div className={`w-2 h-2 rounded-full ${
                    stateKey === 'running' ? 'bg-green-500' :
                    stateKey === 'stopped' ? 'bg-gray-500' :
                    'bg-yellow-500'
                }`} />
                <span className='text-sm text-gray-300'>
                    {stateKey === 'running' ? 'Running' :
                     stateKey === 'stopped' ? 'Stopped' :
                     state || 'Unknown'}
                </span>
            </div>

            {accessLocked && (
                <div className='mb-3 rounded-md border border-amber-400/30 bg-amber-500/10 px-3 py-2 text-sm text-amber-100'>
                    {accessLockedMessage}
                </div>
            )}
            {!accessLocked && guardMessage && (
                <div className='mb-3 rounded-md border border-amber-400/30 bg-amber-500/10 px-3 py-2 text-sm text-amber-100'>
                    {guardMessage}
                </div>
            )}

            <div className={`grid grid-cols-2 lg:grid-cols-6 gap-2 transition-all ${isInstalling || accessLocked ? 'opacity-60 blur-[1px]' : ''}`}>
                <button
                    disabled={isInstalling || accessLocked || (!stateUnavailable && stateKey === 'running')}
                    onClick={() => update('start')}
                    className='px-4 py-2.5 bg-green-600 hover:bg-green-700 disabled:bg-gray-800 disabled:text-gray-600 text-white text-sm font-medium rounded-md transition-colors disabled:cursor-not-allowed'
                >
                    {t('power_actions.start')}
                </button>

                <button
                    disabled={isInstalling || accessLocked || (!stateUnavailable && stateKey !== 'running')}
                    onClick={() => update('restart')}
                    className='px-4 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-800 disabled:text-gray-600 text-white text-sm font-medium rounded-md transition-colors disabled:cursor-not-allowed'
                >
                    {t('power_actions.restart')}
                </button>

                <button
                    disabled={isInstalling || accessLocked || (!stateUnavailable && stateKey !== 'running')}
                    onClick={() => update('shutdown')}
                    className='px-4 py-2.5 bg-orange-600 hover:bg-orange-700 disabled:bg-gray-800 disabled:text-gray-600 text-white text-sm font-medium rounded-md transition-colors disabled:cursor-not-allowed'
                >
                    {t('power_actions.shutdown')}
                </button>

                <button
                    disabled={isInstalling || accessLocked || (!stateUnavailable && stateKey === 'stopped')}
                    onClick={() => update('kill')}
                    className='px-4 py-2.5 bg-red-600 hover:bg-red-700 disabled:bg-gray-800 disabled:text-gray-600 text-white text-sm font-medium rounded-md transition-colors disabled:cursor-not-allowed'
                >
                    {t('power_actions.kill')}
                </button>
                <button
                    disabled={isInstalling || accessLocked}
                    onClick={() => management('suspend')}
                    className='px-4 py-2.5 bg-slate-700 hover:bg-slate-600 disabled:bg-gray-800 disabled:text-gray-600 text-white text-sm font-medium rounded-md transition-colors disabled:cursor-not-allowed'
                >
                    Suspend
                </button>
                <button
                    disabled={isInstalling || accessLocked}
                    onClick={() => management('resume')}
                    className='px-4 py-2.5 bg-cyan-700 hover:bg-cyan-600 disabled:bg-gray-800 disabled:text-gray-600 text-white text-sm font-medium rounded-md transition-colors disabled:cursor-not-allowed'
                >
                    Resume
                </button>
            </div>
        </div>
    )
}

export default ServerPowerBlock
