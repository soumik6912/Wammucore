import { useStoreState } from '@/state'

import ServerContentBlock from '@/components/servers/ServerContentBlock'
import ServerPageHeader from '@/components/servers/common/ServerPageHeader'
import ServerAdminBlock from '@/components/servers/overview/ServerAdminBlock'
import ServerExperiencePanel from '@/components/servers/overview/ServerExperiencePanel'
import ServerNetworkBlock from '@/components/servers/overview/ServerNetworkBlock'


const ServerOverviewContainer = () => {
    const rootAdmin = useStoreState(state => state.user.data!.rootAdmin)
    return (
        <ServerContentBlock title='Overview'>
            <ServerPageHeader title='Overview' />
            <div className='grid grid-cols-10 gap-8'>
                <div className='col-span-10'>
                    <ServerExperiencePanel />
                </div>
                <ServerNetworkBlock />
                {rootAdmin && <ServerAdminBlock />}
            </div>
        </ServerContentBlock>
    )
}

export default ServerOverviewContainer
