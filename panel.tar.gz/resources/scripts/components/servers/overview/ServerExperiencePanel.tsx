import getUsage from '@/api/server/usage/getUsage'
import getInstallProgress from '@/api/server/getInstallProgress'
import getAuthSettings from '@/api/server/settings/getAuthSettings'
import updateStatus from '@/api/server/updateState'
import { ServerContext } from '@/state/server'
import { convertTimeToSmallest, formatBytes } from '@/util/helpers'
import useNotify from '@/util/useNotify'
import { useEffect, useMemo, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import useSWR from 'swr'

import {
    ArrowTopRightOnSquareIcon,
    ClipboardDocumentIcon,
    EllipsisHorizontalIcon,
} from '@heroicons/react/24/outline'

import Menu from '@/components/elements/Menu'
import SensitiveValue from '@/components/elements/SensitiveValue'
import SafeImage from '@/components/elements/SafeImage'

const MAX_POINTS = 14
const setupStatuses = ['installing', 'restoring_backup', 'restoring_snapshot']
const unavailableSetupStatuses = ['install_failed', 'deleting', 'deletion_failed']

const MiniSparkline = ({
    values,
    colorClass,
}: {
    values: number[]
    colorClass: string
}) => {
    if (!values.length) {
        return <div className='h-8 w-full rounded bg-[#1a2238]' />
    }

    const max = Math.max(...values, 1)
    const min = Math.min(...values, 0)
    const range = Math.max(max - min, 1)

    const points = values
        .map((v, i) => {
            const x = (i / Math.max(values.length - 1, 1)) * 100
            const y = 100 - ((v - min) / range) * 100
            return `${x},${y}`
        })
        .join(' ')

    return (
        <svg viewBox='0 0 100 100' className='h-8 w-full'>
            <polyline
                fill='none'
                stroke='currentColor'
                strokeWidth='4'
                points={points}
                className={colorClass}
                strokeLinecap='round'
                strokeLinejoin='round'
            />
        </svg>
    )
}

const ServerExperiencePanel = () => {
    const server = ServerContext.useStoreState(state => state.server.data!)
    const status = ServerContext.useStoreState(state => state.status.data)
    const getStatus = ServerContext.useStoreActions(actions => actions.status.getStatus)
    const getServer = ServerContext.useStoreActions(actions => actions.server.getServer)
    const notify = useNotify()

    const [loadingAction, setLoadingAction] = useState(false)
    const [actionCooldown, setActionCooldown] = useState(false)
    const [sshKeysCount, setSshKeysCount] = useState<number | null>(null)
    const actionCooldownTimerRef = useRef<number | null>(null)
    const installRefreshTimerRef = useRef<number | null>(null)
    const lastGuardWarningKeyRef = useRef<string | null>(null)
    const hadResourceGuardRef = useRef(Boolean(server.resourceGuard?.active))
    const guardClearHandledRef = useRef(false)
    const wasInstallingRef = useRef(false)
    const serverState = String(status?.state || '').toLowerCase()
    const stateUnavailable = serverState === '' || serverState === 'unknown'
    const isStopped = serverState === 'stopped'
    const isRunning = serverState === 'running'
    const isTransitioning = ['starting', 'stopping', 'shutdown', 'shutting_down', 'rebooting'].includes(serverState)

    const persistedStatus = String(server.status || '').toLowerCase()
    const isInstalling = setupStatuses.includes(persistedStatus)
    const setupUnavailable = unavailableSetupStatuses.includes(persistedStatus)
    const isSuspended = String(server.status || '').toLowerCase() === 'suspended'
    const usageSWR = useSWR(
        ['server:overview:usage', server.uuid],
        () => getUsage(server.uuid, 'hour', { showProgress: false }),
        {
            refreshInterval: 10000,
            revalidateOnFocus: false,
            refreshWhenHidden: false,
            refreshWhenOffline: false,
        }
    )
    const liveResourceGuardWarning = usageSWR.data?.resourceGuardWarning ?? null
    const resourceGuardWarning = usageSWR.data !== undefined ? liveResourceGuardWarning : server.resourceGuard ?? null
    const accessLocked = isSuspended || setupUnavailable
    const accessLockedMessage = setupUnavailable
          ? persistedStatus === 'install_failed'
              ? 'VPS setup needs provider review before access can be opened.'
              : 'This VPS is not ready for access right now. Please wait for provider review.'
        : 'This VPS is suspended. SSH password, console, SSO, and power controls stay disabled until the provider restores the service.'
    const installProgressSWR = useSWR(
        isInstalling ? ['server:install-progress', server.uuid] : null,
        () => getInstallProgress(server.uuid),
        {
            refreshInterval: 5000,
            revalidateOnFocus: true,
            refreshWhenHidden: false,
            refreshWhenOffline: false,
        }
    )
    const usagePoints = usageSWR.data?.points || []
    const sampledPoints = usagePoints.slice(Math.max(0, usagePoints.length - MAX_POINTS))
    const latestUsage = usagePoints.length ? usagePoints[usagePoints.length - 1] : undefined
    const latestNetworkUsage =
        [...usagePoints]
            .reverse()
            .find(point => Math.max(0, point.netIn || 0) + Math.max(0, point.netOut || 0) > 0) ||
        latestUsage

    const addresses = useMemo(
        () => [...server.limits.addresses.ipv4, ...server.limits.addresses.ipv6],
        [server.limits.addresses]
    )
    const primaryAddress = addresses.find(address => address.type === 'ipv4') ?? addresses[0] ?? null
    const primaryIp = primaryAddress?.address ?? null
    const setupLockedMessage = 'VPS setup is still running. Panel access unlocks automatically when provisioning completes.'
    const accessUnavailable = accessLocked || isInstalling
    const accessUnavailableMessage = isInstalling
        ? setupLockedMessage
        : accessLockedMessage
    const rootAccessValue = primaryIp ? `ssh root@${primaryIp}` : 'No IP assigned'
    const sshUsername = 'root'
    const sshPort = '22'
    const rootPassword = server.credentials?.rootPassword ?? null
    const terminalEnabled = Boolean(server.node?.terminalEnabled)
    const detailValueClass =
        'inline-flex min-w-0 items-center justify-end gap-1 border-0 bg-transparent p-0 text-right font-semibold text-cyan-200 outline-none transition hover:text-cyan-100'
    const detailSensitiveClass = 'min-w-0 break-all text-right text-cyan-200 font-semibold'

    const memory = useMemo(() => {
        const usedRaw = latestUsage?.memoryUsed ?? status?.memoryUsed ?? 0
        const totalRaw = latestUsage?.memoryTotal || status?.memoryTotal || server.limits.memory
        const used = formatBytes(usedRaw)
        const total = formatBytes(totalRaw)
        const pct = totalRaw > 0 ? Math.min(100, (usedRaw / totalRaw) * 100) : 0

        return { used, total, pct }
    }, [latestUsage, status?.memoryUsed, status?.memoryTotal, server.limits.memory])

    const cpuPct = Math.max(
        0,
        Math.min(100, Math.floor(latestUsage?.cpuPercent ?? ((status?.cpuUsed || 0) * 100)))
    )
    const cpuSeries = sampledPoints.map(point => Math.max(0, Math.min(100, point.cpuPercent)))
    const memorySeries = sampledPoints.map(point => Math.max(0, Math.min(100, point.memoryPercent)))
    const networkSeries = sampledPoints.map(point => Math.max(0, point.netIn + point.netOut))
    const incomingSeries = sampledPoints.map(point => Math.max(0, point.netIn))
    const outgoingSeries = sampledPoints.map(point => Math.max(0, point.netOut))
    const diskSeries = sampledPoints.map(point => Math.max(0, Math.min(100, point.diskPercent)))

    const bandwidth = useMemo(() => {
        const used = formatBytes(server.usages.bandwidth)
        const total = server.limits.bandwidth ? formatBytes(server.limits.bandwidth) : null
        const pct =
            server.limits.bandwidth && server.limits.bandwidth > 0
                ? Math.min(100, (server.usages.bandwidth / server.limits.bandwidth) * 100)
                : 0

        return { used, total, pct }
    }, [server.usages.bandwidth, server.limits.bandwidth])

    useEffect(() => {
        if (!liveResourceGuardWarning) {
            return
        }

        const warningKey = [
            liveResourceGuardWarning.stoppedAt,
            liveResourceGuardWarning.message,
        ].join(':')

        if (lastGuardWarningKeyRef.current === warningKey) {
            return
        }

        lastGuardWarningKeyRef.current = warningKey
        void getStatus({ uuid: server.uuid, silent: true }).catch(() => null)
        void getServer({ uuid: server.uuid, silent: true }).catch(() => null)
    }, [
        liveResourceGuardWarning?.stoppedAt,
        liveResourceGuardWarning?.message,
        server.uuid,
    ])

    useEffect(() => {
        if (resourceGuardWarning?.active) {
            hadResourceGuardRef.current = true
            guardClearHandledRef.current = false
        }

        if (usageSWR.data === undefined || liveResourceGuardWarning) {
            return
        }

        if (guardClearHandledRef.current || (!hadResourceGuardRef.current && !server.resourceGuard?.active)) {
            return
        }

        hadResourceGuardRef.current = false
        guardClearHandledRef.current = true
        lastGuardWarningKeyRef.current = null
        notify({ message: 'Resource usage warning cleared.', color: 'green' })
        void getStatus({ uuid: server.uuid, silent: true }).catch(() => null)
        void getServer({ uuid: server.uuid, silent: true }).catch(() => null)
    }, [
        usageSWR.data,
        liveResourceGuardWarning,
        resourceGuardWarning?.active,
        server.resourceGuard?.active,
        server.uuid,
    ])

    useEffect(() => {
        getStatus({ uuid: server.uuid, silent: true }).catch(() => null)

        const id = window.setInterval(() => {
            if (document.visibilityState === 'hidden') return
            getStatus({ uuid: server.uuid, silent: true }).catch(() => null)
        }, 15000)

        return () => window.clearInterval(id)
    }, [server.uuid])

    useEffect(() => {
        if (!isInstalling) {
            if (installRefreshTimerRef.current) {
                window.clearInterval(installRefreshTimerRef.current)
                installRefreshTimerRef.current = null
            }

            if (wasInstallingRef.current) {
                notify({ message: 'VPS setup finished. Refreshing server access now.', color: 'green' })
                void getStatus({ uuid: server.uuid, silent: true }).catch(() => null)
                void getServer({ uuid: server.uuid, silent: true }).catch(() => null)
                void usageSWR.mutate()
            }

            wasInstallingRef.current = false
            return
        }

        wasInstallingRef.current = true
        if (!installRefreshTimerRef.current) {
            installRefreshTimerRef.current = window.setInterval(() => {
                if (document.visibilityState === 'hidden') return
                void getStatus({ uuid: server.uuid, silent: true }).catch(() => null)
                void getServer({ uuid: server.uuid, silent: true }).catch(() => null)
            }, 7000)
        }

        return () => {
            if (installRefreshTimerRef.current) {
                window.clearInterval(installRefreshTimerRef.current)
                installRefreshTimerRef.current = null
            }
        }
    }, [isInstalling, server.uuid])

    useEffect(() => {
        if (accessUnavailable) {
            setSshKeysCount(null)
            return
        }

        getAuthSettings(server.uuid)
            .then(data => {
                const count = (data.sshKeys || '')
                    .split('\n')
                    .map(line => line.trim())
                    .filter(Boolean).length

            setSshKeysCount(count)
        })
        .catch(() => setSshKeysCount(null))
    }, [accessUnavailable, server.uuid])

    const copy = async (value: string, label: string) => {
        try {
            await navigator.clipboard.writeText(value)
            notify({ message: `${label} copied.`, color: 'green' })
        } catch {
            notify({ message: `Unable to copy ${label.toLowerCase()}.`, color: 'red' })
        }
    }

    const runPowerAction = async (action: 'restart' | 'start' | 'shutdown' | 'kill') => {
        if (loadingAction || actionCooldown) {
            return
        }

        if (accessUnavailable) {
            notify({
                message: accessUnavailableMessage,
                color: 'yellow',
            })
            return
        }

        setLoadingAction(true)
        try {
            const response = await updateStatus(server.uuid, action)
            if (!response.resourceGuardWarning) {
                notify({
                    message: `Power action "${action}" sent.`,
                    color: 'green',
                })
            }
            await getStatus({ uuid: server.uuid, silent: true }).catch(() => null)
            await getServer({ uuid: server.uuid, silent: true }).catch(() => null)
        } catch (error: any) {
            notify({
                message:
                    error?.response?.data?.message ||
                    `Failed to send "${action}" action.`,
                color: 'red',
            })
        } finally {
            setLoadingAction(false)
            setActionCooldown(true)
            if (actionCooldownTimerRef.current) {
                window.clearTimeout(actionCooldownTimerRef.current)
            }
            actionCooldownTimerRef.current = window.setTimeout(() => {
                setActionCooldown(false)
                actionCooldownTimerRef.current = null
            }, 8000)
        }
    }

    useEffect(() => {
        return () => {
            if (actionCooldownTimerRef.current) {
                window.clearTimeout(actionCooldownTimerRef.current)
                actionCooldownTimerRef.current = null
            }
        }
    }, [])

    const uptime = convertTimeToSmallest(status?.uptime || 0)
    const memoryHigh = memory.pct >= 85
    const bandwidthLimitReached = Boolean(
        server.limits.bandwidth &&
            server.limits.bandwidth > 0 &&
            server.usages.bandwidth >= server.limits.bandwidth
    )
    const incomingTraffic = formatBytes(latestNetworkUsage?.netIn || 0)
    const outgoingTraffic = formatBytes(latestNetworkUsage?.netOut || 0)
    const diskTotal = formatBytes(latestUsage?.diskTotal || server.limits.disk)

    const openTerminalPopup = () => {
        if (accessUnavailable) {
            notify({
                message: accessUnavailableMessage,
                color: 'yellow',
            })
            return
        }

        window.open(
            `/console?uuid=${encodeURIComponent(server.uuid)}&type=novnc`,
            `wammu-user-console-${server.id}`,
            'popup=yes,width=1280,height=820,resizable=yes,scrollbars=yes'
        )
    }

    const openUpgradePortal = () => {
        if (!server.billing.upgradeUrl) {
            notify({
                message:
                    server.billing.upgradeMessage ||
                    'Upgrade link is not configured for this VPS yet.',
                color: 'yellow',
            })

            return
        }

        window.location.assign(server.billing.upgradeUrl)
    }

    const actionsBusy = loadingAction || actionCooldown
    const powerLocked = actionsBusy || isInstalling || isTransitioning || accessLocked
    const canStart = !powerLocked && (isStopped || stateUnavailable)
    const canRestart = !powerLocked && (isRunning || stateUnavailable)
    const canStop = !powerLocked && (isRunning || stateUnavailable)
    const canKill = !powerLocked && (!isStopped || stateUnavailable)
    const upgradeVisible = server.billing.upgradeVisible !== false
    const upgradeConfigured = upgradeVisible && !isInstalling && !setupUnavailable && server.billing.upgradeAvailable
    const upgradeButtonLabel = upgradeConfigured
        ? 'Upgrade This VPS'
        : server.billing.upgradeReason === 'manual_or_unlinked'
          ? 'Contact Provider'
          : 'Upgrade Unavailable'
    const installProgress = installProgressSWR.data
    const installPercent = Math.max(5, Math.min(100, installProgress?.progressPercent ?? 12))
    const installStep =
        installProgress?.currentStepLabel ||
        (installProgress?.operation === 'reinstall'
            ? 'Reinstalling operating system'
            : 'Preparing your VPS')
    const installElapsed = convertTimeToSmallest(installProgress?.elapsedSeconds || 0)

    return (
        <div className='space-y-7'>
            {isInstalling && (
                <div className='fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-xl'>
                    <div className='w-full max-w-lg overflow-hidden rounded-3xl border border-cyan-300/20 bg-slate-950/90 shadow-[0_30px_120px_rgba(8,145,178,0.24)]'>
                        <div className='relative p-7'>
                            <div className='absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-cyan-400 via-blue-500 to-emerald-400' />
                            <div className='flex items-start gap-4'>
                                <div className='grid h-14 w-14 shrink-0 place-items-center rounded-2xl border border-cyan-300/20 bg-cyan-400/10'>
                                    <div className='h-7 w-7 animate-spin rounded-full border-2 border-cyan-200/20 border-t-cyan-200' />
                                </div>
                                <div className='min-w-0'>
                                    <p className='text-xs font-bold uppercase tracking-[0.28em] text-cyan-200/80'>
                                        VPS setup in progress
                                    </p>
                                    <h2 className='mt-2 text-2xl font-bold text-white'>
                                        Please wait while your VPS is being prepared
                                    </h2>
                                    <p className='mt-2 text-sm leading-6 text-slate-300'>
                                        WammuHost is configuring disk, network, operating system, and access details.
                                        Power controls unlock automatically when setup is complete.
                                    </p>
                                </div>
                            </div>

                            <div className='mt-6 rounded-2xl border border-white/10 bg-white/[0.04] p-4'>
                                <div className='flex items-center justify-between gap-3 text-sm'>
                                    <span className='font-semibold text-white'>{installStep}</span>
                                    <span className='rounded-full border border-cyan-300/20 bg-cyan-300/10 px-3 py-1 text-xs font-bold text-cyan-100'>
                                        {Math.round(installPercent)}%
                                    </span>
                                </div>
                                <div className='mt-4 h-3 overflow-hidden rounded-full bg-slate-800'>
                                    <div
                                        className='h-full rounded-full bg-gradient-to-r from-cyan-300 via-blue-400 to-emerald-300 transition-all duration-700'
                                        style={{ width: `${installPercent}%` }}
                                    />
                                </div>
                                <div className='mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400'>
                                    <span>
                                        Elapsed:{' '}
                                        {installProgress?.elapsedSeconds
                                            ? `${Math.floor(installElapsed.time)} ${installElapsed.unit}`
                                            : 'starting'}
                                    </span>
                                    <span>
                                        {installProgress?.hasRealTaskLog
                                            ? 'Live task tracking enabled'
                                            : 'Waiting for provisioning task'}
                                    </span>
                                </div>
                                {installProgress?.waitingReason && (
                                    <div className='mt-3 rounded-xl border border-cyan-300/20 bg-cyan-300/10 px-3 py-2 text-xs text-cyan-50'>
                                        {installProgress.waitingReason}
                                    </div>
                                )}
                                {installProgress?.error && (
                                    <div className='mt-4 rounded-xl border border-rose-400/30 bg-rose-500/10 px-3 py-2 text-sm text-rose-100'>
                                        {installProgress.error}
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {accessLocked && (
                <div className='rounded-2xl border border-amber-400/25 bg-amber-500/10 p-4 text-sm text-amber-100 shadow-[0_18px_50px_rgba(245,158,11,0.12)]'>
                    <p className='font-semibold text-amber-50'>VPS access is locked</p>
                    <p className='mt-1 text-amber-100/80'>
                        {accessLockedMessage}
                    </p>
                </div>
            )}

            <div
                className='relative isolate overflow-hidden rounded-2xl border border-white/10 bg-[#1a1441] p-5 shadow-[0_12px_40px_rgba(0,0,0,0.35)] md:p-6'
            >
                <div className='relative z-10'>
                    <div className='flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between'>
                    <div className='flex min-w-0 flex-col gap-4 md:flex-row md:items-start'>
                        <div className='flex h-14 w-14 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-[#1b2440]'>
                            <SafeImage
                                src='/favicon.svg'
                                alt='Server'
                                className='h-9 w-9 object-contain'
                                fallbackClassName='h-9 w-9 rounded-lg'
                                fallbackText={server.name}
                            />
                        </div>
                        <div className='min-w-0 space-y-3'>
                            <div>
                                <p className='truncate text-lg font-semibold text-white'>
                                    {server.name}
                                </p>
                                <div className='mt-1 flex flex-wrap items-center gap-2 text-sm text-white/60'>
                                    <span>KVM {server.vmid}</span>
                                    <span
                                        className={`rounded-md px-2 py-0.5 text-xs font-medium ${
                                            status?.state === 'running'
                                                ? 'bg-emerald-500/20 text-emerald-300'
                                                : 'bg-amber-500/20 text-amber-300'
                                        }`}
                                    >
                                        {status?.state === 'running' ? 'Running' : status?.state || 'Unknown'}
                                    </span>
                                </div>
                            </div>

                            <div className='grid gap-3 sm:grid-cols-2'>
                                <div className='min-w-0'>
                                    <p className='text-xs uppercase tracking-wide text-white/50'>Root access</p>
                                    <button
                                        type='button'
                                        disabled={accessUnavailable || !primaryIp}
                                        onClick={() => primaryIp && copy(`root@${primaryIp}`, 'SSH username')}
                                        className='mt-1 inline-flex max-w-full items-center gap-1 border-0 bg-transparent p-0 text-sm font-semibold text-white outline-none hover:text-indigo-300 disabled:cursor-not-allowed disabled:text-white/45'
                                    >
                                        <SensitiveValue className='truncate'>
                                            {accessUnavailable ? 'Locked' : rootAccessValue}
                                        </SensitiveValue>
                                        {!accessUnavailable && primaryIp && <ClipboardDocumentIcon className='h-4 w-4 shrink-0' />}
                                    </button>
                                </div>
                                <div>
                                    <p className='text-xs uppercase tracking-wide text-white/50'>Root password</p>
                                    {accessUnavailable ? (
                                        <span className='mt-1 inline-flex text-sm font-semibold text-white/45'>
                                            Locked
                                        </span>
                                    ) : (
                                        <Link
                                            className='mt-1 inline-flex items-center text-sm font-semibold text-indigo-300 hover:text-indigo-200'
                                            to={`/servers/${server.id}/settings/security`}
                                        >
                                            Change
                                        </Link>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className='flex flex-wrap items-center gap-2'>
                        {terminalEnabled && !accessUnavailable && (
                            <button
                                type='button'
                                onClick={openTerminalPopup}
                                className='inline-flex items-center gap-2 rounded-lg border border-indigo-500/40 bg-indigo-500/10 px-4 py-2 text-sm font-semibold text-indigo-200 hover:bg-indigo-500/20'
                            >
                                Terminal
                                <ArrowTopRightOnSquareIcon className='h-4 w-4' />
                            </button>
                        )}
                        {upgradeVisible ? (
                            <button
                                type='button'
                                onClick={() => {
                                    if (isInstalling) {
                                        notify({ message: setupLockedMessage, color: 'yellow' })
                                        return
                                    }

                                    if (setupUnavailable) {
                                        notify({ message: accessLockedMessage, color: 'yellow' })
                                        return
                                    }

                                    openUpgradePortal()
                                }}
                                className={`inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold transition ${
                                    upgradeConfigured
                                        ? 'border border-emerald-500/40 bg-emerald-500/10 text-emerald-200 hover:bg-emerald-500/20'
                                        : 'border border-amber-400/30 bg-amber-500/10 text-amber-100 hover:bg-amber-500/15'
                                }`}
                            >
                                {isInstalling ? 'Setup In Progress' : upgradeButtonLabel}
                                <ArrowTopRightOnSquareIcon className='h-4 w-4' />
                            </button>
                        ) : null}
                        <button
                            type='button'
                            disabled={isStopped ? !canStart : !canRestart}
                            onClick={() => runPowerAction(isStopped ? 'start' : 'restart')}
                            className='rounded-lg border border-white/15 bg-white/5 px-4 py-2 text-sm font-semibold text-white hover:bg-white/10 disabled:opacity-50'
                        >
                            {isInstalling
                                ? 'Installing...'
                                : accessLocked
                                  ? 'Locked'
                                : actionsBusy
                                  ? 'Please wait...'
                                  : isStopped
                                    ? 'Start VPS'
                                    : 'Reboot VPS'}
                        </button>
                        <Menu width={170} position='bottom-end'>
                            <Menu.Target>
                                <button
                                    type='button'
                                    disabled={powerLocked}
                                    className='grid h-10 w-10 place-items-center rounded-lg border border-white/15 bg-white/5 text-white/70 hover:bg-white/10 disabled:cursor-not-allowed disabled:opacity-50'
                                >
                                    <EllipsisHorizontalIcon className='h-5 w-5' />
                                </button>
                            </Menu.Target>
                            <Menu.Dropdown>
                                <Menu.Item disabled={!canStart} onClick={() => runPowerAction('start')}>Start</Menu.Item>
                                <Menu.Item disabled={!canStop} onClick={() => runPowerAction('shutdown')}>Shutdown</Menu.Item>
                                <Menu.Item disabled={!canKill} color='red' onClick={() => runPowerAction('kill')}>Force Stop</Menu.Item>
                            </Menu.Dropdown>
                        </Menu>
                    </div>
                </div>

                {memoryHigh && (
                    <div className='mt-4 rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-200'>
                        Memory usage is high. Stop unused apps or add swap memory to keep your VPS stable.
                    </div>
                )}

                {bandwidthLimitReached && (
                    <div className='mt-4 flex flex-col gap-3 rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-100 md:flex-row md:items-center md:justify-between'>
                        <span>
                            Bandwidth quota is fully used. Upgrade bandwidth to restore stable service.
                        </span>
                        {upgradeVisible ? (
                            <button
                                type='button'
                                onClick={openUpgradePortal}
                                className='rounded-lg border border-emerald-400/40 bg-emerald-500/10 px-3 py-2 text-xs font-bold text-emerald-100 hover:bg-emerald-500/20'
                            >
                                Upgrade Bandwidth
                            </button>
                        ) : null}
                    </div>
                )}

                {upgradeVisible && !upgradeConfigured && server.billing.upgradeMessage && (
                    <div className='mt-4 rounded-xl border border-amber-500/25 bg-amber-500/10 px-4 py-3 text-sm text-amber-100'>
                        {server.billing.upgradeMessage}
                    </div>
                )}

                <div className='mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3'>
                    <div className='rounded-xl border border-white/10 bg-[#241a52] p-3'>
                        <p className='text-xs uppercase tracking-wide text-white/50'>CPU usage</p>
                        <div className='mt-2 flex items-end justify-between gap-3'>
                            <p className='text-3xl font-bold text-white'>{cpuPct}%</p>
                            <div className='w-28'>
                                <MiniSparkline values={cpuSeries} colorClass='text-blue-400' />
                            </div>
                        </div>
                    </div>
                    <div className='rounded-xl border border-white/10 bg-[#241a52] p-3'>
                        <p className='text-xs uppercase tracking-wide text-white/50'>Memory usage</p>
                        <div className='mt-2 flex items-end justify-between gap-3'>
                            <p className='text-sm font-semibold text-white truncate'>
                                {memory.used.size} {memory.used.unit} / {memory.total.size} {memory.total.unit}
                            </p>
                            <div className='w-28'>
                                <MiniSparkline values={memorySeries} colorClass='text-violet-400' />
                            </div>
                        </div>
                    </div>
                    <div className='rounded-xl border border-white/10 bg-[#241a52] p-3'>
                        <p className='text-xs uppercase tracking-wide text-white/50'>Disk usage</p>
                        <div className='mt-2 flex items-end justify-between gap-3'>
                            <p className='text-sm font-semibold text-white'>
                                {diskTotal.size} {diskTotal.unit}
                            </p>
                            <div className='w-28'>
                                <MiniSparkline values={diskSeries} colorClass='text-indigo-400' />
                            </div>
                        </div>
                    </div>
                    <div className='rounded-xl border border-white/10 bg-[#241a52] p-3'>
                        <p className='text-xs uppercase tracking-wide text-white/50'>Incoming traffic</p>
                        <div className='mt-2 flex items-end justify-between gap-3'>
                            <p className='text-sm font-semibold text-white truncate'>
                                {incomingTraffic.size} {incomingTraffic.unit}
                            </p>
                            <div className='w-28'>
                                <MiniSparkline values={incomingSeries} colorClass='text-cyan-400' />
                            </div>
                        </div>
                    </div>
                    <div className='rounded-xl border border-white/10 bg-[#241a52] p-3'>
                        <p className='text-xs uppercase tracking-wide text-white/50'>Outgoing traffic</p>
                        <div className='mt-2 flex items-end justify-between gap-3'>
                            <p className='text-sm font-semibold text-white truncate'>
                                {outgoingTraffic.size} {outgoingTraffic.unit}
                            </p>
                            <div className='w-28'>
                                <MiniSparkline values={outgoingSeries} colorClass='text-rose-400' />
                            </div>
                        </div>
                    </div>
                    <div className='rounded-xl border border-white/10 bg-[#241a52] p-3'>
                        <p className='text-xs uppercase tracking-wide text-white/50'>Bandwidth</p>
                        <div className='mt-2 flex items-end justify-between gap-3'>
                            <p className='text-sm font-semibold text-white truncate'>
                                {bandwidth.used.size} {bandwidth.used.unit}
                                {bandwidth.total ? ` / ${bandwidth.total.size} ${bandwidth.total.unit}` : ' / Unlimited'}
                            </p>
                            <div className='w-28'>
                                <MiniSparkline values={networkSeries} colorClass='text-cyan-400' />
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>

            <div className='grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4'>
                <Link to={`/servers/${server.id}/settings/security`} className='rounded-xl border border-white/10 bg-[#1a1441] p-4 hover:bg-[#241a52]'>
                    <p className='text-sm text-white/60'>SSH key</p>
                    <p className='mt-2 text-xl font-bold text-white'>{sshKeysCount ?? '-'}</p>
                </Link>
                <Link to={`/servers/${server.id}/security/firewall`} className='rounded-xl border border-white/10 bg-[#1a1441] p-4 hover:bg-[#241a52]'>
                    <p className='text-sm text-white/60'>Firewall rules</p>
                    <p className='mt-2 text-xl font-bold text-white'>0</p>
                </Link>
                <Link to={`/servers/${server.id}/backups`} className='rounded-xl border border-white/10 bg-[#1a1441] p-4 hover:bg-[#241a52]'>
                    <p className='text-sm text-white/60'>Backups</p>
                    <p className='mt-2 text-xl font-bold text-white'>
                        {server.limits.backups ?? 'Unlimited'}
                    </p>
                </Link>
                <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                    <p className='text-sm text-white/60'>Uptime</p>
                    <p className='mt-2 text-xl font-bold text-white'>
                        {Math.floor(uptime.time)} {uptime.unit}
                    </p>
                </div>
            </div>

            <div className='grid grid-cols-1 gap-5 xl:grid-cols-2'>
                <div className='rounded-2xl border border-white/10 bg-[#1a1441] p-4'>
                    <h3 className='text-base font-semibold text-white'>VPS details</h3>
                    <div className='mt-3 divide-y divide-white/10'>
                        <div className='flex items-center justify-between py-2 text-sm'>
                            <span className='text-white/60'>Hostname</span>
                            <button
                                type='button'
                                disabled={accessUnavailable}
                                onClick={() => copy(server.hostname, 'Hostname')}
                                className={`${detailValueClass} disabled:cursor-not-allowed disabled:text-white/50`}
                            >
                                <SensitiveValue className={accessUnavailable ? 'text-white/50' : detailSensitiveClass}>
                                    {accessUnavailable ? 'Locked' : server.hostname}
                                </SensitiveValue>
                                {!accessUnavailable && <ClipboardDocumentIcon className='h-4 w-4 shrink-0' />}
                            </button>
                        </div>
                        <div className='flex items-center justify-between py-2 text-sm'>
                            <span className='text-white/60'>SSH username</span>
                            <button
                                type='button'
                                disabled={accessUnavailable}
                                onClick={() => copy(sshUsername, 'SSH username')}
                                className={`${detailValueClass} disabled:cursor-not-allowed disabled:text-white/50`}
                            >
                                <SensitiveValue className={accessUnavailable ? 'text-white/50' : detailSensitiveClass}>
                                    {accessUnavailable ? 'Locked' : sshUsername}
                                </SensitiveValue>
                                {!accessUnavailable && <ClipboardDocumentIcon className='h-4 w-4 shrink-0' />}
                            </button>
                        </div>
                        <div className='flex items-center justify-between py-2 text-sm'>
                            <span className='text-white/60'>IPv4</span>
                            <button
                                type='button'
                                disabled={accessUnavailable || !primaryIp}
                                onClick={() => primaryIp && copy(primaryIp, 'IP address')}
                                className={!accessUnavailable && primaryIp ? detailValueClass : `${detailValueClass} cursor-not-allowed text-white/45 hover:text-white/45`}
                            >
                                <SensitiveValue className={!accessUnavailable && primaryIp ? detailSensitiveClass : 'text-right text-white/45'}>
                                    {accessUnavailable ? 'Locked' : primaryIp ?? 'No IPv4 assigned'}
                                </SensitiveValue>
                                {!accessUnavailable && primaryIp && <ClipboardDocumentIcon className='h-4 w-4 shrink-0' />}
                            </button>
                        </div>
                        <div className='flex items-center justify-between py-2 text-sm'>
                            <span className='text-white/60'>Port</span>
                            <button
                                type='button'
                                disabled={accessUnavailable}
                                onClick={() => copy(sshPort, 'SSH port')}
                                className={`${detailValueClass} disabled:cursor-not-allowed disabled:text-white/50`}
                            >
                                <SensitiveValue className={accessUnavailable ? 'text-white/50' : detailSensitiveClass}>
                                    {accessUnavailable ? 'Locked' : sshPort}
                                </SensitiveValue>
                                {!accessUnavailable && <ClipboardDocumentIcon className='h-4 w-4 shrink-0' />}
                            </button>
                        </div>
                        <div className='flex items-center justify-between py-2 text-sm'>
                            <span className='text-white/60'>Password</span>
                            <button
                                type='button'
                                onClick={() => rootPassword && copy(rootPassword, 'Root password')}
                                disabled={!rootPassword || accessUnavailable}
                                className={`${detailValueClass} disabled:cursor-not-allowed disabled:text-white/50`}
                            >
                                <SensitiveValue className={rootPassword && !accessUnavailable ? detailSensitiveClass : 'text-white/50'}>
                                    {accessUnavailable ? 'Locked' : rootPassword || '-'}
                                </SensitiveValue>
                                {rootPassword && !accessUnavailable && <ClipboardDocumentIcon className='h-4 w-4 shrink-0' />}
                            </button>
                        </div>
                    </div>
                </div>

                <div className='rounded-2xl border border-white/10 bg-[#1a1441] p-4'>
                    <h3 className='text-base font-semibold text-white'>Plan details</h3>
                    <div className='mt-3 divide-y divide-white/10'>
                        <div className='flex items-center justify-between py-2 text-sm'>
                            <span className='text-white/60'>Location</span>
                            <span className='text-white font-medium'>
                                {server.node?.locationName ||
                                    server.node?.name ||
                                    server.node?.cluster ||
                                    (server.nodeId ? `Node #${server.nodeId}` : 'Not assigned')}
                            </span>
                        </div>
                        <div className='flex items-center justify-between py-2 text-sm'>
                            <span className='text-white/60'>CPU</span>
                            <span className='text-white font-medium'>
                                {server.limits.cpu} cores
                            </span>
                        </div>
                        <div className='flex items-center justify-between py-2 text-sm'>
                            <span className='text-white/60'>Memory</span>
                            <span className='text-white font-medium'>
                                {formatBytes(server.limits.memory).size} {formatBytes(server.limits.memory).unit}
                            </span>
                        </div>
                        <div className='flex items-center justify-between py-2 text-sm'>
                            <span className='text-white/60'>Disk</span>
                            <span className='text-white font-medium'>
                                {formatBytes(server.limits.disk).size} {formatBytes(server.limits.disk).unit}
                            </span>
                        </div>
                        <div className='flex items-center justify-between py-2 text-sm'>
                            <span className='text-white/60'>Network</span>
                            <span className='text-white font-medium'>
                                {server.limits.bandwidth
                                    ? `${formatBytes(server.limits.bandwidth).size} ${formatBytes(server.limits.bandwidth).unit}`
                                    : 'Unlimited'}{' '}
                                / {formatBytes(server.usages.bandwidth).size} {formatBytes(server.usages.bandwidth).unit}
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default ServerExperiencePanel
