import { Address } from '@/api/server/getServer'
import SensitiveValue from '@/components/elements/SensitiveValue'
import { ServerContext } from '@/state/server'
import { useMemo, useState } from 'react'

const ServerNetworkBlock = () => {
    const server = ServerContext.useStoreState(state => state.server.data!)
    const [copiedId, setCopiedId] = useState<string | null>(null)

    const ipv4 = server.limits.addresses.ipv4
    const ipv6 = server.limits.addresses.ipv6
    const addresses = useMemo(() => [...ipv4, ...ipv6], [ipv4, ipv6])
    const primaryAddress = ipv4[0] ?? addresses[0] ?? null
    const shouldShow = addresses.length > 1 || ipv6.length > 0

    if (!shouldShow) {
        return null
    }

    const copyToClipboard = (text: string, id: string) => {
        if (!text || text === '-') {
            return
        }

        navigator.clipboard.writeText(text).then(() => {
            setCopiedId(id)
            setTimeout(() => setCopiedId(null), 1600)
        })
    }

    const renderCopyValue = (value: string | null | undefined, id: string) => {
        const safeValue = value || '-'

        return (
            <button
                type='button'
                onClick={() => copyToClipboard(safeValue, id)}
                className='group inline-flex max-w-full items-center gap-2 rounded-lg border border-[var(--border-soft)] bg-[var(--surface-soft)] px-3 py-2 text-left font-mono text-xs font-semibold text-white transition hover:border-[var(--tenant-brand-accent)]/60 hover:bg-[var(--surface-hover)]'
            >
                <span className='min-w-0 truncate'>
                    <SensitiveValue>{safeValue}</SensitiveValue>
                </span>
                <span className='shrink-0 text-[10px] font-bold uppercase tracking-wide text-[var(--tenant-brand-accent)] opacity-75'>
                    {copiedId === id ? 'Copied' : 'Copy'}
                </span>
            </button>
        )
    }

    const renderAddress = (address: Address, index: number) => {
        const isPrimary = primaryAddress?.id === address.id
        const label = isPrimary ? 'Primary' : 'Additional'
        const typeLabel = address.type === 'ipv6' ? 'IPv6' : 'IPv4'
        const cidrLabel = Number(address.cidr) > 0 ? `/${address.cidr}` : ''

        return (
            <article
                key={`${address.type}-${address.id}`}
                className='rounded-2xl border border-[var(--border-soft)] bg-[var(--surface-raised)] p-4 shadow-lg shadow-black/10'
            >
                <div className='flex flex-wrap items-start justify-between gap-3'>
                    <div>
                        <div className='flex flex-wrap items-center gap-2'>
                            <span className='rounded-full border border-[var(--tenant-brand-accent)]/30 bg-[var(--tenant-brand-accent)]/10 px-2.5 py-1 text-[11px] font-black uppercase tracking-wide text-[var(--tenant-brand-accent)]'>
                                {typeLabel}
                            </span>
                            <span className='rounded-full border border-[var(--border-soft)] bg-[var(--surface-soft)] px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide text-[var(--text-muted)]'>
                                {label}
                            </span>
                        </div>
                        <h4 className='mt-3 text-sm font-semibold text-white'>
                            {typeLabel} address {index + 1}
                        </h4>
                    </div>
                    {address.claimLabel ? (
                        <span className='rounded-full bg-[var(--surface-active)] px-2.5 py-1 text-[11px] font-semibold text-[var(--text-muted)]'>
                            {address.claimLabel}
                        </span>
                    ) : null}
                </div>

                <div className='mt-4 grid gap-3 lg:grid-cols-3'>
                    <div>
                        <p className='mb-1.5 text-[11px] font-bold uppercase tracking-wide text-[var(--text-muted)]'>
                            Address
                        </p>
                        {renderCopyValue(`${address.address}${cidrLabel}`, `ip-${address.id}`)}
                    </div>
                    <div>
                        <p className='mb-1.5 text-[11px] font-bold uppercase tracking-wide text-[var(--text-muted)]'>
                            Gateway
                        </p>
                        {renderCopyValue(address.gateway, `gateway-${address.id}`)}
                    </div>
                    <div>
                        <p className='mb-1.5 text-[11px] font-bold uppercase tracking-wide text-[var(--text-muted)]'>
                            MAC
                        </p>
                        {renderCopyValue(address.macAddress, `mac-${address.id}`)}
                    </div>
                </div>
            </article>
        )
    }

    return (
        <section className='col-span-10 rounded-3xl border border-[var(--border-soft)] bg-[linear-gradient(135deg,var(--surface-raised),var(--surface-active))] p-5 shadow-2xl shadow-black/10'>
            <div className='flex flex-wrap items-end justify-between gap-3'>
                <div>
                    <p className='text-xs font-black uppercase tracking-[0.24em] text-[var(--tenant-brand-accent)]'>
                        Network
                    </p>
                    <h3 className='mt-2 text-xl font-semibold text-white'>
                        Assigned IP Addresses
                    </h3>
                    <p className='mt-1 text-sm text-[var(--text-muted)]'>
                        Extra IPv4 and IPv6 assignments appear here only after your provider attaches them to this VPS.
                    </p>
                </div>
                <div className='flex gap-2 text-xs font-semibold text-[var(--text-muted)]'>
                    <span className='rounded-full border border-[var(--border-soft)] bg-[var(--surface-soft)] px-3 py-1'>
                        IPv4: {ipv4.length}
                    </span>
                    <span className='rounded-full border border-[var(--border-soft)] bg-[var(--surface-soft)] px-3 py-1'>
                        IPv6: {ipv6.length}
                    </span>
                </div>
            </div>

            <div className='mt-5 grid gap-4'>
                {addresses.map(renderAddress)}
            </div>
        </section>
    )
}

export default ServerNetworkBlock
