import { ServerContext } from '@/state/server'
import { useTranslation } from 'react-i18next'
import { Link } from 'react-router-dom'

import Button from '@/components/elements/Button'
import Card from '@/components/elements/Card'


const ServerAdminBlock = () => {
    const serverId = ServerContext.useStoreState(state => state.server.data!.id)
    const { t } = useTranslation('server.overview')

    return (
        <div className='col-span-10 md:col-span-5 bg-gradient-to-br from-gray-800 to-gray-900 border border-gray-700 rounded-xl p-6 relative overflow-hidden'>
            {/* Decorative background elements */}
            <div className='absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full -mr-16 -mt-16' />
            <div className='absolute bottom-0 left-0 w-24 h-24 bg-purple-500/5 rounded-full -ml-12 -mb-12' />
            
            <div className='relative'>
                {/* Icon and Title */}
                <div className='flex items-start gap-3 mb-4'>
                    <div className='p-2.5 bg-blue-500/10 rounded-lg border border-blue-500/20'>
                        <svg className='w-5 h-5 text-blue-400' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                            <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z' />
                            <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M15 12a3 3 0 11-6 0 3 3 0 016 0z' />
                        </svg>
                    </div>
                    <div className='flex-1'>
                        <h3 className='text-lg font-semibold text-white mb-1'>
                            {t('server_config.title')}
                        </h3>
                        <p className='text-sm text-gray-400 leading-relaxed'>
                            {t('server_config.description')}
                        </p>
                    </div>
                </div>

                {/* Features List */}
                <div className='space-y-2.5 mb-6 mt-5'>
                    <div className='flex items-center gap-2.5'>
                        <div className='w-1.5 h-1.5 rounded-full bg-blue-400' />
                        <span className='text-xs text-gray-300'>Advanced server settings</span>
                    </div>
                    <div className='flex items-center gap-2.5'>
                        <div className='w-1.5 h-1.5 rounded-full bg-purple-400' />
                        <span className='text-xs text-gray-300'>Resource management</span>
                    </div>
                    <div className='flex items-center gap-2.5'>
                        <div className='w-1.5 h-1.5 rounded-full bg-green-400' />
                        <span className='text-xs text-gray-300'>Security configurations</span>
                    </div>
                </div>

                {/* Action Button */}
                <Link to={`/admin/servers/${serverId}`} className='block'>
                    <button className='w-full px-4 py-3 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 group'>
                        <span>{t('server_config.configure_server')}</span>
                        <svg className='w-4 h-4 group-hover:translate-x-1 transition-transform' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                            <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M13 7l5 5m0 0l-5 5m5-5H6' />
                        </svg>
                    </button>
                </Link>
            </div>
        </div>
    )
}

export default ServerAdminBlock