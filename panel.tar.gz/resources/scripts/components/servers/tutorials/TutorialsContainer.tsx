import { useStoreState } from '@/state'
import { ServerContext } from '@/state/server'
import { useMemo, useState } from 'react'

import Modal from '@/components/elements/Modal'
import ServerContentBlock from '@/components/servers/ServerContentBlock'
import ServerPageHeader from '@/components/servers/common/ServerPageHeader'

type LessonStep = {
    title: string
    detail: string
    example?: string
}

type Lesson = {
    id: string
    title: string
    tag: string
    use: string
    summary: string
    steps: LessonStep[]
    commands?: string[]
    checklist: string[]
    mistakes?: string[]
}

const buildLessons = (host: string): Lesson[] => [
    {
        id: 'vps-basics',
        title: 'VPS basics',
        tag: 'Start here',
        use: 'Understand what you are renting before installing anything.',
        summary: 'A VPS is a private cloud computer with CPU, RAM, disk, IP address, and bandwidth limits.',
        steps: [
            {
                title: 'Know your resources',
                detail: 'CPU handles calculations, RAM keeps apps alive, disk stores files, network moves traffic, and bandwidth is total transfer.',
            },
            {
                title: 'Treat it like a real server',
                detail: 'It stays online 24/7, so weak passwords, open ports, or broken services can cause real damage.',
            },
            {
                title: 'Change one thing at a time',
                detail: 'Before a big install or config edit, make a backup and write down what you changed.',
            },
        ],
        checklist: [
            'I know CPU, RAM, disk, network, and bandwidth mean different things.',
            'I will make backups before risky changes.',
            'I will not run random install scripts without checking what they do.',
        ],
        mistakes: [
            'Buying too little RAM for Minecraft and then blaming the panel.',
            'Opening all ports because one app did not work immediately.',
        ],
    },
    {
        id: 'termius-ssh',
        title: 'SSH with Termius',
        tag: 'Access',
        use: 'Login to your VPS from Windows, Android, or iPhone using Termius or any SSH client.',
        summary: 'SSH is the safe terminal connection used to install, repair, and control your VPS.',
        steps: [
            {
                title: 'Create a Termius host',
                detail: 'Add a new host, enter your VPS IP, set username root or your admin user, and keep port 22 unless you changed it.',
                example: host,
            },
            {
                title: 'Connect and verify',
                detail: 'After login, run small read-only commands first so you know the server is healthy.',
            },
            {
                title: 'Save credentials safely',
                detail: 'Use SSH keys when possible. If you save a password, protect your Termius account with strong login security.',
            },
        ],
        commands: [`ssh root@${host}`, 'uptime', 'free -h', 'df -h'],
        checklist: [
            'I can connect to the VPS with Termius.',
            'I can run uptime, free -h, and df -h.',
            'I know SSH is more powerful than the web panel, so I use it carefully.',
        ],
        mistakes: [
            'Typing the hostname field when the provider gave an IP address.',
            'Using root forever instead of creating a safer admin user later.',
        ],
    },
    {
        id: 'linux-health',
        title: 'Linux health checks',
        tag: 'Daily',
        use: 'Find out if CPU, RAM, disk, or services are causing problems.',
        summary: 'A few commands tell you whether the VPS is stable before you restart or reinstall anything.',
        steps: [
            {
                title: 'Check uptime and load',
                detail: 'Load average tells whether CPU is overloaded. Compare it with your CPU core count.',
            },
            {
                title: 'Check memory and disk',
                detail: 'Low free RAM or full disk can break Minecraft, MySQL, Pterodactyl, and Paymenter.',
            },
            {
                title: 'Check service status',
                detail: 'Restart only the broken service instead of rebooting the full VPS every time.',
            },
        ],
        commands: ['uptime', 'free -h', 'df -h', 'systemctl --failed', 'journalctl -xe --no-pager | tail -80'],
        checklist: [
            'I know how to check memory and disk before opening support.',
            'I can see failed services with systemctl --failed.',
            'I can read the newest log lines with journalctl.',
        ],
        mistakes: [
            'Rebooting repeatedly without checking why the service fails.',
            'Ignoring a full disk until databases stop writing data.',
        ],
    },
    {
        id: 'secure-user',
        title: 'Admin user and SSH keys',
        tag: 'Security',
        use: 'Reduce risk by using a normal sudo user and key-based login.',
        summary: 'Root login is powerful. A separate admin user and SSH key make daily work safer.',
        steps: [
            {
                title: 'Create an admin user',
                detail: 'Use a personal admin account for daily work, then use sudo only when needed.',
            },
            {
                title: 'Add your SSH key',
                detail: 'Keys are safer than passwords and work well with Termius.',
            },
            {
                title: 'Keep a recovery path',
                detail: 'Do not disable password/root login until you have confirmed the SSH key works in a second terminal.',
            },
        ],
        commands: ['adduser admin', 'usermod -aG sudo admin', 'su - admin', 'ssh-keygen -t ed25519', 'sudo systemctl restart ssh'],
        checklist: [
            'I have an admin user with sudo access.',
            'My SSH key login works before I disable anything.',
            'I kept recovery access in case I lock myself out.',
        ],
        mistakes: [
            'Disabling root login before testing the new user.',
            'Sharing one root password with multiple people.',
        ],
    },
    {
        id: 'firewall-ports',
        title: 'Firewall ports',
        tag: 'Security',
        use: 'Open only the ports your game, web panel, or database really needs.',
        summary: 'A firewall keeps unwanted traffic out while allowing Minecraft, web, SSH, and panel traffic.',
        steps: [
            {
                title: 'Start with SSH',
                detail: 'Always allow SSH before enabling the firewall, or you can lock yourself out.',
            },
            {
                title: 'Open app ports',
                detail: 'Minecraft Java usually uses 25565/tcp. Web panels usually need 80/tcp and 443/tcp.',
            },
            {
                title: 'Keep databases private',
                detail: 'MySQL or PostgreSQL should usually listen locally only, not open to the whole internet.',
            },
        ],
        commands: ['ufw allow OpenSSH', 'ufw allow 80/tcp', 'ufw allow 443/tcp', 'ufw allow 25565/tcp', 'ufw enable', 'ufw status numbered'],
        checklist: [
            'SSH is allowed before the firewall is enabled.',
            'Only required game and web ports are open.',
            'Database ports are not public unless there is a strong reason.',
        ],
        mistakes: [
            'Opening 3306/mysql publicly for convenience.',
            'Forgetting Bedrock uses UDP ports, not the same Java TCP-only setup.',
        ],
    },
    {
        id: 'updates-packages',
        title: 'Safe updates',
        tag: 'Maintenance',
        use: 'Patch your VPS without breaking production services unexpectedly.',
        summary: 'Updates keep the server secure, but production servers need a careful routine.',
        steps: [
            {
                title: 'Backup first',
                detail: 'For Minecraft, back up worlds and configs. For panels, back up database and app files.',
            },
            {
                title: 'Update packages',
                detail: 'Run package updates during low traffic time when possible.',
            },
            {
                title: 'Check services after update',
                detail: 'Confirm Minecraft, nginx, database, docker, and queues are still running.',
            },
        ],
        commands: ['apt update', 'apt list --upgradable', 'apt upgrade -y', 'systemctl --failed', 'reboot'],
        checklist: [
            'I backup before major updates.',
            'I check failed services after updating.',
            'I reboot only when needed or after kernel updates.',
        ],
        mistakes: [
            'Updating during peak player time without backups.',
            'Forgetting to restart services that need new libraries.',
        ],
    },
    {
        id: 'minecraft-setup',
        title: 'Minecraft Java or Paper setup',
        tag: 'Minecraft',
        use: 'Install a stable Minecraft server without overloading the VPS.',
        summary: 'Paper is usually better for performance than vanilla when hosting players and plugins.',
        steps: [
            {
                title: 'Install Java',
                detail: 'Modern Minecraft versions usually need Java 21. Older versions may need Java 17 or 8.',
            },
            {
                title: 'Create a server folder',
                detail: 'Keep Minecraft files in one folder like /opt/minecraft so backups are easy.',
            },
            {
                title: 'Accept EULA only after reading it',
                detail: 'The server will not start until eula.txt is accepted.',
            },
        ],
        commands: ['apt update', 'apt install -y openjdk-21-jre-headless screen wget', 'mkdir -p /opt/minecraft', 'cd /opt/minecraft', 'java -Xms1G -Xmx2G -jar paper.jar nogui'],
        checklist: [
            'Correct Java version is installed.',
            'Server files are in a clean folder.',
            'RAM allocation does not exceed VPS memory.',
        ],
        mistakes: [
            'Allocating all VPS RAM to Minecraft and leaving nothing for Linux.',
            'Using random modified jars from unknown sources.',
        ],
    },
    {
        id: 'minecraft-service',
        title: 'Run Minecraft as a service',
        tag: 'Minecraft',
        use: 'Keep the server running after SSH closes and restart it cleanly.',
        summary: 'A systemd service is cleaner than leaving Minecraft in a random terminal window.',
        steps: [
            {
                title: 'Use a dedicated user',
                detail: 'Run Minecraft as a minecraft user instead of root.',
            },
            {
                title: 'Create systemd service',
                detail: 'The service should define working directory, Java command, restart policy, and user.',
            },
            {
                title: 'Control it cleanly',
                detail: 'Use systemctl start, stop, restart, and status instead of killing Java manually.',
            },
        ],
        commands: ['adduser --system --home /opt/minecraft --group minecraft', 'chown -R minecraft:minecraft /opt/minecraft', 'systemctl enable minecraft', 'systemctl start minecraft', 'systemctl status minecraft --no-pager'],
        checklist: [
            'Minecraft does not run as root.',
            'Minecraft starts automatically after reboot.',
            'I can view logs with journalctl -u minecraft.',
        ],
        mistakes: [
            'Closing SSH and killing the server because it was not running as a service.',
            'Using kill -9 instead of a graceful stop.',
        ],
    },
    {
        id: 'minecraft-performance',
        title: 'Minecraft performance tuning',
        tag: 'Minecraft',
        use: 'Reduce lag without blindly buying bigger plans.',
        summary: 'Most Minecraft lag comes from high view distance, too many entities, bad plugins, or low RAM.',
        steps: [
            {
                title: 'Tune server.properties',
                detail: 'Lower view-distance and simulation-distance first. These often matter more than CPU percentage.',
            },
            {
                title: 'Watch timings or spark reports',
                detail: 'Use plugin profiling to find laggy plugins, worlds, and entities.',
            },
            {
                title: 'Set sane RAM',
                detail: 'Leave memory for Linux and database. Do not allocate 100% of VPS RAM to Java.',
            },
        ],
        commands: ['nano server.properties', 'view-distance=6', 'simulation-distance=4', 'java -Xms1G -Xmx4G -jar paper.jar nogui'],
        checklist: [
            'View distance and simulation distance are not too high.',
            'RAM allocation leaves space for OS and other apps.',
            'I use profiling before blaming the VPS.',
        ],
        mistakes: [
            'Adding more plugins without checking performance impact.',
            'Keeping huge farms/entities active all the time.',
        ],
    },
    {
        id: 'minecraft-security',
        title: 'Minecraft security',
        tag: 'Minecraft',
        use: 'Protect your server, players, console, and permissions.',
        summary: 'Minecraft security is not only firewall. It also includes whitelist, online mode, backups, and plugin trust.',
        steps: [
            {
                title: 'Use online-mode when possible',
                detail: 'Online mode helps verify real Minecraft accounts. Offline mode needs extra protection.',
            },
            {
                title: 'Control staff permissions',
                detail: 'Use permission plugins carefully and never give operator access casually.',
            },
            {
                title: 'Install plugins from trusted sources',
                detail: 'A malicious plugin can read files, steal tokens, or run commands as your server user.',
            },
        ],
        commands: ['whitelist on', 'whitelist add PlayerName', 'op PlayerName', 'deop PlayerName'],
        checklist: [
            'Only trusted staff have operator or admin permissions.',
            'Plugins come from trusted sources.',
            'World and config backups exist before plugin changes.',
        ],
        mistakes: [
            'Giving OP to players for quick help.',
            'Installing cracked or unknown plugin jars.',
        ],
    },
    {
        id: 'backups-worlds',
        title: 'World and config backups',
        tag: 'Protection',
        use: 'Recover after griefing, bad plugins, failed updates, or accidental deletes.',
        summary: 'For Minecraft, worlds, plugins, configs, and databases all need backup coverage.',
        steps: [
            {
                title: 'Back up before changes',
                detail: 'Before plugin updates, Minecraft updates, or config changes, create a fresh backup.',
            },
            {
                title: 'Store backups outside the server',
                detail: 'A local backup is useful, but offsite backups save you when disk or VPS fails.',
            },
            {
                title: 'Test restore steps',
                detail: 'A backup is only useful if you know how to restore it quickly.',
            },
        ],
        commands: ['systemctl stop minecraft', 'tar -czf minecraft-backup.tar.gz /opt/minecraft', 'systemctl start minecraft', 'ls -lh minecraft-backup.tar.gz'],
        checklist: [
            'World folder is included in backups.',
            'Plugin configs and database exports are included.',
            'At least one backup is stored away from the VPS.',
        ],
        mistakes: [
            'Backing up only the world folder and forgetting plugin data.',
            'Never testing restore until an emergency happens.',
        ],
    },
    {
        id: 'database-basics',
        title: 'Database basics',
        tag: 'Database',
        use: 'Run small website, panel, plugin, or billing databases safely.',
        summary: 'MariaDB/MySQL/PostgreSQL should be secured, backed up, and not exposed unless required.',
        steps: [
            {
                title: 'Keep database local',
                detail: 'Most apps on the same VPS can use 127.0.0.1, so the database port does not need public access.',
            },
            {
                title: 'Create app-specific users',
                detail: 'Do not use root database user for every app. Give each app only the permissions it needs.',
            },
            {
                title: 'Export before upgrades',
                detail: 'Use mysqldump or pg_dump before major updates or migrations.',
            },
        ],
        commands: ['mysql_secure_installation', 'mysql -u root -p', 'mysqldump -u user -p database_name > database-backup.sql', 'du -sh /var/lib/mysql'],
        checklist: [
            'Database root password is strong.',
            'Apps use their own database users.',
            'Database backups are included in the backup routine.',
        ],
        mistakes: [
            'Opening port 3306 to the internet without strict access control.',
            'Keeping every app on the same database user.',
        ],
    },
    {
        id: 'pterodactyl-plan',
        title: 'Pterodactyl install plan',
        tag: 'Panel',
        use: 'Plan a clean game panel install before running commands.',
        summary: 'Pterodactyl needs a fresh supported OS, web server, database, queue, SSL, Docker, and Wings.',
        steps: [
            {
                title: 'Use a fresh server',
                detail: 'Pterodactyl is easiest and safest on a clean Ubuntu/Debian server with a domain ready.',
            },
            {
                title: 'Prepare panel services',
                detail: 'Panel side needs PHP, web server, database, Redis/queue, cron, and SSL.',
            },
            {
                title: 'Prepare Wings separately',
                detail: 'Wings manages game servers through Docker. Keep node networking and allocations organized.',
            },
            {
                title: 'Follow official docs for exact commands',
                detail: 'Package versions change over time, so use this panel as your plan and official docs for exact install commands.',
            },
        ],
        checklist: [
            'Domain and SSL plan are ready.',
            'Database and Redis/queue are planned.',
            'Wings node IP allocations are prepared.',
        ],
        mistakes: [
            'Installing Pterodactyl on a messy VPS already running many unrelated apps.',
            'Forgetting queue workers or cron, causing background tasks to fail.',
        ],
    },
    {
        id: 'paymenter-plan',
        title: 'Paymenter install plan',
        tag: 'Billing',
        use: 'Set up billing, orders, and game/VPS product delivery safely.',
        summary: 'Paymenter needs a billing domain, SMTP, database, queue, cron, payment gateway, and correct server extension.',
        steps: [
            {
                title: 'Prepare billing domain and email',
                detail: 'Billing must send invoices, password resets, and order emails, so SMTP needs to work first.',
            },
            {
                title: 'Configure product carefully',
                detail: 'Match product audience, plan ID, service ID placeholders, and reseller/resource mode correctly.',
            },
            {
                title: 'Test with one small product',
                detail: 'Run one test order before publishing many plans. Confirm create, suspend, unsuspend, terminate, and SSO.',
            },
        ],
        checklist: [
            'SMTP is working before users buy.',
            'Cron and queue workers are running.',
            'One full test order works before production launch.',
        ],
        mistakes: [
            'Publishing products before testing suspend and terminate actions.',
            'Using the wrong extension for platform users vs reseller resources.',
        ],
    },
    {
        id: 'docker-manager',
        title: 'Docker Manager basics',
        tag: 'Apps',
        use: 'Run containers without losing track of ports, volumes, and logs.',
        summary: 'Docker is powerful for apps, but bad compose files can expose ports or lose data.',
        steps: [
            {
                title: 'Understand containers and volumes',
                detail: 'Containers are replaceable. Volumes hold persistent data and must be backed up.',
            },
            {
                title: 'Expose only needed ports',
                detail: 'Do not map admin ports publicly unless you need them and secured them.',
            },
            {
                title: 'Use logs first',
                detail: 'When a container fails, docker logs usually explains the issue faster than reinstalling.',
            },
        ],
        commands: ['docker ps', 'docker logs container_name', 'docker compose up -d', 'docker compose down', 'docker volume ls'],
        checklist: [
            'Important data uses named volumes or bind mounts.',
            'Only required ports are exposed.',
            'I check docker logs before rebuilding.',
        ],
        mistakes: [
            'Deleting containers and accidentally deleting data volumes.',
            'Running random compose files without reading port mappings.',
        ],
    },
    {
        id: 'dns-ssl',
        title: 'DNS and SSL',
        tag: 'Domains',
        use: 'Connect domains to websites, panels, and APIs securely.',
        summary: 'DNS points the name to the server. SSL makes browser connections trusted and encrypted.',
        steps: [
            {
                title: 'Point records correctly',
                detail: 'Use A record for IPv4, AAAA for IPv6, or CNAME when pointing to another hostname.',
            },
            {
                title: 'Wait for propagation',
                detail: 'DNS can take time. Verify the record before blaming SSL or nginx.',
            },
            {
                title: 'Issue SSL after DNS works',
                detail: 'SSL validation fails if the domain does not resolve to the correct server.',
            },
        ],
        commands: [`dig ${host}`, 'dig yourdomain.com A', 'dig yourdomain.com AAAA', 'curl -I https://yourdomain.com'],
        checklist: [
            'DNS points to the correct IP or hostname.',
            'SSL is issued only after DNS is correct.',
            'HTTP redirects to HTTPS after SSL works.',
        ],
        mistakes: [
            'Mixing up root domain, www, and subdomain records.',
            'Changing DNS repeatedly before waiting for propagation.',
        ],
    },
    {
        id: 'ddos-game-network',
        title: 'DDoS and game network protection',
        tag: 'Security',
        use: 'Understand what Cloudflare protects and what it does not protect.',
        summary: 'Cloudflare protects web traffic well, but Minecraft/game ports need game-ready network protection.',
        steps: [
            {
                title: 'Separate web and game traffic',
                detail: 'Web panels use 80/443. Minecraft uses game ports like 25565. They are protected differently.',
            },
            {
                title: 'Use firewall allowlists when possible',
                detail: 'Admin panels, databases, and SSH should be restricted more strongly than public game ports.',
            },
            {
                title: 'Monitor attacks and spikes',
                detail: 'Sudden bandwidth or connection spikes can signal scanning, abuse, or DDoS.',
            },
        ],
        checklist: [
            'I know Cloudflare web proxy does not magically protect every game port.',
            'SSH and admin tools are not exposed broadly.',
            'I watch traffic spikes and logs after attacks.',
        ],
        mistakes: [
            'Assuming orange-cloud DNS protects Minecraft TCP directly.',
            'Leaving admin ports public because the game server needs public traffic.',
        ],
    },
    {
        id: 'monitoring-usage',
        title: 'Usage monitoring',
        tag: 'Monitoring',
        use: 'Catch overload before the VPS is stopped, suspended, or starts lagging players.',
        summary: 'CPU, RAM, disk, network, and bandwidth trends show problems before users complain.',
        steps: [
            {
                title: 'Watch the live chart',
                detail: 'Short spikes are normal. Long high usage means you should tune, upgrade, or remove load.',
            },
            {
                title: 'Check bandwidth',
                detail: 'Large downloads, backups, proxies, and game traffic can consume bandwidth quickly.',
            },
            {
                title: 'Use logs with charts',
                detail: 'Charts show when. Logs show why.',
            },
        ],
        commands: ['top', 'htop', 'free -h', 'df -h', 'iftop', 'journalctl -u minecraft --since "30 minutes ago"'],
        checklist: [
            'I can identify long high CPU or RAM usage.',
            'I check bandwidth before the plan limit is hit.',
            'I use logs and charts together.',
        ],
        mistakes: [
            'Only checking current CPU and ignoring the last hour of history.',
            'Letting disk reach 100% before cleaning logs/backups.',
        ],
    },
    {
        id: 'logs-recovery',
        title: 'Logs and recovery',
        tag: 'Troubleshoot',
        use: 'Fix problems faster by reading the right log first.',
        summary: 'Logs are the fastest way to understand failed installs, crashes, and broken services.',
        steps: [
            {
                title: 'Start with latest action',
                detail: 'If the web panel ran a task, check the latest action or task log first.',
            },
            {
                title: 'Use service logs',
                detail: 'systemd logs show why Minecraft, nginx, database, or docker failed.',
            },
            {
                title: 'Recover in order',
                detail: 'Stop the broken service, read logs, restore config or backup, then start again.',
            },
        ],
        commands: ['systemctl status nginx --no-pager', 'journalctl -u nginx --since "1 hour ago"', 'journalctl -u minecraft --since "1 hour ago"', 'tail -100 server.log'],
        checklist: [
            'I check task logs before repeating failed actions.',
            'I know which service log matches the broken app.',
            'I restore backups instead of guessing for hours.',
        ],
        mistakes: [
            'Clicking the same failed action many times without reading logs.',
            'Deleting files before making a copy of the broken state.',
        ],
    },
    {
        id: 'first-week',
        title: 'First week routine',
        tag: 'Roadmap',
        use: 'Build a stable habit for Minecraft, web apps, databases, or billing panels.',
        summary: 'A small daily routine prevents most beginner VPS disasters.',
        steps: [
            {
                title: 'Day 1: access and security',
                detail: 'Save IP, confirm SSH, set strong password, create admin user, and configure firewall.',
            },
            {
                title: 'Day 2-3: install slowly',
                detail: 'Install one major app at a time, then check service status and logs.',
            },
            {
                title: 'Day 4-5: backup and monitor',
                detail: 'Create backups, check usage charts, and document restore steps.',
            },
            {
                title: 'Day 6-7: polish',
                detail: 'Add DNS/SSL, cleanup unused ports, confirm billing/panel actions, and write support notes.',
            },
        ],
        checklist: [
            'SSH access is verified and secure.',
            'Firewall is minimal and intentional.',
            'Backups and restore plan are ready.',
            'Usage is stable after every install.',
        ],
        mistakes: [
            'Installing Minecraft, Pterodactyl, Paymenter, database, and proxy all in one night without testing.',
            'Not writing down what changed before asking for support.',
        ],
    },
]

const TutorialsContainer = () => {
    const server = ServerContext.useStoreState(state => state.server.data!)
    const tutorialUrl = useStoreState(state => state.settings.data?.tutorialUrl || null)
    const privacyMode = useStoreState(state => state.settings.privacyMode)
    const [activeId, setActiveId] = useState<string | null>(null)

    const tutorialHost = privacyMode
        ? '[hidden-host]'
        : server.limits.addresses.ipv4[0]?.address || server.limits.addresses.ipv6[0]?.address || server.hostname || 'your-vps-ip'
    const lessons = useMemo(() => buildLessons(tutorialHost), [tutorialHost])
    const active = lessons.find(lesson => lesson.id === activeId) ?? null

    return (
        <ServerContentBlock title='Tutorials'>
            <ServerPageHeader title='Tutorials' />

            <section className='mb-6 overflow-hidden rounded-2xl border border-[var(--border-soft)] bg-[var(--surface-raised)] shadow-[0_24px_80px_rgba(0,0,0,0.22)]'>
                <div className='bg-[radial-gradient(120%_120%_at_0%_0%,color-mix(in_srgb,var(--tenant-brand-accent)_16%,transparent),transparent_46%),linear-gradient(135deg,var(--surface-raised),var(--surface-soft))] p-5 md:p-7'>
                    <div className='flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between'>
                        <div className='max-w-3xl'>
                            <span className='inline-flex rounded-full border border-[var(--border-soft)] bg-[var(--surface-active)] px-3 py-1 text-[11px] font-bold uppercase tracking-[0.24em] text-[var(--tenant-brand-accent)]'>
                                One practical section
                            </span>
                            <h2 className='mt-4 text-2xl font-bold text-[var(--text-primary)] md:text-4xl'>VPS + Minecraft Operations Guide</h2>
                            <p className='mt-3 text-sm leading-6 text-[var(--text-muted)] md:text-base'>
                                A beginner-friendly but serious guide for SSH, Termius, Minecraft hosting, Pterodactyl,
                                Paymenter, Docker, databases, DNS, SSL, backups, security, monitoring, and recovery.
                            </p>
                        </div>
                        <div className='rounded-2xl border border-[var(--border-soft)] bg-[var(--surface-soft)] p-4 text-sm text-[var(--text-muted)]'>
                            <p className='text-2xl font-bold text-[var(--text-primary)]'>{lessons.length}</p>
                            <p>important lessons for real VPS users</p>
                        </div>
                    </div>

                    {tutorialUrl && (
                        <a
                            href={tutorialUrl}
                            target='_blank'
                            rel='noreferrer'
                            className='mt-5 inline-flex h-10 items-center rounded-xl border border-[var(--border-soft)] bg-[var(--surface-active)] px-4 text-sm font-semibold text-[var(--text-primary)] transition hover:bg-[var(--surface-hover)]'
                        >
                            Open full documentation
                        </a>
                    )}
                </div>
            </section>

            <section className='rounded-2xl border border-[var(--border-soft)] bg-[var(--surface-soft)] p-4 md:p-5'>
                <div className='mb-4 flex flex-col gap-2 md:flex-row md:items-end md:justify-between'>
                    <div>
                        <h3 className='text-lg font-semibold text-[var(--text-primary)]'>What to learn first</h3>
                        <p className='mt-1 text-sm text-[var(--text-muted)]'>Open any card for steps, commands, checklists, and common mistakes.</p>
                    </div>
                    <span className='w-fit rounded-full border border-[var(--border-soft)] bg-[var(--surface-active)] px-3 py-1 text-xs font-semibold text-[var(--tenant-brand-accent)]'>
                        Built for Minecraft, panels, and billing users
                    </span>
                </div>

                <div className='grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3'>
                    {lessons.map((lesson, index) => (
                        <button
                            key={lesson.id}
                            type='button'
                            onClick={() => setActiveId(lesson.id)}
                            className='group min-h-[190px] rounded-2xl border border-[var(--border-soft)] bg-[var(--surface-raised)] p-4 text-left transition hover:-translate-y-0.5 hover:border-[var(--tenant-brand-accent)] hover:bg-[var(--surface-hover)]'
                        >
                            <div className='flex items-start justify-between gap-3'>
                                <span className='rounded-full border border-[var(--border-soft)] bg-[var(--surface-active)] px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide text-[var(--text-muted)]'>
                                    {lesson.tag}
                                </span>
                                <span className='text-xs font-bold text-[var(--text-muted)]'>#{String(index + 1).padStart(2, '0')}</span>
                            </div>
                            <h4 className='mt-4 text-lg font-semibold text-[var(--text-primary)] group-hover:text-[var(--tenant-brand-accent)]'>{lesson.title}</h4>
                            <p className='mt-2 text-sm font-medium text-[var(--tenant-brand-accent)]'>{lesson.use}</p>
                            <p className='mt-3 text-sm leading-5 text-[var(--text-muted)]'>{lesson.summary}</p>
                        </button>
                    ))}
                </div>
            </section>

            <Modal open={Boolean(active)} onClose={() => setActiveId(null)} size='3xl'>
                {active && (
                    <>
                        <Modal.Header className='!border-[var(--border-soft)] !bg-[var(--surface-raised)]'>
                            <div>
                                <Modal.Title className='!text-[var(--text-primary)]'>{active.title}</Modal.Title>
                                <p className='mt-2 text-center text-sm text-[var(--tenant-brand-accent)]'>{active.use}</p>
                            </div>
                        </Modal.Header>
                        <Modal.Body className='!bg-[var(--brand-bg)] !text-[var(--text-primary)]'>
                            <div className='space-y-4'>
                                <section className='rounded-xl border border-[var(--border-soft)] bg-[var(--surface-soft)] p-4'>
                                    <h4 className='text-sm font-semibold uppercase tracking-wide text-[var(--tenant-brand-accent)]'>Why this matters</h4>
                                    <p className='mt-2 text-sm leading-6 text-[var(--text-muted)]'>{active.summary}</p>
                                </section>

                                <section className='grid grid-cols-1 gap-3 md:grid-cols-2'>
                                    {active.steps.map((step, index) => (
                                        <article key={`${active.id}-${step.title}`} className='rounded-xl border border-[var(--border-soft)] bg-[var(--surface-raised)] p-4 shadow-[0_14px_34px_rgba(0,0,0,0.14)]'>
                                            <p className='text-sm font-semibold text-[var(--text-primary)]'>
                                                {index + 1}. {step.title}
                                            </p>
                                            <p className='mt-1 text-sm leading-6 text-[var(--text-muted)]'>{step.detail}</p>
                                            {step.example && (
                                                <p className='mt-3 rounded-lg border border-[var(--border-soft)] bg-[var(--surface-active)] p-2 text-sm text-[var(--text-primary)]'>
                                                    Example: {step.example}
                                                </p>
                                            )}
                                        </article>
                                    ))}
                                </section>

                                {active.commands && (
                                    <section className='rounded-xl border border-[var(--border-soft)] bg-[var(--surface-raised)] p-4'>
                                        <h4 className='text-sm font-semibold uppercase tracking-wide text-[var(--text-primary)]'>Useful commands</h4>
                                        <div className='mt-3 space-y-2 font-mono text-xs md:text-sm'>
                                            {active.commands.map(command => (
                                                <p key={`${active.id}-${command}`} className='rounded-lg border border-[var(--border-soft)] bg-[var(--surface-soft)] px-3 py-2 text-[var(--text-primary)]'>
                                                    {command}
                                                </p>
                                            ))}
                                        </div>
                                    </section>
                                )}

                                <section className='rounded-xl border border-[var(--border-soft)] bg-[var(--surface-soft)] p-4'>
                                    <h4 className='text-sm font-semibold uppercase tracking-wide text-[var(--tenant-brand-accent)]'>Checklist</h4>
                                    <div className='mt-2 space-y-1.5 text-sm text-[var(--text-primary)]'>
                                        {active.checklist.map(item => (
                                            <p key={`${active.id}-${item}`}>- {item}</p>
                                        ))}
                                    </div>
                                </section>

                                {active.mistakes && (
                                    <section className='rounded-xl border border-[var(--border-soft)] bg-[var(--surface-soft)] p-4'>
                                        <h4 className='text-sm font-semibold uppercase tracking-wide text-[var(--tenant-brand-accent)]'>Avoid these mistakes</h4>
                                        <div className='mt-2 space-y-1.5 text-sm text-[var(--text-primary)]'>
                                            {active.mistakes.map(item => (
                                                <p key={`${active.id}-mistake-${item}`}>- {item}</p>
                                            ))}
                                        </div>
                                    </section>
                                )}
                            </div>
                        </Modal.Body>
                        <Modal.Actions>
                            <Modal.Action type='button' onClick={() => setActiveId(null)}>
                                Close
                            </Modal.Action>
                            <Modal.Action
                                type='button'
                                onClick={() => {
                                    if (tutorialUrl) {
                                        window.open(tutorialUrl, '_blank', 'noopener,noreferrer')
                                    } else {
                                        setActiveId(null)
                                    }
                                }}
                            >
                                {tutorialUrl ? 'Open Full Docs' : 'Done'}
                            </Modal.Action>
                        </Modal.Actions>
                    </>
                )}
            </Modal>
        </ServerContentBlock>
    )
}

export default TutorialsContainer
