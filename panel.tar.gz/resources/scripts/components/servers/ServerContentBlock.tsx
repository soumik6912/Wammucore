import { ServerContext } from '@/state/server'

import PageContentBlock, {
    PageContentBlockProps,
} from '@/components/elements/PageContentBlock'

interface Props extends PageContentBlockProps {
    title: string
}

const ServerContentBlock: React.FC<Props> = ({ title, children, ...props }) => {
    const name = ServerContext.useStoreState(state => state.server.data!.name)

    return (
        <PageContentBlock
            {...props}
            title={`${title} | ${name}`}
            containerSize='wide'
            className={`pt-2 md:pt-4 ${props.className ?? ''}`.trim()}
        >
            {children}
        </PageContentBlock>
    )
}

export default ServerContentBlock
