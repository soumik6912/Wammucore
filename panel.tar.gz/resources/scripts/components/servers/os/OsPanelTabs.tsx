import { NavLink } from 'react-router-dom'
import { ServerContext } from '@/state/server'

const OsPanelTabs = () => {
    const server = ServerContext.useStoreState(state => state.server.data!)

    const tabs = [
        {
            label: 'Operating System',
            to: `/servers/${server.id}/os-panel`,
        },
    ]

    return (
        <div className='mb-4 flex flex-wrap gap-2'>
            {tabs.map(tab => (
                <NavLink
                    key={tab.to}
                    to={tab.to}
                    end={tab.to.endsWith('/os-panel')}
                    className={({ isActive }) =>
                        `rounded-full px-3 py-1.5 text-sm font-medium transition-colors ${
                            isActive
                                ? 'bg-indigo-600/30 text-white'
                                : 'border border-white/15 text-white/60 hover:text-white'
                        }`
                    }
                >
                    {tab.label}
                </NavLink>
            ))}
        </div>
    )
}

export default OsPanelTabs
