import reinstallServer from '@/api/server/settings/reinstallServer'
import getWindowsProvisioningScript, {
    WindowsProvisioningScriptResponse,
} from '@/api/server/settings/getWindowsProvisioningScript'
import { httpErrorToHuman } from '@/api/http'
import useOsOptionsSWR from '@/api/server/settings/useOsOptionsSWR'
import { ServerContext } from '@/state/server'
import useNotify from '@/util/useNotify'
import { ClipboardDocumentIcon, ComputerDesktopIcon, EyeIcon, EyeSlashIcon } from '@heroicons/react/24/outline'
import { useEffect, useMemo, useState } from 'react'

import ServerContentBlock from '@/components/servers/ServerContentBlock'
import ServerPageHeader from '@/components/servers/common/ServerPageHeader'
import OsPanelTabs from '@/components/servers/os/OsPanelTabs'
import SafeImage from '@/components/elements/SafeImage'

const getOsFamily = (name: string) => {
    const n = name.toLowerCase()
    if (n.includes('ubuntu')) return 'Ubuntu'
    if (n.includes('debian')) return 'Debian'
    if (n.includes('alma')) return 'AlmaLinux'
    if (n.includes('rocky')) return 'Rocky Linux'
    if (n.includes('centos')) return 'CentOS'
    if (n.includes('arch')) return 'Arch Linux'
    if (n.includes('windows')) return 'Windows'
    return 'Linux'
}

const iconFor = (name: string) => {
    const n = name.toLowerCase()
    if (n.includes('ubuntu')) return 'https://i.postimg.cc/XJd6ZPvk/image.png'
    if (n.includes('debian')) {
        return 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/debian/debian-original.svg'
    }
    if (n.includes('centos') || n.includes('alma') || n.includes('rocky')) {
        return 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/centos/centos-original.svg'
    }
    if (n.includes('arch')) {
        return 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/archlinux/archlinux-original.svg'
    }
    if (n.includes('windows')) {
        return 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/windows8/windows8-original.svg'
    }
    return 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/linux/linux-original.svg'
}

const ServerOsPanelContainer = () => {
    const server = ServerContext.useStoreState(state => state.server.data!)
    const setServer = ServerContext.useStoreActions(actions => actions.server.setServer)
    const notify = useNotify()
    const { data, isLoading } = useOsOptionsSWR(server.uuid)

    const [selectedTemplateUuid, setSelectedTemplateUuid] = useState('')
    const [password, setPassword] = useState('')
    const [showPassword, setShowPassword] = useState(false)
    const [startOnCompletion, setStartOnCompletion] = useState(true)
    const [submitting, setSubmitting] = useState(false)
    const [windowsScript, setWindowsScript] = useState<WindowsProvisioningScriptResponse | null>(null)
    const [loadingWindowsScript, setLoadingWindowsScript] = useState(false)
    const [copiedWindowsScript, setCopiedWindowsScript] = useState(false)

    const templates = useMemo(
        () =>
            (data ?? []).flatMap(group =>
                (group.templates ?? []).map(template => ({
                    groupName: group.name,
                    groupUuid: group.uuid,
                    templateName: template.name,
                    templateUuid: template.uuid,
                }))
            ),
        [data]
    )

    useEffect(() => {
        if (!selectedTemplateUuid && templates.length > 0) {
            setSelectedTemplateUuid(templates[0].templateUuid)
        }
    }, [templates, selectedTemplateUuid])

    useEffect(() => {
        setWindowsScript(null)
        setCopiedWindowsScript(false)
    }, [server.uuid])

    const familySections = useMemo(() => {
        const sections = new Map<
            string,
            { title: string; items: Array<{ uuid: string; name: string; sourceGroup: string }> }
        >()

        ;(data ?? []).forEach(group => {
            group.templates.forEach(template => {
                const family = getOsFamily(template.name)
                if (!sections.has(family)) {
                    sections.set(family, { title: family, items: [] })
                }

                sections.get(family)!.items.push({
                    uuid: template.uuid,
                    name: template.name,
                    sourceGroup: group.name,
                })
            })
        })

        return Array.from(sections.values()).map(section => ({
            ...section,
            items: section.items.sort((a, b) => a.name.localeCompare(b.name)),
        }))
    }, [data])

    const selectedTemplate = templates.find(
        template => template.templateUuid === selectedTemplateUuid
    )

    const currentOsLabel =
        server.currentOs ||
        (server.description &&
        server.description !== server.name &&
        server.description !== server.hostname
            ? server.description
            : null) ||
        'OS not detected yet'
    const currentOsFamily = getOsFamily(currentOsLabel)
    const selectedTemplateFamily = getOsFamily(selectedTemplate?.templateName || '')
    const showWindowsHelper =
        currentOsFamily === 'Windows' || selectedTemplateFamily === 'Windows'

    const loadWindowsScript = async () => {
        setLoadingWindowsScript(true)
        try {
            setWindowsScript(await getWindowsProvisioningScript(server.uuid))
        } catch (error) {
            notify({
                color: 'red',
                message: httpErrorToHuman(error),
            })
        } finally {
            setLoadingWindowsScript(false)
        }
    }

    const copyWindowsScript = async () => {
        if (!windowsScript?.script) return

        try {
            await navigator.clipboard.writeText(windowsScript.script)
            setCopiedWindowsScript(true)
            notify({
                color: 'green',
                message: 'Windows setup script copied.',
            })
            window.setTimeout(() => setCopiedWindowsScript(false), 2500)
        } catch {
            notify({
                color: 'red',
                message: 'Could not copy the script. Select the script text manually.',
            })
        }
    }

    const submitReinstall = async () => {
        if (!selectedTemplateUuid) {
            notify({ color: 'red', message: 'Select an OS template first.' })
            return
        }

        if (!password || password.length < 8) {
            notify({
                color: 'red',
                message: 'Enter a valid new OS account password (minimum 8 characters).',
            })
            return
        }

        setSubmitting(true)
        try {
            await reinstallServer(server.uuid, {
                templateUuid: selectedTemplateUuid,
                accountPassword: password,
                startOnCompletion,
            })

            setServer({
                ...server,
                status: 'installing',
            })

            notify({
                color: 'green',
                message: 'Reinstall started. The server status will update shortly.',
            })
        } catch (error) {
            notify({
                color: 'red',
                message: httpErrorToHuman(error),
            })
        } finally {
            setSubmitting(false)
        }
    }

    return (
        <ServerContentBlock title='OS & Panel'>
            <ServerPageHeader title='Operating System' />
            <OsPanelTabs />

            <div className='space-y-5'>
                <div className='rounded-2xl border border-white/10 bg-[#1a1441]'>
                    <div className='border-b border-white/10 px-5 py-4'>
                        <h3 className='text-xl font-semibold text-white'>Current OS</h3>
                    </div>
                    <div className='px-5 py-4'>
                        <div className='flex items-center gap-3'>
                            <SafeImage
                                src={iconFor(currentOsLabel)}
                                alt={currentOsLabel}
                                className='h-7 w-7 rounded-full bg-white/5 object-contain p-0.5'
                                fallbackClassName='h-7 w-7 rounded-full'
                                fallbackText={currentOsLabel}
                            />
                            <p className='text-lg font-semibold text-white'>{currentOsLabel}</p>
                        </div>
                        <p className='mt-3 text-sm text-white/60'>
                            Change OS with one click. Reinstall will erase current system data.
                        </p>
                    </div>
                </div>

                <div className='rounded-2xl border border-white/10 bg-[#1a1441] p-5'>
                    <div className='mb-4 flex flex-wrap items-center justify-between gap-3'>
                        <h3 className='text-xl font-semibold text-white'>Change OS</h3>
                    </div>

                    {isLoading ? (
                        <p className='py-8 text-center text-sm text-white/60'>Loading templates...</p>
                    ) : familySections.length === 0 ? (
                        <p className='py-8 text-center text-sm text-white/60'>
                            No OS templates are available for this node right now.
                        </p>
                    ) : (
                        <div className='space-y-5'>
                            {familySections.map(section => (
                                <div
                                    key={section.title}
                                    className='rounded-2xl border border-white/10 bg-[#111a31] p-4'
                                >
                                    <div className='mb-3 flex items-center gap-3'>
                                        <SafeImage
                                            src={iconFor(section.title)}
                                            alt={section.title}
                                            className='h-8 w-8 rounded-full bg-white/5 object-contain p-0.5'
                                            fallbackClassName='h-8 w-8 rounded-full'
                                            fallbackText={section.title}
                                        />
                                        <div>
                                            <p className='text-sm font-semibold text-white'>
                                                {section.title}
                                            </p>
                                            <p className='text-xs text-white/45'>
                                                OS family
                                            </p>
                                        </div>
                                    </div>

                                    <div className='grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3'>
                                        {section.items.map(template => {
                                            const isSelected =
                                                selectedTemplateUuid === template.uuid

                                            return (
                                                <button
                                                    key={template.uuid}
                                                    type='button'
                                                    onClick={() =>
                                                        setSelectedTemplateUuid(template.uuid)
                                                    }
                                                    className={`flex items-center gap-3 rounded-xl border px-3 py-2 text-left transition ${
                                                        isSelected
                                                            ? 'border-indigo-400 bg-indigo-500/10'
                                                            : 'border-white/10 bg-[#0d152b] hover:border-indigo-400/60'
                                                    }`}
                                                >
                                                    <SafeImage
                                                        src={iconFor(template.name)}
                                                        alt={template.name}
                                                        className='h-7 w-7 rounded-full bg-white/5 object-contain p-0.5'
                                                        fallbackClassName='h-7 w-7 rounded-full'
                                                        fallbackText={template.name}
                                                    />
                                                    <div className='min-w-0'>
                                                        <p className='truncate text-sm font-semibold text-white'>
                                                            {template.name}
                                                        </p>
                                                        <p className='truncate text-xs text-white/50'>
                                                            {template.sourceGroup}
                                                        </p>
                                                    </div>
                                                </button>
                                            )
                                        })}
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                {showWindowsHelper && (
                    <div className='overflow-hidden rounded-2xl border border-sky-400/20 bg-[#101a32]'>
                        <div className='flex flex-col gap-4 border-b border-white/10 px-5 py-4 lg:flex-row lg:items-center lg:justify-between'>
                            <div className='flex items-start gap-3'>
                                <div className='flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-xl border border-sky-400/25 bg-sky-500/10 text-sky-200'>
                                    <ComputerDesktopIcon className='h-5 w-5' />
                                </div>
                                <div>
                                    <h3 className='text-xl font-semibold text-white'>
                                        Windows setup helper
                                    </h3>
                                    <p className='mt-1 max-w-3xl text-sm text-white/60'>
                                        Run this script inside the Windows VPS console when Proxmox guest-agent
                                        cannot inject IP or password automatically. It uses the IP already saved
                                        for this VPS in WammuCore IPAM.
                                    </p>
                                </div>
                            </div>
                            <button
                                type='button'
                                onClick={loadWindowsScript}
                                disabled={loadingWindowsScript}
                                className='inline-flex h-10 items-center justify-center rounded-xl border border-sky-300/30 bg-sky-500/10 px-4 text-sm font-semibold text-sky-100 transition hover:border-sky-200/60 hover:bg-sky-400/15 disabled:cursor-not-allowed disabled:opacity-60'
                            >
                                {loadingWindowsScript ? 'Building script...' : 'Preview Windows script'}
                            </button>
                        </div>

                        {windowsScript && (
                            <div className='space-y-4 p-5'>
                                <div className='grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4'>
                                    <div className='rounded-xl border border-white/10 bg-white/[0.04] p-3'>
                                        <p className='text-xs uppercase tracking-wide text-white/45'>IPv4</p>
                                        <p className='mt-1 text-sm font-semibold text-white'>
                                            {windowsScript.network.ip || 'Not assigned'}
                                        </p>
                                    </div>
                                    <div className='rounded-xl border border-white/10 bg-white/[0.04] p-3'>
                                        <p className='text-xs uppercase tracking-wide text-white/45'>Gateway</p>
                                        <p className='mt-1 text-sm font-semibold text-white'>
                                            {windowsScript.network.gateway || 'Not set'}
                                        </p>
                                    </div>
                                    <div className='rounded-xl border border-white/10 bg-white/[0.04] p-3'>
                                        <p className='text-xs uppercase tracking-wide text-white/45'>Computer name</p>
                                        <p className='mt-1 text-sm font-semibold text-white'>
                                            {windowsScript.computerName}
                                        </p>
                                    </div>
                                    <div className='rounded-xl border border-white/10 bg-white/[0.04] p-3'>
                                        <p className='text-xs uppercase tracking-wide text-white/45'>Login user</p>
                                        <p className='mt-1 text-sm font-semibold text-white'>
                                            {windowsScript.administratorUsername}
                                        </p>
                                    </div>
                                </div>

                                {windowsScript.warnings.length > 0 && (
                                    <div className='rounded-xl border border-amber-400/25 bg-amber-500/10 p-3 text-sm text-amber-100'>
                                        {windowsScript.warnings.map(warning => (
                                            <p key={warning}>{warning}</p>
                                        ))}
                                    </div>
                                )}

                                <div className='overflow-hidden rounded-xl border border-white/10 bg-[#070b1b]'>
                                    <div className='flex flex-wrap items-center justify-between gap-3 border-b border-white/10 px-4 py-3'>
                                        <p className='text-sm font-semibold text-white'>
                                            PowerShell script
                                        </p>
                                        <button
                                            type='button'
                                            onClick={copyWindowsScript}
                                            className='inline-flex items-center gap-2 rounded-lg border border-white/15 bg-white/10 px-3 py-2 text-xs font-semibold text-white transition hover:bg-white/15'
                                        >
                                            <ClipboardDocumentIcon className='h-4 w-4' />
                                            {copiedWindowsScript ? 'Copied' : 'Copy script'}
                                        </button>
                                    </div>
                                    <pre className='max-h-96 overflow-auto whitespace-pre-wrap px-4 py-3 text-xs leading-5 text-slate-100'>
                                        {windowsScript.script}
                                    </pre>
                                </div>
                            </div>
                        )}
                    </div>
                )}

                <div className='rounded-2xl border border-rose-400/20 bg-[#1a1441] px-5 py-4'>
                    <div className='flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between'>
                        <div className='min-w-0 flex-1'>
                            <div className='flex items-start gap-3'>
                                <div className='mt-0.5 flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-xl border border-rose-400/25 bg-rose-500/10 text-rose-200'>
                                    <svg className='h-5 w-5' fill='none' viewBox='0 0 24 24' stroke='currentColor' strokeWidth={1.8}>
                                        <path strokeLinecap='round' strokeLinejoin='round' d='M12 9v4m0 4h.01M10.29 3.86l-7.5 13A1 1 0 003.67 18h16.66a1 1 0 00.88-1.5l-7.5-13a1 1 0 00-1.74 0z' />
                                    </svg>
                                </div>
                                <div>
                                    <h3 className='text-lg font-semibold text-white'>Reinstall OS</h3>
                                    <p className='mt-1 text-sm text-white/60'>
                                        This will erase the current VPS system data and deploy the selected OS again.
                                    </p>
                                </div>
                            </div>

                            <div className='mt-4 rounded-xl border border-white/10 bg-[#111a31] p-4'>
                                <label className='block text-sm font-medium text-white/80'>
                                    New OS account password
                                </label>
                                <div className='relative mt-2'>
                                    <input
                                        type={showPassword ? 'text' : 'password'}
                                        value={password}
                                        onChange={e => setPassword(e.target.value)}
                                        placeholder='Enter a strong new password'
                                        className='w-full rounded-lg border border-white/15 bg-[#0d152b] px-3 py-2.5 pr-11 text-sm text-white placeholder:text-white/35 outline-none focus:border-indigo-400'
                                    />
                                    <button
                                        type='button'
                                        onClick={() => setShowPassword(current => !current)}
                                        className='absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1 text-white/70 hover:bg-white/10 hover:text-white'
                                        aria-label={showPassword ? 'Hide password' : 'Show password'}
                                    >
                                        {showPassword ? (
                                            <EyeSlashIcon className='h-4 w-4' />
                                        ) : (
                                            <EyeIcon className='h-4 w-4' />
                                        )}
                                    </button>
                                </div>
                                <label className='mt-4 inline-flex items-center gap-2 text-sm text-white/70'>
                                    <input
                                        type='checkbox'
                                        checked={startOnCompletion}
                                        onChange={e => setStartOnCompletion(e.target.checked)}
                                        className='h-4 w-4 rounded border-white/25 bg-transparent text-indigo-500 focus:ring-indigo-500'
                                    />
                                    Start after reinstall
                                </label>
                            </div>
                        </div>

                        <div className='flex w-full flex-col gap-2 lg:w-auto lg:min-w-[220px]'>
                            <button
                                type='button'
                                onClick={submitReinstall}
                                disabled={submitting}
                                className='h-11 w-full whitespace-nowrap rounded-xl bg-rose-600 px-5 text-sm font-semibold text-white transition hover:bg-rose-500 disabled:cursor-not-allowed disabled:opacity-60'
                            >
                                {submitting ? 'Starting reinstall...' : 'Reinstall OS'}
                            </button>
                            <p className='text-center text-xs text-white/45 lg:text-right'>
                                Use this only when you want a fresh operating system.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </ServerContentBlock>
    )
}

export default ServerOsPanelContainer
