import { httpErrorToHuman } from '@/api/http'
import {
    dockerContainerAction,
    dockerServiceAction,
    DockerAction,
    DockerStatus,
    getDockerStatus,
} from '@/api/server/settings/dockerManager'
import { ServerContext } from '@/state/server'
import useNotify from '@/util/useNotify'
import useSWR from 'swr'
import { useState } from 'react'

import ServerContentBlock from '@/components/servers/ServerContentBlock'
import ServerPageHeader from '@/components/servers/common/ServerPageHeader'

const ServerDockerManagerContainer = () => {
    const server = ServerContext.useStoreState(state => state.server.data!)
    const notify = useNotify()
    const [workingKey, setWorkingKey] = useState<string | null>(null)

    const { data, isLoading, isValidating, error, mutate } = useSWR(
        ['server:docker-status', server.uuid],
        () => getDockerStatus(server.uuid),
        {
            dedupingInterval: 15000,
            keepPreviousData: true,
            revalidateOnFocus: false,
            revalidateIfStale: false,
            shouldRetryOnError: false,
        }
    )

    const runMutation = async (
        key: string,
        handler: () => Promise<DockerStatus>,
        successMessage: string
    ) => {
        try {
            setWorkingKey(key)
            const freshStatus = await handler()
            await mutate(freshStatus, { revalidate: false })
            notify({ color: 'green', message: successMessage })
        } catch (error) {
            notify({ color: 'red', message: httpErrorToHuman(error) })
        } finally {
            setWorkingKey(null)
        }
    }

    const onServiceAction = async (action: DockerAction) =>
        runMutation(
            `service:${action}`,
            () => dockerServiceAction(server.uuid, action),
            `Docker service ${action} command executed.`
        )

    const onContainerAction = async (container: string, action: DockerAction) =>
        runMutation(
            `container:${container}:${action}`,
            () => dockerContainerAction(server.uuid, container, action),
            `Container ${container} ${action} command executed.`
        )

    const isBusy = (key: string) => workingKey === key

    const renderStatusContent = () => {
        if (isLoading && !data) {
            return (
                <div className='rounded-2xl border border-white/10 bg-[#1a1441] p-8 text-center text-white/60'>
                    Loading Docker manager status...
                </div>
            )
        }

        if (error) {
            return (
                <div className='rounded-2xl border border-rose-500/30 bg-rose-500/10 p-8 text-center text-rose-200'>
                    Failed to load Docker manager status.
                </div>
            )
        }

        const status = data ?? {
            available: true,
            unavailableMessage: null,
            installed: false,
            active: false,
            enabled: false,
            state: 'not_installed' as const,
            requiresRunning: false,
            requiresRunningMessage: null,
            version: null,
            composeVersion: null,
            containersTotal: 0,
            containersRunning: 0,
            containers: [],
        }
        const dockerUnavailable = status.available === false
        const serviceStateClass =
            dockerUnavailable
                ? 'border-amber-400/35 bg-amber-500/15 text-amber-200'
                : status.state === 'running'
                ? 'border-emerald-400/35 bg-emerald-500/15 text-emerald-200'
                : status.state === 'stopped'
                  ? 'border-amber-400/35 bg-amber-500/15 text-amber-200'
                  : 'border-white/20 bg-white/5 text-white/75'

        return (
            <>
                <section className='rounded-2xl border border-white/10 bg-[#1a1441] p-5'>
                    <div className='flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between'>
                        <div>
                            <h2 className='text-2xl font-semibold text-white'>Docker Engine Management</h2>
                            <p className='mt-1 text-sm text-white/60'>
                                Monitor and manage Docker only when Docker is already installed inside this VPS.
                            </p>
                            {status.requiresRunning && !dockerUnavailable && (
                                <div className='mt-3 rounded-xl border border-amber-400/25 bg-amber-500/10 px-3 py-2 text-sm text-amber-200'>
                                    {status.requiresRunningMessage || 'Start the VPS to manage Docker.'}
                                </div>
                            )}
                            {dockerUnavailable && (
                                <div className='mt-3 rounded-xl border border-amber-400/25 bg-amber-500/10 px-3 py-2 text-sm text-amber-200'>
                                    <p className='font-semibold'>Docker Manager is not available right now.</p>
                                    <p className='mt-1 text-amber-100/80'>
                                        {status.unavailableMessage || 'Start the VPS and retry, or contact support if this continues.'}
                                    </p>
                                </div>
                            )}
                            <div
                                className={`mt-3 inline-flex rounded-full border px-3 py-1 text-xs font-semibold ${serviceStateClass}`}
                            >
                                Status:{' '}
                                {dockerUnavailable
                                    ? 'Unavailable'
                                    : status.state === 'running'
                                    ? 'Installed & Running'
                                    : status.state === 'stopped'
                                      ? 'Installed (Stopped)'
                                      : 'Not Installed'}
                            </div>
                        </div>

                        <div className='flex flex-wrap gap-2'>
                            <button
                                type='button'
                                onClick={() => mutate()}
                                disabled={workingKey !== null}
                                className='rounded-lg border border-white/20 bg-white/5 px-4 py-2 text-sm font-semibold text-white hover:bg-white/10 disabled:cursor-not-allowed disabled:opacity-60'
                            >
                                {isValidating ? 'Refreshing...' : 'Refresh'}
                            </button>
                            {status.installed && (
                                <>
                                    <button
                                        type='button'
                                        onClick={() => onServiceAction('start')}
                                        disabled={workingKey !== null || dockerUnavailable || status.active || status.requiresRunning}
                                        className='rounded-lg border border-emerald-400/30 bg-emerald-500/10 px-4 py-2 text-sm font-semibold text-emerald-200 hover:bg-emerald-500/20 disabled:cursor-not-allowed disabled:opacity-60'
                                    >
                                        {isBusy('service:start') ? 'Starting...' : 'Start service'}
                                    </button>
                                    <button
                                        type='button'
                                        onClick={() => onServiceAction('stop')}
                                        disabled={workingKey !== null || dockerUnavailable || !status.active || status.requiresRunning}
                                        className='rounded-lg border border-amber-400/30 bg-amber-500/10 px-4 py-2 text-sm font-semibold text-amber-200 hover:bg-amber-500/20 disabled:cursor-not-allowed disabled:opacity-60'
                                    >
                                        {isBusy('service:stop') ? 'Stopping...' : 'Stop service'}
                                    </button>
                                    <button
                                        type='button'
                                        onClick={() => onServiceAction('restart')}
                                        disabled={workingKey !== null || dockerUnavailable || !status.active || status.requiresRunning}
                                        className='rounded-lg border border-indigo-400/30 bg-indigo-500/10 px-4 py-2 text-sm font-semibold text-indigo-200 hover:bg-indigo-500/20 disabled:cursor-not-allowed disabled:opacity-60'
                                    >
                                        {isBusy('service:restart') ? 'Restarting...' : 'Restart service'}
                                    </button>
                                </>
                            )}
                        </div>
                    </div>
                </section>

                <section className='grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4'>
                    <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                        <p className='text-xs uppercase tracking-wide text-white/50'>Docker version</p>
                        <p className='mt-2 text-sm font-semibold text-white'>{status.version || '-'}</p>
                    </div>
                    <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                        <p className='text-xs uppercase tracking-wide text-white/50'>Compose version</p>
                        <p className='mt-2 text-sm font-semibold text-white'>{status.composeVersion || '-'}</p>
                    </div>
                    <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                        <p className='text-xs uppercase tracking-wide text-white/50'>Containers</p>
                        <p className='mt-2 text-sm font-semibold text-white'>{status.containersTotal || 0}</p>
                    </div>
                    <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                        <p className='text-xs uppercase tracking-wide text-white/50'>Running containers</p>
                        <p className='mt-2 text-sm font-semibold text-white'>{status.containersRunning || 0}</p>
                    </div>
                </section>

                <section className='rounded-2xl border border-white/10 bg-[#1a1441] p-5'>
                    <h3 className='text-xl font-semibold text-white'>Containers</h3>
                    <p className='mt-1 text-sm text-white/60'>
                        Start, stop, or restart containers directly from panel.
                    </p>

                    {dockerUnavailable ? (
                        <div className='mt-4 rounded-xl border border-amber-400/25 bg-amber-500/10 p-4 text-sm text-amber-100'>
                            <p className='font-semibold'>Container list cannot be loaded yet.</p>
                            <p className='mt-1 text-amber-100/80'>
                                {status.unavailableMessage || 'Start the VPS and retry, or contact support if this continues.'}
                            </p>
                            <button
                                type='button'
                                onClick={() => mutate()}
                                className='mt-3 rounded-lg border border-amber-200/25 bg-amber-200/10 px-3 py-1.5 text-xs font-semibold text-amber-50 hover:bg-amber-200/20'
                            >
                                Retry Docker check
                            </button>
                        </div>
                    ) : !status.installed ? (
                        <div className='mt-4 rounded-xl border border-white/10 bg-[#111a31] p-4 text-sm text-white/65'>
                            Docker is not installed inside this VPS. Install Docker manually via SSH, then refresh this page.
                        </div>
                    ) : status.requiresRunning ? (
                        <div className='mt-4 rounded-xl border border-white/10 bg-[#111a31] p-4 text-sm text-white/65'>
                            {status.requiresRunningMessage || 'Start the VPS to inspect Docker containers.'}
                        </div>
                    ) : !status.containers.length ? (
                        <div className='mt-4 rounded-xl border border-white/10 bg-[#111a31] p-4 text-sm text-white/65'>
                            No containers found on this VPS.
                        </div>
                    ) : (
                        <div className='mt-4 overflow-x-auto'>
                            <table className='w-full min-w-[900px] text-left text-sm'>
                                <thead>
                                    <tr className='border-b border-white/10 text-white/55'>
                                        <th className='py-2 pr-4 font-medium'>Name</th>
                                        <th className='py-2 pr-4 font-medium'>Container ID</th>
                                        <th className='py-2 pr-4 font-medium'>Image</th>
                                        <th className='py-2 pr-4 font-medium'>Status</th>
                                        <th className='py-2 pr-4 font-medium'>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {status.containers.map(container => {
                                        const isRunning = container.status.toLowerCase().startsWith('up')
                                        return (
                                            <tr
                                                key={container.id || container.name}
                                                className='border-b border-white/5 text-white/85'
                                            >
                                                <td className='py-3 pr-4 font-medium text-white'>
                                                    {container.name || '-'}
                                                </td>
                                                <td className='py-3 pr-4 font-mono text-xs text-white/70'>
                                                    {container.id || '-'}
                                                </td>
                                                <td className='py-3 pr-4 text-white/80'>{container.image || '-'}</td>
                                                <td className='py-3 pr-4 text-white/80'>{container.status || '-'}</td>
                                                <td className='py-3 pr-4'>
                                                    <div className='flex flex-wrap gap-2'>
                                                        <button
                                                            type='button'
                                                            onClick={() =>
                                                                onContainerAction(container.name, 'start')
                                                            }
                                                            disabled={
                                                                workingKey !== null || isRunning || !container.name
                                                            }
                                                            className='rounded-lg border border-emerald-400/30 bg-emerald-500/10 px-3 py-1 text-xs font-semibold text-emerald-200 hover:bg-emerald-500/20 disabled:cursor-not-allowed disabled:opacity-60'
                                                        >
                                                            {isBusy(`container:${container.name}:start`)
                                                                ? 'Starting...'
                                                                : 'Start'}
                                                        </button>
                                                        <button
                                                            type='button'
                                                            onClick={() =>
                                                                onContainerAction(container.name, 'stop')
                                                            }
                                                            disabled={
                                                                workingKey !== null || !isRunning || !container.name
                                                            }
                                                            className='rounded-lg border border-amber-400/30 bg-amber-500/10 px-3 py-1 text-xs font-semibold text-amber-200 hover:bg-amber-500/20 disabled:cursor-not-allowed disabled:opacity-60'
                                                        >
                                                            {isBusy(`container:${container.name}:stop`)
                                                                ? 'Stopping...'
                                                                : 'Stop'}
                                                        </button>
                                                        <button
                                                            type='button'
                                                            onClick={() =>
                                                                onContainerAction(container.name, 'restart')
                                                            }
                                                            disabled={workingKey !== null || !container.name}
                                                            className='rounded-lg border border-indigo-400/30 bg-indigo-500/10 px-3 py-1 text-xs font-semibold text-indigo-200 hover:bg-indigo-500/20 disabled:cursor-not-allowed disabled:opacity-60'
                                                        >
                                                            {isBusy(`container:${container.name}:restart`)
                                                                ? 'Restarting...'
                                                                : 'Restart'}
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        )
                                    })}
                                </tbody>
                            </table>
                        </div>
                    )}
                </section>
            </>
        )
    }

    return (
        <ServerContentBlock title='Docker Manager'>
            <ServerPageHeader title='Docker Manager' />
            <div className='space-y-4'>{renderStatusContent()}</div>
        </ServerContentBlock>
    )
}

export default ServerDockerManagerContainer
