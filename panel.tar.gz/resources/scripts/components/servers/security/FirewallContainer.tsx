import { httpErrorToHuman } from '@/api/http'
import {
    addFirewallRule,
    deleteFirewallRule,
    getFirewallStatus,
    updateFirewallStatus,
} from '@/api/server/security/firewall'
import ServerContentBlock from '@/components/servers/ServerContentBlock'
import ServerPageHeader from '@/components/servers/common/ServerPageHeader'
import SecurityTabs from '@/components/servers/security/SecurityTabs'
import { ServerContext } from '@/state/server'
import useNotify from '@/util/useNotify'
import { FormEvent, useEffect, useMemo, useState } from 'react'
import useSWR from 'swr'

type PolicyValue = 'ACCEPT' | 'DROP' | 'REJECT'
type RuleKind = 'single-ipv4' | 'single-ipv6' | 'cidr'

const defaultIpset = 'ipfilter-net0'
const commonIpsets = [
    {
        value: defaultIpset,
        label: 'Primary Network Allowlist',
        description: 'Recommended. Controls which source IPs may reach the main network interface.',
    },
]
const policyOptions: Array<{ value: PolicyValue; label: string; description: string }> = [
    { value: 'ACCEPT', label: 'Accept', description: 'Allow traffic by default unless a stricter rule is added.' },
    { value: 'DROP', label: 'Drop', description: 'Silently block traffic that is not explicitly allowed.' },
    { value: 'REJECT', label: 'Reject', description: 'Block traffic and return a rejection response.' },
]
const ruleKindOptions: Array<{ value: RuleKind; label: string; placeholder: string; help: string }> = [
    {
        value: 'single-ipv4',
        label: 'Single IPv4 address',
        placeholder: '203.0.113.10',
        help: 'Best for allowing your own home, office, or VPN IPv4 address.',
    },
    {
        value: 'single-ipv6',
        label: 'Single IPv6 address',
        placeholder: '2001:db8::10',
        help: 'Use this when your access point uses IPv6.',
    },
    {
        value: 'cidr',
        label: 'CIDR / subnet',
        placeholder: '203.0.113.0/24',
        help: 'Use only when you intentionally trust a whole network range.',
    },
]

const FirewallContainer = () => {
    const server = ServerContext.useStoreState(state => state.server.data!)
    const notify = useNotify()
    const [submitting, setSubmitting] = useState(false)
    const [ruleKind, setRuleKind] = useState<RuleKind>('single-ipv4')
    const [ruleCidr, setRuleCidr] = useState('')
    const [ruleComment, setRuleComment] = useState('')
    const [ruleIpset, setRuleIpset] = useState(defaultIpset)
    const [policyIn, setPolicyIn] = useState<PolicyValue>('ACCEPT')
    const [policyOut, setPolicyOut] = useState<PolicyValue>('ACCEPT')
    const [ipfilterEnabled, setIpfilterEnabled] = useState(true)

    const { data, isLoading, error, mutate } = useSWR(['server:security:firewall', server.uuid], () =>
        getFirewallStatus(server.uuid)
    )

    useEffect(() => {
        if (!data) {
            return
        }

        setPolicyIn((data.policyIn as PolicyValue) || 'ACCEPT')
        setPolicyOut((data.policyOut as PolicyValue) || 'ACCEPT')
        setIpfilterEnabled(data.ipfilter ?? true)
    }, [data])

    const ipsetOptions = useMemo(() => {
        const existing = (data?.ipsets || []).map(set => ({
            value: set.name,
            label: set.name === defaultIpset ? 'Primary Network Allowlist' : set.name,
            description: set.comment || 'Existing firewall IP set.',
        }))

        const merged = [...commonIpsets, ...existing]
        const seen = new Set<string>()

        return merged.filter(option => {
            if (seen.has(option.value)) {
                return false
            }

            seen.add(option.value)
            return true
        })
    }, [data?.ipsets])

    const selectedRuleKind = ruleKindOptions.find(option => option.value === ruleKind) || ruleKindOptions[0]
    const firewallUnavailable = data?.available === false

    const ruleRows = useMemo(
        () =>
            (data?.ipsets || []).flatMap(set =>
                set.rules.map(rule => ({
                    ipset: set.name,
                    ipsetComment: set.comment,
                    cidr: rule.cidr,
                    comment: rule.comment,
                    managed: !!rule.managed,
                }))
            ),
        [data?.ipsets]
    )

    const onEnableFirewall = async () => {
        try {
            setSubmitting(true)
            await updateFirewallStatus(server.uuid, {
                enabled: true,
                ipfilter: true,
                policyIn,
                policyOut,
            })
            setIpfilterEnabled(true)
            await mutate()
            notify({
                color: 'green',
                message: 'Firewall enabled.',
            })
        } catch (error) {
            notify({ color: 'red', message: httpErrorToHuman(error) })
        } finally {
            setSubmitting(false)
        }
    }

    const onSavePolicies = async () => {
        try {
            setSubmitting(true)
            await updateFirewallStatus(server.uuid, {
                enabled: true,
                ipfilter: true,
                policyIn,
                policyOut,
            })
            setIpfilterEnabled(true)
            await mutate()
            notify({ color: 'green', message: 'Firewall behavior updated.' })
        } catch (error) {
            notify({ color: 'red', message: httpErrorToHuman(error) })
        } finally {
            setSubmitting(false)
        }
    }

    const onAddRule = async (event: FormEvent) => {
        event.preventDefault()

        if (!ruleCidr.trim()) {
            notify({ color: 'red', message: 'Source address is required.' })
            return
        }

        try {
            setSubmitting(true)
            await addFirewallRule(server.uuid, {
                cidr: ruleCidr.trim(),
                ipset: ruleIpset.trim() || defaultIpset,
                comment: ruleComment.trim(),
            })
            await mutate()
            setRuleCidr('')
            setRuleComment('')
            notify({ color: 'green', message: 'Firewall rule added.' })
        } catch (error) {
            notify({ color: 'red', message: httpErrorToHuman(error) })
        } finally {
            setSubmitting(false)
        }
    }

    const onDeleteRule = async (ipset: string, cidr: string) => {
        if (!window.confirm(`Remove rule ${cidr} from ${ipset}?`)) {
            return
        }

        try {
            setSubmitting(true)
            await deleteFirewallRule(server.uuid, { ipset, cidr })
            await mutate()
            notify({ color: 'green', message: 'Firewall rule removed.' })
        } catch (error) {
            notify({ color: 'red', message: httpErrorToHuman(error) })
        } finally {
            setSubmitting(false)
        }
    }

    return (
        <ServerContentBlock title='Firewall'>
            <ServerPageHeader title='Firewall' />
            <SecurityTabs />

            {isLoading ? (
                <div className='rounded-2xl border border-white/10 bg-[#1a1441] p-8 text-center text-white/60'>
                    Loading firewall settings...
                </div>
            ) : error ? (
                <div className='rounded-2xl border border-rose-500/30 bg-rose-500/10 p-8 text-center text-rose-200'>
                    Failed to load firewall settings.
                </div>
            ) : (
                <div className='space-y-4'>
                    <section className='rounded-2xl border border-white/10 bg-[#1a1441] p-5'>
                        <div className='flex flex-col gap-3 xl:flex-row xl:items-start xl:justify-between'>
                            <div className='max-w-3xl'>
                                <h2 className='text-2xl font-semibold text-white'>Firewall guide</h2>
                                <p className='mt-2 text-sm leading-6 text-white/70'>
                                    Use this page to decide who can reach your VPS. The easiest safe setup is:
                                    enable the firewall, set inbound policy to <span className='font-semibold text-white'>Drop</span>,
                                    keep outbound policy on <span className='font-semibold text-white'>Accept</span>, and add
                                    only your own IP addresses to the allowlist below.
                                </p>
                            </div>
                            {data?.enabled ? (
                                <div className='inline-flex h-11 items-center rounded-xl border border-emerald-400/30 bg-emerald-500/10 px-4 text-sm font-semibold text-emerald-100'>
                                    Firewall enforced
                                </div>
                            ) : (
                                <button
                                    type='button'
                                    onClick={onEnableFirewall}
                                    disabled={submitting || firewallUnavailable}
                                    className='h-11 rounded-xl bg-indigo-600 px-4 text-sm font-semibold text-white transition hover:bg-indigo-500 disabled:cursor-not-allowed disabled:opacity-60'
                                >
                                    Enable firewall
                                </button>
                            )}
                        </div>

                        {firewallUnavailable ? (
                            <div className='mt-4 rounded-xl border border-amber-400/25 bg-amber-500/10 p-4 text-sm text-amber-100'>
                                <p className='font-semibold'>Firewall controls are not available right now.</p>
                                <p className='mt-1 text-amber-100/80'>
                                    {data?.unavailableMessage || 'Retry after the VPS finishes installing or contact support if this continues.'}
                                </p>
                                <button
                                    type='button'
                                    onClick={() => mutate()}
                                    className='mt-3 rounded-lg border border-amber-200/25 bg-amber-200/10 px-3 py-1.5 text-xs font-semibold text-amber-50 hover:bg-amber-200/20'
                                >
                                    Retry firewall check
                                </button>
                            </div>
                        ) : null}

                        <div className='mt-4 grid grid-cols-1 gap-3 lg:grid-cols-3'>
                            <div className='rounded-xl border border-white/8 bg-[#111a31]/70 p-4'>
                                <p className='text-xs font-semibold uppercase tracking-[0.18em] text-white/45'>Current State</p>
                                <p className='mt-2 text-lg font-semibold text-white'>
                                    {data?.enabled ? 'Enabled' : 'Disabled'}
                                </p>
                                <p className='mt-1 text-sm text-white/60'>
                                    Rules configured: {data?.rulesCount || 0}
                                </p>
                            </div>
                            <div className='rounded-xl border border-white/8 bg-[#111a31]/70 p-4'>
                                <p className='text-xs font-semibold uppercase tracking-[0.18em] text-white/45'>Inbound Traffic</p>
                                <p className='mt-2 text-lg font-semibold text-white'>{data?.policyIn || 'ACCEPT'}</p>
                                <p className='mt-1 text-sm text-white/60'>Controls who can reach your VPS from the internet.</p>
                            </div>
                            <div className='rounded-xl border border-white/8 bg-[#111a31]/70 p-4'>
                                <p className='text-xs font-semibold uppercase tracking-[0.18em] text-white/45'>Outbound Traffic</p>
                                <p className='mt-2 text-lg font-semibold text-white'>{data?.policyOut || 'ACCEPT'}</p>
                                <p className='mt-1 text-sm text-white/60'>Usually keep this on Accept so updates and downloads work.</p>
                            </div>
                        </div>

                        <div className='mt-4 rounded-xl border border-amber-400/20 bg-amber-500/10 p-4 text-sm text-amber-100'>
                            <p className='font-semibold'>Recommended order</p>
                            <ol className='mt-2 list-decimal space-y-1 pl-5 text-amber-100/90'>
                                <li>Add your own IP address first.</li>
                                <li>Save inbound policy as <span className='font-semibold'>Drop</span>.</li>
                                <li>Enable the firewall. It stays enforced for traffic safety.</li>
                            </ol>
                        </div>
                    </section>

                    <section className='rounded-2xl border border-white/10 bg-[#1a1441] p-5'>
                        <div className='flex flex-col gap-1'>
                            <h3 className='text-xl font-semibold text-white'>Firewall behavior</h3>
                            <p className='text-sm text-white/60'>
                                These controls decide what happens when traffic does not match one of your allowlist rules.
                            </p>
                        </div>

                        <div className='mt-4 grid grid-cols-1 gap-4 lg:grid-cols-2'>
                            <label className='space-y-2'>
                                <span className='text-sm font-medium text-white/80'>Inbound policy</span>
                                <select
                                    value={policyIn}
                                    onChange={event => setPolicyIn(event.target.value as PolicyValue)}
                                    disabled={firewallUnavailable}
                                    className='h-11 w-full rounded-xl border border-white/15 bg-[#111a31] px-3 text-sm text-white outline-none focus:border-indigo-400'
                                >
                                    {policyOptions.map(option => (
                                        <option key={option.value} value={option.value}>
                                            {option.label}
                                        </option>
                                    ))}
                                </select>
                                <p className='text-xs text-white/50'>
                                    {policyOptions.find(option => option.value === policyIn)?.description}
                                </p>
                            </label>

                            <label className='space-y-2'>
                                <span className='text-sm font-medium text-white/80'>Outbound policy</span>
                                <select
                                    value={policyOut}
                                    onChange={event => setPolicyOut(event.target.value as PolicyValue)}
                                    disabled={firewallUnavailable}
                                    className='h-11 w-full rounded-xl border border-white/15 bg-[#111a31] px-3 text-sm text-white outline-none focus:border-indigo-400'
                                >
                                    {policyOptions.map(option => (
                                        <option key={option.value} value={option.value}>
                                            {option.label}
                                        </option>
                                    ))}
                                </select>
                                <p className='text-xs text-white/50'>
                                    {policyOptions.find(option => option.value === policyOut)?.description}
                                </p>
                            </label>

                            <div className='rounded-xl border border-emerald-400/20 bg-emerald-500/10 p-4'>
                                <span className='text-sm font-medium text-emerald-100'>IP filter mode</span>
                                <p className='mt-2 text-sm font-semibold text-white'>Enabled and enforced</p>
                                <p className='mt-1 text-xs text-emerald-100/75'>
                                    This cannot be disabled from the customer panel because it protects network controls.
                                </p>
                            </div>
                        </div>

                        <div className='mt-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between'>
                            <p className='text-sm text-white/55'>
                                Need a recovery option? You can also use the firewall reset action from server settings.
                            </p>
                            <button
                                type='button'
                                onClick={onSavePolicies}
                                disabled={submitting || firewallUnavailable}
                                className='h-11 rounded-xl bg-indigo-600 px-5 text-sm font-semibold text-white transition hover:bg-indigo-500 disabled:cursor-not-allowed disabled:opacity-60'
                            >
                                Save firewall behavior
                            </button>
                        </div>
                    </section>

                    <section className='rounded-2xl border border-white/10 bg-[#1a1441] p-5'>
                        <div className='flex flex-col gap-1'>
                            <h3 className='text-xl font-semibold text-white'>Add firewall rule</h3>
                            <p className='text-sm text-white/60'>
                                Add the source IPs or subnets that should be allowed to reach this VPS.
                            </p>
                        </div>

                        <div className='mt-4 grid grid-cols-1 gap-3 lg:grid-cols-3'>
                            <label className='space-y-2'>
                                <span className='text-sm font-medium text-white/80'>Rule type</span>
                                <select
                                    value={ruleKind}
                                    onChange={event => setRuleKind(event.target.value as RuleKind)}
                                    disabled={firewallUnavailable}
                                    className='h-11 w-full rounded-xl border border-white/15 bg-[#111a31] px-3 text-sm text-white outline-none focus:border-indigo-400'
                                >
                                    {ruleKindOptions.map(option => (
                                        <option key={option.value} value={option.value}>
                                            {option.label}
                                        </option>
                                    ))}
                                </select>
                                <p className='text-xs text-white/50'>{selectedRuleKind.help}</p>
                            </label>

                            <label className='space-y-2'>
                                <span className='text-sm font-medium text-white/80'>Firewall group</span>
                                <select
                                    value={ruleIpset}
                                    onChange={event => setRuleIpset(event.target.value)}
                                    disabled={firewallUnavailable}
                                    className='h-11 w-full rounded-xl border border-white/15 bg-[#111a31] px-3 text-sm text-white outline-none focus:border-indigo-400'
                                >
                                    {ipsetOptions.map(option => (
                                        <option key={option.value} value={option.value}>
                                            {option.label}
                                        </option>
                                    ))}
                                </select>
                                <p className='text-xs text-white/50'>
                                    {ipsetOptions.find(option => option.value === ruleIpset)?.description}
                                </p>
                            </label>

                            <div className='rounded-xl border border-white/8 bg-[#111a31]/70 p-4 text-sm text-white/70'>
                                <p className='font-semibold text-white'>Examples</p>
                                <ul className='mt-2 space-y-1 text-xs text-white/55'>
                                    <li>`203.0.113.10` for one IPv4 address</li>
                                    <li>`2001:db8::10` for one IPv6 address</li>
                                    <li>`203.0.113.0/24` for a subnet</li>
                                </ul>
                            </div>
                        </div>

                        <form onSubmit={onAddRule} className='mt-4 grid grid-cols-1 gap-3 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)_auto]'>
                            <label className='space-y-2'>
                                <span className='text-sm font-medium text-white/80'>Source address or subnet</span>
                                <input
                                    value={ruleCidr}
                                    onChange={event => setRuleCidr(event.target.value)}
                                    placeholder={selectedRuleKind.placeholder}
                                    disabled={firewallUnavailable}
                                    className='h-11 w-full rounded-xl border border-white/15 bg-[#111a31] px-3 text-sm text-white placeholder:text-white/35 outline-none focus:border-indigo-400'
                                />
                                <p className='text-xs text-white/50'>
                                    Plain IPs are accepted and will be converted automatically to `/32` or `/128`.
                                </p>
                            </label>

                            <label className='space-y-2'>
                                <span className='text-sm font-medium text-white/80'>Comment</span>
                                <input
                                    value={ruleComment}
                                    onChange={event => setRuleComment(event.target.value)}
                                    placeholder='Example: My home IP'
                                    disabled={firewallUnavailable}
                                    className='h-11 w-full rounded-xl border border-white/15 bg-[#111a31] px-3 text-sm text-white placeholder:text-white/35 outline-none focus:border-indigo-400'
                                />
                                <p className='text-xs text-white/50'>
                                    Optional, but useful when you need to remember who this rule belongs to.
                                </p>
                            </label>

                            <div className='flex items-end'>
                                <button
                                    type='submit'
                                    disabled={submitting || firewallUnavailable}
                                    className='h-11 w-full rounded-xl bg-indigo-600 px-4 text-sm font-semibold text-white transition hover:bg-indigo-500 disabled:cursor-not-allowed disabled:opacity-60 lg:w-auto'
                                >
                                    Add rule
                                </button>
                            </div>
                        </form>
                    </section>

                    <section className='rounded-2xl border border-white/10 bg-[#1a1441] p-5'>
                        <div className='flex flex-col gap-1'>
                            <h3 className='text-xl font-semibold text-white'>Firewall rules</h3>
                            <p className='text-sm text-white/60'>
                                These are the source addresses currently allowed by your configured firewall groups.
                            </p>
                        </div>

                        <div className='mt-3 overflow-x-auto'>
                            <table className='w-full min-w-[760px] text-left text-sm'>
                                <thead>
                                    <tr className='border-b border-white/10 text-white/60'>
                                        <th className='py-2 pr-4 font-medium'>Firewall Group</th>
                                        <th className='py-2 pr-4 font-medium'>Source</th>
                                        <th className='py-2 pr-4 font-medium'>Comment</th>
                                        <th className='py-2 pr-4 font-medium'>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {ruleRows.map(rule => (
                                        <tr
                                            key={`${rule.ipset}:${rule.cidr}`}
                                            className='border-b border-white/5 text-white/85'
                                        >
                                            <td className='py-3 pr-4'>
                                                <div className='flex flex-col'>
                                                    <span>{rule.ipset}</span>
                                                    <span className='text-xs text-white/45'>
                                                        {rule.ipsetComment || 'Managed firewall group'}
                                                    </span>
                                                </div>
                                            </td>
                                            <td className='py-3 pr-4 font-mono text-xs sm:text-sm'>{rule.cidr}</td>
                                            <td className='py-3 pr-4'>{rule.comment || '-'}</td>
                                            <td className='py-3 pr-4'>
                                                {rule.managed ? (
                                                    <span className='rounded-lg border border-white/15 bg-white/5 px-3 py-1 text-xs font-semibold text-white/55'>
                                                        Managed
                                                    </span>
                                                ) : (
                                                    <button
                                                        type='button'
                                                        onClick={() => onDeleteRule(rule.ipset, rule.cidr)}
                                                        disabled={submitting || firewallUnavailable}
                                                        className='rounded-lg border border-rose-400/30 bg-rose-500/10 px-3 py-1 text-xs font-semibold text-rose-200 hover:bg-rose-500/20 disabled:cursor-not-allowed disabled:opacity-60'
                                                    >
                                                        Remove
                                                    </button>
                                                )}
                                            </td>
                                        </tr>
                                    ))}
                                    {!ruleRows.length && (
                                        <tr>
                                            <td colSpan={4} className='py-8 text-center text-white/55'>
                                                No firewall rules configured yet. Add your own IP first before switching inbound policy to Drop.
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </section>
                </div>
            )}
        </ServerContentBlock>
    )
}

export default FirewallContainer
