import { NavLink, useParams } from 'react-router-dom'

const SecurityTabs = () => {
    const { id } = useParams()

    const tabs = [
        { label: 'Firewall', to: `/servers/${id}/security/firewall` },
    ]

    return (
        <div className='mb-5 flex flex-wrap gap-2'>
            {tabs.map(tab => (
                <NavLink
                    key={tab.to}
                    to={tab.to}
                    className={({ isActive }) =>
                        `rounded-full px-3 py-1.5 text-sm font-medium transition-colors ${
                            isActive
                                ? 'bg-indigo-600/30 text-white'
                                : 'border border-white/15 text-white/60 hover:text-white'
                        }`
                    }
                >
                    {tab.label}
                </NavLink>
            ))}
        </div>
    )
}

export default SecurityTabs
