import { ServerContext } from '@/state/server'
import { ArrowTopRightOnSquareIcon, HomeIcon } from '@heroicons/react/24/outline'
import SensitiveValue from '@/components/elements/SensitiveValue'
import useNotify from '@/util/useNotify'

interface Props {
    title: string
}

const ServerPageHeader = ({ title }: Props) => {
    const server = ServerContext.useStoreState(state => state.server.data!)
    const terminalEnabled = Boolean(server.node?.terminalEnabled)
    const isSuspended = String(server.status || '').toLowerCase() === 'suspended'
    const accessLocked = isSuspended
    const notify = useNotify()

    const openTerminalPopup = () => {
        if (accessLocked) {
            notify({
                message: 'Console access is disabled while this VPS is suspended.',
                color: 'yellow',
            })
            return
        }

        window.open(
            `/console?uuid=${encodeURIComponent(server.uuid)}&type=novnc`,
            `wammu-user-console-${server.id}`,
            'popup=yes,width=1280,height=820,resizable=yes,scrollbars=yes'
        )
    }

    return (
        <div className='mb-7 flex flex-wrap items-center justify-between gap-4 md:mb-8'>
            <div>
                <h1 className='text-3xl font-semibold tracking-tight text-white md:text-4xl'>{title}</h1>
                <p className='mt-2 inline-flex items-center gap-2 text-sm text-white/55 md:text-base'>
                    <HomeIcon className='h-4 w-4' />
                    <span className='truncate'>
                        VPS - <SensitiveValue>{server.hostname}</SensitiveValue> - {title}
                    </span>
                </p>
            </div>
            {terminalEnabled && !accessLocked && (
                <button
                    type='button'
                    onClick={openTerminalPopup}
                    className='inline-flex h-11 items-center gap-2 rounded-xl border border-indigo-500/50 bg-indigo-500/10 px-5 text-sm font-semibold text-indigo-200 hover:bg-indigo-500/20'
                >
                    Terminal
                    <ArrowTopRightOnSquareIcon className='h-4 w-4' />
                </button>
            )}
        </div>
    )
}

export default ServerPageHeader
