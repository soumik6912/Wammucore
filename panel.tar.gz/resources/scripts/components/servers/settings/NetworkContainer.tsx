import { ServerContext } from '@/state/server'
import SensitiveValue from '@/components/elements/SensitiveValue'

import NameserversCard from '@/components/servers/settings/partials/network/NameserversCard'

const NetworkContainer = () => {
    const server = ServerContext.useStoreState(state => state.server.data!)
    const ipv4 = server.limits.addresses.ipv4
    const ipv6 = server.limits.addresses.ipv6

    return (
        <div className='space-y-4'>
            <section className='rounded-2xl border border-white/10 bg-[#1a1441] p-5'>
                <h3 className='text-2xl font-semibold text-white'>IP Addresses</h3>
                <div className='mt-4 grid gap-3 md:grid-cols-2'>
                    <div className='rounded-xl border border-white/10 bg-[#111a31] p-4'>
                        <p className='text-sm font-semibold text-white'>IPv4</p>
                        {ipv4.length ? (
                            <ul className='mt-2 space-y-1 text-sm text-white/70'>
                                {ipv4.map(address => (
                                    <li key={address.id}>
                                        <SensitiveValue>{address.address}</SensitiveValue>
                                    </li>
                                ))}
                            </ul>
                        ) : (
                            <p className='mt-2 text-sm text-white/50'>No IPv4 assigned.</p>
                        )}
                    </div>
                    <div className='rounded-xl border border-white/10 bg-[#111a31] p-4'>
                        <p className='text-sm font-semibold text-white'>IPv6</p>
                        {ipv6.length ? (
                            <ul className='mt-2 space-y-1 text-sm text-white/70'>
                                {ipv6.map(address => (
                                    <li key={address.id}>
                                        <SensitiveValue>{address.address}</SensitiveValue>
                                    </li>
                                ))}
                            </ul>
                        ) : (
                            <p className='mt-2 text-sm text-white/50'>No IPv6 assigned.</p>
                        )}
                    </div>
                </div>
            </section>

            <NameserversCard />
        </div>
    )
}

export default NetworkContainer
