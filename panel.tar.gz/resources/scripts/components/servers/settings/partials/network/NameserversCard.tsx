import { ServerContext } from '@/state/server'
import { useFlashKey } from '@/util/useFlash'
import { ipAddress } from '@/util/validation'
import { TrashIcon } from '@heroicons/react/20/solid'
import { zodResolver } from '@hookform/resolvers/zod'
import { useEffect } from 'react'
import { FormProvider, useFieldArray, useForm } from 'react-hook-form'
import { useTranslation } from 'react-i18next'
import useSWR from 'swr'
import { z } from 'zod'

import getNetwork from '@/api/server/settings/getNetworkSettings'
import updateNetwork from '@/api/server/settings/updateNetworkSettings'

import Button from '@/components/elements/Button'
import FlashMessageRender from '@/components/elements/FlashMessageRenderer'
import FormCard from '@/components/elements/FormCard'
import TextInputForm from '@/components/elements/forms/TextInputForm'


const NameserversCard = () => {
    const { t: tStrings } = useTranslation('strings')
    const server = ServerContext.useStoreState(state => state.server.data!)

    const { clearFlashes, clearAndAddHttpError } = useFlashKey(
        `servers.${server.uuid}.settings.network.nameservers`
    )

    const { data, mutate } = useSWR(
        ['server:settings:hardware', server.uuid],
        () => getNetwork(server.uuid)
    )

    const schema = z.object({
        nameservers: z
            .object({
                value: ipAddress(),
            })
            .array(),
    })

    const form = useForm({
        resolver: zodResolver(schema),
        defaultValues: {
            nameservers:
                data?.nameservers.map(nameserver => ({
                    value: nameserver,
                })) ?? [],
        } as unknown as z.infer<typeof schema>,
    })

    const { fields, append, remove } = useFieldArray({
        control: form.control,
        name: 'nameservers',
    })

    const submit = async (values: z.infer<typeof schema>) => {
        clearFlashes()

        try {
            await updateNetwork(
                server.uuid,
                values.nameservers.map(nameserver => nameserver.value)
            )

            form.reset(values)
        } catch (e) {
            clearAndAddHttpError(e as Error)
        }
    }

    useEffect(() => {
        form.reset({
            nameservers:
                data?.nameservers.map(nameserver => ({
                    value: nameserver,
                })) ?? [],
        } as unknown as z.infer<typeof schema>)
    }, [data])

    return (
        <div className='w-full'>
            <div className='overflow-hidden rounded-2xl border border-white/10 bg-[#1a1441]'>
                <div className='border-b border-white/10 bg-white/5 px-7 py-5'>
                    <div className="flex items-center justify-between">
                        <div>
                            <h2 className="text-xl font-semibold text-white tracking-tight">
                                {tStrings('nameserver', { count: 2 })}
                            </h2>
                            <p className='mt-1 text-sm text-white/60'>Configure DNS nameservers for your server</p>
                        </div>
                        <svg className='h-10 w-10 text-white/25' fill='none' viewBox='0 0 24 24' stroke='currentColor' strokeWidth={1.5}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M5 12h14m-7 7V5" />
                        </svg>
                    </div>
                </div>

                <FormProvider {...form}>
                    <form onSubmit={form.handleSubmit(submit)}>
                        <div className='p-7'>
                            <FlashMessageRender
                                className='mb-6'
                                byKey={`servers.${server.uuid}.settings.network.nameservers`}
                            />

                            <div className='space-y-4'>
                                {fields.map((field, index) => (
                                    <div 
                                        key={field.id}
                                        className='rounded-xl border border-white/10 bg-[#111a31] p-5 transition-colors hover:border-indigo-400/40'
                                    >
                                        <div className='flex items-start gap-3'>
                                            <div className='mt-0.5 flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg border border-indigo-400/30 bg-indigo-500/10'>
                                                <span className='text-sm font-semibold text-indigo-300'>{index + 1}</span>
                                            </div>
                                            <div className='flex-1'>
                                                <TextInputForm
                                                    disabled={form.formState.isSubmitting}
                                                    name={`nameservers.${index}.value`}
                                                    label={`${tStrings('nameserver', { count: 1 })} ${index + 1}`}
                                                    rightSection={
                                                        <button
                                                            type='button'
                                                            onClick={() => remove(index)}
                                                            className='group rounded-lg bg-transparent p-2 transition-colors hover:bg-red-500/10'
                                                            title='Remove nameserver'
                                                        >
                                                            <TrashIcon className='h-4 w-4 text-white/40 transition-colors group-hover:text-red-400' />
                                                        </button>
                                                    }
                                                />
                                            </div>
                                        </div>
                                    </div>
                                ))}

                                {form.getValues().nameservers.length < 2 && (
                                    <button
                                        type='button'
                                        onClick={() => append({ value: '' })}
                                        className='group w-full rounded-xl border-2 border-dashed border-white/15 bg-[#111a31] p-4 transition-all hover:border-indigo-400/50 hover:bg-[#16203d]'
                                    >
                                        <div className='flex items-center justify-center gap-2 text-white/60 transition-colors group-hover:text-indigo-300'>
                                            <svg className='h-5 w-5' fill='none' viewBox='0 0 24 24' stroke='currentColor' strokeWidth={2}>
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
                                            </svg>
                                            <span className='font-medium'>{tStrings('add')} Nameserver</span>
                                        </div>
                                    </button>
                                )}
                            </div>
                        </div>

                        <div className='flex items-center justify-between border-t border-white/10 bg-white/5 px-7 py-4'>
                            <div className='flex items-center gap-2 text-xs text-white/45'>
                                <span className='inline-block h-1.5 w-1.5 rounded-full bg-emerald-500'></span>
                                <code className='font-mono'>{server.uuid.slice(0, 8)}</code>
                            </div>
                            <button
                                disabled={!form.formState.isDirty}
                                type='submit'
                                className={`
                                    relative rounded-lg px-5 py-2.5 text-sm font-medium transition-all duration-200
                                    ${form.formState.isDirty && !form.formState.isSubmitting
                                        ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/30 hover:-translate-y-0.5 hover:bg-indigo-500 hover:shadow-indigo-900/50'
                                        : 'cursor-not-allowed bg-white/10 text-white/35'
                                    }
                                    ${form.formState.isSubmitting ? 'opacity-70 cursor-wait' : ''}
                                `}
                            >
                                <span className="flex items-center gap-2">
                                    {form.formState.isSubmitting ? (
                                        <>
                                            <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                            </svg>
                                            Saving...
                                        </>
                                    ) : (
                                        <>
                                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                                            </svg>
                                            {tStrings('save')}
                                        </>
                                    )}
                                </span>
                            </button>
                        </div>
                    </form>
                </FormProvider>
            </div>
        </div>
    )
}

export default NameserversCard
