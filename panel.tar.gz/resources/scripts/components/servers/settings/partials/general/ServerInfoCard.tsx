import { ServerContext } from '@/state/server'
import { useFlashKey } from '@/util/useFlash'
import { hostname } from '@/util/validation'
import { zodResolver } from '@hookform/resolvers/zod'
import { FormProvider, useForm } from 'react-hook-form'
import { useTranslation } from 'react-i18next'
import { z } from 'zod'

import renameServer from '@/api/server/settings/renameServer'

import Button from '@/components/elements/Button'
import FlashMessageRender from '@/components/elements/FlashMessageRenderer'
import FormCard from '@/components/elements/FormCard'
import TextInputForm from '@/components/elements/forms/TextInputForm'


const ServerInfoCard = () => {
    const { t } = useTranslation('server.settings')
    const { t: tStrings } = useTranslation('strings')
    const server = ServerContext.useStoreState(state => state.server.data!)
    const setServer = ServerContext.useStoreActions(
        actions => actions.server.setServer
    )
    const { clearFlashes, clearAndAddHttpError } = useFlashKey(
        `servers.${server.uuid}.settings.general.info`
    )

    const schema = z.object({
        name: z.string().nonempty().max(40),
        hostname: hostname().max(191),
    })

    const methods = useForm({
        resolver: zodResolver(schema),
        defaultValues: {
            name: server.name,
            hostname: server.hostname,
        },
    })

    const submit = async (data: z.infer<typeof schema>) => {
        clearFlashes()

        try {
            await renameServer(server.uuid, data)

            setServer({ ...server, name: data.name })
            methods.reset(data)
        } catch (e) {
            console.error(e)

            clearAndAddHttpError(e as Error)
        }
    }

    return (
        <div className="w-full max-w-4xl mx-auto">
            <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 rounded-xl shadow-2xl border border-slate-700/50 overflow-hidden">
                
                {/* Header */}
                <div className="bg-slate-800/50 border-b border-slate-700/50 px-7 py-5">
                    <div className="flex items-center justify-between">
                        <div>
                            <h2 className="text-xl font-semibold text-white tracking-tight">{t('display_info.title')}</h2>
                            <p className="text-slate-400 text-sm mt-1">Update server display name and hostname</p>
                        </div>
                        <svg className="w-10 h-10 text-slate-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                    </div>
                </div>

                <FormProvider {...methods}>
                    <form onSubmit={methods.handleSubmit(submit)}>
                        {/* Content */}
                        <div className="p-7">
                            <FlashMessageRender
                                className='mb-6'
                                byKey={`servers.${server.uuid}.settings.general.info`}
                            />

                            <div className="space-y-6">
                                {/* Display Name */}
                                <div className="bg-slate-800/30 border border-slate-700/30 rounded-lg p-5 hover:border-blue-500/30 transition-colors">
                                    <div className="flex items-start gap-3">
                                        <svg className="w-5 h-5 text-blue-400 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                            <path strokeLinecap="round" strokeLinejoin="round" d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
                                        </svg>
                                        <div className="flex-1">
                                            <TextInputForm
                                                name='name'
                                                label={tStrings('display_name')}
                                            />
                                        </div>
                                    </div>
                                </div>

                                {/* Hostname */}
                                <div className="bg-slate-800/30 border border-slate-700/30 rounded-lg p-5 hover:border-blue-500/30 transition-colors">
                                    <div className="flex items-start gap-3">
                                        <svg className="w-5 h-5 text-cyan-400 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                            <path strokeLinecap="round" strokeLinejoin="round" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
                                        </svg>
                                        <div className="flex-1">
                                            <TextInputForm
                                                name='hostname'
                                                label={tStrings('hostname')}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Footer */}
                        <div className="bg-slate-900/50 border-t border-slate-700/50 px-7 py-4 flex items-center justify-between">
                            <div className="flex items-center gap-2 text-xs text-slate-500">
                                <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                                <code className="font-mono">{server.uuid.slice(0, 8)}</code>
                            </div>
                            <button
                                disabled={!methods.formState.isDirty}
                                type='submit'
                                className={`
                                    relative px-5 py-2.5 rounded-lg font-medium text-sm transition-all duration-200
                                    ${methods.formState.isDirty && !methods.formState.isSubmitting
                                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-900/30 hover:shadow-emerald-900/50 hover:-translate-y-0.5' 
                                        : 'bg-slate-700 text-slate-500 cursor-not-allowed'
                                    }
                                    ${methods.formState.isSubmitting ? 'opacity-70 cursor-wait' : ''}
                                `}
                            >
                                <span className="flex items-center gap-2">
                                    {methods.formState.isSubmitting ? (
                                        <>
                                            <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                            </svg>
                                            Saving...
                                        </>
                                    ) : (
                                        <>
                                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                                            </svg>
                                            {tStrings('save')}
                                        </>
                                    )}
                                </span>
                            </button>
                        </div>
                    </form>
                </FormProvider>
            </div>
        </div>
    )
}

export default ServerInfoCard