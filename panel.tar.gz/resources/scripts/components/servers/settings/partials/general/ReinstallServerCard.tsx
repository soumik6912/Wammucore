import { ServerContext } from '@/state/server'
import { useFlashKey } from '@/util/useFlash'
import { password, usKeyboardCharacters } from '@/util/validation'
import { zodResolver } from '@hookform/resolvers/zod'
import { useState } from 'react'
import { FormProvider, useForm } from 'react-hook-form'
import { useTranslation } from 'react-i18next'
import { z } from 'zod'

import reinstallServer from '@/api/server/settings/reinstallServer'

import Button from '@/components/elements/Button'
import FlashMessageRender from '@/components/elements/FlashMessageRenderer'
import FormCard from '@/components/elements/FormCard'
import Modal from '@/components/elements/Modal'
import CheckboxForm from '@/components/elements/forms/CheckboxForm'
import TextInputForm from '@/components/elements/forms/TextInputForm'

import TemplatesSelectForm from '@/components/servers/settings/TemplatesSelectForm'


const ReinstallServerCard = () => {
    const { t } = useTranslation('server.settings')
    const { t: tStrings } = useTranslation('strings')
    const [isModalOpen, setIsModalOpen] = useState(false)
    const server = ServerContext.useStoreState(state => state.server.data!)
    const { clearFlashes, clearAndAddHttpError } = useFlashKey(
        `servers.${server.uuid}.settings.general.reinstall`
    )
    const setServer = ServerContext.useStoreActions(
        state => state.server.setServer
    )

    const schema = z.object({
        templateUuid: z.string().nonempty(),
        accountPassword: password(usKeyboardCharacters()).nonempty(),
        startOnCompletion: z.boolean(),
    })

    const form = useForm({
        resolver: zodResolver(schema),
        mode: 'onChange',
        defaultValues: {
            templateUuid: '',
            accountPassword: '',
            startOnCompletion: false,
        },
    })

    const submit = async (data: z.infer<typeof schema>) => {
        clearFlashes()
        try {
            await reinstallServer(server.uuid, data)

            setServer({
                ...server,
                status: 'installing',
            })
        } catch (error) {
            clearAndAddHttpError(error as any)
        }
    }

    return (
        <>
            <Modal open={isModalOpen} onClose={() => setIsModalOpen(false)}>
                <Modal.Header>
                    <Modal.Title>{t('reinstall.modal.title')}</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Modal.Description bottomMargin>
                        {t('reinstall.modal.description')}
                    </Modal.Description>
                </Modal.Body>
                <Modal.Actions>
                    <Modal.Action onClick={() => setIsModalOpen(false)}>
                        {tStrings('cancel')}
                    </Modal.Action>
                    <Modal.Action
                        loading={form.formState.isSubmitting}
                        onClick={form.handleSubmit(submit)}
                    >
                        {tStrings('confirm')}
                    </Modal.Action>
                </Modal.Actions>
            </Modal>
            <FormProvider {...form}>
                <div className="w-full max-w-4xl mx-auto">
                    <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 rounded-xl shadow-2xl border border-slate-700/50 overflow-hidden">
                        
                        {/* Header */}
                        <div className="bg-slate-800/50 border-b border-slate-700/50 px-7 py-5">
                            <div className="flex items-center justify-between">
                                <div>
                                    <h2 className="text-xl font-semibold text-white tracking-tight">{t('reinstall.title')}</h2>
                                    <p className="text-slate-400 text-sm mt-1">{t('reinstall.description')}</p>
                                </div>
                                <svg className="w-10 h-10 text-slate-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01" />
                                </svg>
                            </div>
                        </div>

                        {/* Content */}
                        <div className="p-7">
                            <FlashMessageRender
                                className='mb-6'
                                byKey={`servers.${server.uuid}.settings.general.reinstall`}
                            />

                            <div className="space-y-6">
                                {/* OS Template */}
                                <div className="bg-slate-800/30 border border-slate-700/30 rounded-lg p-5 hover:border-blue-500/30 transition-colors">
                                    <div className="flex items-start gap-3 mb-3">
                                        <svg className="w-5 h-5 text-blue-400 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                            <path strokeLinecap="round" strokeLinejoin="round" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
                                        </svg>
                                        <div className="flex-1">
                                            <label className="block text-sm font-medium text-slate-200 mb-2">
                                                Operating System Template
                                            </label>
                                            <TemplatesSelectForm />
                                        </div>
                                    </div>
                                </div>

                                {/* Password */}
                                <div className="bg-slate-800/30 border border-slate-700/30 rounded-lg p-5 hover:border-blue-500/30 transition-colors">
                                    <div className="flex items-start gap-3">
                                        <svg className="w-5 h-5 text-violet-400 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                            <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                                        </svg>
                                        <div className="flex-1">
                                            <TextInputForm
                                                name={'accountPassword'}
                                                label={tStrings('system_os_password')}
                                                type={'password'}
                                            />
                                        </div>
                                    </div>
                                </div>

                                {/* Options */}
                                <div className="bg-slate-800/30 border border-slate-700/30 rounded-lg p-5 hover:border-blue-500/30 transition-colors">
                                    <div className="flex items-start gap-3">
                                        <svg className="w-5 h-5 text-emerald-400 mt-1" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                            <path strokeLinecap="round" strokeLinejoin="round" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
                                        </svg>
                                        <div className="flex-1 pt-0.5">
                                            <CheckboxForm
                                                name={'startOnCompletion'}
                                                label={t('reinstall.start_server_after_installing')}
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Footer */}
                        <div className="bg-slate-900/50 border-t border-slate-700/50 px-7 py-4 flex items-center justify-between">
                            <div className="flex items-center gap-2 text-xs text-slate-500">
                                <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                                <code className="font-mono">{server.uuid.slice(0, 8)}</code>
                            </div>
                            <button
                                disabled={!form.formState.isValid}
                                onClick={() => setIsModalOpen(true)}
                                type="button"
                                className={`
                                    relative px-5 py-2.5 rounded-lg font-medium text-sm transition-all duration-200
                                    ${form.formState.isValid 
                                        ? 'bg-red-600 hover:bg-red-500 text-white shadow-lg shadow-red-900/30 hover:shadow-red-900/50 hover:-translate-y-0.5' 
                                        : 'bg-slate-700 text-slate-500 cursor-not-allowed'
                                    }
                                `}
                            >
                                <span className="flex items-center gap-2">
                                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                                    </svg>
                                    {tStrings('reinstall')}
                                </span>
                            </button>
                        </div>
                    </div>
                </div>
            </FormProvider>
        </>
    )
}

export default ReinstallServerCard