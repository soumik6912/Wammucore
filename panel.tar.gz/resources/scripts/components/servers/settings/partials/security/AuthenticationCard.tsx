import { ServerContext } from '@/state/server'
import { useFlashKey } from '@/util/useFlash'
import useNotify from '@/util/useNotify'
import { password, usKeyboardCharacters } from '@/util/validation'
import { zodResolver } from '@hookform/resolvers/zod'
import { ClipboardDocumentIcon } from '@heroicons/react/24/outline'
import { useEffect, useMemo, useState } from 'react'
import { FormProvider, useForm } from 'react-hook-form'
import { useTranslation } from 'react-i18next'
import useSWR from 'swr'
import { z } from 'zod'

import getSecurity from '@/api/server/settings/getAuthSettings'
import updateSecurity from '@/api/server/settings/updateAuthSettings'

import FlashMessageRender from '@/components/elements/FlashMessageRenderer'
import SegmentedControl from '@/components/elements/SegmentedControl'
import SensitiveValue from '@/components/elements/SensitiveValue'
import TextInputForm from '@/components/elements/forms/TextInputForm'
import TextareaForm from '@/components/elements/forms/TextareaForm'


const AuthenticationCard = () => {
    const { t: tStrings } = useTranslation('strings')
    const server = ServerContext.useStoreState(state => state.server.data!)
    const uuid = server.uuid
    const notify = useNotify()
    const { clearFlashes, clearAndAddHttpError } = useFlashKey(
        `servers.${uuid}.settings.security.auth`
    )
    const [type, setType] = useState<'password' | 'ssh_keys'>('password')

    const { data, mutate } = useSWR(['server:settings:security', uuid], () =>
        getSecurity(uuid)
    )

    const sshKeysSchema = z.object({
        sshKeys: z.string().optional(),
        password: z.string().optional(),
    })

    const passwordSchema = z.object({
        sshKeys: z.string().optional(),
        password: usKeyboardCharacters(password()),
    })
    const schema = type === 'password' ? passwordSchema : sshKeysSchema

    const form = useForm({
        resolver: zodResolver(schema),
        defaultValues: {
            sshKeys: data?.sshKeys ?? '',
            password: '',
        },
    })

    const submit = async (values: z.infer<typeof schema>) => {
        clearFlashes()

        try {
            await updateSecurity(uuid, {
                type,
                password: type === 'password' ? values.password : undefined,
                sshKeys: type === 'ssh_keys' ? values.sshKeys : undefined,
            })

            if (type === 'ssh_keys') {
                await mutate({ sshKeys: values.sshKeys ?? '' }, false)
            } else {
                await mutate()
            }

            notify({
                color: 'green',
                message: type === 'ssh_keys' ? 'SSH keys updated successfully.' : 'Root password updated successfully.',
            })

            form.reset({
                sshKeys: type === 'ssh_keys' ? values.sshKeys ?? '' : data?.sshKeys ?? '',
                password: '',
            })
        } catch (e) {
            clearAndAddHttpError(e as Error)
        }
    }

    useEffect(() => {
        form.reset({
            sshKeys: data?.sshKeys ?? '',
            password: '',
        })
    }, [data])

    const watchedSshKeys = form.watch('sshKeys') || ''

    const keyCount = useMemo(() => {
        return watchedSshKeys
            .split('\n')
            .map(line => line.trim())
            .filter(Boolean).length
    }, [watchedSshKeys])

    const primaryAddress =
        server.limits.addresses.ipv4[0]?.address ||
        server.limits.addresses.ipv6[0]?.address ||
        server.hostname
    const sshCommand = `ssh root@${primaryAddress}`

    const copySshCommand = async () => {
        try {
            await navigator.clipboard.writeText(sshCommand)
            notify({ color: 'green', message: 'SSH command copied.' })
        } catch {
            notify({ color: 'red', message: 'Unable to copy SSH command.' })
        }
    }

    return (
        <div className='mx-auto w-full max-w-5xl space-y-4'>
            <section className='rounded-2xl border border-white/10 bg-[#1a1441] p-5 shadow-[0_14px_36px_rgba(0,0,0,0.35)] md:p-6'>
                <div className='flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between'>
                    <div className='space-y-2'>
                        <h2 className='text-2xl font-semibold text-white'>SSH Access Control</h2>
                        <p className='max-w-2xl text-sm text-white/60'>
                            Securely manage root login credentials and authorized SSH public keys.
                        </p>
                    </div>

                    <button
                        type='button'
                        onClick={copySshCommand}
                        className='inline-flex max-w-full items-center gap-2 rounded-xl border border-indigo-400/30 bg-indigo-500/10 px-3 py-2 text-left hover:bg-indigo-500/20'
                    >
                        <div className='min-w-0'>
                            <p className='text-xs uppercase tracking-wide text-indigo-200/80'>Connection</p>
                            <p className='truncate font-mono text-sm text-indigo-100'>
                                <SensitiveValue>{sshCommand}</SensitiveValue>
                            </p>
                        </div>
                        <ClipboardDocumentIcon className='h-4 w-4 shrink-0 text-indigo-100' />
                    </button>
                </div>

                <div className='mt-5 grid grid-cols-1 gap-3 sm:grid-cols-3'>
                    <div className='rounded-xl border border-white/10 bg-[#241a52] p-3'>
                        <p className='text-xs uppercase tracking-wide text-white/50'>Mode</p>
                        <p className='mt-2 text-sm font-semibold text-white'>
                            {type === 'password' ? 'Password Login' : 'SSH Key Login'}
                        </p>
                    </div>
                    <div className='rounded-xl border border-white/10 bg-[#241a52] p-3'>
                        <p className='text-xs uppercase tracking-wide text-white/50'>SSH Keys</p>
                        <p className='mt-2 text-sm font-semibold text-white'>{keyCount} key(s) configured</p>
                    </div>
                    <div className='rounded-xl border border-white/10 bg-[#241a52] p-3'>
                        <p className='text-xs uppercase tracking-wide text-white/50'>SSH Port</p>
                        <p className='mt-2 text-sm font-semibold text-white'>
                            <SensitiveValue>22</SensitiveValue>
                        </p>
                    </div>
                </div>
            </section>

            <FormProvider {...form}>
                {/* @ts-ignore */}
                <form onSubmit={form.handleSubmit(submit)} className='rounded-2xl border border-white/10 bg-[#1a1441] p-5 md:p-6'>
                    <FlashMessageRender
                        className='mb-5'
                        byKey={`servers.${uuid}.settings.security.auth`}
                    />

                    <div className='space-y-5'>
                        <div>
                            <label className='text-xs font-semibold uppercase tracking-wide text-white/60'>
                                Authentication Method
                            </label>
                            <SegmentedControl
                                className='mt-3 !w-full md:!max-w-md'
                                disabled={form.formState.isSubmitting}
                                value={type}
                                onChange={val => setType(val as typeof type)}
                                data={[
                                    {
                                        value: 'password',
                                        label: tStrings('password'),
                                    },
                                    {
                                        value: 'ssh_keys',
                                        label: tStrings('ssh_key', {
                                            count: 2,
                                        }),
                                    },
                                ]}
                            />
                        </div>

                        {type === 'password' && (
                            <div className='rounded-xl border border-white/10 bg-[#241a52] p-4'>
                                <TextInputForm
                                    type='password'
                                    name='password'
                                    label='Root Password'
                                />
                                <p className='mt-2 text-xs text-white/55'>
                                    Use a strong password with at least 8 characters.
                                </p>
                            </div>
                        )}

                        {type === 'ssh_keys' && (
                            <div className='rounded-xl border border-white/10 bg-[#241a52] p-4'>
                                <TextareaForm
                                    name='sshKeys'
                                    label='Authorized SSH Public Keys'
                                    autosize
                                    minRows={8}
                                />
                                <div className='mt-3 flex flex-col gap-1 text-xs text-white/55'>
                                    <p>Paste one public key per line (OpenSSH format).</p>
                                    <p>Detected keys: {keyCount}</p>
                                </div>
                            </div>
                        )}
                    </div>

                    <div className='mt-6 flex flex-col gap-3 border-t border-white/10 pt-4 sm:flex-row sm:items-center sm:justify-between'>
                        <p className='text-xs text-white/45'>Server ID: {uuid.slice(0, 8)}</p>

                        <div className='flex flex-wrap items-center gap-2'>
                            <button
                                type='button'
                                onClick={() =>
                                    form.reset({
                                        sshKeys: data?.sshKeys ?? '',
                                        password: '',
                                    })
                                }
                                disabled={!form.formState.isDirty || form.formState.isSubmitting}
                                className='h-10 rounded-lg border border-white/20 bg-white/5 px-4 text-sm font-semibold text-white hover:bg-white/10 disabled:cursor-not-allowed disabled:opacity-50'
                            >
                                Discard
                            </button>
                            <button
                                disabled={!form.formState.isDirty || form.formState.isSubmitting}
                                type='submit'
                                className='h-10 rounded-lg bg-indigo-600 px-5 text-sm font-semibold text-white hover:bg-indigo-500 disabled:cursor-not-allowed disabled:opacity-50'
                            >
                                {form.formState.isSubmitting ? 'Saving...' : tStrings('save')}
                            </button>
                        </div>
                    </div>
                </form>
            </FormProvider>
        </div>
    )
}

export default AuthenticationCard
