import { ServerContext } from '@/state/server'
import React, { useMemo } from 'react'
import { useFormContext } from 'react-hook-form'
import useTemplateGroupsSWR from '@/api/server/settings/useTemplateGroupsSWR'
import Select from '@/components/elements/inputs/Select'
import SafeImage from '@/components/elements/SafeImage'

interface Props {
  disabled?: boolean
}

type UiGroup = {
  value: string
  label: string
  image?: string
  templates: { value: string; label: string }[]
}

// Fallback icon if your API doesn't provide image
const iconFor = (name: string) => {
  const n = (name || '').toLowerCase()
  if (
    n.includes('windows') ||
    n.includes('win11') ||
    n.includes('win10') ||
    n.includes('microsoft')
  ) {
    return 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/windows11/windows11-original.svg'
  }
  if (n.includes('ubuntu')) return 'https://i.postimg.cc/XJd6ZPvk/image.png'
  if (n.includes('debian')) return 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/debian/debian-original.svg'
  if (n.includes('centos') || n.includes('alma') || n.includes('rocky')) {
    return 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/centos/centos-original.svg'
  }
  if (n.includes('arch')) {
    return 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/archlinux/archlinux-original.svg'
  }
  return 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/linux/linux-original.svg'
}

const TemplatesSelectForm = ({ disabled }: Props) => {
  const uuid = ServerContext.useStoreState((s) => s.server.data!.uuid)
  const { setValue, getValues } = useFormContext()
  const { data, isValidating, isLoading } = useTemplateGroupsSWR(uuid)

  // Use ALL groups; allow custom group.image
  const groups: UiGroup[] = useMemo(
    () =>
      (data ?? []).map((group) => ({
        value: group.uuid,
        label: group.name,
        image: group.image || iconFor(group.name),
        templates: (group.templates ?? []).map((t) => ({
          value: t.uuid,
          label: t.name,
        })),
      })),
    [data]
  )

  const selectedTemplateUuid = (getValues('templateUuid') as string) || ''

  if (isLoading || isValidating) {
    return (
      <div className="grid place-items-center rounded-lg border border-slate-700/30 bg-slate-800/30 py-8 text-slate-400">
        <div className="flex items-center gap-2 text-sm">
          <svg className="h-4 w-4 animate-spin" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 3v3m6.364-.364-2.121 2.121M21 12h-3m.364 6.364-2.121-2.121M12 21v-3M5.636 18.364l2.121-2.121M3 12h3M5.636 5.636l2.121 2.121"/>
          </svg>
          Loading templates…
        </div>
      </div>
    )
  }

  if (!groups.length) return <p className="text-sm text-slate-400">No template groups found.</p>

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {groups.map((g) => {
        const icon = g.image || iconFor(g.label)
        const isSelected = selectedTemplateUuid && g.templates.some((t) => t.value === selectedTemplateUuid)

        return (
          <div
            key={g.value}
            className={`rounded-2xl border bg-slate-900/60 px-6 py-7 text-center shadow-sm transition
              ${isSelected ? 'border-blue-500 ring-2 ring-blue-500/20' : 'border-slate-700/50 hover:border-blue-400/40'}`}
          >
            {/* BIG clean image — no outer box */}
            <SafeImage
              src={icon}
              alt={`${g.label} logo`}
              className="mx-auto mb-3 h-24 w-24 object-contain md:h-28 md:w-28"
              fallbackClassName="mx-auto mb-3 h-24 w-24 md:h-28 md:w-28"
              fallbackText={g.label}
            />

            {/* Name (lowercase like your ref) */}
            <div className="mb-4 text-sm font-semibold lowercase text-slate-200">
              {String(g.label || '').toLowerCase()}
            </div>

            {/* SELECT VERSION */}
            <Select
              data={g.templates}
              value={isSelected ? selectedTemplateUuid : ''}
              onChange={(val) =>
                setValue('templateUuid', val || '', { shouldValidate: true, shouldDirty: true })
              }
              placeholder="SELECT VERSION"
              nothingFound="No versions found"
              loading={isValidating || isLoading}
              disabled={disabled}
            />
          </div>
        )
      })}
    </div>
  )
}

export default TemplatesSelectForm
