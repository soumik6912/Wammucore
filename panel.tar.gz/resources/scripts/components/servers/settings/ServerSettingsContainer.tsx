﻿import ServerPageHeader from '@/components/servers/common/ServerPageHeader'
import ServerContentBlock from '@/components/servers/ServerContentBlock'
import { useEffect } from 'react'
import { NavLink, Outlet, useLocation, useNavigate, useParams } from 'react-router-dom'

const tabs = (id?: string) => [
    { path: `/servers/${id}/settings/general`, name: 'Main settings' },
    { path: `/servers/${id}/settings/network`, name: 'IP address' },
    { path: `/servers/${id}/settings/security`, name: 'SSH keys' },
]

const ServerSettingsContainer = () => {
    const { id } = useParams()
    const location = useLocation()
    const navigate = useNavigate()

    useEffect(() => {
        if (location.pathname.endsWith('/settings')) {
            navigate(`/servers/${id}/settings/general`, { replace: true })
        }
    }, [location.pathname, navigate, id])

    return (
        <ServerContentBlock title='Settings'>
            <ServerPageHeader title='Settings' />

            <div className='mb-5 flex flex-wrap gap-2'>
                {tabs(id).map(tab => (
                    <NavLink
                        key={tab.path}
                        to={tab.path}
                        className={({ isActive }) =>
                            `rounded-full px-3 py-1.5 text-sm font-medium transition-colors ${
                                isActive
                                    ? 'bg-indigo-600/30 text-white'
                                    : 'border border-white/15 text-white/60 hover:text-white'
                            }`
                        }
                    >
                        {tab.name}
                    </NavLink>
                ))}
            </div>

            <Outlet />
        </ServerContentBlock>
    )
}

export default ServerSettingsContainer
