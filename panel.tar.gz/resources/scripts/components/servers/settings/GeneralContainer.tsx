import renameServer from '@/api/server/settings/renameServer'
import updateAuthSettings from '@/api/server/settings/updateAuthSettings'
import {
    cleanupLogs,
    resetFirewallConfiguration,
    resetSshConfiguration,
} from '@/api/server/settings/systemActions'
import { httpErrorToHuman } from '@/api/http'
import { ServerContext } from '@/state/server'
import useNotify from '@/util/useNotify'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { EyeIcon, EyeSlashIcon } from '@heroicons/react/24/outline'
import SensitiveValue from '@/components/elements/SensitiveValue'

const randomPassword = (length = 14) => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%*?'
    let output = ''
    for (let i = 0; i < length; i++) {
        output += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    return output
}

const Row = ({
    title,
    description,
    button,
    onClick,
    busy,
}: {
    title: string
    description: string
    button: string
    onClick: () => void
    busy?: boolean
}) => (
    <div className='flex flex-col gap-3 border-t border-white/10 py-4 md:flex-row md:items-center md:justify-between'>
        <div>
            <p className='text-base font-medium text-white'>{title}</p>
            <p className='mt-1 text-sm text-white/60'>{description}</p>
        </div>
        <button
            type='button'
            onClick={onClick}
            disabled={busy}
            className='h-9 rounded-lg border border-white/20 bg-white/5 px-4 text-sm font-semibold text-white hover:bg-white/10 disabled:cursor-not-allowed disabled:opacity-60'
        >
            {busy ? 'Working...' : button}
        </button>
    </div>
)

const GeneralContainer = () => {
    const server = ServerContext.useStoreState(state => state.server.data!)
    const setServer = ServerContext.useStoreActions(actions => actions.server.setServer)
    const notify = useNotify()
    const navigate = useNavigate()

    const [password, setPassword] = useState('')
    const [showPassword, setShowPassword] = useState(false)
    const [hostname, setHostname] = useState(server.hostname)
    const [updatingPassword, setUpdatingPassword] = useState(false)
    const [updatingHostname, setUpdatingHostname] = useState(false)
    const [resetFirewallBusy, setResetFirewallBusy] = useState(false)
    const [resetSshBusy, setResetSshBusy] = useState(false)
    const [cleanupBusy, setCleanupBusy] = useState(false)

    const updatePassword = async () => {
        if (!password || password.length < 8) {
            notify({ color: 'red', message: 'Enter a password with at least 8 characters.' })
            return
        }

        setUpdatingPassword(true)
        try {
            await updateAuthSettings(server.uuid, { type: 'password', password })
            notify({ color: 'green', message: 'Root password updated successfully.' })
            setPassword('')
        } catch {
            notify({ color: 'red', message: 'Failed to update root password.' })
        } finally {
            setUpdatingPassword(false)
        }
    }

    const updateHostname = async () => {
        if (!hostname.trim()) {
            notify({ color: 'red', message: 'Hostname cannot be empty.' })
            return
        }

        setUpdatingHostname(true)
        try {
            await renameServer(server.uuid, {
                name: server.name,
                hostname: hostname.trim(),
            })
            setServer({ ...server, hostname: hostname.trim() })
            notify({ color: 'green', message: 'Hostname updated.' })
        } catch {
            notify({ color: 'red', message: 'Failed to update hostname.' })
        } finally {
            setUpdatingHostname(false)
        }
    }

    const onResetFirewall = async () => {
        try {
            setResetFirewallBusy(true)
            await resetFirewallConfiguration(server.uuid)
            notify({ color: 'green', message: 'Firewall configuration reset queued.' })
        } catch (error) {
            notify({ color: 'red', message: httpErrorToHuman(error) })
        } finally {
            setResetFirewallBusy(false)
        }
    }

    const onResetSsh = async () => {
        try {
            setResetSshBusy(true)
            await resetSshConfiguration(server.uuid)
            notify({ color: 'green', message: 'SSH configuration reset queued.' })
        } catch (error) {
            notify({ color: 'red', message: httpErrorToHuman(error) })
        } finally {
            setResetSshBusy(false)
        }
    }

    const onCleanupLogs = async () => {
        try {
            setCleanupBusy(true)
            await cleanupLogs(server.uuid)
            notify({ color: 'green', message: 'Log cleanup completed.' })
        } catch (error) {
            notify({ color: 'red', message: httpErrorToHuman(error) })
        } finally {
            setCleanupBusy(false)
        }
    }

    return (
        <div className='space-y-4'>
            <section className='rounded-2xl border border-white/10 bg-[#1a1441]'>
                <div className='border-b border-white/10 px-5 py-4'>
                    <h2 className='text-2xl font-semibold text-white'>Change Root Password</h2>
                    <p className='mt-1 text-sm text-white/60'>
                        Set a secure root password for your VPS login.
                    </p>
                </div>

                <div className='flex flex-col gap-3 p-5 lg:flex-row lg:items-center'>
                    <div className='min-w-0 flex-1'>
                        <div className='relative'>
                            <input
                                type={showPassword ? 'text' : 'password'}
                                value={password}
                                onChange={event => setPassword(event.target.value)}
                                placeholder='Enter your password'
                                className='w-full rounded-lg border border-white/15 bg-[#111a31] px-3 py-2 pr-11 text-sm text-white placeholder:text-white/35 outline-none focus:border-indigo-400'
                            />
                            <button
                                type='button'
                                onClick={() => setShowPassword(current => !current)}
                                className='absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1 text-white/70 hover:bg-white/10 hover:text-white'
                                aria-label={showPassword ? 'Hide password' : 'Show password'}
                            >
                                {showPassword ? (
                                    <EyeSlashIcon className='h-4 w-4' />
                                ) : (
                                    <EyeIcon className='h-4 w-4' />
                                )}
                            </button>
                        </div>
                    </div>
                    <div className='flex flex-col gap-3 sm:flex-row lg:shrink-0'>
                        <button
                            type='button'
                            onClick={() => setPassword(randomPassword())}
                            className='h-10 whitespace-nowrap rounded-lg border border-white/20 bg-white/5 px-4 text-sm font-semibold text-white hover:bg-white/10'
                        >
                            Generate
                        </button>
                        <button
                            type='button'
                            onClick={updatePassword}
                            disabled={updatingPassword}
                            className='h-10 whitespace-nowrap rounded-lg bg-indigo-600 px-5 text-sm font-semibold text-white hover:bg-indigo-500 disabled:cursor-not-allowed disabled:opacity-60'
                        >
                            {updatingPassword ? 'Updating...' : 'Update password'}
                        </button>
                    </div>
                </div>
            </section>

            <section className='rounded-2xl border border-white/10 bg-[#1a1441] p-5'>
                <h3 className='text-2xl font-semibold text-white'>VPS Configurations</h3>

                <Row
                    title='Reset firewall configuration'
                    description='Reset firewall settings if your IP gets blocked.'
                    button='Reset'
                    onClick={onResetFirewall}
                    busy={resetFirewallBusy}
                />

                <Row
                    title='Reset SSH configuration'
                    description='Reset SSH settings to default secure values.'
                    button='Reset'
                    onClick={onResetSsh}
                    busy={resetSshBusy}
                />

                <div className='flex flex-col gap-3 border-t border-white/10 py-4 sm:flex-row sm:items-end sm:justify-between'>
                    <div className='min-w-0 flex-1'>
                        <p className='text-base font-medium text-white'>Hostname</p>
                        <p className='mt-1 text-sm text-white/60'>
                            Current hostname is <SensitiveValue>{server.hostname}</SensitiveValue>
                        </p>
                        <input
                            type='text'
                            value={hostname}
                            onChange={event => setHostname(event.target.value)}
                            className='mt-3 w-full rounded-lg border border-white/15 bg-[#111a31] px-3 py-2 text-sm text-white placeholder:text-white/35 outline-none focus:border-indigo-400 sm:max-w-lg'
                        />
                    </div>
                    <button
                        type='button'
                        onClick={updateHostname}
                        disabled={updatingHostname}
                        className='h-9 self-start whitespace-nowrap rounded-lg border border-white/20 bg-white/5 px-4 text-sm font-semibold text-white hover:bg-white/10 disabled:cursor-not-allowed disabled:opacity-60 sm:self-end'
                    >
                        {updatingHostname ? 'Changing...' : 'Change'}
                    </button>
                </div>

                <Row
                    title='Delete unnecessary logs'
                    description='Clean old logs to free disk space without affecting websites.'
                    button='Delete'
                    onClick={onCleanupLogs}
                    busy={cleanupBusy}
                />

                <Row
                    title='DNS Resolvers'
                    description='Manage custom DNS resolvers for your VPS network.'
                    button='Change'
                    onClick={() => navigate(`/servers/${server.id}/settings/network`)}
                />
            </section>

        </div>
    )
}

export default GeneralContainer
