import { ServerContext } from '@/state/server'
import { bytesToString } from '@/util/helpers'

const DetailCard = ({
    label,
    value,
    helper,
}: {
    label: string
    value: string
    helper?: string
}) => (
    <div className='rounded-xl border border-slate-700/50 bg-slate-900/70 p-5'>
        <p className='text-xs font-semibold uppercase tracking-[0.2em] text-slate-400'>
            {label}
        </p>
        <p className='mt-2 text-2xl font-bold text-white'>{value}</p>
        {helper ? <p className='mt-2 text-sm text-slate-400'>{helper}</p> : null}
    </div>
)

const HardwareContainer = () => {
    const server = ServerContext.useStoreState(state => state.server.data!)
    const ipv4 = server.limits.addresses.ipv4
    const ipv6 = server.limits.addresses.ipv6

    return (
        <div className='mx-auto w-full max-w-5xl space-y-6'>
            <div className='rounded-2xl border border-slate-700/50 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-6 shadow-2xl'>
                <div>
                    <p className='text-xs font-bold uppercase tracking-[0.25em] text-blue-300'>
                        Hardware
                    </p>
                    <h2 className='mt-2 text-2xl font-bold text-white'>
                        VPS Allocation
                    </h2>
                    <p className='mt-2 max-w-2xl text-sm leading-6 text-slate-400'>
                        Hardware limits are managed by your selected plan. Upgrade
                        from billing if you need more CPU, memory, disk, bandwidth,
                        or address capacity.
                    </p>
                </div>

                <div className='mt-6 grid gap-4 md:grid-cols-2 xl:grid-cols-3'>
                    <DetailCard
                        label='CPU'
                        value={`${server.limits.cpu} vCPU`}
                        helper={`Limit ${server.limits.cpuLimit || 0}% · ${server.limits.cpuSockets || 1} socket(s)`}
                    />
                    <DetailCard
                        label='Memory'
                        value={bytesToString(server.limits.memory)}
                        helper={server.limits.swap > 0 ? `Swap ${bytesToString(server.limits.swap)}` : 'No swap allocation'}
                    />
                    <DetailCard
                        label='Disk'
                        value={bytesToString(server.limits.disk)}
                        helper={`Backups ${server.limits.backups ?? 'unlimited'} · Snapshots ${server.limits.snapshots ?? 'unlimited'}`}
                    />
                    <DetailCard
                        label='Bandwidth'
                        value={server.limits.bandwidth ? bytesToString(server.limits.bandwidth) : 'Unlimited'}
                        helper='Monthly traffic allocation managed by your plan'
                    />
                    <DetailCard
                        label='Addresses'
                        value={`${ipv4.length} IPv4 / ${ipv6.length} IPv6`}
                        helper={server.limits.macAddress ? `MAC ${server.limits.macAddress}` : 'Primary MAC managed by node'}
                    />
                    <DetailCard
                        label='Node'
                        value={server.node?.name || `Node #${server.nodeId}`}
                        helper={server.node?.locationName || server.node?.cluster || 'Location managed by admin'}
                    />
                </div>
            </div>
        </div>
    )
}

export default HardwareContainer
