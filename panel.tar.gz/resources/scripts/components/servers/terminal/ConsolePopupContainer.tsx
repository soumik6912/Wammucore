import createConsoleSession, { ConsoleType } from '@/api/server/createConsoleSession'
import { httpErrorToHuman } from '@/api/http'
import { Loader } from '@mantine/core'
import { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'

const ConsolePopupContainer = () => {
    const [params] = useSearchParams()
    const [message, setMessage] = useState('Initializing terminal session...')
    const uuid = params.get('uuid') || ''
    const type = ((params.get('type') as ConsoleType) || 'novnc') as ConsoleType

    useEffect(() => {
        // Strip query params from popup URL as soon as possible.
        window.history.replaceState({}, document.title, window.location.pathname)
        document.title = 'Secure Terminal'
        window.name = ''

        if (!uuid) {
            setMessage('Missing server identifier.')
            return
        }

        const messages = ['Checking remote health...', 'Generating token...', 'Connecting...']
        messages.forEach((text, idx) => {
            window.setTimeout(() => setMessage(text), (idx + 1) * 700)
        })

        const run = async () => {
            try {
                const creds = await createConsoleSession(uuid, type)
                if (!('token' in creds)) {
                    throw new Error('Secure terminal gateway is not configured for this node.')
                }

                window.location.replace(
                    `${creds.isTlsEnabled ? 'https' : 'http'}://${creds.fqdn}:${creds.port}/?type=${encodeURIComponent(type)}&token=${encodeURIComponent(creds.token)}`
                )
            } catch (error) {
                setMessage(httpErrorToHuman(error))
            }
        }

        void run()
    }, [uuid, type])

    return (
        <div className='min-h-screen bg-[radial-gradient(1000px_600px_at_15%_0%,#1d0a53_0%,#0c0330_45%,#08021f_100%)] text-white grid place-items-center'>
            <div className='flex flex-col items-center gap-3'>
                <h1 className='text-lg font-semibold'>Opening Terminal</h1>
                <p className='text-sm text-white/70'>{message}</p>
                <Loader size='lg' />
            </div>
        </div>
    )
}

export default ConsolePopupContainer
