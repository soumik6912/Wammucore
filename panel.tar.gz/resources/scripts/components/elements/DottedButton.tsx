import { EllipsisVerticalIcon } from '@heroicons/react/24/outline'
import { ComponentProps, forwardRef } from 'react'

const DottedButton = forwardRef<
    HTMLButtonElement,
    Omit<ComponentProps<'button'>, 'children'>
>(({ className, ...props }, ref) => {
    return (
        <button
            ref={ref}
            type='button'
            className={`inline-flex h-9 w-9 items-center justify-center rounded-xl border border-[var(--border-soft)] bg-[var(--surface-soft)] text-[var(--text-primary)] shadow-[0_10px_24px_rgba(0,0,0,0.24)] transition hover:-translate-y-0.5 hover:bg-[var(--surface-hover)] hover:text-white ${className ?? ''}`}
            {...props}
        >
            <EllipsisVerticalIcon className='h-4 w-4 min-w-[1rem]' />
        </button>
    )
})

export default DottedButton
