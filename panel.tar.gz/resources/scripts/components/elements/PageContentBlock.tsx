import { useStoreState } from '@/state'
import { ReactNode, useEffect, useRef } from 'react'
import { CSSTransition } from 'react-transition-group'

import ContentContainer from '@/components/elements/ContentContainer'
import FlashMessageRender from '@/components/elements/FlashMessageRenderer'

export interface PageContentBlockProps {
    title?: string
    className?: string
    showFlashKey?: string
    containerSize?: 'default' | 'wide'
    children?: ReactNode
}

const PageContentBlock = ({
    title,
    showFlashKey,
    className,
    containerSize = 'default',
    children,
}: PageContentBlockProps) => {
    const panelName = useStoreState(state => state.settings.data?.panelName || 'WammuCore')
    const footerText = useStoreState(state => state.settings.data?.footerText || 'WammuCore')
    const footerUrl = useStoreState(state => state.settings.data?.footerUrl || 'https://wammuhost.com')
    const ref = useRef(null)

    useEffect(() => {
        if (title) {
            document.title = title
        }
    }, [title])

    return (
        <CSSTransition nodeRef={ref} timeout={150} classNames='fade' appear in>
            <div ref={ref}>
                <ContentContainer
                    containerSize={containerSize}
                    className={`${className} min-h-[75vh]`}
                    padding
                >
                    {showFlashKey && (
                        <FlashMessageRender
                            byKey={showFlashKey}
                            className='mb-4'
                        />
                    )}
                    {children}
                </ContentContainer>
                <ContentContainer containerSize={containerSize}>
                    <div className='flex justify-between pb-8'>
                        <p className='text-xs text-[var(--text-muted)]'>
                            &copy; 2023 - {new Date().getFullYear()}{' '}
                            <a
                                className='transition hover:text-[var(--text-primary)]'
                                href={footerUrl || 'https://wammuhost.com'}
                                target='_blank'
                            >
                                {footerText || panelName}
                            </a>
                        </p>

                    </div>
                </ContentContainer>
            </div>
        </CSSTransition>
    )
}

export default PageContentBlock


