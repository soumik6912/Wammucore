import styled from '@emotion/styled'
import { ComponentProps, ElementType } from 'react'
import tw from 'twin.macro'

import LoadingDots from '@/components/elements/LoadingDots'

export type ButtonSize = 'sm'
export type ButtonShape = 'square'
export type ButtonVariant = 'outline' | 'filled'
export type ButtonColor = 'success' | 'danger' | 'accent'

export interface ButtonProps extends ComponentProps<'button'> {
    variant?: ButtonVariant
    color?: ButtonColor
    size?: ButtonSize
    loading?: boolean
    shape?: ButtonShape
    as?: ElementType<any>
}

const getSizes = ({ size, shape }: ButtonProps) => {
    if (shape === 'square') {
        switch (size) {
            case 'sm':
                return tw`w-8 h-8 min-w-[5rem]`
            default:
                return tw`w-9 h-9`
        }
    }

    switch (size) {
        case 'sm':
            return tw`px-3 h-8 min-w-[5rem]`
        default:
            return tw`px-5 h-9`
    }
}

const StyledButton = styled.button<ButtonProps>`
    ${tw`border text-sm rounded font-semibold inline-flex items-center justify-center whitespace-nowrap disabled:cursor-not-allowed`}

    ${props => getSizes(props)}

    transition:
        transform 160ms ease,
        filter 160ms ease,
        background 160ms ease,
        border-color 160ms ease,
        box-shadow 160ms ease,
        color 160ms ease;
    border-radius: 0.75rem;
    letter-spacing: 0.01em;
    color: var(--text-primary, #f8fbff);
    background: var(--button-glass);
    border-color: var(--border-soft);
    box-shadow:
        0 10px 26px rgba(0,0,0,0.22),
        inset 0 1px 0 rgba(255,255,255,0.08);

    ${({ variant = 'outline', color = 'accent' }) => {
        if (variant === 'filled') {
            if (color === 'success') {
                return `
                    color: #ffffff;
                    background: linear-gradient(135deg, #16a34a, #22c55e);
                    border-color: rgba(74, 222, 128, 0.68);
                    box-shadow: 0 14px 34px rgba(22, 163, 74, 0.22);
                `
            }

            if (color === 'danger') {
                return `
                    color: #ffffff;
                    background: linear-gradient(135deg, #dc2626, #fb7185);
                    border-color: rgba(251, 113, 133, 0.68);
                    box-shadow: 0 14px 34px rgba(220, 38, 38, 0.22);
                `
            }

            return `
                color: var(--tenant-action-text, #ffffff);
                background: var(--button-gradient);
                border-color: color-mix(in srgb, var(--brand-accent-2) 56%, rgba(255,255,255,0.20));
                box-shadow:
                    0 16px 40px color-mix(in srgb, var(--brand-accent) 24%, transparent),
                    inset 0 1px 0 rgba(255,255,255,0.16);
            `
        }

        if (color === 'success') {
            return `
                color: #bbf7d0;
                border-color: rgba(74, 222, 128, 0.42);
                background: linear-gradient(180deg, rgba(22, 163, 74, 0.16), rgba(22, 101, 52, 0.10));
            `
        }

        if (color === 'danger') {
            return `
                color: #fecdd3;
                border-color: rgba(251, 113, 133, 0.42);
                background: linear-gradient(180deg, rgba(220, 38, 38, 0.16), rgba(127, 29, 29, 0.10));
            `
        }

        return ''
    }}

    &:hover:not(:disabled) {
        transform: translateY(-1px);
        filter: brightness(1.07);
        border-color: color-mix(in srgb, var(--brand-accent-2) 50%, rgba(255,255,255,0.22));
        box-shadow:
            0 16px 38px rgba(0,0,0,0.28),
            0 0 24px color-mix(in srgb, var(--brand-accent) 18%, transparent),
            inset 0 1px 0 rgba(255,255,255,0.1);
    }

    &:active:not(:disabled) {
        transform: translateY(0);
        filter: brightness(0.98);
    }

    &:disabled {
        color: rgba(226,232,255,0.42) !important;
        background: linear-gradient(180deg, rgba(255,255,255,0.05), rgba(255,255,255,0.025)) !important;
        border-color: rgba(226,232,255,0.12) !important;
        box-shadow: none !important;
        opacity: 0.76;
    }
`

const Button = ({ loading, disabled, ...props }: ButtonProps) => {
    return (
        <StyledButton disabled={loading || disabled} {...props}>
            {loading ? (
                <div className='w-full h-full grid place-items-center'>
                    <LoadingDots size={5} />
                </div>
            ) : null}
            <span className={loading ? 'invisible' : undefined}>
                {props.children}
            </span>
        </StyledButton>
    )
}

export default Button
