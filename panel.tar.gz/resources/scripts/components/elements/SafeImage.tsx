import { ImgHTMLAttributes, useEffect, useMemo, useState } from 'react'

const DEFAULT_FALLBACK_IMAGE = '/favicon.svg'

export const normalizeImageUrl = (value?: string | null): string | null => {
    const raw = (value || '').trim()

    if (!raw || /^(javascript|vbscript):/i.test(raw)) {
        return null
    }

    if (/^data:/i.test(raw)) {
        return /^data:image\//i.test(raw) ? raw : null
    }

    try {
        if (raw.startsWith('//')) {
            return `${window.location.protocol}${raw}`
        }

        const url = new URL(raw, window.location.origin)
        if (!['http:', 'https:'].includes(url.protocol)) {
            return null
        }

        return url.toString()
    } catch {
        return raw.startsWith('/') ? raw : null
    }
}

export const normalizeLocalImageUrl = (value?: string | null): string | null => {
    const safeUrl = normalizeImageUrl(value)

    if (!safeUrl) {
        return null
    }

    if (/^data:image\//i.test(safeUrl)) {
        return safeUrl
    }

    try {
        const url = new URL(safeUrl, window.location.origin)

        return url.origin === window.location.origin ? url.toString() : null
    } catch {
        return safeUrl.startsWith('/') ? safeUrl : null
    }
}

export const useResolvedImageUrl = (value?: string | null): string | null => {
    const safeUrl = useMemo(() => normalizeImageUrl(value), [value])
    const [resolvedUrl, setResolvedUrl] = useState<string | null>(null)

    useEffect(() => {
        let active = true
        setResolvedUrl(null)

        if (!safeUrl) {
            return () => {
                active = false
            }
        }

        const image = new Image()
        image.referrerPolicy = 'no-referrer'
        image.onload = () => {
            if (active) {
                setResolvedUrl(safeUrl)
            }
        }
        image.onerror = () => {
            if (active) {
                setResolvedUrl(null)
            }
        }
        image.src = safeUrl

        return () => {
            active = false
            image.onload = null
            image.onerror = null
        }
    }, [safeUrl])

    return resolvedUrl
}

interface Props extends Omit<ImgHTMLAttributes<HTMLImageElement>, 'src'> {
    src?: string | null
    fallbackSrc?: string | null
    fallbackText?: string
    fallbackClassName?: string
}

const fallbackInitial = (value?: string) => {
    const initial = (value || 'W').trim().charAt(0)

    return (initial || 'W').toUpperCase()
}

const SafeImage = ({
    src,
    fallbackSrc = DEFAULT_FALLBACK_IMAGE,
    fallbackText = 'WammuHost',
    fallbackClassName,
    alt = '',
    className,
    onError,
    decoding = 'async',
    loading = 'lazy',
    ...props
}: Props) => {
    const primaryUrl = useMemo(() => normalizeImageUrl(src), [src])
    const fallbackUrl = useMemo(() => normalizeImageUrl(fallbackSrc), [fallbackSrc])
    const [primaryFailed, setPrimaryFailed] = useState(false)
    const [fallbackFailed, setFallbackFailed] = useState(false)

    useEffect(() => {
        setPrimaryFailed(false)
        setFallbackFailed(false)
    }, [primaryUrl, fallbackUrl])

    const activeUrl = !primaryFailed && primaryUrl ? primaryUrl : !fallbackFailed && fallbackUrl ? fallbackUrl : null

    if (!activeUrl) {
        return (
            <span
                className={[
                    'inline-grid place-items-center rounded-xl border border-white/10 bg-white/10 font-black text-white shadow-inner',
                    fallbackClassName || className || 'h-10 w-10',
                ].join(' ')}
                aria-label={alt || fallbackText}
                role='img'
            >
                {fallbackInitial(fallbackText)}
            </span>
        )
    }

    return (
        <img
            {...props}
            src={activeUrl}
            alt={alt}
            className={className}
            decoding={decoding}
            loading={loading}
            referrerPolicy='no-referrer'
            onError={event => {
                if (activeUrl === primaryUrl) {
                    setPrimaryFailed(true)
                } else {
                    setFallbackFailed(true)
                }

                onError?.(event)
            }}
        />
    )
}

export default SafeImage
