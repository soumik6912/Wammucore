import { ComponentProps } from 'react'

const Logo = (props: ComponentProps<'img'>) => (
    <img
        alt='WammuHost'
        src='https://i.postimg.cc/wjVWzbcZ/hl.png'
        {...props}
    />
)

export default Logo
