import styled from '@emotion/styled'
import { Menu as MantineMenu, MenuItemProps, MenuProps } from '@mantine/core'
import { FC, MouseEventHandler } from 'react'
import tw from 'twin.macro'

interface Menu extends FC<MenuProps> {
    Dropdown: typeof StyledMenuDropdown
    Target: typeof MantineMenu.Target
    Divider: typeof StyledDivider
    Item: typeof StyledMenuItem
}

const StyledMenuDropdown = styled(MantineMenu.Dropdown)`
    &.mantine-Menu-dropdown {
        ${tw`p-2 rounded-2xl border border-white/10 text-sm`}
        z-index: 5000;
        min-width: min(17rem, calc(100vw - 1rem));
        max-width: calc(100vw - 1rem);
        max-height: min(24rem, calc(100dvh - 1rem));
        overflow-y: auto;
        overscroll-behavior: contain;
        box-shadow: 0 20px 45px rgba(0, 0, 0, 0.42);
        background: linear-gradient(
            180deg,
            rgba(10, 14, 30, 0.9) 0%,
            rgba(8, 10, 22, 0.84) 100%
        ) !important;
        backdrop-filter: blur(18px) saturate(145%);
        -webkit-backdrop-filter: blur(18px) saturate(145%);
        background-image: none !important;
    }
`

const StyledMenuItem = styled(MantineMenu.Item)<
    MenuItemProps & {
        onClick?: MouseEventHandler<HTMLButtonElement>
        disabled?: boolean
    }
>`
    &.mantine-Menu-item {
        ${tw`w-full rounded-xl bg-transparent px-3 py-3 text-left text-sm font-medium text-white disabled:cursor-not-allowed disabled:text-white/40`}
        min-height: 2.65rem;
        color: #ffffff !important;
        font-weight: 600;
        line-height: 1.25rem;
        transition:
            background-color 120ms ease,
            color 120ms ease,
            transform 120ms ease;

        ${({ color }) =>
            color === 'red'
                ? tw`text-rose-300 hover:bg-rose-500/20 active:bg-rose-500/20`
                : tw`text-white hover:bg-white/10 active:bg-white/10`}
    }

    .mantine-Menu-itemLabel {
        color: inherit !important;
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    &.mantine-Menu-item[data-hovered='true'] {
        ${({ color }) =>
            color === 'red'
                ? tw`bg-rose-500/20 text-rose-300`
                : tw`bg-white/10 text-white`}
    }
`

const StyledDivider = styled(MantineMenu.Divider)`
    ${tw`my-[6px] mx-auto w-[93%] bg-white/10`}
`

const Menu: Menu = props => <MantineMenu {...props} />

Menu.Dropdown = StyledMenuDropdown

Menu.Target = MantineMenu.Target

Menu.Divider = StyledDivider

Menu.Item = StyledMenuItem

export default Menu
