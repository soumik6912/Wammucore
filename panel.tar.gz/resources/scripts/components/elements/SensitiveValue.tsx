import { useStoreState } from '@/state'
import { classNames } from '@/util/helpers'
import { KeyboardEvent, PointerEvent, ReactNode, useEffect, useState } from 'react'

interface Props {
    children: ReactNode
    className?: string
}

const SensitiveValue = ({ children, className }: Props) => {
    const privacyMode = useStoreState(state => state.settings.privacyMode)
    const [hoverRevealed, setHoverRevealed] = useState(false)
    const [tapRevealed, setTapRevealed] = useState(false)
    const revealed = hoverRevealed || tapRevealed

    useEffect(() => {
        if (!privacyMode) {
            setHoverRevealed(false)
            setTapRevealed(false)
        }
    }, [privacyMode])

    const toggleReveal = () => {
        if (!privacyMode) {
            return
        }

        setTapRevealed(previous => !previous)
    }

    const onKeyDown = (event: KeyboardEvent<HTMLSpanElement>) => {
        if (!privacyMode) {
            return
        }

        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault()
            toggleReveal()
        }
    }

    const onPointerEnter = (event: PointerEvent<HTMLSpanElement>) => {
        if (!privacyMode || event.pointerType !== 'mouse') {
            return
        }

        setHoverRevealed(true)
    }

    const onPointerLeave = (event: PointerEvent<HTMLSpanElement>) => {
        if (!privacyMode || event.pointerType !== 'mouse') {
            return
        }

        setHoverRevealed(false)
    }

    const onPointerDown = (event: PointerEvent<HTMLSpanElement>) => {
        if (!privacyMode) {
            return
        }

        if (event.pointerType === 'touch' || event.pointerType === 'pen') {
            event.preventDefault()
            toggleReveal()
        }
    }

    return (
        <span
            className={classNames(
                className,
                privacyMode ? 'privacy-sensitive' : undefined,
                privacyMode && !revealed ? 'privacy-blur' : undefined,
                privacyMode && revealed ? 'privacy-reveal' : undefined,
            )}
            title={
                privacyMode
                    ? 'Hover to reveal (desktop) or tap to toggle (mobile)'
                    : undefined
            }
            tabIndex={privacyMode ? 0 : undefined}
            role={privacyMode ? 'button' : undefined}
            aria-label={
                privacyMode
                    ? 'Sensitive value. Hover to reveal on desktop or tap to toggle on mobile.'
                    : undefined
            }
            onPointerEnter={onPointerEnter}
            onPointerLeave={onPointerLeave}
            onPointerDown={onPointerDown}
            onFocus={() => privacyMode && setHoverRevealed(true)}
            onBlur={() => privacyMode && setHoverRevealed(false)}
            onKeyDown={onKeyDown}
        >
            {children}
        </span>
    )
}

export default SensitiveValue
