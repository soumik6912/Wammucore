import { bindUrlParams } from '@/util/helpers';
import { Burger, LoadingOverlay, Avatar } from '@mantine/core'; // Added Avatar
import React, { createContext, useContext, useEffect, useState } from 'react';
import { Link, useMatches, useLocation, useNavigate } from 'react-router-dom';
import ContentContainer from '@/components/elements/ContentContainer';
import logoutRequest from '@/api/auth/logout';
import setTenantContext from '@/api/admin/tenancy/setTenantContext';
import { httpErrorToHuman } from '@/api/http';
import SafeImage from '@/components/elements/SafeImage';
// import UserDropdown from '@/components/elements/navigation/UserDropdown'; // Removed UserDropdown

// Additional imports needed from UserDropdown
import { useStoreState } from '@/state';
import { getInitials } from '@/util/helpers';
import { normalizeExternalUrl } from '@/util/storefront';
import { useTranslation } from 'react-i18next';
// End additional imports
import { getAdminPrimaryRoutes } from '@/routers/adminPrimaryRoutes';
import { getResellerPrimaryRoutes } from '@/routers/resellerPrimaryRoutes';
import useTenantContextSWR from '@/api/admin/tenancy/useTenantContextSWR';

// Heroicons
import {
  HomeIcon,
  Cog6ToothIcon,
  ArchiveBoxArrowDownIcon,
  ServerStackIcon,
  MapPinIcon,
  UserGroupIcon,
  KeyIcon,
  Squares2X2Icon,
  CircleStackIcon,
  ClipboardDocumentListIcon,
  ArrowRightOnRectangleIcon,
  CreditCardIcon,
  CommandLineIcon,
  ComputerDesktopIcon,
  FireIcon,
  ShieldCheckIcon,
  GlobeAltIcon,
  BookOpenIcon,
  ChartBarIcon,
  ArrowUturnLeftIcon,
  BuildingStorefrontIcon,
  EnvelopeIcon,
  // UserIcon, // Not needed
} from '@heroicons/react/24/outline';

export interface RouteDefinition {
  name: string;
  path: string;
  end?: boolean;
  group?: string;
}

interface NavigationBarContextInterface {
  routes: RouteDefinition[];
  setRoutes: (routes: RouteDefinition[]) => void;
  breadcrumb?: string | null;
  setBreadcrumb: (breadcrumb: string | null | undefined) => void;
}

type RouteGroup = {
  title: string;
  routes: RouteDefinition[];
};

type AdminReturnSession = {
  url: string;
  expiresAt: string | null;
};

const ADMIN_RETURN_STORAGE_KEY = 'wammucore:view-as-admin-return';

export const NavigationBarContext = createContext<NavigationBarContextInterface>({
  routes: [],
  setRoutes: () => {},
  breadcrumb: null,
  setBreadcrumb: () => {},
});

const SIDEBAR_W = 264;
const SIDEBAR_W_COLLAPSED = 72;
const MOBILE_BREAKPOINT = 640;

const NavigationBar: React.FC = () => {
  const { routes, breadcrumb } = useContext(NavigationBarContext);
  const [menuVisible, setMenuVisible] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [logoutConfirmationVisible, setLogoutConfirmationVisible] = useState(false);
  const [isAdminPanelSwitching, setIsAdminPanelSwitching] = useState(false);
  const [adminPanelSwitchError, setAdminPanelSwitchError] = useState<string | null>(null);
  const [adminReturnSession, setAdminReturnSession] = useState<AdminReturnSession | null>(null);
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();

  const isAdminArea =
    location.pathname === '/admin' || location.pathname.startsWith('/admin/');
  const matches = useMatches();
  const navigate = useNavigate();

  // Logic imported from UserDropdown
  const user = useStoreState(state => state.user.data);
  const safeUser = user ?? {
    name: 'Account',
    email: '',
    avatarUrl: null,
    rootAdmin: false,
    platformAdmin: false,
    resellerAdmin: false,
    resellerId: null,
    resellerOnboardingStatus: null,
    resellerOnboardingCurrentStep: null,
    resellerOnboardingPath: '/admin/reseller-panel/onboarding',
    resellerOnboardingCompleted: true,
    resellerCustomerPanelLocked: false,
    adminRoles: [],
    adminPermissions: [],
    createdAt: '',
    updatedAt: '',
  };
  const panelName = useStoreState(state => {
    const rawName = state.settings.data?.panelName?.trim() || 'WammuCore';
    return /wammucore/i.test(rawName) ? 'WammuCore' : rawName;
  });
  const panelLogoUrl = useStoreState(
    state => state.settings.data?.logoUrl || 'https://i.postimg.cc/wjVWzbcZ/hl.png'
  );
  const billingUrl = useStoreState(state => state.settings.data?.billingUrl || null);
  const tenantId = useStoreState(state => state.settings.data?.tenantId ?? null);
  const isTenantCustomerPanel = tenantId !== null;
  const resolvedBillingUrl = React.useMemo(
    () => normalizeExternalUrl(billingUrl),
    [billingUrl]
  );
  const tenantHostname = useStoreState(
    state => state.settings.data?.tenantHostname || null
  );
  const configuredPlatformAdminUrl = useStoreState(
    state => state.settings.data?.platformAdminUrl || null
  );
  const platformAdminBaseUrl = React.useMemo(() => {
    const normalized = normalizeExternalUrl(configuredPlatformAdminUrl);

    if (normalized) {
      return normalized.replace(/\/+$/, '');
    }

    const currentHost = window.location.hostname.toLowerCase();
    const isLocalLikeHost =
      currentHost === 'localhost' ||
      currentHost.endsWith('.local') ||
      /^\d{1,3}(?:\.\d{1,3}){3}$/.test(currentHost);

    return isLocalLikeHost ? window.location.origin : 'https://vps.wammuhost.com';
  }, [configuredPlatformAdminUrl]);
  const { t: tStrings } = useTranslation('strings');
  const { t: tAuth } = useTranslation('auth');
  const isAdminUser = Boolean(safeUser.rootAdmin || safeUser.platformAdmin || safeUser.resellerAdmin);
  const isRootAdmin = Boolean(safeUser.rootAdmin);
  const isResellerOnlyAdmin = Boolean(safeUser.resellerAdmin && !safeUser.rootAdmin);
  const adminReturnSessionIsExpired = React.useCallback((expiresAt: string | null): boolean => {
    if (!expiresAt) {
      return false;
    }

    const timestamp = Date.parse(expiresAt);

    return Number.isFinite(timestamp) && timestamp <= Date.now();
  }, []);
  const clearAdminReturnSession = React.useCallback(() => {
    window.sessionStorage.removeItem(ADMIN_RETURN_STORAGE_KEY);
    setAdminReturnSession(null);
  }, []);
  const adminReturnUrlIsValid = React.useCallback(
    (url: string): boolean => {
      try {
        const parsedUrl = new URL(url);
        const platformOrigin = new URL(platformAdminBaseUrl).origin;

        return (
          parsedUrl.origin === platformOrigin &&
          /^\/auth\/return-admin\/[A-Za-z0-9]{40,120}$/.test(parsedUrl.pathname)
        );
      } catch {
        return false;
      }
    },
    [platformAdminBaseUrl]
  );
  const returnToAdmin = React.useCallback(() => {
    if (!adminReturnSession?.url || !adminReturnUrlIsValid(adminReturnSession.url)) {
      clearAdminReturnSession();
      return;
    }

    const returnUrl = adminReturnSession.url;
    clearAdminReturnSession();
    window.location.assign(returnUrl);
  }, [adminReturnSession, adminReturnUrlIsValid, clearAdminReturnSession]);
  const resellerOwnerStatusLocked =
    safeUser.resellerId !== null &&
    safeUser.resellerOnboardingStatus !== 'completed';
  const resellerOwnerOnboardingLocked = Boolean(
    isResellerOnlyAdmin &&
      (
        safeUser.resellerCustomerPanelLocked ||
        !safeUser.resellerOnboardingCompleted ||
        resellerOwnerStatusLocked
      )
  );
  const { data: tenantContext, mutate: mutateTenantContext } = useTenantContextSWR(isAdminArea && isAdminUser);
  const isResellerPanelPath =
    location.pathname === '/admin/reseller-panel' ||
    location.pathname.startsWith('/admin/reseller-panel/');
  const activeResellerContext = tenantContext?.activeReseller || tenantContext?.hostReseller || null;
  const resellerOperationalLocked = Boolean(
    activeResellerContext &&
      (
        activeResellerContext.status !== 'active' ||
        activeResellerContext.verificationStatus !== 'approved' ||
        activeResellerContext.onboardingStatus !== 'completed'
      )
  );
  const shouldForceResellerNav = Boolean(
    isAdminArea && (isResellerPanelPath || isResellerOnlyAdmin || tenantContext?.mode === 'reseller')
  );
  const isResellerOnboardingPath = location.pathname.startsWith('/admin/reseller-panel/onboarding');
  const resellerNavOperationalLocked =
    resellerOwnerOnboardingLocked || resellerOperationalLocked || isResellerOnboardingPath;
  const isResellerAdminView =
    isAdminArea &&
    (isResellerOnlyAdmin || isResellerPanelPath || tenantContext?.mode === 'reseller');
  const shouldUseLockedResellerRoutes = Boolean(
    isAdminArea && isResellerAdminView && resellerNavOperationalLocked
  );
  const resellerFallbackRoutes = React.useMemo(
    () =>
      getResellerPrimaryRoutes({
        includeOnboarding:
          resellerNavOperationalLocked ||
          location.pathname.startsWith('/admin/reseller-panel/domain-guide'),
        operationalLocked: resellerNavOperationalLocked,
      }),
    [location.pathname, resellerNavOperationalLocked]
  );
  const isMasterAdminView = !isResellerAdminView;
  const isResellerScopedRootView = Boolean(
    isAdminArea && (safeUser.rootAdmin || safeUser.platformAdmin) && tenantContext?.mode === 'reseller'
  );
  const fallbackAdminRoutes = isResellerAdminView
    ? resellerFallbackRoutes
    : getAdminPrimaryRoutes(tStrings, isMasterAdminView, isRootAdmin);
  const resellerOnboardingPath =
    safeUser.resellerOnboardingPath || '/admin/reseller-panel/onboarding';
  const fallbackClientRoutes = resellerOwnerOnboardingLocked
    ? [
        {
          name: 'Onboarding',
          path: resellerOnboardingPath,
        },
      ]
    : [
        { name: tStrings('overview'), path: '/' },
        ...(!isTenantCustomerPanel
          ? [
              { name: 'VPS Plans', path: '/store' },
              { name: 'Buy Dedicated', path: '/dedicated' },
            ]
          : [{ name: 'VPS Plans', path: '/store' }]),
        { name: 'Account', path: '/account' },
      ];
  // End imported logic

  useEffect(() => {
    if (isAdminUser) {
      clearAdminReturnSession();
      return;
    }

    const params = new URLSearchParams(location.search);
    const url = params.get('admin_return_url')?.trim() || '';
    const expiresAt = params.get('admin_return_expires_at')?.trim() || null;

    if (url) {
      try {
        const nextSession = { url, expiresAt };

        if (
          adminReturnUrlIsValid(nextSession.url) &&
          !adminReturnSessionIsExpired(nextSession.expiresAt)
        ) {
          window.sessionStorage.setItem(
            ADMIN_RETURN_STORAGE_KEY,
            JSON.stringify(nextSession)
          );
          setAdminReturnSession(nextSession);
        }
      } catch {
        clearAdminReturnSession();
      }

      params.delete('admin_return_url');
      params.delete('admin_return_expires_at');
      const query = params.toString();
      window.history.replaceState(
        window.history.state,
        document.title,
        `${location.pathname}${query ? `?${query}` : ''}${location.hash}`
      );

      return;
    }

    try {
      const raw = window.sessionStorage.getItem(ADMIN_RETURN_STORAGE_KEY);
      if (!raw) {
        setAdminReturnSession(null);
        return;
      }

      const parsed = JSON.parse(raw) as Partial<AdminReturnSession>;
      const storedUrl = typeof parsed.url === 'string' ? parsed.url.trim() : '';
      const storedExpiresAt =
        typeof parsed.expiresAt === 'string' && parsed.expiresAt.trim() !== ''
          ? parsed.expiresAt.trim()
          : null;

      if (
        !storedUrl ||
        !adminReturnUrlIsValid(storedUrl) ||
        adminReturnSessionIsExpired(storedExpiresAt)
      ) {
        clearAdminReturnSession();
        return;
      }

      setAdminReturnSession({ url: storedUrl, expiresAt: storedExpiresAt });
    } catch {
      clearAdminReturnSession();
    }
  }, [
    adminReturnSessionIsExpired,
    adminReturnUrlIsValid,
    clearAdminReturnSession,
    isAdminUser,
    location.hash,
    location.pathname,
    location.search,
  ]);

  const showAdminReturnButton = Boolean(
    adminReturnSession?.url &&
      !isAdminUser &&
      !isAdminArea
  );

  const masterOnlyAdminPrefixes = [
    '/admin/locations',
    '/admin/nodes',
    '/admin/ipam',
    '/admin/diagnostics',
    '/admin/core',
    '/admin/horizon',
    '/admin/coterms',
    '/admin/tokens',
  ];

  const isMasterOnlyAdminRoute = (path: string): boolean => {
    return masterOnlyAdminPrefixes.some(
      prefix => path === prefix || path.startsWith(prefix + '/')
    );
  };

  useEffect(() => {
    let rafId: number | null = null;

    const applyPadding = () => {
      const w = window.innerWidth;
      document.body.style.paddingLeft =
        w < MOBILE_BREAKPOINT
          ? '0px'
          : `${collapsed ? SIDEBAR_W_COLLAPSED : SIDEBAR_W}px`;
    };

    const onResize = () => {
      if (rafId) {
        cancelAnimationFrame(rafId);
      }
      rafId = requestAnimationFrame(applyPadding);
    };

    applyPadding();
    window.addEventListener('resize', onResize, { passive: true });
    return () => {
      document.body.style.paddingLeft = '0px';
      window.removeEventListener('resize', onResize);
      if (rafId) {
        cancelAnimationFrame(rafId);
      }
    };
  }, [collapsed]);

  const requestLogout = () => {
    if (!isLoggingOut) {
      setLogoutConfirmationVisible(true);
    }
  };

  const logout = () => {
    setLogoutConfirmationVisible(false);
    setIsLoggingOut(true);
    logoutRequest().finally(() => {
      // @ts-expect-error
      window.location = '/';
    });
  };

  const resolveAdminBackPath = (pathname: string): string => {
    const segments = pathname.split('/').filter(Boolean);

    // Expected admin path starts with ["admin", ...]
    if (segments.length <= 1) {
      return '/admin';
    }

    if (segments.length === 2) {
      return '/admin';
    }

    if (segments[1] === 'reseller-panel') {
      if (segments[2] === 'r' && segments[3]) {
        return `/admin/reseller-panel/r/${segments[3]}`;
      }

      if (segments[2] === 'r') {
        return '/admin/reseller-panel';
      }

      if (segments[2] && !['onboarding', 'domain-guide'].includes(segments[2])) {
        return `/admin/reseller-panel/${segments[2]}`;
      }

      return '/admin/reseller-panel';
    }

    const section = segments[1];
    const id = segments[2];

    // Entity-level admin pages: go to entity root, not history back.
    if (section === 'nodes' || section === 'servers') {
      if (!id) {
        return `/admin/${section}`;
      }

      return segments.length > 3 ? `/admin/${section}/${id}` : `/admin/${section}`;
    }

    if (section === 'users') {
      if (!id) {
        return '/admin/users';
      }

      if (segments[3] === 'settings') {
        return '/admin/users';
      }

      if (segments[3] === 'servers') {
        return '/admin/users/' + id + '/settings';
      }

      return '/admin/users';
    }

    if (section === 'ipam') {
      if (!id) {
        return '/admin/ipam';
      }

      return `/admin/ipam/${id}`;
    }

    if (section === 'locations' || section === 'coterms' || section === 'tokens') {
      return '/admin';
    }

    return '/admin';
  };

  const goBackInAdmin = () => {
    if (!isAdminArea) {
      navigate(-1);
      return;
    }

    navigate(resolveAdminBackPath(location.pathname));
  };

  const adminBackPath = isAdminArea ? resolveAdminBackPath(location.pathname) : null;
  const showAdminBackButton =
    isAdminArea &&
    !resellerOwnerOnboardingLocked &&
    !!adminBackPath &&
    adminBackPath !== location.pathname;
  const resellerAdminRouteReference =
    tenantContext?.activeReseller?.uuid ||
    tenantContext?.hostReseller?.uuid ||
    tenantContext?.activeReseller?.slug ||
    tenantContext?.hostReseller?.slug ||
    null;
  const resellerAdminRoutePath = `/admin/reseller-panel${resellerAdminRouteReference ? `/r/${resellerAdminRouteReference}` : ''}`;

  const makeTo = (path: string) => {
    const params = matches.length > 0 ? matches[matches.length - 1].params : {};
    const attachResellerReference = (url: string): string => {
      if (!resellerAdminRouteReference) {
        return url;
      }

      const [pathname, query = ''] = url.split('?');
      if (pathname !== '/admin/reseller-panel') {
        return url;
      }

      return `${resellerAdminRoutePath}${query ? `?${query}` : ''}`;
    };

    try {
      return attachResellerReference(bindUrlParams(path, params));
    } catch {
      return attachResellerReference(path);
    }
  };

  const scopedRoutes = routes.filter((route) => {
    const isAdminRoute = route.path.startsWith('/admin');
    if (isAdminArea) {
      if (!isAdminRoute) {
        return false;
      }

      if (resellerOwnerOnboardingLocked) {
        return (
          route.path === resellerOnboardingPath ||
          route.path === '/admin/reseller-panel/onboarding' ||
          route.path.startsWith('/admin/reseller-panel/onboarding/')
        );
      }

      if (shouldUseLockedResellerRoutes) {
        return (
          route.path === '/admin/reseller-panel/onboarding' ||
          route.path.startsWith('/admin/reseller-panel/onboarding/')
        );
      }

      if (isResellerAdminView && !route.path.startsWith('/admin/reseller-panel')) {
        return false;
      }

      if (!isMasterAdminView && isMasterOnlyAdminRoute(route.path)) {
        return false;
      }

      return true;
    }

    if (resellerOwnerOnboardingLocked) {
      return route.path === resellerOnboardingPath;
    }

    return !isAdminRoute;
  });
  const pathSegments = location.pathname.split('/').filter(Boolean);
  const adminServerId = pathSegments[0] === 'admin' && pathSegments[1] === 'servers' ? pathSegments[2] : null;

  const serverDetailFallbackRoutes: RouteDefinition[] = adminServerId
    ? [
        {
          name: tStrings('overview'),
          path: `/admin/servers/${adminServerId}`,
          end: true,
        },
        {
          name: tStrings('setting_other'),
          path: `/admin/servers/${adminServerId}/settings`,
        },
      ]
    : [];

  const visibleRoutes: RouteDefinition[] =
    shouldUseLockedResellerRoutes
      ? resellerFallbackRoutes
      : serverDetailFallbackRoutes.length > 0
      ? serverDetailFallbackRoutes
      : scopedRoutes.length > 0
      ? scopedRoutes
      : shouldForceResellerNav
      ? resellerFallbackRoutes
      : isAdminArea
      ? fallbackAdminRoutes
      : routes.length > 0 && !resellerOwnerOnboardingLocked
      ? routes
      : fallbackClientRoutes;

  const isRouteMatch = (to: string, end?: boolean) => {
    if (to.includes('?')) {
      return `${location.pathname}${location.search}` === to;
    }

    if (end) {
      return location.pathname === to && location.search.length === 0;
    }

    return location.pathname === to || location.pathname.startsWith(to + '/');
  };

  const adminRouteGroups = React.useMemo<RouteGroup[]>(() => {
    if (!isAdminArea) {
      return [];
    }

    const primaryRoutes = visibleRoutes.filter(route => route.path.startsWith('/admin'));

    if (primaryRoutes.some(route => route.group)) {
      const grouped = new Map<string, RouteDefinition[]>();

      primaryRoutes.forEach(route => {
        const title = route.group || 'Other';
        const existing = grouped.get(title) || [];
        existing.push(route);
        grouped.set(title, existing);
      });

      return Array.from(grouped.entries()).map(([title, groupedRoutes]) => ({
        title,
        routes: groupedRoutes,
      }));
    }

    const normalize = (value?: string) =>
      typeof value === 'string' ? value.trim().toLowerCase() : '';
    const matchNames = (routes: RouteDefinition[], names: string[]) =>
      routes.filter(route => names.includes(normalize(route.name)));

    const dashboard = matchNames(primaryRoutes, [
      'overview',
      'dashboard',
      'root control',
      'owner console',
    ]);
    const operations = matchNames(primaryRoutes, [
      'services',
      'servers',
      'vps services',
      'users',
      'resellers',
      'reseller settings',
      'plans',
      'vps plans',
      'plan catalog',
      'ip plans',
      'dedicated services',
    ]);
    const infrastructure = matchNames(primaryRoutes, [
      'locations',
      'nodes',
      'ipam',
      'ip addressing',
      'coterms',
      'coterm gateways',
    ]);
    const security = matchNames(primaryRoutes, [
      'security',
      'security center',
      'diagnostics',
      'health checks',
      'logs',
      'audit logs',
    ]);
    const access = matchNames(primaryRoutes, [
      'tokens',
      'api tokens',
      'email & templates',
      'core',
      'core services',
    ]);

    const seen = new Set(
      [...dashboard, ...operations, ...infrastructure, ...security, ...access].map(route => route.path)
    );
    const remaining = primaryRoutes.filter(route => !seen.has(route.path));

    return [
      { title: 'Command Center', routes: dashboard },
      { title: 'Operations', routes: operations },
      { title: 'Infrastructure', routes: infrastructure },
      { title: 'Security & Audit', routes: security },
      { title: 'System & API', routes: access },
      { title: 'Other', routes: remaining },
    ].filter(group => group.routes.length > 0);
  }, [isAdminArea, visibleRoutes]);

  const activeRoutePath = (() => {
    let best: { path: string; score: number } | null = null;

    for (const route of visibleRoutes) {
      const to = makeTo(route.path);
      if (!isRouteMatch(to, route.end)) {
        continue;
      }

      const score = to.length + (route.end ? 1000 : 0);
      if (!best || score > best.score) {
        best = { path: to, score };
      }
    }

    return best?.path ?? null;
  })();

  const mobileQuickRoutes = visibleRoutes
    .map(route => ({
      ...route,
      to: makeTo(route.path),
    }))
    .filter(route => !route.to.includes(':'));
  const shouldShowMobileQuickNav =
    mobileQuickRoutes.length > 1 && mobileQuickRoutes.length <= 8;
  const activeMobileRoute =
    mobileQuickRoutes.find(route => route.to === activeRoutePath) ||
    mobileQuickRoutes.find(route => isRouteMatch(route.to, route.end)) ||
    mobileQuickRoutes[0];

  const adminPanelToggleLabel = (() => {
    if (isResellerOnlyAdmin) {
      if (resellerOwnerOnboardingLocked) {
        return 'Continue Onboarding';
      }

      return isAdminArea ? 'Exit Reseller Admin' : 'Enter Reseller Admin';
    }

    if (isResellerScopedRootView) {
      return 'Return To Root Admin';
    }

    return isAdminArea ? 'Exit Admin Panel' : 'Enter Main Admin';
  })();

  const resellerCustomerPanelUrl = React.useMemo(() => {
    const resellerHostname =
      tenantContext?.activeReseller?.domain ||
      tenantContext?.hostReseller?.domain ||
      tenantHostname ||
      null;
    const resellerReference =
      tenantContext?.activeReseller?.uuid ||
      tenantContext?.hostReseller?.uuid ||
      tenantContext?.activeReseller?.slug ||
      tenantContext?.hostReseller?.slug ||
      null;

    if (!resellerHostname || !resellerReference) {
      return null;
    }

    const normalizedHostname = resellerHostname.trim();
    const normalizedReference = String(resellerReference).trim();
    if (!normalizedHostname || !normalizedReference) {
      return null;
    }
    const tenantPath = `/${encodeURIComponent(normalizedReference)}`;

    if (/^https?:\/\//i.test(normalizedHostname)) {
      try {
        const url = new URL(normalizedHostname);
        url.pathname = tenantPath;
        url.search = '';
        url.hash = '';
        return url.toString();
      } catch {
        return null;
      }
    }

    const isLocalLikeHost =
      normalizedHostname === 'localhost' ||
      normalizedHostname.endsWith('.local') ||
      /^\d{1,3}(?:\.\d{1,3}){3}(?::\d+)?$/.test(normalizedHostname);

    const protocol = isLocalLikeHost ? window.location.protocol : 'https:';

    return `${protocol}//${normalizedHostname}${tenantPath}`;
  }, [tenantContext, tenantHostname]);

  const canOpenResellerCustomerPanel = Boolean(
    isAdminArea &&
      (safeUser.resellerAdmin || isResellerScopedRootView) &&
      !resellerNavOperationalLocked &&
      !resellerOwnerOnboardingLocked
  );
  const canShowAdminPanelToggle = !(
    resellerOwnerOnboardingLocked ||
    (isAdminArea &&
      isResellerOnlyAdmin &&
      resellerNavOperationalLocked)
  );

  const resellerAdminPanelUrl = React.useMemo(() => {
    const resellerReference =
      tenantContext?.activeReseller?.uuid ||
      tenantContext?.hostReseller?.uuid ||
      tenantContext?.activeReseller?.slug ||
      tenantContext?.hostReseller?.slug ||
      null;
    const resellerAdminPath = `/admin/reseller-panel${resellerReference ? `/r/${resellerReference}` : ''}`;

    return `${platformAdminBaseUrl}${resellerAdminPath}`;
  }, [platformAdminBaseUrl, tenantContext]);

  const platformAdminPanelUrl = React.useMemo(() => {
    return `${platformAdminBaseUrl}/admin`;
  }, [platformAdminBaseUrl]);

  const navigateWithinPanel = React.useCallback(
    (target: string) => {
      if (!target) {
        navigate('/');
        return;
      }

      if (!/^https?:\/\//i.test(target)) {
        navigate(target);
        return;
      }

      try {
        const targetUrl = new URL(target);
        if (targetUrl.origin === window.location.origin) {
          navigate(`${targetUrl.pathname}${targetUrl.search}${targetUrl.hash}`);
          return;
        }
      } catch {
        navigate(target);
        return;
      }

      window.location.assign(target);
    },
    [navigate]
  );

  const openResellerCustomerPanel = () => {
    if (!resellerCustomerPanelUrl) {
      return;
    }

    window.open(resellerCustomerPanelUrl, '_blank', 'noopener,noreferrer');
  };

  const switchAdminPanel = async () => {
    setAdminPanelSwitchError(null);
    setIsAdminPanelSwitching(true);

    try {
      if (isAdminArea) {
        if (isResellerOnlyAdmin && resellerOwnerOnboardingLocked) {
          if (safeUser.resellerId) {
            const nextContext = await setTenantContext({
              mode: 'reseller',
              resellerId: safeUser.resellerId,
            });
            await mutateTenantContext(nextContext, false);
          }

          navigateWithinPanel(`${platformAdminBaseUrl}${resellerOnboardingPath}`);
          return;
        }

        if (isResellerOnlyAdmin) {
          navigateWithinPanel(resellerCustomerPanelUrl || '/');
          return;
        }

        if (safeUser.rootAdmin || safeUser.platformAdmin) {
          const nextContext = await setTenantContext({
            mode: isResellerScopedRootView ? 'all' : 'platform',
          });
          await mutateTenantContext(nextContext, false);
          if (isResellerScopedRootView) {
            window.location.assign(platformAdminPanelUrl);
            return;
          }
          navigateWithinPanel('/');
          return;
        } else if (safeUser.resellerAdmin && safeUser.resellerId) {
          const nextContext = await setTenantContext({ mode: 'reseller', resellerId: safeUser.resellerId });
          await mutateTenantContext(nextContext, false);
        }

        navigateWithinPanel('/');
        return;
      }

      if (safeUser.rootAdmin || safeUser.platformAdmin) {
        const nextContext = await setTenantContext({ mode: 'platform' });
        await mutateTenantContext(nextContext, false);
        navigateWithinPanel(platformAdminPanelUrl);
        return;
      } else if (safeUser.resellerAdmin && safeUser.resellerId) {
        const nextContext = await setTenantContext({ mode: 'reseller', resellerId: safeUser.resellerId });
        await mutateTenantContext(nextContext, false);
        navigateWithinPanel(
          resellerOwnerOnboardingLocked
            ? `${platformAdminBaseUrl}${resellerOnboardingPath}`
            : resellerAdminPanelUrl
        );
        return;
      }

      navigateWithinPanel('/admin');
    } catch (error) {
      setAdminPanelSwitchError(httpErrorToHuman(error));
    } finally {
      setIsAdminPanelSwitching(false);
    }
  };

  const homeRoute =
    !isAdminArea &&
    visibleRoutes.length > 0 &&
    typeof visibleRoutes[0].name === 'string' &&
    visibleRoutes[0].name.toLowerCase() === 'home'
      ? visibleRoutes[0]
      : null;
  const nonAdminPrimaryRoutes = homeRoute ? visibleRoutes.slice(1) : visibleRoutes;

  // Icon mapper - consistent style
  const getIcon = (name: string, active: boolean) => {
    const cls = `h-[18px] w-[18px] shrink-0 ${
      active ? 'text-indigo-300' : 'text-white/80 group-hover:text-white'
    }`;
    switch ((name || '').toLowerCase()) {
      case 'overview':
      case 'dashboard':
        return <HomeIcon className={cls} />;
      case 'owner console':
      case 'root control':
        return <ShieldCheckIcon className={cls} />;
      case 'reseller workspace':
        return <BuildingStorefrontIcon className={cls} />;
      case 'onboarding':
      case 'verification':
        return <ClipboardDocumentListIcon className={cls} />;
      case 'domains & branding':
        return <GlobeAltIcon className={cls} />;
      case 'vps':
        return <ServerStackIcon className={cls} />;
      case 'support':
        return <ClipboardDocumentListIcon className={cls} />;
      case 'catalog & pricing':
        return <BuildingStorefrontIcon className={cls} />;
      case 'billing':
        return <CreditCardIcon className={cls} />;
      case 'paymenter':
        return <CreditCardIcon className={cls} />;
      case 'resources & ips':
        return <CircleStackIcon className={cls} />;
      case 'api keys':
        return <KeyIcon className={cls} />;
      case 'security & logs':
      case 'security & audit':
        return <ShieldCheckIcon className={cls} />;
      case 'analytics':
        return <ChartBarIcon className={cls} />;
      case 'backups':
        return <ArchiveBoxArrowDownIcon className={cls} />;
      case 'server usage':
        return <ChartBarIcon className={cls} />;
      case 'latest actions':
        return <ClipboardDocumentListIcon className={cls} />;
      case 'settings':
        return <Cog6ToothIcon className={cls} />;
      case 'docker manager':
        return <CommandLineIcon className={cls} />;
      case 'os & panel':
        return <ComputerDesktopIcon className={cls} />;
      case 'security':
      case 'security center':
        return <ShieldCheckIcon className={cls} />;
      case 'malware scanner':
        return <ShieldCheckIcon className={cls} />;
      case 'firewall':
        return <ShieldCheckIcon className={cls} />;
      case 'api':
        return <KeyIcon className={cls} />;
      case 'dns manager':
        return <GlobeAltIcon className={cls} />;
      case 'tutorials':
        return <BookOpenIcon className={cls} />;
      case 'servers':
        return <ServerStackIcon className={cls} />;
      case 'locations':
        return <MapPinIcon className={cls} />;
      case 'users':
        return <UserGroupIcon className={cls} />;
      case 'resellers':
      case 'reseller settings':
        return <BuildingStorefrontIcon className={cls} />;
      case 'plans':
      case 'plan catalog':
      case 'store':
        return <BuildingStorefrontIcon className={cls} />;
      case 'tokens':
      case 'api tokens':
        return <KeyIcon className={cls} />;
      case 'email & templates':
        return <EnvelopeIcon className={cls} />;
      case 'nodes':
        return <Squares2X2Icon className={cls} />;
      case 'ipam':
      case 'ip addressing':
        return <CircleStackIcon className={cls} />;
      case 'coterms':
      case 'coterm gateways':
        return <CommandLineIcon className={cls} />;
      case 'diagnostics':
      case 'health checks':
        return <ClipboardDocumentListIcon className={cls} />;
      case 'logs':
      case 'audit logs':
        return <ClipboardDocumentListIcon className={cls} />;
      case 'horizon':
      case 'core':
      case 'core services':
        return <FireIcon className={cls} />;
      default:
        return <HomeIcon className={cls} />;
    }
  };

  return (
    <>
      <LoadingOverlay visible={isLoggingOut || isAdminPanelSwitching} zIndex={4000} />

      {showAdminReturnButton && (
        <button
          type="button"
          onClick={returnToAdmin}
          className={[
            'fixed right-4 top-4 z-[4100] inline-flex items-center gap-2 rounded-2xl border px-4 py-2.5 text-sm font-black shadow-2xl backdrop-blur-xl transition',
            'border-cyan-300/30 bg-slate-950/80 text-white hover:bg-slate-900/90 hover:text-cyan-100',
            'focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-300',
          ].join(' ')}
        >
          <ShieldCheckIcon className="h-5 w-5 text-cyan-200" />
          <span>Return to Admin</span>
        </button>
      )}

      {logoutConfirmationVisible && (
        <div
          className="fixed inset-0 z-[4200] flex items-center justify-center bg-black/60 px-4 backdrop-blur-md"
          role="presentation"
          onMouseDown={() => setLogoutConfirmationVisible(false)}
        >
          <div
            className="w-full max-w-md rounded-3xl border border-white/10 bg-[#100b2f]/95 p-6 text-white shadow-2xl"
            role="dialog"
            aria-modal="true"
            aria-labelledby="logout-confirm-title"
            onMouseDown={event => event.stopPropagation()}
          >
            <div className="mx-auto mb-4 grid h-14 w-14 place-items-center rounded-2xl border border-red-300/20 bg-red-500/10 text-red-200">
              <ArrowRightOnRectangleIcon className="h-7 w-7" />
            </div>
            <h2 id="logout-confirm-title" className="text-center text-2xl font-black tracking-tight">
              Confirm logout
            </h2>
            <p className="mt-2 text-center text-sm leading-6 text-white/70">
              Do you want to sign out of this panel session?
            </p>
            <div className="mt-6 grid grid-cols-2 gap-3">
              <button
                type="button"
                className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-bold text-white transition hover:bg-white/10"
                onClick={() => setLogoutConfirmationVisible(false)}
              >
                No
              </button>
              <button
                type="button"
                className="rounded-xl border border-red-300/25 bg-red-500/20 px-4 py-3 text-sm font-black text-red-50 transition hover:bg-red-500/30"
                onClick={logout}
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===== LEFT SIDEBAR (Desktop) ===== */}
      <aside
        className={[
          'wammu-sidebar fixed inset-y-0 left-0 z-[3000] hidden sm:flex flex-col',
          'bg-[#0b0430] text-white border-r border-purple-400/25',
          'transition-[width] duration-200 ease-out',
        ].join(' ')}
        style={{ width: collapsed ? SIDEBAR_W_COLLAPSED : SIDEBAR_W }}
      >
        {/* Logo + Collapse */}
        <div className="mx-2 mt-2 flex items-center justify-between rounded-xl border border-white/10 bg-white/[0.06] px-3 py-3">
          <Link
            to={isAdminArea ? (shouldForceResellerNav ? resellerAdminRoutePath : '/admin') : '/'}
            className="group flex items-center gap-3"
          >
            {!collapsed && (
              <SafeImage
                src={panelLogoUrl}
                alt="Wammu Logo"
                className="h-7 w-7 rounded-lg"
                fallbackClassName="h-7 w-7 rounded-lg"
                fallbackText={panelName}
              />
            )}
            {!collapsed && (
              <span className="font-semibold tracking-tight text-base">
                {panelName}
              </span>
            )}
          </Link>

        {/* Collapse button */}
          <button
            className="hidden md:grid place-items-center rounded-lg px-2 py-2 hover:bg-indigo-600/20 text-indigo-300"
            onClick={() => setCollapsed((v) => !v)}
            title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="currentColor"
              className="w-4 h-4"
            >
              {collapsed ? (
                <path d="M9 5l7 7-7 7V5z" />
              ) : (
                <path d="M15 19l-7-7 7-7v14z" />
              )}
            </svg>
          </button>
        </div>

        {/* Divider */}
        <div className="mx-3 h-px bg-white/10" />

        {/* Breadcrumb (fixed height to avoid sidebar jump between routes) */}
        {!collapsed && breadcrumb && (
          <div className="mx-2 h-9 rounded-lg bg-white/5 px-3 py-2 text-xs text-white/80 truncate whitespace-nowrap">
            {breadcrumb}
          </div>
        )}

        {showAdminBackButton && (
          <div className="px-2 mt-1">
            <button
              onClick={goBackInAdmin}
              className={[
                'w-full !flex !flex-row !items-center !justify-start gap-3 rounded-xl px-3 py-2.5 text-sm min-h-[42px] transition-colors border border-white/10',
                'bg-white/5 text-white hover:bg-white/10',
                'active:outline active:outline-2 active:outline-dotted active:outline-blue-400',
                'focus-visible:outline focus-visible:outline-2 focus-visible:outline-dotted focus-visible:outline-blue-400',
                collapsed ? 'justify-center' : '',
              ].join(' ')}
              title={collapsed ? 'Go back' : undefined}
            >
              <ArrowUturnLeftIcon className="h-[18px] w-[18px] shrink-0 text-indigo-300" />
              {!collapsed && <span className="truncate whitespace-nowrap">Go back</span>}
            </button>
          </div>
        )}

        {/* Navigation items */}
        <nav className="mt-2 flex-1 overflow-y-auto px-2 space-y-2">
          {isAdminArea && adminRouteGroups.length > 0 ? (
            adminRouteGroups.map((group) => (
              <div key={group.title} className="space-y-1">
                {!collapsed && (
                  <div className="px-3 pt-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-white/45">
                    {group.title}
                  </div>
                )}
                {group.routes.map((route) => {
                  const to = makeTo(route.path);
                  const active = activeRoutePath === to;

                  return (
                    <Link
                      key={route.path}
                      to={to}
                      className={[
                        'group !flex !flex-row !items-center !justify-start gap-3 rounded-xl px-3 py-2.5 text-sm min-h-[42px] transition-colors border border-white/10',
                        active
                          ? 'bg-indigo-600/30 text-white shadow-inner'
                          : 'text-white/90 hover:text-white hover:bg-white/10',
                        'active:outline active:outline-2 active:outline-dotted active:outline-blue-400',
                        'focus-visible:outline focus-visible:outline-2 focus-visible:outline-dotted focus-visible:outline-blue-400',
                      ].join(' ')}
                    >
                      <span className="shrink-0">{getIcon(route.name, active)}</span>
                      {!collapsed && (
                        <span className="truncate whitespace-nowrap">
                          {route.name}
                        </span>
                      )}
                    </Link>
                  );
                })}
              </div>
            ))
          ) : (
            <>
              {homeRoute && (
                <div className="space-y-1">
                  {!collapsed && (
                    <div className="px-3 pt-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-white/45">
                      Home
                    </div>
                  )}
                  {(() => {
                    const to = makeTo(homeRoute.path);
                    const active = activeRoutePath === to;
                    return (
                      <Link
                        key={homeRoute.path}
                        to={to}
                        className={[
                          'group !flex !flex-row !items-center !justify-start gap-3 rounded-xl px-3 py-2.5 text-sm min-h-[42px] transition-colors border border-white/10',
                          active
                            ? 'bg-indigo-600/30 text-white shadow-inner'
                            : 'text-white/90 hover:text-white hover:bg-white/10',
                          'active:outline active:outline-2 active:outline-dotted active:outline-blue-400',
                          'focus-visible:outline focus-visible:outline-2 focus-visible:outline-dotted focus-visible:outline-blue-400',
                        ].join(' ')}
                      >
                        <span className="shrink-0">{getIcon(homeRoute.name, active)}</span>
                        {!collapsed && (
                          <span className="truncate whitespace-nowrap">
                            {homeRoute.name}
                          </span>
                        )}
                      </Link>
                    );
                  })()}
                </div>
              )}
              {nonAdminPrimaryRoutes.length > 0 && (
                <div className="space-y-1">
                  {homeRoute && <div className="mx-2 h-px bg-white/10" />}
                  {!collapsed && (
                    <div className="px-3 pt-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-white/45">
                      Server
                    </div>
                  )}
                  {nonAdminPrimaryRoutes.map((route) => {
                    const to = makeTo(route.path);
                    const active = activeRoutePath === to;
                    return (
                      <Link
                        key={route.path}
                        to={to}
                        className={[
                          'group !flex !flex-row !items-center !justify-start gap-3 rounded-xl px-3 py-2.5 text-sm min-h-[42px] transition-colors border border-white/10',
                          active
                            ? 'bg-indigo-600/30 text-white shadow-inner'
                            : 'text-white/90 hover:text-white hover:bg-white/10',
                          'active:outline active:outline-2 active:outline-dotted active:outline-blue-400',
                          'focus-visible:outline focus-visible:outline-2 focus-visible:outline-dotted focus-visible:outline-blue-400',
                        ].join(' ')}
                      >
                        <span className="shrink-0">{getIcon(route.name, active)}</span>
                        {!collapsed && (
                          <span className="truncate whitespace-nowrap">
                            {route.name}
                          </span>
                        )}
                      </Link>
                    );
                  })}
                </div>
              )}
            </>
          )}
        </nav>

        {/* User Info, Admin CP, and Sign out (Always Visible) */}
        <div className="mt-auto px-2 pb-3 pt-2">
          <div className="mx-2 mb-2 h-px bg-white/10" />

          {!isAdminArea && resolvedBillingUrl && !resellerOwnerOnboardingLocked && (
            <a
              href={resolvedBillingUrl}
              target="_blank"
              rel="noreferrer"
              className={[
                'w-full !flex !flex-row !items-center !justify-start gap-3 rounded-xl px-3 py-2.5 text-sm min-h-[42px] transition-colors border border-white/10',
                'text-white/90 hover:bg-white/10 hover:text-white',
                'active:outline active:outline-2 active:outline-dotted active:outline-blue-400',
                'focus-visible:outline focus-visible:outline-2 focus-visible:outline-dotted focus-visible:outline-blue-400',
                collapsed ? 'justify-center' : '',
              ].join(' ')}
              title={collapsed ? 'Billing' : undefined}
            >
              <CreditCardIcon className="h-[18px] w-[18px] shrink-0 text-white/70" />
              {!collapsed && <span className="truncate whitespace-nowrap">Billing</span>}
            </a>
          )}

          {/* Admin panel toggle (Visible if user is rootAdmin) */}
          {isAdminUser && canShowAdminPanelToggle && (
            <button
              type="button"
              onClick={() => {
                void switchAdminPanel();
              }}
              disabled={isAdminPanelSwitching}
              className={[
                'w-full !flex !flex-row !items-center !justify-start gap-3 rounded-xl px-3 py-2.5 text-sm min-h-[42px] transition-colors border border-white/10',
                'text-white/90 hover:bg-white/10 hover:text-white',
                'active:outline active:outline-2 active:outline-dotted active:outline-blue-400',
                'focus-visible:outline focus-visible:outline-2 focus-visible:outline-dotted focus-visible:outline-blue-400',
                isAdminPanelSwitching ? 'cursor-wait opacity-70' : '',
                collapsed ? 'justify-center' : '',
              ].join(' ')}
              title={collapsed ? adminPanelToggleLabel : undefined}
            >
              <ShieldCheckIcon className="h-[18px] w-[18px] shrink-0 text-white/70" />
              {!collapsed && <span className='truncate whitespace-nowrap'>
                {adminPanelToggleLabel}
              </span>}
            </button>
          )}
          {adminPanelSwitchError && !collapsed && (
            <p className="mt-2 rounded-lg border border-red-400/30 bg-red-500/10 px-3 py-2 text-xs leading-5 text-red-100">
              {adminPanelSwitchError}
            </p>
          )}

          {canOpenResellerCustomerPanel && resellerCustomerPanelUrl && (
            <button
              type="button"
              onClick={openResellerCustomerPanel}
              className={[
                'mt-1 w-full !flex !flex-row !items-center !justify-start gap-3 rounded-xl px-3 py-2.5 text-sm min-h-[42px] transition-colors border border-white/10',
                'text-white/90 hover:bg-white/10 hover:text-white',
                'active:outline active:outline-2 active:outline-dotted active:outline-blue-400',
                'focus-visible:outline focus-visible:outline-2 focus-visible:outline-dotted focus-visible:outline-blue-400',
                collapsed ? 'justify-center' : '',
              ].join(' ')}
              title={collapsed ? 'Open Customer Panel' : undefined}
            >
              <HomeIcon className="h-[18px] w-[18px] shrink-0 text-white/70" />
              {!collapsed && (
                <span className="truncate whitespace-nowrap">
                  Open Customer Panel
                </span>
              )}
            </button>
          )}

          {/* Sign Out Link */}
          <button
            onClick={requestLogout}
            onMouseUp={event => event.currentTarget.blur()}
            className={[
              'mt-1 w-full !flex !flex-row !items-center !justify-start gap-3 rounded-xl px-3 py-2.5 text-sm min-h-[42px] transition-colors border border-white/10',
              'appearance-none bg-transparent text-red-300 hover:bg-white/10 active:bg-white/15',
              'active:outline active:outline-2 active:outline-dotted active:outline-blue-400',
              'focus:bg-transparent focus-visible:outline focus-visible:outline-2 focus-visible:outline-dotted focus-visible:outline-blue-400',
              collapsed ? 'justify-center' : '',
            ].join(' ')}
            title={collapsed ? 'Sign out' : undefined}
          >
            <ArrowRightOnRectangleIcon className="h-[18px] w-[18px] shrink-0" />
            {!collapsed && (
              <span className="truncate whitespace-nowrap">{tAuth('sign_out')}</span>
            )}
          </button>
          
          {!resellerOwnerOnboardingLocked && (
            <Link
              to='/account'
              className={[
                'mt-2 w-full !flex !flex-row !items-center !justify-start gap-3 rounded-xl px-3 py-2 text-sm text-white/90 hover:bg-white/10 transition border border-white/10',
                'active:outline active:outline-2 active:outline-dotted active:outline-blue-400',
                'focus-visible:outline focus-visible:outline-2 focus-visible:outline-dotted focus-visible:outline-blue-400',
                collapsed ? 'justify-center' : '',
              ].join(' ')}
            >
              <Avatar src={safeUser.avatarUrl || undefined} color='indigo' size={collapsed ? 'sm' : 'md'} radius='xl' className="shrink-0">
                {getInitials(safeUser.name, ' ', 2)}
              </Avatar>
              {!collapsed && (
                <span className="truncate whitespace-nowrap font-semibold">
                  {safeUser.name}
                </span>
              )}
            </Link>
          )}

        </div>
      </aside>

      {/* ===== MOBILE TOP BAR (Original code retained for mobile consistency) ===== */}
      <div className="wammu-mobile-nav sm:hidden sticky top-0 z-[3000] bg-[#0b0430]/95 text-white border-b border-purple-400/25 backdrop-blur">
        <ContentContainer padding className="py-3">
          <div className="flex items-center justify-between">
            <Link
              to={isAdminArea ? (shouldForceResellerNav ? resellerAdminRoutePath : '/admin') : '/'}
              className="flex items-center gap-3"
            >
              <SafeImage
                src={panelLogoUrl}
                alt="Wammu Logo"
                className="h-6 w-6 rounded-lg"
                fallbackClassName="h-6 w-6 rounded-lg"
                fallbackText={panelName}
              />
              <span className="font-semibold">{panelName}</span>
            </Link>
            <div className="flex items-center gap-2">
              {/* NOTE: UserDropdown is retained here for mobile quick actions, but you may need to update its imports. */}
              {/* For now, I'll replace it with a simple avatar button to avoid re-introducing the component. */}
              {!resellerOwnerOnboardingLocked && (
                <button
                  onClick={() => navigate('/account')}
                  title="Account"
                  className="rounded-full ring-transparent ring-4 hover:ring-white/10 transition"
                >
                   <Avatar src={safeUser.avatarUrl || undefined} color='indigo' size='sm' radius='xl'>
                     {getInitials(safeUser.name, ' ', 2)}
                   </Avatar>
                </button>
              )}
              <Burger
                opened={menuVisible}
                onClick={() => setMenuVisible((v) => !v)}
                aria-label={menuVisible ? 'Close menu' : 'Open menu'}
              />
            </div>
          </div>
        </ContentContainer>

        {shouldShowMobileQuickNav && (
          <div className="border-t border-white/10 px-3 pb-3">
            <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-2">
              <div className="flex items-center gap-2">
                {showAdminBackButton && (
                  <button
                    type="button"
                    onClick={goBackInAdmin}
                    className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-white/10 bg-white/5 text-white/80"
                    aria-label="Go back"
                  >
                    <ArrowUturnLeftIcon className="h-5 w-5" />
                  </button>
                )}
                <div className="min-w-0 flex-1">
                  <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-white/45">
                    Current section
                  </p>
                  <p className="truncate text-sm font-black text-white">
                    {activeMobileRoute?.name || breadcrumb || 'Navigation'}
                  </p>
                </div>
              </div>
              <div className="mt-2 flex gap-2 overflow-x-auto overscroll-x-contain pb-2 [-webkit-overflow-scrolling:touch]">
                {mobileQuickRoutes.map(route => {
                  const active = route.to === activeRoutePath || isRouteMatch(route.to, route.end);

                  return (
                    <Link
                      key={route.path}
                      to={route.to}
                      className={[
                        'inline-flex shrink-0 items-center gap-2 rounded-xl border px-3 py-2 text-xs font-bold transition',
                        active
                          ? 'border-white/15 bg-indigo-600/25 text-white'
                          : 'border-white/10 bg-white/5 text-white/75 hover:bg-white/10 hover:text-white',
                      ].join(' ')}
                    >
                      <span className="h-4 w-4 shrink-0">{getIcon(route.name, active)}</span>
                      <span className="whitespace-nowrap">{route.name}</span>
                    </Link>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ===== MOBILE DROPDOWN PANEL (Original code retained) ===== */}
        {menuVisible && (
          <div
            className="max-h-[calc(100dvh-84px)] overflow-y-auto border-t border-purple-400/25 bg-[#0b0430]/95 z-[3500] backdrop-blur"
            role="dialog"
            aria-modal="true"
          >
            {/* Account quick section — always visible on mobile */}
            <div className="px-4 py-2">
              {!resellerOwnerOnboardingLocked && (
                <button
                  onClick={() => {
                    setMenuVisible(false);
                    navigate('/account');
                  }}
                  className="w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm bg-white/5 hover:bg-white/10 transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-dotted focus-visible:outline-blue-400"
                >
                  <Avatar src={safeUser.avatarUrl || undefined} color='indigo' size='sm' radius='xl'>
                      {getInitials(safeUser.name, ' ', 2)}
                  </Avatar>
                  <span className="truncate">Account</span>
                </button>
              )}
              <button
                onClick={() => {
                  if (!resolvedBillingUrl) {
                    return;
                  }
                  setMenuVisible(false);
                  window.open(resolvedBillingUrl, '_blank', 'noopener,noreferrer');
                }}
                className={[
                  'w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm bg-white/5 hover:bg-white/10 transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-dotted focus-visible:outline-blue-400',
                  !resolvedBillingUrl || resellerOwnerOnboardingLocked ? 'hidden' : '',
                ].join(' ')}
              >
                <CreditCardIcon className="h-5 w-5 text-white/80" />
                <span className="truncate">Billing</span>
              </button>

              <button
                onClick={() => {
                  setMenuVisible(false);
                  requestLogout();
                }}
                className="mt-2 w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm appearance-none bg-white/5 hover:bg-white/10 active:bg-white/15 text-red-300 transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-dotted focus-visible:outline-blue-400"
              >
                <ArrowRightOnRectangleIcon className="h-5 w-5 text-white/80" />
                <span className="truncate">Logout</span>
              </button>

              {isAdminUser && canShowAdminPanelToggle && (
                <button
                  onClick={() => {
                    setMenuVisible(false);
                    void switchAdminPanel();
                  }}
                  disabled={isAdminPanelSwitching}
                  className="mt-2 w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm bg-white/5 hover:bg-white/10 text-white/90 transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-dotted focus-visible:outline-blue-400"
                >
                  <ShieldCheckIcon className="h-5 w-5 text-white/80" />
                  <span className="truncate">
                    {adminPanelToggleLabel}
                  </span>
                </button>
              )}
              {adminPanelSwitchError && (
                <p className="mt-2 rounded-lg border border-red-400/30 bg-red-500/10 px-3 py-2 text-xs leading-5 text-red-100">
                  {adminPanelSwitchError}
                </p>
              )}

              {canOpenResellerCustomerPanel && resellerCustomerPanelUrl && (
                <button
                  onClick={() => {
                    setMenuVisible(false);
                    openResellerCustomerPanel();
                  }}
                  className="mt-2 w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm bg-white/5 hover:bg-white/10 text-white/90 transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-dotted focus-visible:outline-blue-400"
                >
                  <HomeIcon className="h-5 w-5 text-white/80" />
                  <span className="truncate">Open Customer Panel</span>
                </button>
              )}
            </div>

            <div className="mx-4 my-2 h-px bg-white/10" />

            {/* Navigation items */}
            <nav className="py-2">
              {showAdminBackButton && (
                <button
                  onClick={() => {
                    setMenuVisible(false);
                    goBackInAdmin();
                  }}
                  className="mx-2 flex w-[calc(100%-1rem)] min-w-0 items-center gap-3 overflow-hidden rounded-lg border border-white/10 px-4 py-2 text-sm text-white/85 transition hover:bg-white/5 hover:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-dotted focus-visible:outline-blue-400"
                >
                  <ArrowUturnLeftIcon className="h-5 w-5 text-indigo-300" />
                  <span className="truncate whitespace-nowrap">Go back</span>
                </button>
              )}

              {isAdminArea && adminRouteGroups.length > 0
                ? adminRouteGroups.flatMap(group => [
                    <div
                      key={`heading-${group.title}`}
                      className="px-4 pt-2 pb-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-white/45"
                    >
                      {group.title}
                    </div>,
                    ...group.routes.map((route) => {
                      const to = makeTo(route.path);
                      const active = activeRoutePath === to;
                      return (
                        <Link
                          key={route.path}
                          to={to}
                          onClick={() => setMenuVisible(false)}
                          className={[
                            'mx-2 my-0.5 flex min-w-0 items-center gap-3 overflow-hidden rounded-lg border border-white/10 px-4 py-2 text-sm',
                            active
                              ? 'bg-indigo-600/25 text-white'
                              : 'text-white/90 hover:bg-white/10 hover:text-white',
                            'active:outline active:outline-2 active:outline-dotted active:outline-blue-400',
                            'focus-visible:outline focus-visible:outline-2 focus-visible:outline-dotted focus-visible:outline-blue-400',
                          ].join(' ')}
                        >
                          <span className="shrink-0">
                            {getIcon(route.name, active)}
                          </span>
                          <span className="truncate whitespace-nowrap">
                            {route.name}
                          </span>
                        </Link>
                      );
                    }),
                  ])
                : (
                    <>
                      {homeRoute && (
                        <>
                          <div
                            className='px-4 pt-2 pb-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-white/45'
                          >
                            Home
                          </div>
                          {(() => {
                            const to = makeTo(homeRoute.path);
                            const active = activeRoutePath === to;

                            return (
                              <Link
                                key={homeRoute.path}
                                to={to}
                                onClick={() => setMenuVisible(false)}
                                className={[
                                  'mx-2 my-0.5 flex min-w-0 items-center gap-3 overflow-hidden rounded-lg border border-white/10 px-4 py-2 text-sm',
                                  active
                                    ? 'bg-indigo-600/25 text-white'
                                    : 'text-white/90 hover:bg-white/10 hover:text-white',
                                  'active:outline active:outline-2 active:outline-dotted active:outline-blue-400',
                                  'focus-visible:outline focus-visible:outline-2 focus-visible:outline-dotted focus-visible:outline-blue-400',
                                ].join(' ')}
                              >
                                <span className='shrink-0'>{getIcon(homeRoute.name, active)}</span>
                                <span className='truncate whitespace-nowrap'>{homeRoute.name}</span>
                              </Link>
                            );
                          })()}
                          <div className='mx-4 my-2 h-px bg-white/10' />
                        </>
                      )}

                      {nonAdminPrimaryRoutes.length > 0 && (
                        <>
                          <div className='px-4 pt-2 pb-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-white/45'>
                            Server
                          </div>
                          {nonAdminPrimaryRoutes.map((route) => {
                            const to = makeTo(route.path);
                            const active = activeRoutePath === to;

                            return (
                              <Link
                                key={route.path}
                                to={to}
                                onClick={() => setMenuVisible(false)}
                                className={[
                                  'mx-2 my-0.5 flex min-w-0 items-center gap-3 overflow-hidden rounded-lg border border-white/10 px-4 py-2 text-sm',
                                  active
                                    ? 'bg-indigo-600/25 text-white'
                                    : 'text-white/90 hover:bg-white/10 hover:text-white',
                                  'active:outline active:outline-2 active:outline-dotted active:outline-blue-400',
                                  'focus-visible:outline focus-visible:outline-2 focus-visible:outline-dotted focus-visible:outline-blue-400',
                                ].join(' ')}
                              >
                                <span className='shrink-0'>{getIcon(route.name, active)}</span>
                                <span className='truncate whitespace-nowrap'>{route.name}</span>
                              </Link>
                            );
                          })}
                        </>
                      )}
                    </>
                  )
                }
            </nav>
          </div>
        )}
      </div>
    </>
  );
};

export default NavigationBar;

