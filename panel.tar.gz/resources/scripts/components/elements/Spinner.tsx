import styled from '@emotion/styled'
import { useStoreState } from '@/state'
import { ReactNode, Suspense, useEffect, useState } from 'react'
import { normalizeImageUrl } from '@/components/elements/SafeImage'
import tw from 'twin.macro'

interface Props {
  screen?: boolean
  flat?: boolean
}

interface SpinnerType extends React.FC<Props> {
  Suspense: React.FC<{ children: ReactNode; screen?: boolean }>
}

/* ================= CENTER LOGO LOADER ================= */
const LoadingScreen = () => {
  const loadingLogoUrl = useStoreState(state => state.settings.data?.loadingLogoUrl)
  const panelLogoUrl = useStoreState(state => state.settings.data?.logoUrl)
  const logoSrc = normalizeImageUrl(loadingLogoUrl || panelLogoUrl || '/favicon.svg') || '/favicon.svg'
  const [logoFailed, setLogoFailed] = useState(false)
  const [showRecoveryHint, setShowRecoveryHint] = useState(false)

  useEffect(() => {
    setLogoFailed(false)
  }, [logoSrc])

  useEffect(() => {
    const timer = window.setTimeout(() => setShowRecoveryHint(true), 12000)

    return () => window.clearTimeout(timer)
  }, [])

  return (
  <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-[radial-gradient(circle_at_50%_36%,color-mix(in_srgb,var(--tenant-brand-primary,#4a9eff)_18%,transparent),transparent_34%),linear-gradient(135deg,var(--tenant-bg,#050118),#050010)]">
    <style>
      {`
        @keyframes wammu-loader-glow {
          0%, 100% { opacity: 0.25; transform: scale(1); }
          50% { opacity: 0.45; transform: scale(1.15); }
        }

        @keyframes wammu-loader-pulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.03); }
        }
      `}
    </style>
    <div className="absolute inset-0 grid place-items-center">
      <div className="relative h-56 w-56">
      {/* Outer glow */}
      <div className="absolute inset-0 rounded-full bg-[color-mix(in_srgb,var(--tenant-brand-primary,#4a9eff)_14%,transparent)] blur-3xl motion-safe:animate-[wammu-loader-glow_2.2s_ease-in-out_infinite]" />

      {/* Rotating ring */}
      <div className="wammu-loader-ring absolute inset-2 rounded-full border-[3px] border-[color-mix(in_srgb,var(--tenant-brand-primary,#4a9eff)_20%,transparent)] border-t-[color-mix(in_srgb,var(--tenant-brand-accent,#00e0ff)_88%,white_8%)] motion-safe:animate-[spin_1.4s_linear_infinite]" />

      {/* Center logo */}
      <div className="absolute inset-0 z-10 flex items-center justify-center motion-safe:animate-[wammu-loader-pulse_1.8s_ease-in-out_infinite]">
        <div className="isolate grid h-24 w-24 place-items-center overflow-hidden rounded-[1.35rem] border border-white/10 bg-[linear-gradient(145deg,rgba(255,255,255,0.08),rgba(255,255,255,0.02))] p-3 shadow-[0_24px_70px_rgba(0,0,0,0.42),0_0_32px_color-mix(in_srgb,var(--tenant-brand-primary,#4a9eff)_24%,transparent)] backdrop-blur-xl md:h-28 md:w-28">
          {logoFailed ? (
            <span className="text-5xl font-black tracking-[-0.12em] text-white drop-shadow-[0_0_22px_color-mix(in_srgb,var(--tenant-brand-accent,#00e0ff)_60%,transparent)]">
              W
            </span>
          ) : (
            <img
              className="block h-full w-full object-contain drop-shadow-[0_0_20px_color-mix(in_srgb,var(--tenant-brand-primary,#4a9eff)_42%,transparent)]"
              alt="WammuHost"
              src={logoSrc}
              decoding="async"
              referrerPolicy="no-referrer"
              onError={() => setLogoFailed(true)}
            />
          )}
        </div>
      </div>

      {showRecoveryHint && (
        <div className="absolute -bottom-16 left-1/2 z-20 w-[22rem] -translate-x-1/2 rounded-xl border border-white/20 bg-black/55 p-3 text-center text-sm text-white/90 backdrop-blur">
          Loading is taking longer than expected.
          <button
            type="button"
            onClick={() => window.location.reload()}
            className="ml-2 rounded-md border border-indigo-400/50 bg-indigo-500/20 px-2 py-0.5 text-indigo-200 hover:bg-indigo-500/30"
          >
            Reload
          </button>
        </div>
      )}
      </div>
    </div>
  </div>
)}

/* ================= WRAPPER ================= */
const SpinnerContainer = styled.div<{ $screen?: boolean }>`
  ${tw`flex items-center justify-center`}
  ${({ $screen }) => ($screen ? tw`fixed inset-0 z-[9999] w-screen h-screen` : tw`w-full h-full min-h-[120px]`)}
`

const InlineSpinnerDot = styled.div`
  ${tw`h-8 w-8 rounded-full border-2 border-blue-400/20 border-t-blue-400/90`}
  animation: spin 0.9s linear infinite;

  @keyframes spin {
    to {
      transform: rotate(360deg);
    }
  }
`

const Spinner: SpinnerType = ({ screen, flat }: Props) => {
  if (!screen) {
    return (
      <SpinnerContainer $screen={false}>
        <InlineSpinnerDot />
      </SpinnerContainer>
    )
  }

  return (
    <SpinnerContainer $screen>
      <LoadingScreen />
    </SpinnerContainer>
  )
}

/* ================= SUSPENSE FALLBACK ================= */
Spinner.Suspense = ({ children, screen }) => (
  <Suspense fallback={<Spinner screen={screen} />}>{children}</Suspense>
)

export default Spinner
