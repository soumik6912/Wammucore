import { ErrorMessage } from '@/components/elements/ScreenBlock'
import {
    isBrowserOffline,
    isDynamicImportError,
    tryRecoverFromChunkError,
} from '@/util/chunkLoadRecovery'
import { useEffect } from 'react'
import { isRouteErrorResponse, useRouteError } from 'react-router-dom'

const RouteErrorFallback = () => {
    const error = useRouteError()

    const message = (() => {
        if (isRouteErrorResponse(error)) {
            return error.data?.message || error.statusText || 'Request failed.'
        }

        if (error instanceof Error) {
            return error.message
        }

        return 'An unexpected error occurred.'
    })()

    const isChunkError = isDynamicImportError(error)
    const offline = isBrowserOffline()

    useEffect(() => {
        if (isChunkError) {
            tryRecoverFromChunkError()
        }
    }, [isChunkError])

    return (
        <ErrorMessage
            full
            message={
                isChunkError
                    ? offline
                        ? 'Internet is offline. Reconnect first; the panel will avoid reloading into the browser offline page.'
                        : 'A new version was deployed. Reloading the page should fix this.'
                    : message
            }
            onRetry={() => {
                if (isBrowserOffline()) {
                    window.dispatchEvent(new CustomEvent('wammucore:offline-recovery-blocked'))
                    return
                }

                window.location.reload()
            }}
        />
    )
}

export default RouteErrorFallback
