import type { SVGProps } from 'react'

type Tone = 'danger' | 'warning'

interface Props {
    title: string
    description: string
    tone?: Tone
    Icon: (props: SVGProps<SVGSVGElement>) => JSX.Element
}

const toneStyles: Record<Tone, { chip: string; iconWrap: string }> = {
    warning: {
        chip: 'border-amber-300/35 bg-amber-400/10 text-amber-100',
        iconWrap: 'border-amber-300/35 bg-amber-400/10 text-amber-200',
    },
    danger: {
        chip: 'border-rose-300/35 bg-rose-400/10 text-rose-100',
        iconWrap: 'border-rose-300/35 bg-rose-400/10 text-rose-200',
    },
}

const StatusStateBlock = ({ title, description, tone = 'warning', Icon }: Props) => {
    const styles = toneStyles[tone]

    return (
        <div className='mx-auto w-full max-w-4xl rounded-2xl border border-white/15 bg-[#140f34] p-6 shadow-[0_20px_60px_rgba(8,6,24,0.55)]'>
            <div className='mb-3 inline-flex items-center gap-2 rounded-full border px-3 py-1 text-xs font-semibold tracking-wide uppercase text-white/90'>
                <span className={`rounded-full border px-2 py-0.5 ${styles.chip}`}>
                    Attention
                </span>
                Status update
            </div>

            <div className='flex items-start gap-4'>
                <div className={`rounded-xl border p-3 ${styles.iconWrap}`}>
                    <Icon className='h-6 w-6' />
                </div>
                <div className='min-w-0'>
                    <h2 className='text-2xl font-bold text-white'>{title}</h2>
                    <p className='mt-2 text-sm leading-6 text-white/75'>{description}</p>
                </div>
            </div>
        </div>
    )
}

export default StatusStateBlock
