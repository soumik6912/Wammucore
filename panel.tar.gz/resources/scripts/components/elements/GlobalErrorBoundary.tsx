import React from 'react'

import {
    isBrowserOffline,
    isDynamicImportError,
    tryRecoverFromChunkError,
} from '@/util/chunkLoadRecovery'

interface State {
    hasError: boolean
    message: string
}

class GlobalErrorBoundary extends React.Component<
    { children: React.ReactNode },
    State
> {
    public state: State = {
        hasError: false,
        message: '',
    }

    public static getDerivedStateFromError(error: Error): State {
        return {
            hasError: true,
            message: error?.message || 'Unexpected application error.',
        }
    }

    public componentDidCatch(error: Error): void {
        if (isDynamicImportError(error)) {
            tryRecoverFromChunkError()
        }
    }

    public render(): React.ReactNode {
        if (!this.state.hasError) {
            return this.props.children
        }

        return (
            <div className='fixed inset-0 z-[9999] flex items-center justify-center bg-[#070018] p-4'>
                <div className='w-full max-w-xl rounded-2xl border border-white/20 bg-black/50 p-6 text-white'>
                    <h1 className='text-xl font-semibold'>Panel failed to load</h1>
                    <p className='mt-2 text-sm text-white/80'>
                        {this.state.message ||
                            'A runtime error stopped the UI from rendering.'}
                    </p>
                    <button
                        type='button'
                        onClick={() => {
                            if (isBrowserOffline()) {
                                window.dispatchEvent(new CustomEvent('wammucore:offline-recovery-blocked'))
                                return
                            }

                            window.location.reload()
                        }}
                        className='mt-4 rounded-lg border border-indigo-400/50 bg-indigo-500/20 px-4 py-2 text-indigo-200 hover:bg-indigo-500/30'
                    >
                        Reload
                    </button>
                </div>
            </div>
        )
    }
}

export default GlobalErrorBoundary
