import { useEffect, useState } from 'react'

const OfflineRecoveryOverlay = () => {
    const [offline, setOffline] = useState(
        () => typeof navigator !== 'undefined' && navigator.onLine === false
    )
    const [blockedReload, setBlockedReload] = useState(false)

    useEffect(() => {
        const markOnline = () => {
            setOffline(false)
            setBlockedReload(false)
        }
        const markOffline = () => setOffline(true)
        const markBlockedReload = () => {
            setOffline(true)
            setBlockedReload(true)
        }

        window.addEventListener('online', markOnline)
        window.addEventListener('offline', markOffline)
        window.addEventListener('wammucore:offline-recovery-blocked', markBlockedReload)

        return () => {
            window.removeEventListener('online', markOnline)
            window.removeEventListener('offline', markOffline)
            window.removeEventListener('wammucore:offline-recovery-blocked', markBlockedReload)
        }
    }, [])

    if (!offline) {
        return null
    }

    return (
        <div className='pointer-events-none fixed inset-x-0 bottom-4 z-[10000] flex justify-center px-4 sm:bottom-6'>
            <div className='pointer-events-auto w-full max-w-lg rounded-2xl border border-amber-300/30 bg-[#120817]/95 p-4 text-white shadow-[0_24px_80px_rgba(0,0,0,.5)] backdrop-blur-xl'>
                <div className='flex items-start gap-3'>
                    <div className='mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-amber-300/40 bg-amber-400/15 text-amber-100'>
                        !
                    </div>
                    <div className='min-w-0 flex-1'>
                        <h2 className='text-sm font-semibold text-white'>
                            Connection paused
                        </h2>
                        <p className='mt-1 text-xs leading-5 text-white/70'>
                            {blockedReload
                                ? 'Your panel stayed open instead of reloading to the browser offline page. Reconnect internet and continue.'
                                : 'Internet is offline. Keep this tab open; the panel will continue once your connection returns.'}
                        </p>
                        <div className='mt-3 flex flex-wrap gap-2'>
                            <button
                                type='button'
                                onClick={() => {
                                    if (navigator.onLine) {
                                        window.location.reload()
                                        return
                                    }

                                    setOffline(true)
                                }}
                                className='rounded-lg border border-amber-200/40 bg-amber-300/15 px-3 py-1.5 text-xs font-semibold text-amber-100 hover:bg-amber-300/25'
                            >
                                Retry when online
                            </button>
                            <span className='rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-white/55'>
                                Auto-reconnect enabled
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default OfflineRecoveryOverlay
