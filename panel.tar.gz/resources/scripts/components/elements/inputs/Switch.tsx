import styled from '@emotion/styled'
import {
    Switch as MantineSwitch,
    SwitchProps as MantineSwitchProps,
} from '@mantine/core'
import tw from 'twin.macro'

export interface SwitchProps extends MantineSwitchProps {}

const Switch = styled(MantineSwitch)`
    & .mantine-Switch-track {
        ${tw`h-6 w-11 rounded-xl bg-accent-200 transition-colors border-none`}
    }

    & input:checked + .mantine-Switch-track {
        ${tw`bg-success`}
    }

    & .mantine-Switch-thumb {
        ${tw`h-5 w-5 border-none transition-all bg-background`}
    }

    & input:checked + * > .mantine-Switch-thumb {
        left: calc(100% - 1.4rem);
    }

    & .mantine-Switch-label {
        ${tw`text-foreground`}
    }

    & .mantine-Switch-labelWrapper {
        ${tw`self-center`}
    }

    &.account-privacy-switch .mantine-Switch-track {
        background: #0f172a;
        border: 1px solid rgba(203, 213, 225, 0.48);
        box-shadow:
            inset 0 0 0 1px rgba(15, 23, 42, 0.85),
            0 0 0 1px rgba(255, 255, 255, 0.08);
    }

    &.account-privacy-switch input:checked + .mantine-Switch-track {
        background: linear-gradient(135deg, #10b981, #22c55e);
        border-color: rgba(167, 243, 208, 0.7);
        box-shadow: 0 0 18px rgba(16, 185, 129, 0.26);
    }

    &.account-privacy-switch .mantine-Switch-thumb {
        background: #f8fafc;
        border: 1px solid rgba(15, 23, 42, 0.18);
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.28);
    }
`

export default Switch
