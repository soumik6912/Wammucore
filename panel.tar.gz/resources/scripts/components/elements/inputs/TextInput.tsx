import styled from '@emotion/styled'
import { TextInput as MantineTextInput, TextInputProps } from '@mantine/core'
import { forwardRef } from 'react'
import tw from 'twin.macro'

import ErrorMessage from '@/components/elements/ErrorMessage'

const StyledTextInput = styled(MantineTextInput)`
    .mantine-TextInput-label {
        ${tw`text-sm font-bold text-white mb-1`}
    }

    .mantine-TextInput-input {
        ${tw`bg-background border text-white transition-all duration-150 disabled:bg-accent-100 disabled:text-accent-500 disabled:placeholder:text-accent-300`}
        box-shadow: inset 0 0 0 1px rgba(148, 163, 184, 0.1);

        ${({ error }) =>
            error
                ? tw`border-error placeholder:text-white/50 text-white focus:border-error`
                : tw`border-accent-300 placeholder:text-accent-400 hover:border-accent-200 focus:border-accent-500 focus:shadow-[0_0_0_3px_rgba(74,158,255,0.25)]`}
    }
`

const TextInput = forwardRef<HTMLInputElement, TextInputProps>(
    ({ error, ...props }, ref) => {
        return (
            <StyledTextInput
                ref={ref}
                error={error ? <ErrorMessage>{error}</ErrorMessage> : undefined}
                {...props}
            />
        )
    }
)

export default TextInput
