import { ArrowPathIcon, CheckCircleIcon } from '@heroicons/react/24/outline'
import { useEffect, useMemo, useState } from 'react'
import getInstallProgress, {
    InstallProgress,
    ProvisioningPhase,
} from '@/api/server/getInstallProgress'

interface Props {
    title: string
    description: string
    serverUuid: string
    forceCompleted?: boolean
}

interface PersistedProgressState {
    progress: number
    currentStepLabel: string
    taskState: string
    timestamp: number
}

const formatElapsed = (seconds: number): string => {
    if (seconds < 60) return `${seconds}s`
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}m ${secs}s`
}

const StatusProgressBlock = ({
    title,
    description,
    serverUuid,
    forceCompleted = false,
}: Props) => {
    const [progressData, setProgressData] = useState<InstallProgress | null>(
        null
    )
    const [fetchError, setFetchError] = useState<string | null>(null)
    const storageKey = `wammucore:install-progress:${serverUuid}`

    const readPersistedState = (): PersistedProgressState | null => {
        try {
            const raw = window.sessionStorage.getItem(storageKey)
            if (!raw) return null
            return JSON.parse(raw) as PersistedProgressState
        } catch {
            return null
        }
    }

    const persistState = (state: PersistedProgressState) => {
        try {
            window.sessionStorage.setItem(storageKey, JSON.stringify(state))
        } catch {
            //
        }
    }

    useEffect(() => {
        let cancelled = false
        let timer: number | null = null

        const load = async () => {
            try {
                const data = await getInstallProgress(serverUuid)
                if (cancelled) return
                const persisted = readPersistedState()
                const mergedProgress = Math.max(
                    Number(data.progressPercent ?? 0),
                    Number(persisted?.progress ?? 0)
                )
                const mergedData = {
                    ...data,
                    progressPercent: mergedProgress,
                    currentStepLabel:
                        data.currentStepLabel ??
                        persisted?.currentStepLabel ??
                        'Provisioning',
                    taskState: data.taskState ?? persisted?.taskState ?? 'unknown',
                }
                setProgressData(mergedData)
                setFetchError(null)
                persistState({
                    progress: mergedProgress,
                    currentStepLabel:
                        mergedData.currentStepLabel ?? 'Provisioning',
                    taskState: mergedData.taskState ?? 'unknown',
                    timestamp: Date.now(),
                })

                if (timer) {
                    window.clearTimeout(timer)
                }
                const nextMs = Math.max(
                    10000,
                    Number(data.pollIntervalSeconds || 60) * 1000
                )
                timer = window.setTimeout(load, nextMs)
            } catch (error) {
                if (cancelled) return
                setFetchError(null)

                if (timer) {
                    window.clearTimeout(timer)
                }
                timer = window.setTimeout(load, 30000)
            }
        }

        load()
        return () => {
            cancelled = true
            if (timer) {
                window.clearTimeout(timer)
            }
        }
    }, [serverUuid])

    useEffect(() => {
        if (forceCompleted) {
            const completedState = {
                serverId: serverUuid,
                serverStatus: null,
                isProvisioning: false,
                task: null,
                taskState: 'completed',
                exitStatus: null,
                phase: 'completed' as ProvisioningPhase,
                progressPercent: 100,
                operation: 'create' as const,
                pollIntervalSeconds: 10,
                startedAt: null,
                elapsedSeconds: progressData?.elapsedSeconds ?? null,
                hasRealTaskLog: Boolean(progressData?.hasRealTaskLog),
                buildStage: 'completed',
                currentStepLabel: 'Completed',
                waitingReason: null,
                error: null,
            }
            setProgressData(completedState)
            setFetchError(null)
            persistState({
                progress: 100,
                currentStepLabel: 'Completed',
                taskState: 'completed',
                timestamp: Date.now(),
            })
        }
    }, [forceCompleted])

    useEffect(() => {
        if (forceCompleted) {
            return
        }

        if (!fetchError) {
            return
        }

        const interval = window.setInterval(() => {
            setProgressData(current => {
                if (!current) {
                    const persisted = readPersistedState()
                    const progress = Math.min(
                        95,
                        Math.max(12, Number(persisted?.progress ?? 12) + 1)
                    )
                    const next = {
                        serverId: serverUuid,
                        serverStatus: 'installing',
                        isProvisioning: true,
                        task: null,
                        taskState: persisted?.taskState ?? 'loading',
                        exitStatus: null,
                        phase: 'provisioning' as ProvisioningPhase,
                        progressPercent: progress,
                        operation: 'create' as const,
                        pollIntervalSeconds: 10,
                        startedAt: null,
                        elapsedSeconds: null,
                        hasRealTaskLog: false,
                        buildStage: null,
                        currentStepLabel:
                            persisted?.currentStepLabel ?? 'Provisioning',
                        waitingReason: null,
                        error: null,
                    }
                    persistState({
                        progress,
                        currentStepLabel: next.currentStepLabel ?? 'Provisioning',
                        taskState: next.taskState,
                        timestamp: Date.now(),
                    })
                    return next
                }

                if (current.progressPercent >= 95) {
                    return current
                }

                const next = {
                    ...current,
                    progressPercent: Math.min(95, current.progressPercent + 1),
                }
                persistState({
                    progress: next.progressPercent,
                    currentStepLabel: next.currentStepLabel ?? 'Provisioning',
                    taskState: next.taskState,
                    timestamp: Date.now(),
                })
                return next
            })
        }, 1200)

        return () => window.clearInterval(interval)
    }, [fetchError, forceCompleted, serverUuid])

    const elapsedSeconds = progressData?.elapsedSeconds ?? 0
    const progress = Math.max(
        0,
        Math.min(100, Number(progressData?.progressPercent ?? 0))
    )
    const phase: ProvisioningPhase = progressData?.phase ?? 'unknown'
    const taskState = progressData?.taskState ?? 'unknown'
    const currentStepLabel = progressData?.currentStepLabel ?? 'Provisioning'

    const phaseThresholdMap: Record<ProvisioningPhase, number> = {
        queued: 5,
        provisioning: 35,
        configuring_os: 70,
        finalizing: 92,
        completed: 100,
        unknown: 0,
    }

    const phases = [
        { label: 'Clone complete', threshold: 28 },
        { label: 'Applying hardware', threshold: 58 },
        { label: 'Applying network', threshold: 82 },
        { label: 'Finalizing', threshold: 94 },
    ]
    const effectivePhaseProgress = Math.max(
        progress,
        phaseThresholdMap[phase] ?? 0
    )

    return (
        <div className='mx-auto w-full max-w-4xl rounded-2xl border border-white/15 bg-[#140f34] p-6 shadow-[0_20px_60px_rgba(8,6,24,0.55)]'>
            <div className='flex flex-col gap-4 md:flex-row md:items-start md:justify-between'>
                <div className='min-w-0'>
                    <div className='mb-2 inline-flex items-center gap-2 rounded-full border border-cyan-300/35 bg-cyan-400/10 px-3 py-1 text-xs font-semibold text-cyan-100'>
                        <ArrowPathIcon className='h-4 w-4 animate-spin' />
                        In progress
                    </div>
                    <h2 className='text-2xl font-bold text-white'>{title}</h2>
                    <p className='mt-2 max-w-2xl text-sm text-white/75'>{description}</p>
                    <p className='mt-3 text-sm font-semibold text-cyan-100'>{currentStepLabel}</p>
                </div>

                <div className='rounded-xl border border-white/12 bg-black/25 px-4 py-3 text-right'>
                    <p className='text-xs uppercase tracking-wide text-white/55'>Elapsed</p>
                    <p className='text-lg font-semibold text-white'>{formatElapsed(elapsedSeconds)}</p>
                    <p className='mt-1 text-xs text-white/55'>Task state: {taskState}</p>
                </div>
            </div>

            <div className='mt-5'>
                <div className='mb-2 flex items-center justify-between text-xs font-semibold text-white/70'>
                    <span>Progress</span>
                    <span>{progress}%</span>
                </div>
                <div className='h-3 w-full overflow-hidden rounded-full bg-white/10'>
                    <div
                        className='h-full rounded-full bg-gradient-to-r from-sky-400 via-cyan-300 to-indigo-300 shadow-[0_0_16px_rgba(56,189,248,0.55)] transition-all duration-500'
                        style={{ width: `${progress}%` }}
                    />
                </div>
                {fetchError ? (
                    <p className='mt-2 text-xs text-amber-200/90'>{fetchError}</p>
                ) : null}
            </div>

            <div className='mt-5 grid gap-2 sm:grid-cols-2'>
                {phases.map(phase => {
                    const done = effectivePhaseProgress >= phase.threshold
                    return (
                        <div
                            key={phase.label}
                            className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-sm ${
                                done
                                    ? 'border-emerald-300/30 bg-emerald-400/10 text-emerald-100'
                                    : 'border-white/10 bg-black/20 text-white/70'
                            }`}
                        >
                            <CheckCircleIcon className={`h-4 w-4 ${done ? 'text-emerald-300' : 'text-white/35'}`} />
                            <span>{phase.label}</span>
                        </div>
                    )
                })}
            </div>
        </div>
    )
}

export default StatusProgressBlock
