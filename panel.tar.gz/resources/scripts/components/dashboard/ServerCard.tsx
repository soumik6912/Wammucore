import { formatBytes } from '@/util/helpers'
import styled from '@emotion/styled'
import { Badge } from '@mantine/core'
import { useMemo } from 'react'
import { useTranslation } from 'react-i18next'
import { Link } from 'react-router-dom'
import tw from 'twin.macro'

import { ServerBuild } from '@/api/server/getServer'
import SensitiveValue from '@/components/elements/SensitiveValue'
import { normalizeImageUrl } from '@/components/elements/SafeImage'

interface Props {
    server: ServerBuild
}

export const Dt = styled.dt`
    ${tw`text-xs font-semibold uppercase tracking-wider text-white/70`}
`

export const Dd = styled.dd<{ $isBlurred?: boolean }>`
    ${tw`text-base font-semibold text-white`}
    ${props => props.$isBlurred && `filter: blur(3px);`}
`

const statusMeta = (status: string | null) => {
    const value = String(status || '').toLowerCase()

    if (value === 'suspended') {
        return {
            label: 'Suspended',
            dotClass: 'bg-orange-400',
            badgeColor: 'orange',
            footerTextClass: 'text-orange-300',
            cardBorderClass: 'border-orange-500/40',
        }
    }

    if (value === 'installing' || value === 'restoring_backup' || value === 'restoring_snapshot') {
        return {
            label: 'Installing',
            dotClass: 'bg-amber-400',
            badgeColor: 'yellow',
            footerTextClass: 'text-amber-300',
            cardBorderClass: 'border-amber-500/40',
        }
    }

    return {
        label: 'Active',
        dotClass: 'bg-emerald-400',
        badgeColor: 'green',
        footerTextClass: 'text-emerald-300',
        cardBorderClass: 'border-emerald-500/40',
    }
}

const ServerCard = ({ server }: Props) => {
    const { t: tStrings } = useTranslation('strings')

    const memory = useMemo(() => formatBytes(server.limits.memory, 1), [server.limits.memory])
    const disk = useMemo(() => formatBytes(server.limits.disk, 1), [server.limits.disk])

    const meta = statusMeta(server.status ?? null)
    const safeCardBackgroundImageUrl = useMemo(
        () => normalizeImageUrl(server.node?.cardBackgroundImageUrl ?? null),
        [server.node?.cardBackgroundImageUrl]
    )
    const cardImageBrightness = useMemo(() => {
        const value = Number(server.node?.cardBackgroundImageBrightness ?? 25)

        return Math.max(5, Math.min(100, Number.isFinite(value) ? value : 25))
    }, [server.node?.cardBackgroundImageBrightness])
    const cardBackgroundClass = safeCardBackgroundImageUrl ? 'bg-transparent' : 'bg-[#17123b]'
    const hoverBackgroundClass = safeCardBackgroundImageUrl ? '' : 'hover:bg-[#241a52]'

    return (
        <Link
            to={`/servers/${server.id}`}
            className={`group relative isolate block overflow-hidden rounded-2xl border ${meta.cardBorderClass} ${cardBackgroundClass} shadow-lg transition-all duration-200 hover:border-white/20 ${hoverBackgroundClass}`}
        >
            {safeCardBackgroundImageUrl && (
                <>
                    <img
                        src={safeCardBackgroundImageUrl}
                        alt=''
                        aria-hidden='true'
                        className='pointer-events-none absolute inset-0 z-0 h-full w-full object-cover transition duration-300 group-hover:scale-105'
                        style={{ opacity: cardImageBrightness / 100 }}
                        decoding='async'
                        loading='lazy'
                        referrerPolicy='no-referrer'
                    />
                    <div className='pointer-events-none absolute inset-0 z-[1] bg-gradient-to-b from-[#05020f]/65 via-[#05020f]/78 to-[#05020f]/94' />
                </>
            )}

            <div className='relative z-10 p-4'>
                <div className='flex items-start justify-between gap-3'>
                    <div className='min-w-0'>
                        <p className='truncate text-lg font-bold text-white'>{server.name}</p>
                        <p className='truncate text-xs text-white/60'>
                            <SensitiveValue>{server.hostname}</SensitiveValue>
                        </p>
                        <p className='mt-1 truncate text-[11px] text-white/50'>{server.node?.name ?? `Node #${server.nodeId}`}</p>
                    </div>
                    <Badge color={meta.badgeColor} variant='light' radius='sm' size='sm'>
                        {meta.label}
                    </Badge>
                </div>

                <div className='mt-4 grid grid-cols-2 gap-2'>
                    <dl className='rounded-lg border border-white/10 bg-black/20 p-3 backdrop-blur-sm'>
                        <Dt>{tStrings('cpu')}</Dt>
                        <Dd>{server.limits.cpu} Cores</Dd>
                    </dl>
                    <dl className='rounded-lg border border-white/10 bg-black/20 p-3 backdrop-blur-sm'>
                        <Dt>{tStrings('memory')}</Dt>
                        <Dd>{memory.size} {memory.unit}</Dd>
                    </dl>
                    <dl className='rounded-lg border border-white/10 bg-black/20 p-3 backdrop-blur-sm'>
                        <Dt>{tStrings('disk')}</Dt>
                        <Dd>{disk.size} {disk.unit}</Dd>
                    </dl>
                    <dl className='rounded-lg border border-white/10 bg-black/20 p-3 backdrop-blur-sm'>
                        <Dt>{tStrings('status')}</Dt>
                        <Dd className='text-sm'>{meta.label}</Dd>
                    </dl>
                </div>

                <div className='mt-4 flex items-center justify-between border-t border-white/10 pt-3'>
                    <div className='flex items-center gap-2'>
                        <span className={`h-2 w-2 rounded-full ${meta.dotClass}`} />
                        <span className={`text-xs font-semibold uppercase tracking-wide ${meta.footerTextClass}`}>
                            {meta.label}
                        </span>
                    </div>
                    <span className='text-[11px] font-mono text-white/45'>ID: {server.id}</span>
                </div>
            </div>
        </Link>
    )
}

export default ServerCard
