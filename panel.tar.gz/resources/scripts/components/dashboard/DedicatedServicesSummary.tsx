import http from '@/api/http'
import Spinner from '@/components/elements/Spinner'
import { useStoreState } from '@/state'
import { ArrowTopRightOnSquareIcon, CpuChipIcon, ServerStackIcon } from '@heroicons/react/20/solid'
import { Link } from 'react-router-dom'
import useSWR from 'swr'

type DedicatedService = {
    id: number
    name: string
    plan: string | null
    status: string
    location: string | null
    dedicated_ip: string | null
    cpu_cores: number
    ram_gb: number
    storage_gb: number
    monitoring?: {
        status?: string
        latency_ms?: number | null
    }
}

const getDedicatedServices = async (): Promise<DedicatedService[]> => {
    const { data } = await http.get('/api/client/dedicated', { showProgress: false })

    return Array.isArray(data?.data) ? data.data : []
}

const DedicatedServicesSummary = () => {
    const tenantId = useStoreState(state => state.settings.data?.tenantId ?? null)
    const resellerAdmin = useStoreState(state => state.user.data?.resellerAdmin ?? false)
    const hiddenForTenantCustomer = tenantId !== null && !resellerAdmin

    const { data, error, mutate } = useSWR(
        hiddenForTenantCustomer ? null : '/api/client/dedicated',
        getDedicatedServices,
        {
        revalidateOnFocus: false,
        refreshInterval: 120000,
        refreshWhenHidden: false,
        refreshWhenOffline: false,
        dedupingInterval: 60000,
        }
    )

    if (hiddenForTenantCustomer) {
        return null
    }

    return (
        <section className='mt-8 rounded-2xl border border-white/10 bg-[#0b1026]/70 p-5 shadow-xl shadow-black/20'>
            <div className='flex flex-wrap items-center justify-between gap-3'>
                <div>
                    <p className='text-xs font-bold uppercase tracking-[0.25em] text-cyan-200/80'>Dedicated Plans</p>
                    <h2 className='mt-1 text-2xl font-bold text-white'>Dedicated hardware</h2>
                    <p className='mt-1 text-sm text-white/60'>Purchased dedicated Proxmox services and handover status.</p>
                </div>
                <Link
                    to='/dedicated'
                    className='inline-flex items-center gap-2 rounded-xl border border-cyan-300/30 bg-cyan-400/10 px-4 py-2 text-sm font-bold text-cyan-100 hover:bg-cyan-400/20'
                >
                    Buy Dedicated
                    <ArrowTopRightOnSquareIcon className='h-4 w-4' />
                </Link>
            </div>

            {!data && !error ? (
                <div className='py-8'>
                    <Spinner />
                </div>
            ) : error ? (
                <div className='mt-5 rounded-xl border border-red-500/25 bg-red-950/20 p-4 text-sm text-red-100'>
                    <p className='font-semibold'>Failed to load dedicated services.</p>
                    <button
                        type='button'
                        onClick={() => mutate()}
                        className='mt-3 rounded-lg border border-red-300/40 px-3 py-1.5 text-xs font-bold hover:bg-red-900/20'
                    >
                        Retry
                    </button>
                </div>
            ) : !data || data.length === 0 ? (
                <div className='mt-5 rounded-xl border border-white/10 bg-white/[0.03] p-5 text-sm text-white/70'>
                    No dedicated services yet. Choose a dedicated plan when you need full hardware control.
                </div>
            ) : (
                <div className='mt-5 grid grid-cols-1 gap-4 lg:grid-cols-2'>
                    {data.slice(0, 4).map(service => (
                        <Link
                            key={service.id}
                            to={`/dedicated/${service.id}`}
                            className='rounded-2xl border border-white/10 bg-[#090d20]/80 p-5 transition hover:border-cyan-300/35 hover:bg-[#0d1430]'
                        >
                            <div className='flex items-start justify-between gap-4'>
                                <div className='min-w-0'>
                                    <p className='truncate text-xl font-extrabold text-white'>{service.name}</p>
                                    <p className='mt-1 text-sm text-white/55'>{service.plan || 'Dedicated Server'}</p>
                                </div>
                                <span className='shrink-0 rounded-full border border-cyan-300/25 bg-cyan-400/10 px-3 py-1 text-xs font-bold uppercase text-cyan-100'>
                                    {service.status}
                                </span>
                            </div>
                            <div className='mt-4 grid grid-cols-2 gap-3 text-sm text-white/75'>
                                <span className='inline-flex items-center gap-2'>
                                    <CpuChipIcon className='h-4 w-4 text-cyan-200' />
                                    {service.cpu_cores} cores
                                </span>
                                <span className='inline-flex items-center gap-2'>
                                    <ServerStackIcon className='h-4 w-4 text-cyan-200' />
                                    {service.ram_gb} GB RAM
                                </span>
                                <span>{service.storage_gb} GB storage</span>
                                <span>{service.location || 'Location pending'}</span>
                            </div>
                            <div className='mt-4 flex flex-wrap gap-2 text-xs text-white/55'>
                                <span>IP: {service.dedicated_ip || 'pending'}</span>
                                <span>Monitoring: {service.monitoring?.status || 'unknown'}</span>
                            </div>
                        </Link>
                    ))}
                </div>
            )}
        </section>
    )
}

export default DedicatedServicesSummary
