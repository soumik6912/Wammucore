import PageContentBlock from '@/components/elements/PageContentBlock'

import ServersContainer from '@/components/dashboard/ServersContainer'
import DedicatedServicesSummary from '@/components/dashboard/DedicatedServicesSummary'

const DashboardContainer = () => {
    return (
        <PageContentBlock title='Dashboard' showFlashKey='dashboard'>
            <section className='rounded-2xl border border-white/10 bg-[#0b1026]/70 p-5 shadow-xl shadow-black/20'>
                <div className='mb-5'>
                    <p className='text-xs font-bold uppercase tracking-[0.25em] text-indigo-200/80'>VPS Plans</p>
                    <h2 className='mt-1 text-2xl font-bold text-white'>Virtual private servers</h2>
                    <p className='mt-1 text-sm text-white/60'>Your active VPS services, resource usage, and quick access cards.</p>
                </div>
                <ServersContainer />
            </section>
            <DedicatedServicesSummary />
        </PageContentBlock>
    )
}

export default DashboardContainer
