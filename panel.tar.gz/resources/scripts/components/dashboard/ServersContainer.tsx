import getServers from '@/api/getServers'
import ServerCard from '@/components/dashboard/ServerCard'
import SensitiveValue from '@/components/elements/SensitiveValue'
import Pagination from '@/components/elements/Pagination'
import Spinner from '@/components/elements/Spinner'
import { useStoreState } from '@/state'
import { usePersistedState } from '@/util/usePersistedState'
import {
    CpuChipIcon,
    MagnifyingGlassIcon,
    ServerStackIcon,
    XMarkIcon,
} from '@heroicons/react/20/solid'
import { Switch } from '@mantine/core'
import { useDebouncedValue } from '@mantine/hooks'
import { useEffect, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { useLocation, useNavigate } from 'react-router-dom'
import useSWR from 'swr'

const ServerContainer = () => {
    const { t } = useTranslation('dashboard.index')
    const { t: tStrings } = useTranslation('strings')
    const { search: location } = useLocation()
    const navigate = useNavigate()

    const defaultPage = Number(new URLSearchParams(location).get('page') || '1')
    const [page, setPage] = useState(!isNaN(defaultPage) && defaultPage > 0 ? defaultPage : 1)
    const [query, setQuery] = useState('')
    const [debouncedQuery] = useDebouncedValue(query, 200)
    const [searchOpen, setSearchOpen] = useState(false)
    const searchInputRef = useRef<HTMLInputElement | null>(null)

    const uuid = useStoreState(state => state.user.data!.email)
    const rootAdmin = useStoreState(state => state.user.data!.rootAdmin)
    const resellerAdmin = useStoreState(state => state.user.data!.resellerAdmin)
    const resellerId = useStoreState(state => state.user.data!.resellerId)
    const canShowAllServers = rootAdmin || (resellerAdmin && Number(resellerId) > 0)
    const [showAllServers, setShowAllServers] = usePersistedState(`${uuid}:show_all_servers`, false)
    const allServersEnabled = showAllServers && canShowAllServers

    const { data, error, mutate } = useSWR(
        ['/api/client/servers', allServersEnabled, page, debouncedQuery],
        () =>
            getServers({
                query: debouncedQuery,
                page,
                type: allServersEnabled ? 'all' : undefined,
                perPage: 24,
            }, { showProgress: false }),
        {
            revalidateOnFocus: false,
            refreshInterval: 60000,
            refreshWhenHidden: false,
            refreshWhenOffline: false,
            dedupingInterval: 30000,
        }
    )

    const [cachedData, setCachedData] = useState<typeof data>(undefined)

    useEffect(() => {
        if (data) {
            setCachedData(data)
        }
    }, [data])

    useEffect(() => {
        setPage(1)
    }, [debouncedQuery])

    useEffect(() => {
        if (!searchOpen) return

        searchInputRef.current?.focus()
        document.body.style.overflow = 'hidden'

        const onEscape = (event: KeyboardEvent) => {
            if (event.key === 'Escape') {
                setSearchOpen(false)
            }
        }

        document.addEventListener('keydown', onEscape)

        return () => {
            document.body.style.overflow = ''
            document.removeEventListener('keydown', onEscape)
        }
    }, [searchOpen])

    const displayData = data ?? cachedData

    if (error) {
        return (
            <div className='rounded-xl border border-red-500/30 bg-red-950/20 p-6 text-center'>
                <p className='text-base font-semibold text-red-200'>
                    Failed to load servers.
                </p>
                <p className='mt-1 text-sm text-red-200/80'>
                    Please refresh or try again in a moment.
                </p>
                <button
                    type='button'
                    onClick={() => mutate()}
                    className='mt-4 rounded-lg border border-red-300/40 px-4 py-2 text-sm text-red-100 hover:bg-red-900/20'
                >
                    Retry
                </button>
            </div>
        )
    }

    if (!displayData) {
        return <Spinner />
    }

    return (
        <div>
            <div className='mb-4 flex items-center justify-between gap-3'>
                <button
                    type='button'
                    onClick={() => setSearchOpen(true)}
                    className='inline-flex h-10 w-10 items-center justify-center rounded-xl border border-indigo-300/35 bg-indigo-500/10 text-indigo-100 hover:bg-indigo-500/20 focus-visible:outline focus-visible:outline-2 focus-visible:outline-blue-400'
                    title='Search servers'
                    aria-label='Search servers'
                >
                    <MagnifyingGlassIcon className='h-5 w-5' />
                </button>

                {canShowAllServers && (
                    <div className='flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.04] px-3 py-2'>
                        <div className='text-right'>
                            <p className='text-xs font-semibold uppercase tracking-wide text-white/75'>
                                {allServersEnabled ? 'Showing all servers' : 'Showing your servers'}
                            </p>
                        </div>
                        <Switch
                            checked={allServersEnabled}
                            onChange={() => setShowAllServers(!showAllServers)}
                            aria-label='Toggle server scope'
                        />
                    </div>
                )}
            </div>

            {displayData.pagination.total === 0 ? (
                <div className='rounded-xl border border-white/10 bg-[#1a1441]/60 p-8 text-center'>
                    <p className='text-lg font-semibold text-white'>
                        {allServersEnabled ? t('no_servers_admin_empty_state') : t('no_servers_empty_state')}
                    </p>
                </div>
            ) : (
                <Pagination data={displayData} onPageSelect={setPage}>
                    {({ items }) => (
                        <div className='grid grid-cols-1 gap-6 md:grid-cols-2'>
                            {items.map(server => (
                                <ServerCard key={server.uuid} server={server} />
                            ))}
                        </div>
                    )}
                </Pagination>
            )}

            {searchOpen && (
                <div
                    className='fixed inset-0 z-[90] bg-[#05030f]/75 backdrop-blur-sm'
                    onClick={event => {
                        if (event.target === event.currentTarget) {
                            setSearchOpen(false)
                        }
                    }}
                >
                    <div className='mx-auto mt-[18vh] w-[92vw] max-w-2xl rounded-2xl border border-white/10 bg-[#0b0733]/95 p-6 shadow-2xl shadow-black/40'>
                        <div className='mb-4 flex items-start justify-between gap-4'>
                            <div>
                                <h2 className='text-4xl font-bold text-[#f0ecff]'>Search Server</h2>
                                <p className='mt-1 text-sm text-[#b8acf0]'>
                                    Jump to a VPS quickly by name, UUID, or allocation.
                                </p>
                            </div>
                            <button
                                type='button'
                                onClick={() => setSearchOpen(false)}
                                className='inline-flex h-10 w-10 items-center justify-center rounded-lg border border-white/15 bg-white/5 text-white hover:bg-white/10'
                                aria-label='Close search'
                            >
                                <XMarkIcon className='h-5 w-5' />
                            </button>
                        </div>

                        <input
                            ref={searchInputRef}
                            type='text'
                            value={query}
                            onChange={e => setQuery(e.currentTarget.value)}
                            placeholder='Type server name, uuid, or allocation...'
                            className='h-12 w-full rounded-xl border border-white/12 bg-[#090626] px-4 text-base font-semibold text-white placeholder:text-white/40 focus:border-indigo-300 focus:outline-none focus:ring-2 focus:ring-indigo-400/20'
                        />

                        <p className='mt-2 text-sm text-[#8ea3ff]'>
                            Enter a server name, uuid, or allocation to begin searching.
                        </p>

                        {debouncedQuery.trim().length > 0 && (
                            <div className='mt-5 space-y-3'>
                                {displayData.items.length === 0 ? (
                                    <div className='rounded-xl border border-white/10 bg-[#120c3e]/70 p-4 text-sm text-white/70'>
                                        No matching servers found.
                                    </div>
                                ) : (
                                    displayData.items.slice(0, 6).map(server => {
                                        const status = (server.status ?? 'active').toLowerCase()
                                        const statusLabel =
                                            status === 'suspended'
                                                ? 'SUSPENDED'
                                                : status === 'installing'
                                                  ? 'INSTALLING'
                                                  : status === 'offline'
                                                    ? 'OFFLINE'
                                                    : 'ACTIVE'

                                        return (
                                            <div
                                                key={server.uuid}
                                                className='rounded-xl border border-white/10 bg-[#120c3e]/80 p-4 transition-colors hover:border-indigo-300/30 hover:bg-[#17124a]'
                                            >
                                                <div className='flex items-start justify-between gap-4'>
                                                    <div className='min-w-0'>
                                                        <p className='truncate text-3xl font-extrabold uppercase text-white'>
                                                            {server.name}
                                                        </p>
                                                        <p className='mt-1 truncate rounded-md bg-white/8 px-2 py-1 text-sm text-white/70'>
                                                            <SensitiveValue>{server.hostname}</SensitiveValue>
                                                        </p>
                                                    </div>
                                                    <span className='rounded-lg bg-black px-3 py-1 text-xs font-bold text-white'>
                                                        {statusLabel}
                                                    </span>
                                                </div>

                                                <div className='mt-3 flex flex-wrap items-center justify-between gap-3'>
                                                    <div className='flex flex-wrap items-center gap-4 text-sm text-white/85'>
                                                        <span className='inline-flex items-center gap-1'>
                                                            <CpuChipIcon className='h-4 w-4 text-indigo-300' />
                                                            {server.limits.cpu}%
                                                        </span>
                                                        <span className='inline-flex items-center gap-1'>
                                                            <ServerStackIcon className='h-4 w-4 text-indigo-300' />
                                                            {Math.round(server.limits.memory / 1024)}GB
                                                        </span>
                                                        <span className='inline-flex items-center gap-1'>
                                                            <ServerStackIcon className='h-4 w-4 text-indigo-300' />
                                                            {(server.limits.disk / (1024 * 1024)).toFixed(2)}GB
                                                        </span>
                                                    </div>

                                                    <button
                                                        type='button'
                                                        onClick={() => {
                                                            setSearchOpen(false)
                                                            navigate(`/servers/${server.id}`)
                                                        }}
                                                        className='rounded-lg bg-indigo-500 px-4 py-2 text-sm font-bold text-white hover:bg-indigo-400'
                                                    >
                                                        View
                                                    </button>
                                                </div>
                                            </div>
                                        )
                                    })
                                )}
                            </div>
                        )}
                    </div>
                </div>
            )}
        </div>
    )
}

export default ServerContainer
