import {
    completeReviewPrompt,
    ReviewPromptStatus,
    tickReviewPrompt,
} from '@/api/client/reviewPrompt'
import { useStoreState } from '@/state'
import { ChatBubbleBottomCenterTextIcon, StarIcon } from '@heroicons/react/24/outline'
import { useEffect, useState } from 'react'
import { useLocation } from 'react-router-dom'

const TrustpilotReviewPrompt = () => {
    const user = useStoreState(state => state.user.data)
    const configuredPanelName = useStoreState(
        state => state.settings.data?.panelName || 'WammuHost'
    )
    const location = useLocation()
    const [status, setStatus] = useState<ReviewPromptStatus | null>(null)
    const [isSubmitting, setIsSubmitting] = useState(false)

    useEffect(() => {
        const isAdmin =
            Boolean(user?.rootAdmin) ||
            Boolean(user?.platformAdmin) ||
            Boolean(user?.resellerAdmin)
        const isAdminPath =
            location.pathname === '/admin' ||
            location.pathname.startsWith('/admin/')

        if (!user || isAdmin || isAdminPath) {
            setStatus(null)
            return
        }

        let mounted = true

        tickReviewPrompt()
            .then(nextStatus => {
                if (mounted && nextStatus.enabled && nextStatus.shouldPrompt) {
                    setStatus(nextStatus)
                }
            })
            .catch(() => null)

        return () => {
            mounted = false
        }
    }, [
        location.pathname,
        user?.email,
        user?.rootAdmin,
        user?.platformAdmin,
        user?.resellerAdmin,
    ])

    if (!status?.shouldPrompt || !status.reviewUrl) {
        return null
    }

    const reviewUrl = status.reviewUrl
    const panelName = status.panelName || configuredPanelName

    const handleRate = async () => {
        if (isSubmitting) {
            return
        }

        setIsSubmitting(true)
        try {
            await completeReviewPrompt()
        } finally {
            window.location.assign(reviewUrl)
        }
    }

    return (
        <div
            role='dialog'
            aria-modal='true'
            aria-labelledby='trustpilot-review-title'
            className='fixed inset-0 z-[10000] flex items-center justify-center bg-slate-950/82 px-4 backdrop-blur-md'
        >
            <div className='relative w-full max-w-lg overflow-hidden rounded-[2rem] border border-emerald-300/25 bg-[radial-gradient(circle_at_top_left,rgba(16,185,129,0.26),transparent_34%),linear-gradient(180deg,rgba(13,20,36,0.98),rgba(7,10,20,0.98))] p-6 shadow-[0_30px_90px_rgba(0,0,0,0.55)]'>
                <div className='absolute -right-16 -top-16 h-36 w-36 rounded-full bg-emerald-400/20 blur-3xl' />
                <div className='relative'>
                    <div className='flex items-start gap-4'>
                        <div className='flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border border-emerald-300/25 bg-emerald-400/10 text-emerald-100'>
                            <ChatBubbleBottomCenterTextIcon className='h-7 w-7' />
                        </div>
                        <div>
                            <p className='text-xs font-bold uppercase tracking-[0.28em] text-emerald-200/80'>
                                Quick Review
                            </p>
                            <h2
                                id='trustpilot-review-title'
                                className='mt-2 text-2xl font-bold text-white'
                            >
                                How is your {panelName} experience?
                            </h2>
                        </div>
                    </div>

                    <div className='mt-5 flex gap-1 text-amber-300'>
                        {[0, 1, 2, 3, 4].map(index => (
                            <StarIcon
                                key={index}
                                className='h-6 w-6 fill-current'
                            />
                        ))}
                    </div>

                    <p className='mt-4 text-sm leading-7 text-white/72'>
                        If your VPS panel experience has been helpful, please rate us on Trustpilot. It only takes a moment and helps future customers trust the platform.
                    </p>

                    <div className='mt-5 rounded-2xl border border-white/10 bg-black/22 p-4 text-xs leading-6 text-white/62'>
                        This prompt appears only once per account. Click <span className='font-semibold text-white'>Rate us</span> to continue to our Trustpilot page.
                    </div>

                    <button
                        type='button'
                        onClick={handleRate}
                        disabled={isSubmitting}
                        className='mt-6 inline-flex w-full items-center justify-center rounded-2xl bg-emerald-500 px-5 py-3 text-sm font-bold text-slate-950 transition hover:bg-emerald-400 disabled:cursor-wait disabled:opacity-70'
                    >
                        {isSubmitting ? 'Opening Trustpilot...' : 'Rate us on Trustpilot'}
                    </button>
                </div>
            </div>
        </div>
    )
}

export default TrustpilotReviewPrompt
