import { MantineProvider, createEmotionCache } from '@mantine/core'
import { NotificationsProvider } from '@mantine/notifications'
import { ReactNode, useEffect, useLayoutEffect } from 'react'
import { useStoreState } from '@/state'
import { resolveThemePreset } from '@/util/themePresets'

const emotionCache = createEmotionCache({
    key: 'mantine',
    prepend: false,
})

interface Props {
    children: ReactNode
}

const readableTextOn = (hexColor: string): '#06111f' | '#ffffff' => {
    const normalized = hexColor.replace('#', '').trim()

    if (!/^[0-9a-f]{6}$/i.test(normalized)) {
        return '#ffffff'
    }

    const red = parseInt(normalized.slice(0, 2), 16) / 255
    const green = parseInt(normalized.slice(2, 4), 16) / 255
    const blue = parseInt(normalized.slice(4, 6), 16) / 255
    const linear = [red, green, blue].map(value =>
        value <= 0.03928 ? value / 12.92 : Math.pow((value + 0.055) / 1.055, 2.4)
    )
    const luminance = 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2]

    return luminance > 0.58 ? '#06111f' : '#ffffff'
}

const normalizeHex = (hexColor: string, fallback: string): string => {
    const normalized = hexColor.replace('#', '').trim()

    return /^[0-9a-f]{6}$/i.test(normalized) ? `#${normalized}` : fallback
}

const hexToRgb = (hexColor: string): [number, number, number] => {
    const normalized = normalizeHex(hexColor, '#000000').replace('#', '')

    return [
        parseInt(normalized.slice(0, 2), 16),
        parseInt(normalized.slice(2, 4), 16),
        parseInt(normalized.slice(4, 6), 16),
    ]
}

const toHexPair = (value: number): string =>
    Math.max(0, Math.min(255, Math.round(value))).toString(16).padStart(2, '0')

const mixHex = (base: string, overlay: string, overlayWeight: number): string => {
    const [baseRed, baseGreen, baseBlue] = hexToRgb(base)
    const [overlayRed, overlayGreen, overlayBlue] = hexToRgb(overlay)
    const weight = Math.max(0, Math.min(1, overlayWeight))

    return `#${toHexPair(baseRed * (1 - weight) + overlayRed * weight)}${toHexPair(
        baseGreen * (1 - weight) + overlayGreen * weight
    )}${toHexPair(baseBlue * (1 - weight) + overlayBlue * weight)}`
}

const ThemeProvider = ({ children }: Props) => {
    const settings = useStoreState(state => state.settings.data)
    const rawUserThemeKey = useStoreState(state => state.user.data?.panelThemeKey ?? null)
    const userThemeKey = rawUserThemeKey
    const tenantThemeKey = settings?.tenantThemeKey || 'wammuhost'
    const themeKey = userThemeKey || tenantThemeKey
    const preset = resolveThemePreset(themeKey)
    const primary = userThemeKey
        ? preset.primary
        : settings?.brandPrimaryColor || preset.primary
    const secondary = userThemeKey
        ? preset.secondary
        : settings?.brandSecondaryColor || preset.secondary
    const accent = userThemeKey
        ? preset.accent
        : settings?.brandAccentColor || preset.accent
    const textOnPrimary = readableTextOn(primary)

    const applyThemeVariables = () => {
        const background = normalizeHex(preset.background, '#050118')
        const card = normalizeHex(preset.card, '#17113a')
        const safePrimary = normalizeHex(primary, preset.primary)
        const safeSecondary = normalizeHex(secondary, preset.secondary)
        const safeAccent = normalizeHex(accent, preset.accent)
        const accentRamp = [
            mixHex(background, card, 0.22),
            mixHex(background, card, 0.42),
            mixHex(background, card, 0.62),
            mixHex(card, safePrimary, 0.16),
            mixHex(card, safePrimary, 0.28),
            mixHex(card, safeAccent, 0.34),
            mixHex('#aeb6d2', safeAccent, 0.18),
            mixHex('#e9eef7', safeAccent, 0.12),
        ]

        document.documentElement.classList.add('dark')
        document.documentElement.style.colorScheme = 'dark'
        document.body.style.backgroundColor = background
        document.documentElement.dataset.tenantTheme = themeKey

        document.documentElement.style.setProperty('--tenant-brand-primary', safePrimary)
        document.documentElement.style.setProperty('--tenant-brand-secondary', safeSecondary)
        document.documentElement.style.setProperty('--tenant-brand-accent', safeAccent)
        document.documentElement.style.setProperty('--tenant-bg', background)
        document.documentElement.style.setProperty('--tenant-card', card)
        document.documentElement.style.setProperty('--tenant-glow', preset.glow)
        document.documentElement.style.setProperty('--tenant-action-text', textOnPrimary)

        document.documentElement.style.setProperty('--brand-bg', background)
        document.documentElement.style.setProperty('--brand-surface', card)
        document.documentElement.style.setProperty('--brand-accent', safePrimary)
        document.documentElement.style.setProperty('--brand-accent-2', safeAccent)
        document.documentElement.style.setProperty('--brand-secondary', safeSecondary)
        document.documentElement.style.setProperty('--color-background', background)
        document.documentElement.style.setProperty('--color-foreground', '#f7fbff')
        document.documentElement.style.setProperty('--glass-bg', `color-mix(in srgb, ${card} 68%, transparent)`)
        document.documentElement.style.setProperty('--glass-bg-strong', `color-mix(in srgb, ${card} 90%, black)`)
        document.documentElement.style.setProperty('--glass-border', `color-mix(in srgb, ${safeAccent} 12%, rgba(255,255,255,0.12))`)
        document.documentElement.style.setProperty('--surface-soft', `color-mix(in srgb, ${card} 58%, transparent)`)
        document.documentElement.style.setProperty('--surface-raised', `color-mix(in srgb, ${card} 88%, ${background})`)
        document.documentElement.style.setProperty('--surface-hover', `color-mix(in srgb, ${safePrimary} 9%, ${card})`)
        document.documentElement.style.setProperty('--surface-active', `color-mix(in srgb, ${safePrimary} 14%, ${card})`)
        document.documentElement.style.setProperty('--border-soft', `color-mix(in srgb, ${safeAccent} 12%, rgba(255,255,255,0.14))`)
        document.documentElement.style.setProperty('--focus-ring', `color-mix(in srgb, ${safeAccent} 28%, transparent)`)
        document.documentElement.style.setProperty('--button-gradient', `linear-gradient(180deg, color-mix(in srgb, ${safePrimary} 88%, white), color-mix(in srgb, ${safePrimary} 78%, ${background}))`)
        document.documentElement.style.setProperty('--button-glass', `linear-gradient(180deg, color-mix(in srgb, ${card} 92%, rgba(255,255,255,0.05)), color-mix(in srgb, ${background} 82%, rgba(255,255,255,0.03)))`)
        document.documentElement.style.setProperty('--text-primary', '#f7fbff')
        document.documentElement.style.setProperty('--text-muted', 'rgba(229, 237, 255, 0.72)')

        accentRamp.forEach((color, index) => {
            document.documentElement.style.setProperty(`--color-accent-${index + 1}`, color)
        })
    }

    useLayoutEffect(() => {
        applyThemeVariables()
    }, [themeKey, primary, secondary, accent, preset, textOnPrimary])

    useEffect(() => {
        applyThemeVariables()
    }, [themeKey, primary, secondary, accent, preset, textOnPrimary])

    useEffect(() => {
        const elementId = 'tenant-custom-css'
        let styleElement = document.getElementById(elementId) as HTMLStyleElement | null

        if (!styleElement) {
            styleElement = document.createElement('style')
            styleElement.id = elementId
            document.head.appendChild(styleElement)
        }

        styleElement.textContent = settings?.customCss || ''
    }, [settings?.customCss])

    return (
        <MantineProvider
            emotionCache={emotionCache}
            theme={{
                colorScheme: 'dark',
                fontFamily: `Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";`,
            }}
        >
            <NotificationsProvider
                position='top-right'
                limit={5}
                autoClose={3800}
                zIndex={5200}
                containerWidth={460}
            >
                {children}
            </NotificationsProvider>
        </MantineProvider>
    )
}

export default ThemeProvider
