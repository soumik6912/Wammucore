import router from '@/routers/router'
import { store, useStoreState } from '@/state'
import { NavigationProgress } from '@mantine/nprogress'
import { StoreProvider } from 'easy-peasy'
import { RouterProvider } from 'react-router-dom'
import { SWRConfig } from 'swr'
import { useEffect } from 'react'

import Spinner from '@/components/elements/Spinner'
import GlobalErrorBoundary from '@/components/elements/GlobalErrorBoundary'
import { normalizeImageUrl } from '@/components/elements/SafeImage'
import OfflineRecoveryOverlay from '@/components/elements/OfflineRecoveryOverlay'

import ThemeProvider from '@/components/ThemeProvider'
import { applyDocumentFavicon } from '@/util/favicon'

const DocumentBrandingSync = () => {
    const panelName = useStoreState(state => state.settings.data?.panelName || 'WammuCore')
    const faviconUrl = useStoreState(state => state.settings.data?.faviconUrl || null)

    useEffect(() => {
        const titleParts = document.title.split('|').map(part => part.trim()).filter(Boolean)
        const pageTitle = titleParts.length > 1 ? titleParts[0] : ''

        document.title = pageTitle ? `${pageTitle} | ${panelName}` : panelName
    }, [panelName])

    useEffect(() => {
        applyDocumentFavicon(faviconUrl)
    }, [faviconUrl])

    return null
}


interface ExtendedWindow extends Window {
    WammuCoreUser?: {
        name: string
        email: string
        avatar_url?: string | null
        root_admin: boolean
        is_platform_admin?: boolean
        reseller_admin?: boolean
        reseller_id?: number | null
        reseller_onboarding_status?: string | null
        reseller_onboarding_current_step?: string | null
        reseller_onboarding_path?: string | null
        reseller_onboarding_completed?: boolean
        reseller_customer_panel_locked?: boolean
        panel_theme_key?: string | null
        admin_roles?: Array<{
            id: number
            name: string
            slug: string
        }>
        admin_permissions?: string[]
        created_at: string
        updated_at: string
    }
    SiteConfiguration?: {
        version: string
        panel_name?: string
        logo_url?: string | null
        login_background_image?: string | null
        banner_image_url?: string | null
        favicon_url?: string | null
        loading_logo_url?: string | null
        billing_url?: string | null
        platform_store_redirect_url?: string | null
        platform_admin_url?: string | null
        effective_storefront_url?: string | null
        platform_upgrade_enabled?: boolean
        platform_upgrade_url_template?: string | null
        upgrade_button_enabled?: boolean
        upgrade_url_template?: string | null
        api_docs_url?: string | null
        tutorial_url?: string | null
        reseller_registration_terms_url?: string | null
        reseller_registration_privacy_url?: string | null
        trustpilot_review_enabled?: boolean
        trustpilot_review_url?: string | null
        trustpilot_review_prompt_view_threshold?: number | string | null
        trustpilot_review_prompt_delay_days?: number | string | null
        license_catalog?: Array<{
            id?: string
            name: string
            description?: string | null
            starts_at?: string | null
            price_display?: string | null
            learn_more_url?: string | null
            purchase_url?: string | null
            icon_url?: string | null
        }>
        footer_text?: string | null
        footer_url?: string | null
        brand_primary_color?: string | null
        brand_secondary_color?: string | null
        brand_accent_color?: string | null
        custom_css?: string | null
        tenant_theme_key?: string | null
        tenant_nameservers?: string[]
        tenant_id?: number | null
        reseller_id?: number | null
        tenant_slug?: string | null
        tenant_uuid?: string | null
        tenant_hostname?: string | null
        client_auth?: {
            allow_self_registration?: boolean
            enable_email_2fa?: boolean
            enable_email_verification?: boolean
            mailer_configured?: boolean
            password_reset_enabled?: boolean
        }
        reseller_registration_meta?: {
            enabled?: boolean
            host_allowed?: boolean
            host_message?: string | null
            edge_gateway_host?: string
            verification_prefix?: string
            terms_url?: string | null
            privacy_url?: string | null
            kyc_policy?: {
                allowed_proof_types?: string[]
                aadhaar_enabled?: boolean
                pan_enabled?: boolean
                digilocker_enabled?: boolean
                digilocker_url?: string | null
            }
            email_verification_enabled?: boolean
            email_verification_available?: boolean
            email_verification_required?: boolean
            email_verification_message?: string | null
        }
    }
}

const App = () => {
    const { WammuCoreUser, SiteConfiguration } = window as ExtendedWindow

    useEffect(() => {
        applyDocumentFavicon(SiteConfiguration?.favicon_url)
    }, [SiteConfiguration?.favicon_url])

    useEffect(() => {
        const logoutKey = 'wammucore:auth-invalid-at'
        const isPublicAuthPath = (pathname: string): boolean => {
            if (
                pathname === '/auth/login' ||
                pathname === '/login' ||
                pathname === '/auth/register' ||
                pathname === '/register' ||
                pathname === '/auth/forgot-password' ||
                pathname === '/forgot-password' ||
                pathname === '/verify-email' ||
                pathname === '/reseller/login' ||
                pathname === '/reseller/register'
            ) {
                return true
            }

            return /^\/r\/[^/]+\/auth\/(login|register|forgot-password)$/.test(pathname) ||
                /^\/(?!admin(?:\/|$)|api(?:\/|$)|auth(?:\/|$)|reseller(?:\/|$)|servers(?:\/|$)|store(?:\/|$)|account(?:\/|$))[^/]+\/auth\/(login|register|forgot-password)$/.test(pathname)
        }

        const kickToLogin = () => {
            store.getActions().user.clearUserData()
            if (!isPublicAuthPath(window.location.pathname)) {
                const match = window.location.pathname.match(/^\/([^/?#]+)/)
                const firstSegment = match?.[1] ? decodeURIComponent(match[1]).trim() : ''
                const reservedSegments = new Set([
                    'admin',
                    'api',
                    'auth',
                    'authorize',
                    'assets',
                    'build',
                    'login',
                    'register',
                    'reseller',
                    'servers',
                    'store',
                    'account',
                    'forgot-password',
                    'verify-email',
                ])
                const tenantPrefix =
                    firstSegment && !reservedSegments.has(firstSegment.toLowerCase())
                        ? `/${encodeURIComponent(firstSegment)}`
                        : ''
                const target = window.location.pathname.startsWith('/admin/reseller-panel')
                    ? '/reseller/login'
                    : `${tenantPrefix}/auth/login`
                window.location.replace(target)
            }
        }

        const onInvalid = () => {
            try {
                window.localStorage.setItem(logoutKey, String(Date.now()))
            } catch {
                // Ignore storage failures; current tab still gets kicked.
            }
            kickToLogin()
        }

        const onStorage = (event: StorageEvent) => {
            if (event.key === logoutKey && event.newValue) {
                kickToLogin()
            }
        }

        window.addEventListener('wammucore:auth-invalid', onInvalid)
        window.addEventListener('storage', onStorage)

        return () => {
            window.removeEventListener('wammucore:auth-invalid', onInvalid)
            window.removeEventListener('storage', onStorage)
        }
    }, [])

    useEffect(() => {
        const fallbackUrl = normalizeImageUrl('/favicon.svg') || '/favicon.svg'
        const onImageError = (event: Event) => {
            const target = event.target

            if (!(target instanceof HTMLImageElement)) {
                return
            }

            if (target.dataset.wammuImageFallbackApplied === 'true') {
                return
            }

            target.dataset.wammuImageFallbackApplied = 'true'
            target.referrerPolicy = 'no-referrer'
            target.decoding = 'async'
            target.src = fallbackUrl
        }

        window.addEventListener('error', onImageError, true)

        return () => window.removeEventListener('error', onImageError, true)
    }, [])

    if (WammuCoreUser && !store.getState().user.data) {
        store.getActions().user.setUserData({
            name: WammuCoreUser.name,
            email: WammuCoreUser.email,
            avatarUrl: WammuCoreUser.avatar_url ?? null,
            rootAdmin: WammuCoreUser.root_admin,
            platformAdmin: Boolean(WammuCoreUser.is_platform_admin ?? false),
            resellerAdmin: Boolean(WammuCoreUser.reseller_admin ?? false),
            resellerId:
                WammuCoreUser.reseller_id === undefined
                    ? null
                    : WammuCoreUser.reseller_id,
            resellerOnboardingStatus:
                WammuCoreUser.reseller_onboarding_status ?? null,
            resellerOnboardingCurrentStep:
                WammuCoreUser.reseller_onboarding_current_step ?? null,
            resellerOnboardingPath:
                WammuCoreUser.reseller_onboarding_path ||
                '/admin/reseller-panel/onboarding',
            resellerOnboardingCompleted: Boolean(
                WammuCoreUser.reseller_onboarding_completed ?? true
            ),
            resellerCustomerPanelLocked: Boolean(
                WammuCoreUser.reseller_customer_panel_locked ?? false
            ),
            adminRoles: Array.isArray(WammuCoreUser.admin_roles)
                ? WammuCoreUser.admin_roles
                : [],
            adminPermissions: Array.isArray(WammuCoreUser.admin_permissions)
                ? WammuCoreUser.admin_permissions
                : [],
            panelThemeKey: WammuCoreUser.panel_theme_key ?? null,
            createdAt: WammuCoreUser.created_at,
            updatedAt: WammuCoreUser.updated_at,
        })
    }

    if (!store.getState().settings.data) {
        const storedTheme = localStorage.getItem('theme')
        const initialTheme =
            storedTheme === 'light' || storedTheme === 'system'
                ? storedTheme
                : 'dark'
        const initialPrivacyMode = localStorage.getItem('privacy_mode') === 'true'

        store.getActions().settings.setSettings({
            theme: initialTheme,
            version: SiteConfiguration?.version || '',
            panelName: SiteConfiguration?.panel_name || 'WammuCore',
            logoUrl: SiteConfiguration?.logo_url || null,
            loginBackgroundImage: SiteConfiguration?.login_background_image || null,
            bannerImageUrl: SiteConfiguration?.banner_image_url || null,
            faviconUrl: SiteConfiguration?.favicon_url || null,
            loadingLogoUrl: SiteConfiguration?.loading_logo_url || null,
            billingUrl: SiteConfiguration?.billing_url || null,
            platformStoreRedirectUrl:
                SiteConfiguration?.platform_store_redirect_url || null,
            platformAdminUrl: SiteConfiguration?.platform_admin_url || null,
            effectiveStorefrontUrl:
                SiteConfiguration?.effective_storefront_url || null,
            platformUpgradeEnabled:
                SiteConfiguration?.platform_upgrade_enabled ?? true,
            platformUpgradeUrlTemplate:
                SiteConfiguration?.platform_upgrade_url_template || null,
            upgradeButtonEnabled:
                SiteConfiguration?.upgrade_button_enabled ?? true,
            upgradeUrlTemplate: SiteConfiguration?.upgrade_url_template || null,
            apiDocsUrl: SiteConfiguration?.api_docs_url || null,
            tutorialUrl: SiteConfiguration?.tutorial_url || null,
            resellerRegistrationTermsUrl:
                SiteConfiguration?.reseller_registration_terms_url || null,
            resellerRegistrationPrivacyUrl:
                SiteConfiguration?.reseller_registration_privacy_url || null,
            trustpilotReview: {
                enabled: Boolean(SiteConfiguration?.trustpilot_review_enabled),
                url: SiteConfiguration?.trustpilot_review_url || null,
                viewThreshold: Number(
                    SiteConfiguration?.trustpilot_review_prompt_view_threshold ??
                        10
                ),
                delayDays: Number(
                    SiteConfiguration?.trustpilot_review_prompt_delay_days ?? 1
                ),
            },
            licenseCatalog: (SiteConfiguration?.license_catalog || []).map(item => ({
                id: item.id,
                name: item.name,
                description: item.description || null,
                startsAt: item.starts_at || null,
                priceDisplay: item.price_display || null,
                learnMoreUrl: item.learn_more_url || null,
                purchaseUrl: item.purchase_url || null,
                iconUrl: item.icon_url || null,
            })),
            footerText: SiteConfiguration?.footer_text || 'WammuCore',
            footerUrl: SiteConfiguration?.footer_url || 'https://wammuhost.com',
            brandPrimaryColor: SiteConfiguration?.brand_primary_color || null,
            brandSecondaryColor: SiteConfiguration?.brand_secondary_color || null,
            brandAccentColor: SiteConfiguration?.brand_accent_color || null,
            customCss: SiteConfiguration?.custom_css || null,
            tenantThemeKey: SiteConfiguration?.tenant_theme_key || 'wammuhost',
            tenantNameservers: Array.isArray(SiteConfiguration?.tenant_nameservers)
                ? SiteConfiguration?.tenant_nameservers
                : [],
            tenantId:
                SiteConfiguration?.tenant_id === undefined
                    ? null
                    : SiteConfiguration?.tenant_id,
            resellerId:
                SiteConfiguration?.reseller_id === undefined
                    ? null
                    : SiteConfiguration?.reseller_id,
            tenantSlug: SiteConfiguration?.tenant_slug || null,
            tenantUuid: SiteConfiguration?.tenant_uuid || null,
            tenantHostname: SiteConfiguration?.tenant_hostname || null,
            clientAuth: {
                allowSelfRegistration: Boolean(
                    SiteConfiguration?.client_auth?.allow_self_registration
                ),
                enableEmail2fa: Boolean(
                    SiteConfiguration?.client_auth?.enable_email_2fa
                ),
                enableEmailVerification: Boolean(
                    SiteConfiguration?.client_auth?.enable_email_verification
                ),
                mailerConfigured: Boolean(
                    SiteConfiguration?.client_auth?.mailer_configured
                ),
                passwordResetEnabled: Boolean(
                    SiteConfiguration?.client_auth?.password_reset_enabled
                ),
            },
            resellerRegistrationMeta: {
                enabled: Boolean(
                    SiteConfiguration?.reseller_registration_meta?.enabled
                ),
                hostAllowed: Boolean(
                    SiteConfiguration?.reseller_registration_meta?.host_allowed ?? true
                ),
                hostMessage:
                    SiteConfiguration?.reseller_registration_meta?.host_message ?? null,
                edgeGatewayHost:
                    SiteConfiguration?.reseller_registration_meta
                        ?.edge_gateway_host || 'edge.wammuhost.com',
                verificationPrefix:
                    SiteConfiguration?.reseller_registration_meta
                        ?.verification_prefix || '_wammuhost-verify',
                termsUrl:
                    SiteConfiguration?.reseller_registration_meta?.terms_url ??
                    SiteConfiguration?.reseller_registration_terms_url ??
                    null,
                privacyUrl:
                    SiteConfiguration?.reseller_registration_meta
                        ?.privacy_url ??
                    SiteConfiguration?.reseller_registration_privacy_url ??
                    null,
                kycPolicy: {
                    allowedProofTypes: Array.isArray(
                        SiteConfiguration?.reseller_registration_meta
                            ?.kyc_policy?.allowed_proof_types
                    )
                        ? SiteConfiguration?.reseller_registration_meta
                              ?.kyc_policy?.allowed_proof_types
                              ?.filter(
                                  (type): type is 'aadhaar' | 'pan' =>
                                      type === 'aadhaar' || type === 'pan'
                              ) || ['aadhaar', 'pan']
                        : ['aadhaar', 'pan'],
                    aadhaarEnabled: Boolean(
                        SiteConfiguration?.reseller_registration_meta
                            ?.kyc_policy?.aadhaar_enabled ?? true
                    ),
                    panEnabled: Boolean(
                        SiteConfiguration?.reseller_registration_meta
                            ?.kyc_policy?.pan_enabled ?? true
                    ),
                    digilockerEnabled: Boolean(
                        SiteConfiguration?.reseller_registration_meta
                            ?.kyc_policy?.digilocker_enabled
                    ),
                    digilockerUrl:
                        SiteConfiguration?.reseller_registration_meta
                            ?.kyc_policy?.digilocker_url ?? null,
                },
                emailVerificationEnabled: Boolean(
                    SiteConfiguration?.reseller_registration_meta
                        ?.email_verification_enabled
                ),
                emailVerificationAvailable: Boolean(
                    SiteConfiguration?.reseller_registration_meta
                        ?.email_verification_available
                ),
                emailVerificationRequired: Boolean(
                    SiteConfiguration?.reseller_registration_meta
                        ?.email_verification_required
                ),
                emailVerificationMessage:
                    SiteConfiguration?.reseller_registration_meta
                        ?.email_verification_message ?? null,
            },
        })
        store.getActions().settings.setPrivacyMode(initialPrivacyMode)
    }

    useEffect(() => {
        window.__wammucoreAppReady = true
    }, [])

    return (
        <StoreProvider store={store}>
            <SWRConfig
                value={{
                    revalidateOnFocus: false,
                    revalidateIfStale: true,
                    revalidateOnReconnect: true,
                    refreshWhenHidden: false,
                    refreshWhenOffline: false,
                    dedupingInterval: 20000,
                    focusThrottleInterval: 30000,
                    keepPreviousData: true,
                    errorRetryCount: 1,
                }}
            >
                <ThemeProvider>
                    <DocumentBrandingSync />
                    <NavigationProgress />
                    <OfflineRecoveryOverlay />
                    <GlobalErrorBoundary>
                        <Spinner.Suspense screen>
                            <RouterProvider router={router} />
                        </Spinner.Suspense>
                    </GlobalErrorBoundary>
                </ThemeProvider>
            </SWRConfig>
        </StoreProvider>
    )
}

export default App


