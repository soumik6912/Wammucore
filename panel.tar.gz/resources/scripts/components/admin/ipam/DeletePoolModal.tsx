import { useFlashKey } from '@/util/useFlash'
import { FormEvent, useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { KeyedMutator } from 'swr'
import useSWRMutation from 'swr/mutation'

import deleteAddressPool from '@/api/admin/addressPools/deleteAddressPool'
import {
    AddressPool,
    AddressPoolResponse,
} from '@/api/admin/addressPools/getAddressPools'

import FlashMessageRender from '@/components/elements/FlashMessageRenderer'
import MessageBox from '@/components/elements/MessageBox'
import Modal from '@/components/elements/Modal'


interface Props {
    pool: AddressPool | null
    onClose: () => void
    mutate: KeyedMutator<AddressPoolResponse>
}

const CreatePoolModal = ({ pool, onClose, mutate }: Props) => {
    const { t } = useTranslation('admin.addressPools.index')
    const { t: tStrings } = useTranslation('strings')
    const { clearFlashes, clearAndAddHttpError } = useFlashKey(
        `admin.addressPools.${pool?.id}.delete`
    )
    const [forceDelete, setForceDelete] = useState(false)

    useEffect(() => {
        setForceDelete(false)
    }, [pool?.id])
    const { trigger, isMutating } = useSWRMutation(
        ['admin.address-pools.delete', pool?.id],
        async () => {
            clearFlashes()
            try {
                await deleteAddressPool(pool!.id, forceDelete)

                mutate(data => {
                    if (!data) return data

                    return {
                        ...data,
                        items: data.items.filter(item => item.id !== pool!.id),
                    }
                }, false)

                onClose()
            } catch (e) {
                clearAndAddHttpError(e as Error)
                throw e
            }
        }
    )

    const submit = (e: FormEvent) => {
        e.preventDefault()
        trigger()
    }

    return (
        <Modal open={Boolean(pool)} onClose={onClose}>
            <Modal.Header>
                <Modal.Title>
                    {t('delete_modal.title', { name: pool?.name })}
                </Modal.Title>
            </Modal.Header>

            <form onSubmit={submit}>
                <Modal.Body>
                    {pool ? (
                        pool.nodesCount > 0 ? (
                            <>
                                <MessageBox
                                    className={'mb-3'}
                                    type={'warning'}
                                    title={'Nodes attached'}
                                >
                                    {t('delete_modal.nodes_linked_error')}
                                </MessageBox>
                                <div className='mb-5 rounded-lg border border-amber-400/40 bg-amber-900/20 p-3 text-sm text-amber-100'>
                                    <label className='flex items-start gap-2 font-semibold leading-6 text-amber-50'>
                                        <input
                                            className='mt-1 h-4 w-4 accent-amber-400'
                                            type='checkbox'
                                            checked={forceDelete}
                                            onChange={e => setForceDelete(e.target.checked)}
                                        />
                                        <span>
                                            Force delete: detach linked nodes automatically
                                        </span>
                                    </label>
                                    <p className='mt-2 pl-6 leading-6 text-amber-200/90'>
                                        This will remove node links and then delete this pool.
                                    </p>
                                </div>
                            </>
                        ) : null
                    ) : null}
                    <FlashMessageRender
                        className='mb-5'
                        byKey={`admin.addressPools.${pool?.id}.delete`}
                    />
                    <Modal.Description>
                        {t('delete_modal.description')}
                    </Modal.Description>
                </Modal.Body>

                <Modal.Actions>
                    <Modal.Action type='button' onClick={onClose}>
                        {tStrings('cancel')}
                    </Modal.Action>
                    <Modal.Action
                        type='submit'
                        disabled={pool ? pool.nodesCount > 0 && !forceDelete : false}
                        loading={isMutating}
                    >
                        {pool?.nodesCount ? (forceDelete ? 'Force Delete' : tStrings('delete')) : tStrings('delete')}
                    </Modal.Action>
                </Modal.Actions>
            </form>
        </Modal>
    )
}

export default CreatePoolModal
