import { useFlashKey } from '@/util/useFlash'
import { zodResolver } from '@hookform/resolvers/zod'
import { useEffect } from 'react'
import { FormProvider, useForm } from 'react-hook-form'
import { useTranslation } from 'react-i18next'
import { KeyedMutator } from 'swr'
import { z } from 'zod'

import {
    AddressPool,
    AddressPoolResponse,
} from '@/api/admin/addressPools/getAddressPools'
import updateAddressPool from '@/api/admin/addressPools/updateAddressPool'
import useAddressPoolNodesSWR from '@/api/admin/addressPools/useAddressPoolNodesSWR'
import useResellersSWR from '@/api/admin/resellers/useResellersSWR'

import FlashMessageRender from '@/components/elements/FlashMessageRenderer'
import CheckboxForm from '@/components/elements/forms/CheckboxForm'
import Modal from '@/components/elements/Modal'
import TextInputForm from '@/components/elements/forms/TextInputForm'

import NodesMultiSelectForm from '@/components/admin/ipam/NodesMultiSelectForm'


interface Props {
    pool: AddressPool | null
    onClose: () => void
    mutate: KeyedMutator<AddressPoolResponse>
}

const EditPoolModal = ({ pool, onClose, mutate }: Props) => {
    const { t } = useTranslation('admin.addressPools.index')
    const { t: tStrings } = useTranslation('strings')
    const { clearFlashes, clearAndAddHttpError } = useFlashKey(
        `admin.addressPools.${pool?.id}.update`
    )
    const { data: resellers } = useResellersSWR({ page: 1, perPage: 200, query: '' })
    const { data: nodes, isLoading: isLoadingNodes } = useAddressPoolNodesSWR(
        pool?.id ?? -1,
        {}
    )

    const schema = z.object({
        name: z.string().min(1).max(191),
        resellerIpPriceEach: z
            .string()
            .trim()
            .min(1)
            .refine(value => !Number.isNaN(Number(value)) && Number(value) >= 0, {
                message: 'Enter a valid per-IP price.',
            }),
        enableForResellers: z.boolean(),
        nodeIds: z.array(z.coerce.number()),
        resellerId: z
            .preprocess(
                value =>
                    value === '' || value === null || value === undefined
                        ? null
                        : Number(value),
                z.number().int().positive().nullable()
            )
            .optional(),
    })

    const form = useForm({
        resolver: zodResolver(schema),
        defaultValues: {
            name: '',
            resellerIpPriceEach: '0.00',
            enableForResellers: true,
            nodeIds: [] as string[],
            resellerId: '',
        },
    })

    useEffect(() => {
        form.reset({
            nodeIds: nodes?.items.map(node => node.id.toString()) ?? [],
            resellerIpPriceEach: pool?.resellerIpPriceEach ?? '0.00',
            enableForResellers: pool?.enableForResellers ?? true,
            resellerId: pool?.resellerId ? pool.resellerId.toString() : '',
        })
    }, [nodes])

    useEffect(() => {
        form.reset({
            name: pool?.name ?? '',
            nodeIds: nodes?.items.map(node => node.id.toString()) ?? [],
            resellerIpPriceEach: pool?.resellerIpPriceEach ?? '0.00',
            enableForResellers: pool?.enableForResellers ?? true,
            resellerId: pool?.resellerId ? pool.resellerId.toString() : '',
        })
    }, [pool])

    const handleClose = () => {
        form.reset()
        onClose()
    }

    const submit = async (_data: any) => {
        const data = _data as z.infer<typeof schema>

        clearFlashes()
        try {
            const updatedPool = await updateAddressPool(pool!.id, data)

            mutate(data => {
                if (!data) return data

                return {
                    ...data,
                    items: data.items.map(item =>
                        item.id === updatedPool.id ? updatedPool : item
                    ),
                }
            }, false)

            handleClose()
        } catch (e) {
            clearAndAddHttpError(e as Error)
        }
    }

    return (
        <Modal open={Boolean(pool)} onClose={handleClose}>
            <Modal.Header>
                <Modal.Title>
                    {t('edit_modal.title', { name: pool?.name })}
                </Modal.Title>
            </Modal.Header>

            <FormProvider {...form}>
                <form onSubmit={form.handleSubmit(submit)}>
                    <Modal.Body>
                        <FlashMessageRender
                            className='mb-5'
                            byKey={`admin.addressPools.${pool?.id}.update`}
                        />
                        <TextInputForm name='name' label={tStrings('name')} />
                        <TextInputForm
                            name='resellerIpPriceEach'
                            label='Reseller IP price each'
                            description='This pool-level per-IP base cost is controlled by root admin for reseller-side sales.'
                        />
                        <div className='mt-4 rounded-lg border border-white/10 bg-white/[0.03] p-4'>
                            <CheckboxForm
                                name='enableForResellers'
                                label='Enable for resellers'
                            />
                            <p className='mt-2 text-xs text-white/50'>
                                Disable this to keep the pool platform-only even if nodes and addresses stay attached.
                            </p>
                        </div>
                        <div className='mt-4'>
                            <label className='mb-2 block text-sm font-medium text-white/85'>
                                Exclusive Reseller Owner
                            </label>
                            <select
                                {...form.register('resellerId')}
                                className='w-full rounded-lg border border-white/15 bg-[#111a31] px-4 py-2.5 text-white outline-none focus:border-indigo-400'
                            >
                                <option value=''>Shared with all resellers</option>
                                {(resellers?.items ?? []).map(reseller => (
                                    <option key={reseller.id} value={reseller.id}>
                                        {reseller.displayName}
                                    </option>
                                ))}
                            </select>
                            <p className='mt-1 text-xs text-white/50'>
                                Leave this empty to keep the pool shared. Set a reseller here only when the whole pool should belong to that reseller alone.
                            </p>
                        </div>
                        <NodesMultiSelectForm loading={isLoadingNodes} />
                    </Modal.Body>

                    <Modal.Actions>
                        <Modal.Action type='button' onClick={handleClose}>
                            {tStrings('cancel')}
                        </Modal.Action>
                        <Modal.Action
                            type='submit'
                            loading={form.formState.isSubmitting}
                        >
                            {tStrings('save')}
                        </Modal.Action>
                    </Modal.Actions>
                </form>
            </FormProvider>
        </Modal>
    )
}

export default EditPoolModal
