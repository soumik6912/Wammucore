import usePagination from '@/util/usePagination'
import { useDebouncedValue } from '@mantine/hooks'
import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Link } from 'react-router-dom'

import { AddressPool } from '@/api/admin/addressPools/getAddressPools'
import useAddressPoolsSWR from '@/api/admin/addressPools/useAddressPoolsSWR'

import Menu from '@/components/elements/Menu'
import PageContentBlock from '@/components/elements/PageContentBlock'
import Pagination from '@/components/elements/Pagination'
import Spinner from '@/components/elements/Spinner'
import Table, {
    Actions,
    ColumnArray,
    RowActionsProps,
} from '@/components/elements/displays/Table'

import SearchBar from '@/components/admin/SearchBar'
import CreatePoolModal from '@/components/admin/ipam/CreatePoolModal'
import DeletePoolModal from '@/components/admin/ipam/DeletePoolModal'
import EditPoolModal from '@/components/admin/ipam/EditPoolModal'


const IpamContainer = () => {
    const { t: tStrings } = useTranslation('strings')
    const { t } = useTranslation('admin.addressPools.index')
    const [page, setPage] = usePagination()
    const [isCreating, setIsCreating] = useState(false)
    const [poolToDelete, setPoolToDelete] = useState<AddressPool | null>(null)
    const [poolToEdit, setPoolToEdit] = useState<AddressPool | null>(null)

    const [query, setQuery] = useState('')
    const [debouncedQuery] = useDebouncedValue(query, 200)
    const { data, mutate } = useAddressPoolsSWR({ page, query: debouncedQuery })

    const columns: ColumnArray<AddressPool> = [
        {
            header: tStrings('name'),
            accessor: 'name',
            cell: ({ value, row }) => (
                <Link
                    to={`/admin/ipam/${row.id}`}
                    className='link text-foreground'
                >
                    <span className='block font-medium text-white'>
                        #{row.id} - {value}
                    </span>
                    <span className='mt-0.5 block text-[11px] font-mono text-white/45'>
                        Pool ID #{row.id}
                    </span>
                </Link>
            ),
        },
        {
            header: 'Reseller Access',
            accessor: 'resellerAccessMode',
            cell: ({ row }) => {
                if (!row.enableForResellers) {
                    return 'Platform only'
                }

                if (row.resellerId && row.resellerDisplayName) {
                    return `Exclusive: ${row.resellerDisplayName}`
                }

                return 'Shared'
            },
        },
        {
            header: 'Reseller IP Cost',
            accessor: 'resellerIpPriceEach',
            cell: ({ value }) => `${value} / IP`,
            align: 'center',
        },
        {
            header: tStrings('node', { count: 2 }),
            accessor: 'nodesCount',
            align: 'center',
        },
        {
            header: tStrings('address_other'),
            accessor: 'addressesCount',
            align: 'center',
        },
    ]

    const rowActions = ({ row: pool }: RowActionsProps<AddressPool>) => {
        return (
            <Actions>
                <Menu.Item onClick={() => setPoolToEdit(pool)}>
                    {tStrings('edit')}
                </Menu.Item>
                <Menu.Divider />
                <Menu.Item color='red' onClick={() => setPoolToDelete(pool)}>
                    {tStrings('delete')}
                </Menu.Item>
            </Actions>
        )
    }

    return (
        <div className='min-h-screen bg-[#05020f]'>
            <PageContentBlock title={tStrings('ipam') ?? ''}>
                <CreatePoolModal
                    open={isCreating}
                    onClose={() => setIsCreating(false)}
                    mutate={mutate}
                />
                <DeletePoolModal
                    pool={poolToDelete}
                    onClose={() => setPoolToDelete(null)}
                    mutate={mutate}
                />
                <EditPoolModal
                    pool={poolToEdit}
                    onClose={() => setPoolToEdit(null)}
                    mutate={mutate}
                />
                <div className='mb-6 rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                    <SearchBar
                        value={query}
                        onChange={e => setQuery(e.target.value)}
                        buttonText={t('create_pool')}
                        onClick={() => setIsCreating(true)}
                    />
                </div>
                <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                    {!data ? (
                        <div className='flex flex-col items-center justify-center py-12'>
                            <Spinner />
                            <p className='mt-3 text-sm text-white/60'>
                                Loading IP pools...
                            </p>
                        </div>
                    ) : data.items.length === 0 ? (
                        <div className='rounded-xl border border-white/10 bg-[#111a31] p-10 text-center'>
                            <h3 className='text-lg font-semibold text-white'>
                                {query ? 'No pools found' : 'No IP pools yet'}
                            </h3>
                            <p className='mt-2 text-sm text-white/60'>
                                {query
                                    ? 'Try a different search query.'
                                    : 'Create an IP pool to get started.'}
                            </p>
                        </div>
                    ) : (
                        <Pagination data={data} onPageSelect={setPage}>
                            {({ items }) => (
                                <Table
                                    columns={columns}
                                    data={items}
                                    rowActions={rowActions}
                                    minWidth={920}
                                />
                            )}
                        </Pagination>
                    )}
                </div>
            </PageContentBlock>
        </div>
    )
}

export default IpamContainer
