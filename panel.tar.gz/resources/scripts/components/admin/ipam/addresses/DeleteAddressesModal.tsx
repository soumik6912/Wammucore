import { useFlashKey } from '@/util/useFlash'
import { FormEvent, useMemo } from 'react'
import { useTranslation } from 'react-i18next'
import { KeyedMutator } from 'swr'
import useSWRMutation from 'swr/mutation'

import deleteAddresses from '@/api/admin/addressPools/addresses/deleteAddresses'
import { AddressResponse } from '@/api/admin/nodes/addresses/getAddresses'
import { Address } from '@/api/server/getServer'

import FlashMessageRender from '@/components/elements/FlashMessageRenderer'
import Modal from '@/components/elements/Modal'

interface Props {
    addresses: Address[]
    poolId: number | null
    onClose: () => void
    mutate: KeyedMutator<AddressResponse>
}

const DeleteAddressesModal = ({ addresses, poolId, onClose, mutate }: Props) => {
    const { t: tStrings } = useTranslation('strings')
    const selectedIds = useMemo(() => addresses.map(address => address.id), [addresses])
    const selectedCount = selectedIds.length
    const flashKey = `admin.addressPools.${poolId}.addresses.bulk-delete`
    const { clearFlashes, clearAndAddHttpError } = useFlashKey(flashKey)

    const { trigger, isMutating } = useSWRMutation(
        ['admin.address-pools.addresses.bulk-delete', poolId, ...selectedIds],
        async () => {
            clearFlashes()

            try {
                await deleteAddresses(poolId!, selectedIds)

                mutate(data => {
                    if (!data) return data

                    const selectedSet = new Set(selectedIds)

                    return {
                        ...data,
                        items: data.items.filter(item => !selectedSet.has(item.id)),
                    }
                }, false)

                onClose()
            } catch (error) {
                clearAndAddHttpError(error as Error)
                throw error
            }
        }
    )

    const submit = (e: FormEvent) => {
        e.preventDefault()
        trigger()
    }

    return (
        <Modal open={selectedCount > 0} onClose={onClose}>
            <Modal.Header>
                <Modal.Title>Delete Selected IPs</Modal.Title>
            </Modal.Header>
            <form onSubmit={submit}>
                <Modal.Body>
                    <FlashMessageRender className='mb-5' byKey={flashKey} />
                    <Modal.Description>
                        {`This will delete ${selectedCount} selected IP address${selectedCount > 1 ? 'es' : ''}.`}
                    </Modal.Description>
                </Modal.Body>
                <Modal.Actions>
                    <Modal.Action type='button' onClick={onClose}>
                        {tStrings('cancel')}
                    </Modal.Action>
                    <Modal.Action type='submit' loading={isMutating}>
                        {tStrings('delete')}
                    </Modal.Action>
                </Modal.Actions>
            </form>
        </Modal>
    )
}

export default DeleteAddressesModal

