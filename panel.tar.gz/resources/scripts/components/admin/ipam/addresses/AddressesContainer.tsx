import usePagination from '@/util/usePagination'
import { httpErrorToHuman } from '@/api/http'
import { useDebouncedValue } from '@mantine/hooks'
import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Link, useMatch } from 'react-router-dom'

import bulkMacAction, {
    BulkMacAction,
    BulkMacSummary,
} from '@/api/admin/addressPools/addresses/bulkMacAction'
import exportAddressPool from '@/api/admin/addressPools/addresses/exportAddressPool'
import useAddressesSWR from '@/api/admin/addressPools/useAddressesSWR'
import { Address } from '@/api/server/getServer'

import Menu from '@/components/elements/Menu'
import Pagination from '@/components/elements/Pagination'
import Spinner from '@/components/elements/Spinner'
import Table, {
    Actions,
    ColumnArray,
    RowActionsProps,
} from '@/components/elements/displays/Table'

import SearchBar from '@/components/admin/SearchBar'
import PoolContentBlock from '@/components/admin/ipam/PoolContentBlock'
import CreateAddressModal from '@/components/admin/ipam/addresses/CreateAddressModal'
import DeleteAddressModal from '@/components/admin/ipam/addresses/DeleteAddressModal'
import EditAddressModal from '@/components/admin/ipam/addresses/EditAddressModal'
import DeleteAddressesModal from '@/components/admin/ipam/addresses/DeleteAddressesModal'


const AddressesContainer = () => {
    const { t: tStrings } = useTranslation('strings')
    const { t } = useTranslation('admin.addressPools.addresses')
    const [isCreating, setIsCreating] = useState(false)
    const [addressToEdit, setAddressToEdit] = useState<Address | null>(null)
    const [addressToDelete, setAddressToDelete] = useState<Address | null>(null)
    const [addressesToDelete, setAddressesToDelete] = useState<Address[]>([])
    const [macAction, setMacAction] = useState<BulkMacAction | 'export' | null>(
        null
    )
    const [macSummary, setMacSummary] = useState<BulkMacSummary | null>(null)
    const [macError, setMacError] = useState<string | null>(null)

    const [query, setQuery] = useState('')
    const [page, setPage] = usePagination()
    const [debouncedQuery] = useDebouncedValue(query, 200)
    const match = useMatch('/admin/ipam/:id/*')
    const poolId = Number(match?.params.id ?? 0)
    const { data, mutate } = useAddressesSWR({
        page,
        query: debouncedQuery,
        include: ['server'],
    })

    const columns: ColumnArray<Address> = [
        {
            header: tStrings('address_one'),
            accessor: 'address',
        },
        {
            header: tStrings('cidr'),
            accessor: 'cidr',
        },
        {
            header: tStrings('gateway'),
            accessor: 'gateway',
        },
        {
            header: tStrings('mac_address'),
            accessor: 'macAddress',
        },
        {
            header: tStrings('type'),
            accessor: 'type',
        },
        {
            header: tStrings('server'),
            accessor: 'server',
            cell: ({ value, row }) =>
                value ? (
                    <Link
                        to={`/admin/servers/${value.uuidShort}`}
                        className='link text-foreground'
                    >
                        {value.hostname}
                    </Link>
                ) : (
                    <span
                        className={
                            row.claimStatus === 'claimed_by_reseller'
                                ? 'text-yellow-300'
                                : row.claimStatus === 'reserved_for_customer'
                                ? 'text-blue-300'
                                : 'text-foreground/50'
                        }
                    >
                        {row.claimLabel}
                    </span>
                ),
        },
    ]

    const rowActions = ({ row: address }: RowActionsProps<Address>) => {
        return (
            <Actions>
                <Menu.Item onClick={() => setAddressToEdit(address)}>
                    {tStrings('edit')}
                </Menu.Item>
                <Menu.Divider />
                <Menu.Item
                    color='red'
                    onClick={() => setAddressToDelete(address)}
                >
                    {tStrings('delete')}
                </Menu.Item>
            </Actions>
        )
    }

    const runPoolMacAction = async (action: BulkMacAction) => {
        if (!poolId || macAction) return

        setMacAction(action)
        setMacSummary(null)
        setMacError(null)

        try {
            const summary = await bulkMacAction(poolId, action)
            setMacSummary(summary)
            await mutate()
        } catch (error) {
            setMacError(httpErrorToHuman(error))
        } finally {
            setMacAction(null)
        }
    }

    const runExport = async () => {
        if (!poolId || macAction) return

        setMacAction('export')
        setMacError(null)

        try {
            await exportAddressPool(poolId)
        } catch (error) {
            setMacError(httpErrorToHuman(error))
        } finally {
            setMacAction(null)
        }
    }

    const summaryText = macSummary
        ? [
              `Scanned ${macSummary.scanned}`,
              `missing MAC ${macSummary.missingMac}`,
              `fetched ${macSummary.fetched}`,
              `generated ${macSummary.generated}`,
              `skipped ${macSummary.skippedExisting + macSummary.skippedNoServer + macSummary.skippedAttached + macSummary.skippedNotFound}`,
              `failed ${macSummary.failed}`,
          ].join(' | ')
        : null

    const actionButtonClass =
        'rounded-lg border px-3 py-2 text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-50'

    return (
        <div className='min-h-screen bg-[#05020f]'>
            <PoolContentBlock title={tStrings('address_other') ?? 'Addresses'}>
                <CreateAddressModal
                    open={isCreating}
                    onClose={() => setIsCreating(false)}
                    mutate={mutate}
                />
                <EditAddressModal
                    address={addressToEdit}
                    onClose={() => setAddressToEdit(null)}
                    mutate={mutate}
                />
                <DeleteAddressModal
                    address={addressToDelete}
                    onClose={() => setAddressToDelete(null)}
                    mutate={mutate}
                />
                <DeleteAddressesModal
                    addresses={addressesToDelete}
                    poolId={addressesToDelete[0]?.addressPoolId ?? null}
                    onClose={() => setAddressesToDelete([])}
                    mutate={mutate}
                />
                <div className='mb-6 rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                    <SearchBar
                        value={query}
                        onChange={e => setQuery(e.target.value)}
                        buttonText={t('create_address')}
                        onClick={() => setIsCreating(true)}
                    />
                    <div className='mt-4 rounded-xl border border-white/10 bg-[#100b2f]/80 p-4'>
                        <div className='flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between'>
                            <div>
                                <p className='text-sm font-semibold text-white'>
                                    Pool MAC tools
                                </p>
                                <p className='mt-1 text-xs text-white/55'>
                                    Run these for the full pool. Existing MAC values are not overwritten.
                                </p>
                            </div>
                            <div className='grid gap-2 sm:grid-cols-2 xl:grid-cols-4'>
                                <button
                                    type='button'
                                    disabled={macAction !== null}
                                    onClick={() => void runPoolMacAction('fetch')}
                                    className={`${actionButtonClass} border-blue-400/40 bg-blue-500/15 text-blue-100 hover:bg-blue-500/25`}
                                >
                                    {macAction === 'fetch'
                                        ? 'Fetching...'
                                        : 'Fetch MAC from VPS'}
                                </button>
                                <button
                                    type='button'
                                    disabled={macAction !== null}
                                    onClick={() => void runPoolMacAction('generate')}
                                    className={`${actionButtonClass} border-emerald-400/40 bg-emerald-500/15 text-emerald-100 hover:bg-emerald-500/25`}
                                >
                                    {macAction === 'generate'
                                        ? 'Generating...'
                                        : 'Generate Random MAC'}
                                </button>
                                <button
                                    type='button'
                                    disabled={macAction !== null}
                                    onClick={() =>
                                        void runPoolMacAction('fetch_or_generate')
                                    }
                                    className={`${actionButtonClass} border-cyan-400/40 bg-cyan-500/15 text-cyan-100 hover:bg-cyan-500/25`}
                                >
                                    {macAction === 'fetch_or_generate'
                                        ? 'Syncing...'
                                        : 'Fetch or Create MAC'}
                                </button>
                                <button
                                    type='button'
                                    disabled={macAction !== null}
                                    onClick={() => void runExport()}
                                    className={`${actionButtonClass} border-amber-400/40 bg-amber-500/15 text-amber-100 hover:bg-amber-500/25`}
                                >
                                    {macAction === 'export'
                                        ? 'Exporting...'
                                        : 'Export TXT'}
                                </button>
                            </div>
                        </div>
                        {summaryText ? (
                            <div className='mt-3 rounded-lg border border-emerald-400/25 bg-emerald-500/10 px-3 py-2 text-sm text-emerald-100'>
                                {summaryText}
                            </div>
                        ) : null}
                        {macError ? (
                            <div className='mt-3 rounded-lg border border-rose-400/25 bg-rose-500/10 px-3 py-2 text-sm text-rose-100'>
                                {macError}
                            </div>
                        ) : null}
                        {macSummary?.messages.length ? (
                            <div className='mt-3 rounded-lg border border-amber-400/25 bg-amber-500/10 px-3 py-2 text-xs text-amber-100'>
                                {macSummary.messages.join(' | ')}
                            </div>
                        ) : null}
                    </div>
                </div>
                <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                    {!data ? (
                        <div className='flex flex-col items-center justify-center py-12'>
                            <Spinner />
                            <p className='mt-3 text-sm text-white/60'>
                                Loading addresses...
                            </p>
                        </div>
                    ) : data.items.length === 0 ? (
                        <div className='rounded-xl border border-white/10 bg-[#111a31] p-10 text-center'>
                            <h3 className='text-lg font-semibold text-white'>
                                {query
                                    ? 'No addresses found'
                                    : 'No addresses in this pool'}
                            </h3>
                            <p className='mt-2 text-sm text-white/60'>
                                {query
                                    ? 'Try a different search query.'
                                    : 'Create an address to get started.'}
                            </p>
                        </div>
                    ) : (
                        <Pagination data={data} onPageSelect={setPage}>
                            {({ items }) => (
                                <Table
                                    columns={columns}
                                    data={items}
                                    selectable
                                    headerActions={({ rows }) => {
                                        const selectedAddresses = Object.entries(
                                            rows
                                        )
                                            .filter(([, isSelected]) =>
                                                Boolean(isSelected)
                                            )
                                            .map(([rowIndex]) => {
                                                return items[
                                                    Number(rowIndex)
                                                ]
                                            })
                                            .filter(
                                                (
                                                    address
                                                ): address is Address =>
                                                    Boolean(address)
                                            )

                                        if (selectedAddresses.length === 0) {
                                            return (
                                                <Menu.Item disabled>
                                                    Select one or more IPs
                                                </Menu.Item>
                                            )
                                        }

                                        return (
                                            <Menu.Item
                                                color='red'
                                                onClick={() =>
                                                    setAddressesToDelete(
                                                        selectedAddresses
                                                    )
                                                }
                                            >
                                                Delete selected (
                                                {selectedAddresses.length})
                                            </Menu.Item>
                                        )
                                    }}
                                    rowActions={rowActions}
                                    minWidth={980}
                                />
                            )}
                        </Pagination>
                    )}
                </div>
            </PoolContentBlock>
        </div>
    )
}

export default AddressesContainer
