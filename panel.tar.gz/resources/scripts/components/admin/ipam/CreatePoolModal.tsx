import { useFlashKey } from '@/util/useFlash'
import { zodResolver } from '@hookform/resolvers/zod'
import { FormProvider, useForm } from 'react-hook-form'
import { useTranslation } from 'react-i18next'
import { KeyedMutator } from 'swr'
import { z } from 'zod'

import createAddressPool from '@/api/admin/addressPools/createAddressPool'
import { AddressPoolResponse } from '@/api/admin/addressPools/getAddressPools'
import useResellersSWR from '@/api/admin/resellers/useResellersSWR'

import FlashMessageRender from '@/components/elements/FlashMessageRenderer'
import CheckboxForm from '@/components/elements/forms/CheckboxForm'
import Modal from '@/components/elements/Modal'
import TextInputForm from '@/components/elements/forms/TextInputForm'

import NodesMultiSelectForm from '@/components/admin/ipam/NodesMultiSelectForm'


interface Props {
    open: boolean
    onClose: () => void
    mutate: KeyedMutator<AddressPoolResponse>
}

const CreatePoolModal = ({ open, onClose, mutate }: Props) => {
    const { t: tStrings } = useTranslation('strings')
    const { t } = useTranslation('admin.addressPools.index')
    const { clearFlashes, clearAndAddHttpError } = useFlashKey(
        `admin.addressPools.create`
    )
    const { data: resellers } = useResellersSWR({ page: 1, perPage: 200, query: '' })

    const schema = z.object({
        name: z.string().nonempty().max(191),
        resellerIpPriceEach: z
            .string()
            .trim()
            .min(1)
            .refine(value => !Number.isNaN(Number(value)) && Number(value) >= 0, {
                message: 'Enter a valid per-IP price.',
            }),
        enableForResellers: z.boolean(),
        nodeIds: z.array(z.coerce.number()),
        resellerId: z
            .preprocess(
                value =>
                    value === '' || value === null || value === undefined
                        ? null
                        : Number(value),
                z.number().int().positive().nullable()
            )
            .optional(),
    })

    const form = useForm({
        resolver: zodResolver(schema),
        defaultValues: {
            name: '',
            resellerIpPriceEach: '0.00',
            enableForResellers: true,
            nodeIds: [],
            resellerId: '',
        },
    })

    const handleClose = () => {
        form.reset()
        onClose()
    }

    const submit = async (_data: any) => {
        const data = _data as z.infer<typeof schema>

        clearFlashes()
        try {
            const pool = await createAddressPool(data)

            mutate(data => {
                if (!data) return data
                if (data.pagination.currentPage !== 1) return data

                return {
                    ...data,
                    items: [pool, ...data.items],
                }
            }, false)

            handleClose()
        } catch (e) {
            clearAndAddHttpError(e as Error)
        }
    }

    return (
        <Modal open={open} onClose={handleClose}>
            <Modal.Header>
                <Modal.Title>{t('create_pool')}</Modal.Title>
            </Modal.Header>

            <FormProvider {...form}>
                <form onSubmit={form.handleSubmit(submit)}>
                    <Modal.Body>
                        <FlashMessageRender
                            className='mb-5'
                            byKey={`admin.addressPools.create`}
                        />
                        <TextInputForm name='name' label={tStrings('name')} />
                        <TextInputForm
                            name='resellerIpPriceEach'
                            label='Reseller IP price each'
                            description='Root admin sets this shared per-IP base cost for reseller-side sales.'
                        />
                        <div className='mt-4 rounded-lg border border-white/10 bg-white/[0.03] p-4'>
                            <CheckboxForm
                                name='enableForResellers'
                                label='Enable for resellers'
                            />
                            <p className='mt-2 text-xs text-white/50'>
                                Enabled pools can be used in reseller plan pricing and reseller customer VPS orders.
                            </p>
                        </div>
                        <div className='mt-4'>
                            <label className='mb-2 block text-sm font-medium text-white/85'>
                                Exclusive Reseller Owner
                            </label>
                            <select
                                {...form.register('resellerId')}
                                className='w-full rounded-lg border border-white/15 bg-[#111a31] px-4 py-2.5 text-white outline-none focus:border-indigo-400'
                            >
                                <option value=''>Shared with all resellers</option>
                                {(resellers?.items ?? []).map(reseller => (
                                    <option key={reseller.id} value={reseller.id}>
                                        {reseller.displayName}
                                    </option>
                                ))}
                            </select>
                            <p className='mt-1 text-xs text-white/50'>
                                Leave this empty to keep the pool shared. Set a reseller here only when the entire pool should belong to that reseller alone.
                            </p>
                        </div>
                        <NodesMultiSelectForm />
                    </Modal.Body>

                    <Modal.Actions>
                        <Modal.Action type='button' onClick={handleClose}>
                            {tStrings('cancel')}
                        </Modal.Action>
                        <Modal.Action
                            type='submit'
                            loading={form.formState.isSubmitting}
                        >
                            {tStrings('create')}
                        </Modal.Action>
                    </Modal.Actions>
                </form>
            </FormProvider>
        </Modal>
    )
}

export default CreatePoolModal
