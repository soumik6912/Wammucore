import useTenantContextSWR from '@/api/admin/tenancy/useTenantContextSWR'
import Spinner from '@/components/elements/Spinner'
import { lazy } from 'react'
import { Navigate } from 'react-router-dom'

const OverviewContainer = lazy(
    () => import('@/components/admin/overview/OverviewContainer')
)

const AdminHomeContainer = () => {
    const { data: tenantContext } = useTenantContextSWR()

    if (!tenantContext) {
        return <Spinner />
    }

    if (tenantContext.mode === 'reseller') {
        return <Navigate to='/admin/reseller-panel' replace />
    }

    return (
        <Spinner.Suspense>
            <OverviewContainer />
        </Spinner.Suspense>
    )
}

export default AdminHomeContainer
