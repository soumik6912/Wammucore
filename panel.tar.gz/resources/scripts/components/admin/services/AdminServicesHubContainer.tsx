import PageContentBlock from '@/components/elements/PageContentBlock'
import {
    ArrowRightIcon,
    CircleStackIcon,
    CpuChipIcon,
    ServerStackIcon,
    Squares2X2Icon,
    UserGroupIcon,
} from '@heroicons/react/24/outline'
import { Link } from 'react-router-dom'

const serviceCards = [
    {
        title: 'VPS Services',
        description: 'View platform and reseller VPS, owners, nodes, IPs, state, and server actions.',
        href: '/admin/servers',
        action: 'Open VPS services',
        icon: ServerStackIcon,
    },
    {
        title: 'VPS Plans',
        description: 'Edit VPS plan specs, pricing, categories, CPU topology, RAM, disk, bandwidth, and IP defaults.',
        href: '/admin/plans',
        action: 'Edit VPS plans',
        icon: CpuChipIcon,
    },
    {
        title: 'IP Plans',
        description: 'Manage IP pools, stock, reseller access, pool IDs, pricing, and address assignment.',
        href: '/admin/ipam',
        action: 'Open IP plans',
        icon: CircleStackIcon,
    },
    {
        title: 'Dedicated',
        description: 'Handle purchased dedicated services, setup requests, purchased IPs, inventory, and dedicated plans.',
        href: '/admin/dedicated',
        action: 'Open dedicated',
        icon: Squares2X2Icon,
    },
    {
        title: 'Users',
        description: 'Open a customer profile to review linked VPS, IP, reseller, billing, KYC, and dedicated records.',
        href: '/admin/users',
        action: 'Find user',
        icon: UserGroupIcon,
    },
]

export default function AdminServicesHubContainer() {
    return (
        <PageContentBlock title='Services' containerSize='wide'>
            <div className='space-y-6'>
                <section className='rounded-3xl border border-[var(--border-color)] bg-[var(--surface-card)] p-6 shadow-xl shadow-black/10'>
                    <p className='text-xs font-bold uppercase tracking-[0.35em] text-[var(--text-muted)]'>
                        Root Admin
                    </p>
                    <div className='mt-3 max-w-4xl'>
                        <h1 className='text-3xl font-black text-[var(--text-primary)]'>
                            Services Control
                        </h1>
                        <p className='mt-2 text-sm leading-6 text-[var(--text-secondary)]'>
                            One place for VPS services, VPS plans, IP plans, dedicated services,
                            purchased IPs, and per-user service lookup.
                        </p>
                    </div>
                </section>

                <section className='grid gap-4 md:grid-cols-2 xl:grid-cols-3'>
                    {serviceCards.map(card => {
                        const Icon = card.icon

                        return (
                            <Link
                                key={card.href}
                                to={card.href}
                                className='group rounded-3xl border border-[var(--border-color)] bg-[var(--surface-card)] p-5 transition hover:-translate-y-0.5 hover:border-[var(--accent-primary)] hover:shadow-2xl hover:shadow-[var(--accent-primary)]/10'
                            >
                                <div className='flex items-start gap-4'>
                                    <div className='rounded-2xl border border-[var(--border-color)] bg-[var(--surface-hover)] p-3 text-[var(--accent-primary)]'>
                                        <Icon className='h-6 w-6' />
                                    </div>
                                    <div className='min-w-0 flex-1'>
                                        <h2 className='text-lg font-black text-[var(--text-primary)]'>
                                            {card.title}
                                        </h2>
                                        <p className='mt-2 text-sm leading-6 text-[var(--text-secondary)]'>
                                            {card.description}
                                        </p>
                                        <span className='mt-4 inline-flex items-center gap-2 rounded-xl border border-[var(--border-color)] px-3 py-2 text-sm font-bold text-[var(--text-primary)] transition group-hover:border-[var(--accent-primary)] group-hover:text-[var(--accent-primary)]'>
                                            {card.action}
                                            <ArrowRightIcon className='h-4 w-4' />
                                        </span>
                                    </div>
                                </div>
                            </Link>
                        )
                    })}
                </section>
            </div>
        </PageContentBlock>
    )
}
