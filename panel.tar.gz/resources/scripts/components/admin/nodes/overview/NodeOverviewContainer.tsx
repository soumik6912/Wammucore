import NodeContentBlock from '@/components/admin/nodes/NodeContentBlock'
import NodeDetailsBlock from '@/components/admin/nodes/overview/NodeDetailsBlock'

const NodeOverviewContainer = () => {
    return (
        <NodeContentBlock title='Overview'>
            <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4'>
                <NodeDetailsBlock />
            </div>
        </NodeContentBlock>
    )
}

export default NodeOverviewContainer