import { formatBytes } from '@/util/helpers'
import { useMemo } from 'react'
import { useTranslation } from 'react-i18next'

import useNodeResourcesSWR from '@/api/admin/nodes/useNodeResourcesSWR'
import useNodeSWR from '@/api/admin/nodes/useNodeSWR'

const NodeDetailsBlock = () => {
    const { data: node } = useNodeSWR()
    const { data: resources, error: resourcesError } = useNodeResourcesSWR(node?.id)
    const { t } = useTranslation('admin.nodes.index')

    if (!node) {
        return null
    }

    const memory = useMemo(() => {
        const total = formatBytes(node.memory, 2)
        const used = formatBytes(node.memoryAllocated, 2, total.unit)
        const percentage = node.memory > 0 ? (node.memoryAllocated / node.memory) * 100 : 0
        const free = node.memory - node.memoryAllocated
        const freeFormatted = formatBytes(free, 2)

        return { used, total, percentage, free: freeFormatted }
    }, [node.memory, node.memoryAllocated])

    const disk = useMemo(() => {
        const total = formatBytes(node.disk, 2)
        const used = formatBytes(node.diskAllocated, 2, total.unit)
        const percentage = node.disk > 0 ? (node.diskAllocated / node.disk) * 100 : 0
        const free = node.disk - node.diskAllocated
        const freeFormatted = formatBytes(free, 2)

        return { used, total, percentage, free: freeFormatted }
    }, [node.disk, node.diskAllocated])

    const live = useMemo(() => {
        const toNumber = (value: unknown): number => {
            const parsed = typeof value === 'number' ? value : Number(value)
            return Number.isFinite(parsed) ? parsed : 0
        }

        const clampPercent = (value: number): number => Math.max(0, Math.min(100, value))

        const formatUptime = (seconds: number): string => {
            if (seconds <= 0) return '0s'

            const days = Math.floor(seconds / 86400)
            const hours = Math.floor((seconds % 86400) / 3600)
            const minutes = Math.floor((seconds % 3600) / 60)

            if (days > 0) return `${days}d ${hours}h`
            if (hours > 0) return `${hours}h ${minutes}m`
            return `${minutes}m`
        }

        const nodeLive = resources?.node || {}
        const status = resources?.status || {}

        const cpuRaw = toNumber(nodeLive.cpu || status.cpu)
        const cpuPercent = clampPercent(cpuRaw * 100)
        const cpuCores = toNumber(nodeLive.maxcpu || status.cpuinfo?.cpus)

        const memUsed = toNumber(nodeLive.mem || status.memory?.used)
        const memTotal = toNumber(nodeLive.maxmem || status.memory?.total)
        const memPercent = memTotal > 0 ? clampPercent((memUsed / memTotal) * 100) : 0

        const diskUsed = toNumber(nodeLive.disk || status.rootfs?.used)
        const diskTotal = toNumber(nodeLive.maxdisk || status.rootfs?.total)
        const diskPercent = diskTotal > 0 ? clampPercent((diskUsed / diskTotal) * 100) : 0

        const uptime = toNumber(nodeLive.uptime || status.uptime)

        const nodeState = String(nodeLive.status || status.status || 'unknown').toLowerCase()

        const storages = resources?.storages || []
        const networks = resources?.networks || []

        const bridges = networks.filter((network) => network?.type === 'bridge')
        const vlanAwareBridges = bridges.filter((network) => String(network?.['bridge-vlan-aware']) === '1')

        return {
            nodeState,
            cpuPercent,
            cpuCores,
            memUsed: formatBytes(memUsed, 2),
            memTotal: formatBytes(memTotal, 2),
            memPercent,
            diskUsed: formatBytes(diskUsed, 2),
            diskTotal: formatBytes(diskTotal, 2),
            diskPercent,
            uptime: formatUptime(uptime),
            pveVersion: String(status.pveversion || 'Unknown'),
            kernelVersion: String(status.kversion || 'Unknown'),
            vmSummary: resources?.vmsSummary || { total: 0, running: 0, stopped: 0, qemu: 0, lxc: 0 },
            storageCount: storages.length,
            activeStorageCount: storages.filter((storage) => storage?.active === 1).length,
            enabledStorageCount: storages.filter((storage) => storage?.enabled === 1).length,
            networkCount: networks.length,
            bridgeCount: bridges.length,
            vlanAwareBridgeCount: vlanAwareBridges.length,
        }
    }, [resources])

    const getBarColor = (percent: number) => {
        if (percent >= 90) return 'from-red-500 to-red-600'
        if (percent >= 75) return 'from-orange-500 to-orange-600'
        if (percent >= 50) return 'from-yellow-500 to-yellow-600'
        return 'from-emerald-500 to-emerald-600'
    }

    const getGlowColor = (percent: number) => {
        if (percent >= 90) return 'shadow-red-500/20'
        if (percent >= 75) return 'shadow-orange-500/20'
        if (percent >= 50) return 'shadow-yellow-500/20'
        return 'shadow-emerald-500/20'
    }

    return (
        <>
            <div className='group bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/40 hover:border-gray-600/60 transition-all duration-300 hover:shadow-lg hover:shadow-gray-900/50 hover:-translate-y-1 md:col-span-2'>
                <div className='flex items-start justify-between gap-4'>
                    <div>
                        <h3 className='text-white text-lg font-semibold leading-tight'>{node.name}</h3>
                        <p className='text-gray-400 text-sm mt-1'>
                            {node.cluster} - {node.fqdn}:{node.port}
                        </p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider ${live.nodeState === 'online' ? 'text-emerald-300 bg-emerald-500/20 border border-emerald-500/30' : 'text-amber-300 bg-amber-500/20 border border-amber-500/30'}`}>
                        {live.nodeState}
                    </span>
                </div>

                <div className='grid grid-cols-2 gap-3 mt-5 text-sm'>
                    <div className='rounded-xl border border-gray-700/40 bg-black/20 px-3 py-2'>
                        <p className='text-gray-500 text-xs uppercase tracking-wider'>Proxmox</p>
                        <p className='text-gray-100 font-medium mt-1'>{live.pveVersion}</p>
                    </div>
                    <div className='rounded-xl border border-gray-700/40 bg-black/20 px-3 py-2'>
                        <p className='text-gray-500 text-xs uppercase tracking-wider'>Kernel</p>
                        <p className='text-gray-100 font-medium mt-1'>{live.kernelVersion}</p>
                    </div>
                    <div className='rounded-xl border border-gray-700/40 bg-black/20 px-3 py-2'>
                        <p className='text-gray-500 text-xs uppercase tracking-wider'>Uptime</p>
                        <p className='text-gray-100 font-medium mt-1'>{live.uptime}</p>
                    </div>
                    <div className='rounded-xl border border-gray-700/40 bg-black/20 px-3 py-2'>
                        <p className='text-gray-500 text-xs uppercase tracking-wider'>CPU Cores</p>
                        <p className='text-gray-100 font-medium mt-1'>{live.cpuCores || 0}</p>
                    </div>
                </div>

                {resourcesError && (
                    <p className='mt-4 text-xs text-amber-300'>
                        Live Proxmox stats are temporarily unavailable.
                    </p>
                )}
            </div>

            <div className='group bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/40 hover:border-gray-600/60 transition-all duration-300 hover:shadow-lg hover:shadow-gray-900/50 hover:-translate-y-1'>
                <div className='flex items-center justify-between mb-4'>
                    <h3 className='text-gray-400 text-xs font-semibold uppercase tracking-wider'>Live CPU</h3>
                </div>
                <div className='mb-5'>
                    <span className='text-white text-5xl font-bold leading-none tracking-tight'>
                        {live.cpuPercent.toFixed(1)}
                    </span>
                    <span className='text-gray-400 text-xl font-semibold ml-2'>%</span>
                </div>
                <div className='relative h-2 bg-gray-700/40 rounded-full overflow-hidden'>
                    <div
                        className={`absolute inset-y-0 left-0 bg-gradient-to-r ${getBarColor(live.cpuPercent)} rounded-full transition-all duration-700 ease-out ${getGlowColor(live.cpuPercent)} shadow-lg`}
                        style={{ width: `${Math.min(live.cpuPercent, 100)}%` }}
                    />
                </div>
            </div>

            <div className='group bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/40 hover:border-gray-600/60 transition-all duration-300 hover:shadow-lg hover:shadow-gray-900/50 hover:-translate-y-1'>
                <div className='flex items-center justify-between mb-4'>
                    <h3 className='text-gray-400 text-xs font-semibold uppercase tracking-wider'>Live Memory</h3>
                </div>
                <div className='mb-5'>
                    <span className='text-white text-3xl font-bold leading-none tracking-tight'>
                        {live.memUsed.size}{live.memUsed.unit}
                    </span>
                    <p className='text-xs text-gray-500 mt-2'>
                        {live.memTotal.size}{live.memTotal.unit} total - {live.memPercent.toFixed(1)}%
                    </p>
                </div>
                <div className='relative h-2 bg-gray-700/40 rounded-full overflow-hidden'>
                    <div
                        className={`absolute inset-y-0 left-0 bg-gradient-to-r ${getBarColor(live.memPercent)} rounded-full transition-all duration-700 ease-out ${getGlowColor(live.memPercent)} shadow-lg`}
                        style={{ width: `${Math.min(live.memPercent, 100)}%` }}
                    />
                </div>
            </div>

            <div className='group bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/40 hover:border-gray-600/60 transition-all duration-300 hover:shadow-lg hover:shadow-gray-900/50 hover:-translate-y-1'>
                <div className='flex items-center justify-between mb-4'>
                    <h3 className='text-gray-400 text-xs font-semibold uppercase tracking-wider'>Live Disk</h3>
                </div>
                <div className='mb-5'>
                    <span className='text-white text-3xl font-bold leading-none tracking-tight'>
                        {live.diskUsed.size}{live.diskUsed.unit}
                    </span>
                    <p className='text-xs text-gray-500 mt-2'>
                        {live.diskTotal.size}{live.diskTotal.unit} total - {live.diskPercent.toFixed(1)}%
                    </p>
                </div>
                <div className='relative h-2 bg-gray-700/40 rounded-full overflow-hidden'>
                    <div
                        className={`absolute inset-y-0 left-0 bg-gradient-to-r ${getBarColor(live.diskPercent)} rounded-full transition-all duration-700 ease-out ${getGlowColor(live.diskPercent)} shadow-lg`}
                        style={{ width: `${Math.min(live.diskPercent, 100)}%` }}
                    />
                </div>
            </div>

            <div className='group bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/40 hover:border-gray-600/60 transition-all duration-300 hover:shadow-lg hover:shadow-gray-900/50 hover:-translate-y-1'>
                <div className='flex items-center justify-between mb-4'>
                    <h3 className='text-gray-400 text-xs font-semibold uppercase tracking-wider'>VM Summary</h3>
                </div>
                <div className='grid grid-cols-2 gap-3 text-sm'>
                    <div className='rounded-xl border border-gray-700/40 bg-black/20 px-3 py-2'>
                        <p className='text-gray-500 text-xs uppercase tracking-wider'>Total</p>
                        <p className='text-gray-100 font-medium mt-1'>{live.vmSummary.total}</p>
                    </div>
                    <div className='rounded-xl border border-gray-700/40 bg-black/20 px-3 py-2'>
                        <p className='text-gray-500 text-xs uppercase tracking-wider'>Running</p>
                        <p className='text-emerald-300 font-medium mt-1'>{live.vmSummary.running}</p>
                    </div>
                    <div className='rounded-xl border border-gray-700/40 bg-black/20 px-3 py-2'>
                        <p className='text-gray-500 text-xs uppercase tracking-wider'>Stopped</p>
                        <p className='text-amber-300 font-medium mt-1'>{live.vmSummary.stopped}</p>
                    </div>
                    <div className='rounded-xl border border-gray-700/40 bg-black/20 px-3 py-2'>
                        <p className='text-gray-500 text-xs uppercase tracking-wider'>QEMU / LXC</p>
                        <p className='text-gray-100 font-medium mt-1'>
                            {live.vmSummary.qemu} / {live.vmSummary.lxc}
                        </p>
                    </div>
                </div>
            </div>

            <div className='group bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/40 hover:border-gray-600/60 transition-all duration-300 hover:shadow-lg hover:shadow-gray-900/50 hover:-translate-y-1'>
                <div className='flex items-center justify-between mb-4'>
                    <h3 className='text-gray-400 text-xs font-semibold uppercase tracking-wider'>Infra Details</h3>
                </div>
                <div className='grid grid-cols-2 gap-3 text-sm'>
                    <div className='rounded-xl border border-gray-700/40 bg-black/20 px-3 py-2'>
                        <p className='text-gray-500 text-xs uppercase tracking-wider'>Storages</p>
                        <p className='text-gray-100 font-medium mt-1'>
                            {live.activeStorageCount}/{live.storageCount} active
                        </p>
                    </div>
                    <div className='rounded-xl border border-gray-700/40 bg-black/20 px-3 py-2'>
                        <p className='text-gray-500 text-xs uppercase tracking-wider'>Enabled</p>
                        <p className='text-gray-100 font-medium mt-1'>{live.enabledStorageCount}</p>
                    </div>
                    <div className='rounded-xl border border-gray-700/40 bg-black/20 px-3 py-2'>
                        <p className='text-gray-500 text-xs uppercase tracking-wider'>Networks</p>
                        <p className='text-gray-100 font-medium mt-1'>{live.networkCount}</p>
                    </div>
                    <div className='rounded-xl border border-gray-700/40 bg-black/20 px-3 py-2'>
                        <p className='text-gray-500 text-xs uppercase tracking-wider'>Bridges</p>
                        <p className='text-gray-100 font-medium mt-1'>
                            {live.bridgeCount} ({live.vlanAwareBridgeCount} VLAN aware)
                        </p>
                    </div>
                </div>
            </div>

            {/* Memory Card */}
            <div className='group bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/40 hover:border-gray-600/60 transition-all duration-300 hover:shadow-lg hover:shadow-gray-900/50 hover:-translate-y-1'>
                <div className='flex items-center justify-between mb-4'>
                    <h3 className='text-gray-400 text-xs font-semibold uppercase tracking-wider'>
                        {t('memory_allocation')}
                    </h3>
                    <div className='w-8 h-8 rounded-lg bg-purple-500/10 flex items-center justify-center group-hover:bg-purple-500/20 transition-colors duration-300'>
                        <svg className='w-4 h-4 text-purple-400' fill='none' viewBox='0 0 24 24' stroke='currentColor'>
                            <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z' />
                        </svg>
                    </div>
                </div>
                
                <div className='mb-5'>
                    <span className='text-white text-5xl font-bold leading-none tracking-tight animate-pulse-subtle'>
                        {memory.used.size}
                    </span>
                </div>

                <div className='space-y-1 mb-5 text-gray-400 text-sm'>
                    <div className='flex items-center justify-between'>
                        <span className='font-medium'>{memory.percentage.toFixed(1)}%</span>
                        <span className='text-xs text-gray-500'>utilized</span>
                    </div>
                    <p className='text-xs text-gray-500'>
                        {memory.total.size}{memory.total.unit} total
                    </p>
                    <p className='text-xs text-gray-500'>
                        {memory.free.size}{memory.free.unit} available
                    </p>
                </div>

                <div className='relative h-2 bg-gray-700/40 rounded-full overflow-hidden'>
                    <div 
                        className={`absolute inset-y-0 left-0 bg-gradient-to-r ${getBarColor(memory.percentage)} rounded-full transition-all duration-700 ease-out ${getGlowColor(memory.percentage)} shadow-lg`}
                        style={{ width: `${Math.min(memory.percentage, 100)}%` }}
                    >
                        <div className='absolute inset-0 bg-white/20 animate-shimmer' />
                    </div>
                </div>
            </div>

            {/* Disk Card */}
            <div className='group bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm rounded-2xl p-6 border border-gray-700/40 hover:border-gray-600/60 transition-all duration-300 hover:shadow-lg hover:shadow-gray-900/50 hover:-translate-y-1'>
                <div className='flex items-center justify-between mb-4'>
                    <h3 className='text-gray-400 text-xs font-semibold uppercase tracking-wider'>
                        {t('disk_allocation')}
                    </h3>
                    <div className='w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center group-hover:bg-blue-500/20 transition-colors duration-300'>
                        <svg className='w-4 h-4 text-blue-400' fill='none' viewBox='0 0 24 24' stroke='currentColor'>
                            <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4m0 5c0 2.21-3.582 4-8 4s-8-1.79-8-4' />
                        </svg>
                    </div>
                </div>
                
                <div className='mb-5 flex items-baseline gap-2'>
                    <span className='text-white text-5xl font-bold leading-none tracking-tight animate-pulse-subtle'>
                        {disk.used.size}
                    </span>
                    <span className='text-gray-400 text-xl font-semibold'>
                        {disk.used.unit}
                    </span>
                </div>

                <div className='space-y-1 mb-5 text-gray-400 text-sm'>
                    <div className='flex items-center justify-between'>
                        <span className='font-medium'>{disk.percentage.toFixed(1)}%</span>
                        <span className='text-xs text-gray-500'>utilized</span>
                    </div>
                    <p className='text-xs text-gray-500'>
                        {disk.total.size}{disk.total.unit} total
                    </p>
                    <p className='text-xs text-gray-500'>
                        {disk.free.size}{disk.free.unit} available
                    </p>
                </div>

                <div className='relative h-2 bg-gray-700/40 rounded-full overflow-hidden'>
                    <div 
                        className={`absolute inset-y-0 left-0 bg-gradient-to-r ${getBarColor(disk.percentage)} rounded-full transition-all duration-700 ease-out ${getGlowColor(disk.percentage)} shadow-lg`}
                        style={{ width: `${Math.min(disk.percentage, 100)}%` }}
                    >
                        <div className='absolute inset-0 bg-white/20 animate-shimmer' />
                    </div>
                </div>
            </div>

            <style>{`
                @keyframes shimmer {
                    0% { transform: translateX(-100%); }
                    100% { transform: translateX(100%); }
                }
                .animate-shimmer {
                    animation: shimmer 2s infinite;
                }
                @keyframes pulse-subtle {
                    0%, 100% { opacity: 1; }
                    50% { opacity: 0.95; }
                }
                .animate-pulse-subtle {
                    animation: pulse-subtle 3s ease-in-out infinite;
                }
            `}</style>
        </>
    )
}

export default NodeDetailsBlock
