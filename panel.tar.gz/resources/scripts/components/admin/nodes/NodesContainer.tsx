import { bytesToString } from '@/util/helpers'
import { useFlashKey } from '@/util/useFlash'
import usePagination from '@/util/usePagination'
import { useDebouncedValue } from '@mantine/hooks'
import { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Link } from 'react-router-dom'

import deleteNode from '@/api/admin/nodes/deleteNode'
import { Node, NodeResponse } from '@/api/admin/nodes/getNodes'
import useNodesSWR from '@/api/admin/nodes/useNodesSWR'

import Menu from '@/components/elements/Menu'
import PageContentBlock from '@/components/elements/PageContentBlock'
import Pagination from '@/components/elements/Pagination'
import Spinner from '@/components/elements/Spinner'
import Table, {
    Actions,
    ColumnArray,
    RowActionsProps,
} from '@/components/elements/displays/Table'

import SearchBar from '@/components/admin/SearchBar'
import CreateNodeModal from '@/components/admin/nodes/CreateNodeModal'

const NodesContainer = () => {
    const { t: tStrings } = useTranslation('strings')
    const { t } = useTranslation('admin.nodes.index')
    const [page, setPage] = usePagination()
    const [open, setOpen] = useState(false)
    const { clearFlashes, clearAndAddHttpError } = useFlashKey('admin.nodes.index')

    const [query, setQuery] = useState('')
    const [debouncedQuery] = useDebouncedValue(query, 200)
    const { data, mutate } = useNodesSWR({ page, query: debouncedQuery })

    const columns: ColumnArray<Node> = [
        {
            accessor: 'name',
            header: tStrings('node'),
            cell: ({ value, row }) => (
                <Link
                    to={`/admin/nodes/${row.id}`}
                    className='group flex items-center gap-3 font-semibold text-white hover:text-blue-400 transition-all duration-200'
                >
                    <div className='w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500/20 to-blue-600/20 flex items-center justify-center border border-blue-500/30 group-hover:border-blue-400/50 group-hover:shadow-lg group-hover:shadow-blue-500/20 transition-all duration-200'>
                        <svg className='w-5 h-5 text-blue-400 group-hover:scale-110 transition-transform' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                            <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01' />
                        </svg>
                    </div>
                    <div className='min-w-0'>
                        <span className='block group-hover:translate-x-0.5 transition-transform'>
                            #{row.id} - {value}
                        </span>
                        <span className='mt-0.5 block text-[11px] font-mono text-white/45'>
                            Node ID #{row.id}
                        </span>
                    </div>
                </Link>
            ),
        },
        {
            accessor: 'fqdn',
            header: tStrings('fqdn'),
            cell: ({ value }) => (
                <div className='flex items-center gap-2.5 group cursor-default'>
                    <div className='w-7 h-7 rounded-lg bg-gray-700/30 flex items-center justify-center'>
                        <svg className='w-4 h-4 text-gray-500' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                            <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9' />
                        </svg>
                    </div>
                    <span className='text-gray-400 text-sm font-mono'>{value}</span>
                </div>
            ),
        },
        {
            accessor: 'memory',
            header: tStrings('memory'),
            cell: ({ value }) => {
                const formatted = bytesToString(value)
                return (
                    <span className='inline-flex items-center gap-2 px-3 py-2 text-sm font-semibold rounded-xl bg-gradient-to-r from-purple-500/15 to-purple-600/15 text-purple-300 border border-purple-500/30 shadow-sm hover:shadow-md hover:shadow-purple-500/10 transition-all duration-200'>
                        <svg className='w-4 h-4' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                            <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z' />
                        </svg>
                        <span className='font-bold'>{formatted}</span>
                    </span>
                )
            },
        },
        {
            accessor: 'disk',
            header: tStrings('disk'),
            cell: ({ value }) => {
                const formatted = bytesToString(value)
                return (
                    <span className='inline-flex items-center gap-2 px-3 py-2 text-sm font-semibold rounded-xl bg-gradient-to-r from-blue-500/15 to-blue-600/15 text-blue-300 border border-blue-500/30 shadow-sm hover:shadow-md hover:shadow-blue-500/10 transition-all duration-200'>
                        <svg className='w-4 h-4' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                            <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4' />
                        </svg>
                        <span className='font-bold'>{formatted}</span>
                    </span>
                )
            },
        },
        {
            accessor: 'serversCount',
            header: tStrings('server_other'),
            align: 'center',
            cell: ({ value }) => (
                <div className='flex justify-center'>
                    <span className='inline-flex items-center justify-center min-w-[3.5rem] px-3 py-2 text-sm font-bold rounded-xl bg-gradient-to-r from-emerald-500/15 to-emerald-600/15 text-emerald-300 border border-emerald-500/30 shadow-sm hover:shadow-md hover:shadow-emerald-500/10 transition-all duration-200'>
                        {value}
                    </span>
                </div>
            ),
        },
    ]

    const rowActions = ({ row: node }: RowActionsProps<Node>) => {
        const [isDeleting, setIsDeleting] = useState(false)

        const handleDelete = async () => {
            if (node.serversCount > 0) return
            
            setIsDeleting(true)
            clearFlashes()

            try {
                await deleteNode(node.id)

                mutate(
                    mutateData =>
                        ({
                            ...mutateData,
                            items: mutateData!.items.filter(
                                n => n.id !== node.id
                            ),
                        }) as NodeResponse,
                    false
                )
            } catch (error) {
                clearAndAddHttpError(error as Error)
                setIsDeleting(false)
            }
        }

        return (
            <Actions>
                <Menu.Item
                    onClick={() => {
                        navigator.clipboard.writeText(String(node.id))
                    }}
                >
                    <div className='flex items-center gap-2.5'>
                        <svg className='w-4 h-4' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                            <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z' />
                        </svg>
                        <span className='font-medium'>Copy Node ID</span>
                    </div>
                </Menu.Item>
                <Menu.Item
                    onClick={() => {
                        navigator.clipboard.writeText(node.fqdn)
                    }}
                >
                    <div className='flex items-center gap-2.5'>
                        <svg className='w-4 h-4' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                            <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1' />
                        </svg>
                        <span className='font-medium'>Copy FQDN</span>
                    </div>
                </Menu.Item>
                <Menu.Divider />
                <Menu.Item
                    color='red'
                    disabled={node.serversCount > 0 || isDeleting}
                    onClick={handleDelete}
                >
                    <div className='flex items-center gap-2.5'>
                        {isDeleting ? (
                            <svg className='w-4 h-4 animate-spin' fill='none' viewBox='0 0 24 24'>
                                <circle className='opacity-25' cx='12' cy='12' r='10' stroke='currentColor' strokeWidth='4' />
                                <path className='opacity-75' fill='currentColor' d='M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z' />
                            </svg>
                        ) : (
                            <svg className='w-4 h-4' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16' />
                            </svg>
                        )}
                        <span className='font-medium'>{isDeleting ? 'Deleting...' : tStrings('delete')}</span>
                    </div>
                </Menu.Item>
            </Actions>
        )
    }

    const totalNodes = data?.pagination?.total || 0
    const totalMemory = data?.items?.reduce((sum, node) => sum + node.memory, 0) || 0
    const totalDisk = data?.items?.reduce((sum, node) => sum + node.disk, 0) || 0
    const totalServers = data?.items?.reduce((sum, node) => sum + node.serversCount, 0) || 0

    return (
        <div className='min-h-screen bg-[#05020f]'>
            <PageContentBlock
                title={tStrings('node_other') ?? 'Nodes'}
                showFlashKey='admin.nodes.index'
            >
                {/* Stats Overview */}
                <div className='mb-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4'>
                    <div className='group relative rounded-2xl border border-white/10 bg-[#1a1441] p-6 transition-all duration-300 hover:border-white/20 hover:shadow-xl hover:shadow-black/30'>
                        <div className='absolute right-0 top-0 h-32 w-32 rounded-full bg-slate-500/5 blur-3xl transition-all duration-500 group-hover:bg-slate-500/10' />
                        <div className='relative'>
                            <div className='mb-4 flex items-center justify-between'>
                                <div className='flex h-14 w-14 items-center justify-center rounded-2xl border border-slate-500/30 bg-gradient-to-br from-slate-500/20 to-slate-600/20 shadow-lg transition-all duration-300 group-hover:scale-105 group-hover:border-slate-400/50'>
                                    <svg className='h-7 w-7 text-slate-400' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                        <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01' />
                                    </svg>
                                </div>
                            </div>
                            <p className='mb-2 text-xs font-bold uppercase tracking-wider text-white/60'>Total Nodes</p>
                            <p className='text-4xl font-extrabold text-white'>{totalNodes}</p>
                        </div>
                    </div>

                    <div className='group relative rounded-2xl border border-white/10 bg-[#1a1441] p-6 transition-all duration-300 hover:border-purple-500/40 hover:shadow-xl hover:shadow-purple-900/30'>
                        <div className='absolute top-0 right-0 w-32 h-32 bg-purple-500/5 rounded-full blur-3xl group-hover:bg-purple-500/10 transition-all duration-500' />
                        <div className='relative'>
                            <div className='flex items-center justify-between mb-4'>
                                <div className='w-14 h-14 bg-gradient-to-br from-purple-500/20 to-purple-600/20 rounded-2xl flex items-center justify-center border border-purple-500/30 group-hover:border-purple-400/50 group-hover:scale-105 transition-all duration-300 shadow-lg shadow-purple-500/10'>
                                    <svg className='w-7 h-7 text-purple-400' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                        <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z' />
                                    </svg>
                                </div>
                            </div>
                            <p className='mb-2 text-xs font-bold uppercase tracking-wider text-white/60'>Total Memory</p>
                            <p className='text-4xl font-extrabold text-white'>{bytesToString(totalMemory)}</p>
                        </div>
                    </div>

                    <div className='group relative rounded-2xl border border-white/10 bg-[#1a1441] p-6 transition-all duration-300 hover:border-blue-500/40 hover:shadow-xl hover:shadow-blue-900/30'>
                        <div className='absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-3xl group-hover:bg-blue-500/10 transition-all duration-500' />
                        <div className='relative'>
                            <div className='flex items-center justify-between mb-4'>
                                <div className='w-14 h-14 bg-gradient-to-br from-blue-500/20 to-blue-600/20 rounded-2xl flex items-center justify-center border border-blue-500/30 group-hover:border-blue-400/50 group-hover:scale-105 transition-all duration-300 shadow-lg shadow-blue-500/10'>
                                    <svg className='w-7 h-7 text-blue-400' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                        <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4' />
                                    </svg>
                                </div>
                            </div>
                            <p className='mb-2 text-xs font-bold uppercase tracking-wider text-white/60'>Total Disk</p>
                            <p className='text-4xl font-extrabold text-white'>{bytesToString(totalDisk)}</p>
                        </div>
                    </div>

                    <div className='group relative rounded-2xl border border-white/10 bg-[#1a1441] p-6 transition-all duration-300 hover:border-emerald-500/40 hover:shadow-xl hover:shadow-emerald-900/30'>
                        <div className='absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-3xl group-hover:bg-emerald-500/10 transition-all duration-500' />
                        <div className='relative'>
                            <div className='flex items-center justify-between mb-4'>
                                <div className='w-14 h-14 bg-gradient-to-br from-emerald-500/20 to-emerald-600/20 rounded-2xl flex items-center justify-center border border-emerald-500/30 group-hover:border-emerald-400/50 group-hover:scale-105 transition-all duration-300 shadow-lg shadow-emerald-500/10'>
                                    <svg className='w-7 h-7 text-emerald-400' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                        <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z' />
                                    </svg>
                                </div>
                            </div>
                            <p className='mb-2 text-xs font-bold uppercase tracking-wider text-white/60'>Total Servers</p>
                            <p className='text-4xl font-extrabold text-white'>{totalServers}</p>
                        </div>
                    </div>
                </div>
                {/* Search and Create */}
                <div className='mb-6 rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                    <SearchBar
                        value={query}
                        onChange={e => setQuery(e.target.value)}
                        buttonText={t('create_node')}
                        onClick={() => setOpen(true)}
                    />
                </div>

                {/* Content Area */}
                <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                    {!data ? (
                        <div className='flex flex-col items-center justify-center py-24'>
                            <Spinner />
                            <p className='mt-4 text-sm text-white/60'>Loading nodes...</p>
                        </div>
                    ) : data.items.length === 0 ? (
                        <div className='relative overflow-hidden rounded-3xl border border-white/10 bg-[#111a31] p-20 text-center backdrop-blur-sm'>
                        <div className='absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl' />
                        <div className='relative max-w-lg mx-auto'>
                            <div className='mx-auto mb-8 flex h-24 w-24 items-center justify-center rounded-3xl border border-white/10 bg-white/5 shadow-2xl'>
                                <svg className='h-12 w-12 text-indigo-300' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                    <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01' />
                                </svg>
                            </div>
                            <h3 className='text-2xl font-bold text-white mb-4'>
                                {query ? 'No nodes found' : 'No nodes configured'}
                            </h3>
                            <p className='mb-10 max-w-md mx-auto text-sm leading-relaxed text-white/60'>
                                {query
                                    ? 'Try adjusting your search terms to find what you\'re looking for'
                                    : 'Get started by adding your first Proxmox node to begin hosting and managing your virtual servers'}
                            </p>
                            {!query && (
                                <button
                                    onClick={() => setOpen(true)}
                                    className='inline-flex items-center px-8 py-4 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white text-sm font-bold rounded-xl transition-all duration-200 shadow-xl shadow-blue-900/40 hover:shadow-2xl hover:shadow-blue-900/60 hover:-translate-y-0.5'
                                >
                                    Create Your First Node
                                </button>
                            )}
                        </div>
                        </div>
                    ) : (
                        <Pagination data={data} onPageSelect={setPage}>
                            {({ items }) => (
                                <Table
                                    rowActions={rowActions}
                                    columns={columns}
                                    data={items}
                                />
                            )}
                        </Pagination>
                    )}
                </div>

                <CreateNodeModal open={open} onClose={() => setOpen(false)} />
            </PageContentBlock>
        </div>
    )
}

export default NodesContainer
