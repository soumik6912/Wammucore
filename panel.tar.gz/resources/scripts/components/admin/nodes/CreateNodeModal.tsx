import { useFlashKey } from '@/util/useFlash'
import { gibToBytes } from '@/util/helpers'
import { hostname } from '@/util/validation'
import { zodResolver } from '@hookform/resolvers/zod'
import { FormProvider, useForm } from 'react-hook-form'
import { useTranslation } from 'react-i18next'
import { z } from 'zod'

import createNode from '@/api/admin/nodes/createNode'
import useNodesSWR from '@/api/admin/nodes/useNodesSWR'

import FlashMessageRender from '@/components/elements/FlashMessageRenderer'
import MessageBox from '@/components/elements/MessageBox'
import Modal from '@/components/elements/Modal'
import CheckboxForm from '@/components/elements/forms/CheckboxForm'
import TextInputForm from '@/components/elements/forms/TextInputForm'

import LocationsSelectForm from '@/components/admin/nodes/LocationsSelectForm'

interface Props {
    open: boolean
    onClose: () => void
}

const CreateNodeModal = ({ open, onClose }: Props) => {
    const { clearFlashes, clearAndAddHttpError } = useFlashKey(
        'admin.nodes.index.create'
    )
    const { mutate } = useNodesSWR({ page: 1, query: '' })
    const { t: tStrings } = useTranslation('strings')
    const { t } = useTranslation('admin.nodes.index')

    const schema = z.object({
        name: z.string().min(1).max(191),
        locationId: z.preprocess(Number, z.number()),
        cluster: z.string().min(1).max(191),
        verifyTls: z.boolean(),
        tokenId: z.string().min(1).max(191),
        secret: z.string().min(1).max(191),
        fqdn: hostname().min(1).max(191),
        port: z.preprocess(Number, z.number().int().min(1).max(65535)),
        memory: z.preprocess(Number, z.number().min(0)),
        memoryOverallocate: z.preprocess(Number, z.number().int().min(0)),
        disk: z.preprocess(Number, z.number().min(0)),
        diskOverallocate: z.preprocess(Number, z.number().int().min(0)),
        vmStorage: z.string().min(1).max(191),
        backupStorage: z.string().min(1).max(191),
        isoStorage: z.string().min(1).max(191),
        network: z.string().min(1).max(191),
        cardBackgroundImageUrl: z.union([z.literal(''), z.string().url().max(2048)]),
        cardBackgroundImageBrightness: z.preprocess(
            Number,
            z.number().int().min(5).max(100)
        ),
        provisioningEnabled: z.boolean(),
        maintenanceMode: z.boolean(),
        provisioningPriority: z.preprocess(Number, z.number().int().min(1).max(255)),
        provisioningMemoryThresholdPercent: z.preprocess(
            Number,
            z.number().int().min(1).max(100)
        ),
        provisioningDiskThresholdPercent: z.preprocess(
            Number,
            z.number().int().min(1).max(100)
        ),
        reinstallLimitPerWeek: z.preprocess(Number, z.number().int().min(0).max(100)),
    })

    const form = useForm({
        resolver: zodResolver(schema),
        defaultValues: {
            name: '',
            locationId: '0',
            cluster: '',
            verifyTls: true,
            tokenId: '',
            secret: '',
            fqdn: '',
            port: '8006',
            memory: '0',
            memoryOverallocate: '0',
            disk: '0',
            diskOverallocate: '0',
            vmStorage: '',
            backupStorage: '',
            isoStorage: '',
            network: '',
            cardBackgroundImageUrl: '',
            cardBackgroundImageBrightness: '25',
            provisioningEnabled: true,
            maintenanceMode: false,
            provisioningPriority: '100',
            provisioningMemoryThresholdPercent: '95',
            provisioningDiskThresholdPercent: '95',
            reinstallLimitPerWeek: '2',
        },
    })
    const cardBrightnessValue = Number(
        form.watch('cardBackgroundImageBrightness') || 25
    )

    const handleClose = () => {
        clearFlashes()
        form.reset()
        onClose()
    }

    const submit = async (_data: any) => {
        const { memory, disk, ...data } = _data as z.infer<typeof schema>
        clearFlashes()
        try {
            const node = await createNode({
                memory: gibToBytes(memory),
                disk: gibToBytes(disk),
                ...data,
                cardBackgroundImageUrl:
                    data.cardBackgroundImageUrl.length > 0
                        ? data.cardBackgroundImageUrl
                        : null,
                reinstallLimitPerWeek: data.reinstallLimitPerWeek,
            })

            mutate(data => {
                if (!data) return data

                return {
                    ...data,
                    items: [node, ...data.items],
                }
            }, false)

            handleClose()
        } catch (error) {
            clearAndAddHttpError(error as Error)
        }
    }

    return (
        <Modal open={open} onClose={handleClose} size='2xl'>
            <Modal.Header>
                <div className='flex items-center gap-3'>
                    <div className='w-12 h-12 bg-gradient-to-br from-blue-500/20 to-blue-600/20 rounded-xl flex items-center justify-center border border-blue-500/30'>
                        <svg className='w-6 h-6 text-blue-400' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                            <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01' />
                        </svg>
                    </div>
                    <div>
                        <Modal.Title className='text-xl font-bold'>{t('create_modal.title')}</Modal.Title>
                        <p className='text-sm text-gray-200 mt-1'>Configure and deploy a new Proxmox node</p>
                    </div>
                </div>
            </Modal.Header>

            <FormProvider {...form}>
                <form onSubmit={form.handleSubmit(submit)}>
                    <Modal.Body className='space-y-6'>
                        <FlashMessageRender
                            className='mb-4'
                            byKey={'admin.nodes.index.create'}
                        />

                        {/* Basic Information */}
                        <div className='bg-gray-800/30 rounded-xl p-5 border border-gray-700/50'>
                            <div className='flex items-center gap-2 mb-5'>
                                <div className='w-8 h-8 bg-purple-500/10 rounded-lg flex items-center justify-center'>
                                    <svg className='w-4 h-4 text-purple-400' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                        <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z' />
                                    </svg>
                                </div>
                                <h3 className='text-sm font-semibold text-white uppercase tracking-wider'>Basic Information</h3>
                            </div>
                            
                            <div className='space-y-4'>
                                <TextInputForm
                                    name='name'
                                    label={tStrings('display_name')}
                                />
                                <LocationsSelectForm />
                                <TextInputForm 
                                    name='cluster' 
                                    label={t('pve_name')} 
                                />
                            </div>
                        </div>

                        {/* Authentication */}
                        <div className='bg-gray-800/30 rounded-xl p-5 border border-gray-700/50'>
                            <div className='flex items-center gap-2 mb-5'>
                                <div className='w-8 h-8 bg-amber-500/10 rounded-lg flex items-center justify-center'>
                                    <svg className='w-4 h-4 text-amber-400' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                        <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z' />
                                    </svg>
                                </div>
                                <h3 className='text-sm font-semibold text-white uppercase tracking-wider'>Authentication</h3>
                            </div>

                            <div className='space-y-4'>
                                <MessageBox
                                    title='Security Notice'
                                    type='warning'
                                >
                                    {t('creds_warning')}
                                </MessageBox>

                                <div className='grid gap-4 grid-cols-1 md:grid-cols-2'>
                                    <TextInputForm
                                        name='tokenId'
                                        label={t('token_id')}
                                    />
                                    <TextInputForm 
                                        name='secret' 
                                        label={t('secret')} 
                                    />
                                </div>
                            </div>
                        </div>

                        {/* Connection Details */}
                        <div className='bg-gray-800/30 rounded-xl p-5 border border-gray-700/50'>
                            <div className='flex items-center gap-2 mb-5'>
                                <div className='w-8 h-8 bg-emerald-500/10 rounded-lg flex items-center justify-center'>
                                    <svg className='w-4 h-4 text-emerald-400' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                        <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9' />
                                    </svg>
                                </div>
                                <h3 className='text-sm font-semibold text-white uppercase tracking-wider'>Connection</h3>
                            </div>

                            <div className='space-y-4'>
                                <TextInputForm 
                                    name='fqdn' 
                                    label={tStrings('fqdn')} 
                                />
                                <div className='grid gap-4 grid-cols-1 md:grid-cols-2'>
                                    <TextInputForm 
                                        name='port' 
                                        label={tStrings('port')} 
                                    />
                                    <div className='flex items-end pb-2'>
                                        <CheckboxForm
                                            name={'verifyTls'}
                                            label='Verify TLS Certificate'
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Resource Allocation */}
                        <div className='bg-gray-800/30 rounded-xl p-5 border border-gray-700/50'>
                            <div className='flex items-center gap-2 mb-5'>
                                <div className='w-8 h-8 bg-blue-500/10 rounded-lg flex items-center justify-center'>
                                    <svg className='w-4 h-4 text-blue-400' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                        <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z' />
                                    </svg>
                                </div>
                                <h3 className='text-sm font-semibold text-white uppercase tracking-wider'>Resources</h3>
                            </div>

                            <div className='space-y-4'>
                                <div className='grid gap-4 grid-cols-1 md:grid-cols-2'>
                                    <TextInputForm
                                        name='memory'
                                        label={`${t('memory_allocation')} (GiB)`}
                                    />
                                    <TextInputForm
                                        name='memoryOverallocate'
                                        label={`${t('memory_overallocation')} (%)`}
                                    />
                                </div>
                                <div className='grid gap-4 grid-cols-1 md:grid-cols-2'>
                                    <TextInputForm
                                        name='disk'
                                        label={`${t('disk_allocation')} (GiB)`}
                                    />
                                    <TextInputForm
                                        name='diskOverallocate'
                                        label={`${t('disk_overallocation')} (%)`}
                                    />
                                </div>
                            </div>
                        </div>

                        {/* Storage Configuration */}
                        <div className='bg-gray-800/30 rounded-xl p-5 border border-gray-700/50'>
                            <div className='flex items-center gap-2 mb-5'>
                                <div className='w-8 h-8 bg-cyan-500/10 rounded-lg flex items-center justify-center'>
                                    <svg className='w-4 h-4 text-cyan-400' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                        <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4' />
                                    </svg>
                                </div>
                                <h3 className='text-sm font-semibold text-white uppercase tracking-wider'>Storage</h3>
                            </div>

                            <div className='space-y-4'>
                                <div className='grid gap-4 grid-cols-1 md:grid-cols-3'>
                                    <TextInputForm
                                        name='vmStorage'
                                        label={t('vm_storage')}
                                        placeholder='local'
                                    />
                                    <TextInputForm
                                        name='backupStorage'
                                        label={t('backup_storage')}
                                        placeholder='local'
                                    />
                                    <TextInputForm
                                        name='isoStorage'
                                        label={t('iso_storage')}
                                        placeholder='local'
                                    />
                                </div>
                                <TextInputForm
                                    name='network'
                                    label={tStrings('network')}
                                    placeholder='vmbr0'
                                />
                                <TextInputForm
                                    name='cardBackgroundImageUrl'
                                    label='Card Background Image URL'
                                    placeholder='https://example.com/node-card-bg.jpg'
                                />
                                <div className='rounded-lg border border-gray-700/50 bg-gray-900/30 p-3'>
                                    <div className='flex items-center justify-between gap-3'>
                                        <label
                                            htmlFor='new-node-card-background-image-brightness'
                                            className='text-sm font-medium text-white'
                                        >
                                            Card Image Brightness
                                        </label>
                                        <span className='rounded-md bg-gray-800 px-2 py-1 text-xs font-semibold text-white'>
                                            {cardBrightnessValue}%
                                        </span>
                                    </div>
                                    <input
                                        id='new-node-card-background-image-brightness'
                                        type='range'
                                        min={5}
                                        max={100}
                                        step={1}
                                        className='mt-3 h-2 w-full cursor-pointer accent-blue-500'
                                        {...form.register('cardBackgroundImageBrightness')}
                                    />
                                    <div className='mt-2 flex items-center justify-between text-[11px] uppercase tracking-wide text-gray-500'>
                                        <span>Darker</span>
                                        <span>Brighter</span>
                                    </div>
                                </div>
                                <p className='text-xs text-gray-400'>
                                    Lower brightness makes the plan card darker. Use 15-30 for bright images.
                                </p>
                                <TextInputForm
                                    name='reinstallLimitPerWeek'
                                    label='OS Reinstall Limit (per week, 0 = unlimited)'
                                    placeholder='2'
                                />
                                <div className='grid gap-4 grid-cols-1 md:grid-cols-2'>
                                    <CheckboxForm
                                        name={'provisioningEnabled'}
                                        label='Enable for provisioning'
                                    />
                                    <CheckboxForm
                                        name={'maintenanceMode'}
                                        label='Maintenance mode'
                                    />
                                </div>
                                <div className='grid gap-4 grid-cols-1 md:grid-cols-3'>
                                    <TextInputForm
                                        name='provisioningPriority'
                                        label='Provisioning Priority'
                                    />
                                    <TextInputForm
                                        name='provisioningMemoryThresholdPercent'
                                        label='RAM Threshold (%)'
                                    />
                                    <TextInputForm
                                        name='provisioningDiskThresholdPercent'
                                        label='Disk Threshold (%)'
                                    />
                                </div>
                            </div>
                        </div>
                    </Modal.Body>

                    <Modal.Actions className='flex items-center justify-end gap-3 px-6 py-4 bg-gray-800/30 border-t border-gray-700/50'>
                        <button
                            type='button'
                            onClick={handleClose}
                            className='px-5 py-2.5 text-sm font-medium text-gray-300 bg-gray-700/50 hover:bg-gray-700 rounded-lg border border-gray-600/50 hover:border-gray-600 transition-all duration-200'
                        >
                            {tStrings('cancel')}
                        </button>
                        <button
                            type='submit'
                            disabled={form.formState.isSubmitting}
                            className='inline-flex items-center gap-2 px-6 py-2.5 text-sm font-semibold text-white bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 rounded-lg shadow-lg shadow-blue-900/30 hover:shadow-blue-900/50 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed'
                        >
                            {form.formState.isSubmitting ? (
                                <>
                                    <svg className='w-4 h-4 animate-spin' fill='none' viewBox='0 0 24 24'>
                                        <circle className='opacity-25' cx='12' cy='12' r='10' stroke='currentColor' strokeWidth='4' />
                                        <path className='opacity-75' fill='currentColor' d='M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z' />
                                    </svg>
                                    Creating...
                                </>
                            ) : (
                                <>
                                    {tStrings('create')}
                                </>
                            )}
                        </button>
                    </Modal.Actions>
                </form>
            </FormProvider>
        </Modal>
    )
}

export default CreateNodeModal
