import { useFlashKey } from '@/util/useFlash'
import { bytesToGib, gibToBytes } from '@/util/helpers'
import { hostname } from '@/util/validation'
import { zodResolver } from '@hookform/resolvers/zod'
import { FormProvider, useForm } from 'react-hook-form'
import { useTranslation } from 'react-i18next'
import { z } from 'zod'

import updateNode from '@/api/admin/nodes/updateNode'
import useNodeSWR from '@/api/admin/nodes/useNodeSWR'

import Button from '@/components/elements/Button'
import FlashMessageRender from '@/components/elements/FlashMessageRenderer'
import FormCard from '@/components/elements/FormCard'
import CheckboxForm from '@/components/elements/forms/CheckboxForm'
import TextInputForm from '@/components/elements/forms/TextInputForm'

import LocationsSelectForm from '@/components/admin/nodes/LocationsSelectForm'


const NodeInformationCard = () => {
    const { data: node, mutate } = useNodeSWR()
    const { clearFlashes, clearAndAddHttpError } = useFlashKey(
        `admin.nodes.${node.id}.settings.general.info`
    )
    const { t: tStrings } = useTranslation('strings')
    const { t } = useTranslation('admin.nodes.settings')
    const { t: tIndex } = useTranslation('admin.nodes.index')

    const schema = z.object({
        name: z.string().min(1).max(191),
        locationId: z.preprocess(Number, z.number()),
        cluster: z.string().min(1).max(191),
        verifyTls: z.boolean(),
        tokenId: z.string().max(191),
        secret: z.string().max(191),
        fqdn: hostname().min(1).max(191),
        port: z.preprocess(Number, z.number().int().min(1).max(65535)),
        memory: z.preprocess(Number, z.number().min(0)),
        memoryOverallocate: z.preprocess(Number, z.number().int().min(0)),
        disk: z.preprocess(Number, z.number().min(0)),
        diskOverallocate: z.preprocess(Number, z.number().int().min(0)),
        vmStorage: z.string().min(1).max(191),
        backupStorage: z.string().min(1).max(191),
        isoStorage: z.string().min(1).max(191),
        network: z.string().min(1).max(191),
        cardBackgroundImageUrl: z.union([z.literal(''), z.string().url().max(2048)]),
        cardBackgroundImageBrightness: z.preprocess(
            Number,
            z.number().int().min(5).max(100)
        ),
        provisioningEnabled: z.boolean(),
        maintenanceMode: z.boolean(),
        provisioningPriority: z.preprocess(Number, z.number().int().min(1).max(255)),
        provisioningMemoryThresholdPercent: z.preprocess(
            Number,
            z.number().int().min(1).max(100)
        ),
        provisioningDiskThresholdPercent: z.preprocess(
            Number,
            z.number().int().min(1).max(100)
        ),
        reinstallLimitPerWeek: z.preprocess(Number, z.number().int().min(0).max(100)),
    })

    const form = useForm({
        resolver: zodResolver(schema),
        defaultValues: {
            name: node.name,
            locationId: node.locationId.toString(),
            cluster: node.cluster,
            verifyTls: node.verifyTls,
            tokenId: '',
            secret: '',
            fqdn: node.fqdn,
            port: node.port,
            memory: bytesToGib(node.memory),
            memoryOverallocate: node.memoryOverallocate,
            disk: bytesToGib(node.disk),
            diskOverallocate: node.diskOverallocate,
            vmStorage: node.vmStorage,
            backupStorage: node.backupStorage,
            isoStorage: node.isoStorage,
            network: node.network,
            cardBackgroundImageUrl: node.cardBackgroundImageUrl ?? '',
            cardBackgroundImageBrightness: node.cardBackgroundImageBrightness ?? 25,
            provisioningEnabled: node.provisioningEnabled ?? true,
            maintenanceMode: node.maintenanceMode ?? false,
            provisioningPriority: node.provisioningPriority ?? 100,
            provisioningMemoryThresholdPercent:
                node.provisioningMemoryThresholdPercent ?? 95,
            provisioningDiskThresholdPercent:
                node.provisioningDiskThresholdPercent ?? 95,
            reinstallLimitPerWeek: node.reinstallLimitPerWeek ?? 2,
        },
    })
    const cardBrightnessValue = Number(
        form.watch('cardBackgroundImageBrightness') || 25
    )

    const submit = async (_data: any) => {
        const { memory, disk, ...data } = _data as z.infer<typeof schema>
        clearFlashes()
        try {
            const updatedNode = await updateNode(node.id, {
                ...data,
                memory: gibToBytes(memory),
                disk: gibToBytes(disk),
                cardBackgroundImageUrl:
                    data.cardBackgroundImageUrl.length > 0
                        ? data.cardBackgroundImageUrl
                        : null,
            })

            mutate(() => updatedNode, false)

            form.reset({
                name: data.name,
                locationId: data.locationId.toString(),
                cluster: data.cluster,
                verifyTls: data.verifyTls,
                tokenId: '',
                secret: '',
                fqdn: data.fqdn,
                port: data.port,
                memory,
                memoryOverallocate: data.memoryOverallocate,
                disk,
                diskOverallocate: data.diskOverallocate,
                vmStorage: data.vmStorage,
                backupStorage: data.backupStorage,
                isoStorage: data.isoStorage,
                network: data.network,
                cardBackgroundImageUrl: data.cardBackgroundImageUrl,
                cardBackgroundImageBrightness: data.cardBackgroundImageBrightness,
                provisioningEnabled: data.provisioningEnabled,
                maintenanceMode: data.maintenanceMode,
                provisioningPriority: data.provisioningPriority,
                provisioningMemoryThresholdPercent:
                    data.provisioningMemoryThresholdPercent,
                provisioningDiskThresholdPercent:
                    data.provisioningDiskThresholdPercent,
                reinstallLimitPerWeek: data.reinstallLimitPerWeek,
            })
        } catch (error) {
            clearAndAddHttpError(error as Error)
        }
    }

    return (
        <FormCard className='w-full'>
            <FormProvider {...form}>
                <form onSubmit={form.handleSubmit(submit)}>
                    <FormCard.Body>
                        <FormCard.Title>{t('node_info.title')}</FormCard.Title>
                        <p className='mt-2 text-sm text-accent-500'>
                            Configure connectivity, resources, storage, and security for this node.
                        </p>
                        <div className='space-y-4 mt-4'>
                            <FlashMessageRender
                                byKey={`admin.nodes.${node.id}.settings.general.info`}
                            />
                            <div className='rounded-lg border border-accent-200 bg-accent-100 p-4 space-y-3'>
                                <h4 className='text-sm font-semibold text-foreground'>Basic Details</h4>
                                <TextInputForm
                                    name='name'
                                    label={tStrings('display_name')}
                                />
                                <LocationsSelectForm />
                                <TextInputForm
                                    name='cluster'
                                    label={tIndex('pve_name')}
                                />
                            </div>

                            <div className='rounded-lg border border-accent-200 bg-accent-100 p-4 space-y-3'>
                                <h4 className='text-sm font-semibold text-foreground'>Connection</h4>
                                <TextInputForm
                                    name='fqdn'
                                    label={tStrings('fqdn')}
                                />
                                <div className='grid gap-3 md:grid-cols-2'>
                                    <TextInputForm
                                        name='port'
                                        label={tStrings('port')}
                                    />
                                    <CheckboxForm
                                        name={'verifyTls'}
                                        label='Verify TLS Certificate'
                                        className={'relative mt-8 md:mt-8'}
                                    />
                                </div>
                                <div className='grid gap-3 md:grid-cols-2'>
                                    <TextInputForm
                                        name='tokenId'
                                        label={tIndex('token_id')}
                                        placeholder={
                                            tIndex('override_creds') ??
                                            'Override credentials'
                                        }
                                    />
                                    <TextInputForm
                                        name='secret'
                                        label={tIndex('secret')}
                                        placeholder={
                                            tIndex('override_creds') ??
                                            'Override credentials'
                                        }
                                    />
                                </div>
                                <p className='text-xs text-accent-500'>
                                    Leave Token ID and Secret blank to keep the currently saved Proxmox API credentials.
                                </p>
                            </div>

                            <div className='rounded-lg border border-accent-200 bg-accent-100 p-4 space-y-3'>
                                <h4 className='text-sm font-semibold text-foreground'>Capacity</h4>
                                <div className='grid gap-3 md:grid-cols-2'>
                                    <TextInputForm
                                        name='memory'
                                        label={`${tStrings('memory')} (GiB)`}
                                    />
                                    <TextInputForm
                                        name='memoryOverallocate'
                                        label={`${tIndex(
                                            'memory_overallocation'
                                        )} (%)`}
                                    />
                                </div>
                                <div className='grid gap-3 md:grid-cols-2'>
                                    <TextInputForm
                                        name='disk'
                                        label={`${tStrings('disk')} (GiB)`}
                                    />
                                    <TextInputForm
                                        name='diskOverallocate'
                                        label={`${tIndex(
                                            'disk_overallocation'
                                        )} (%)`}
                                    />
                                </div>
                            </div>

                            <div className='rounded-lg border border-accent-200 bg-accent-100 p-4 space-y-3'>
                                <h4 className='text-sm font-semibold text-foreground'>Storage and Limits</h4>
                                <div className='grid gap-3 md:grid-cols-3'>
                                    <TextInputForm
                                        name='vmStorage'
                                        label={tIndex('vm_storage')}
                                        placeholder='local'
                                    />
                                    <TextInputForm
                                        name='backupStorage'
                                        label={tIndex('backup_storage')}
                                        placeholder='local'
                                    />
                                    <TextInputForm
                                        name='isoStorage'
                                        label={tIndex('iso_storage')}
                                        placeholder='local'
                                    />
                                </div>
                                <TextInputForm
                                    name='network'
                                    label={tStrings('network')}
                                    placeholder='vmbr0'
                                />
                                <TextInputForm
                                    name='cardBackgroundImageUrl'
                                    label='Card Background Image URL'
                                    placeholder='https://example.com/node-card-bg.jpg'
                                />
                                <div className='rounded-lg border border-accent-200 bg-background/40 p-3'>
                                    <div className='flex items-center justify-between gap-3'>
                                        <label
                                            htmlFor='node-card-background-image-brightness'
                                            className='text-sm font-medium text-foreground'
                                        >
                                            Card Image Brightness
                                        </label>
                                        <span className='rounded-md bg-accent-200 px-2 py-1 text-xs font-semibold text-foreground'>
                                            {cardBrightnessValue}%
                                        </span>
                                    </div>
                                    <input
                                        id='node-card-background-image-brightness'
                                        type='range'
                                        min={5}
                                        max={100}
                                        step={1}
                                        className='mt-3 h-2 w-full cursor-pointer accent-primary-500'
                                        {...form.register('cardBackgroundImageBrightness')}
                                    />
                                    <div className='mt-2 flex items-center justify-between text-[11px] uppercase tracking-wide text-accent-500'>
                                        <span>Darker</span>
                                        <span>Brighter</span>
                                    </div>
                                </div>
                                <p className='text-xs text-accent-500'>
                                    Lower brightness makes the plan card darker. Use 15-30 for bright images.
                                </p>
                                <TextInputForm
                                    name='reinstallLimitPerWeek'
                                    label='OS Reinstall Limit (per week, 0 = unlimited)'
                                />
                                <div className='grid gap-3 md:grid-cols-2'>
                                    <CheckboxForm
                                        name={'provisioningEnabled'}
                                        label='Enable for provisioning'
                                    />
                                    <CheckboxForm
                                        name={'maintenanceMode'}
                                        label='Maintenance mode'
                                    />
                                </div>
                                <div className='grid gap-3 md:grid-cols-3'>
                                    <TextInputForm
                                        name='provisioningPriority'
                                        label='Provisioning Priority'
                                    />
                                    <TextInputForm
                                        name='provisioningMemoryThresholdPercent'
                                        label='RAM Threshold (%)'
                                    />
                                    <TextInputForm
                                        name='provisioningDiskThresholdPercent'
                                        label='Disk Threshold (%)'
                                    />
                                </div>
                            </div>
                        </div>
                    </FormCard.Body>
                    <FormCard.Footer>
                        <Button
                            loading={form.formState.isSubmitting}
                            disabled={!form.formState.isDirty}
                            type='submit'
                            variant='filled'
                            color='success'
                            size='sm'
                        >
                            {tStrings('save')}
                        </Button>
                    </FormCard.Footer>
                </form>
            </FormProvider>
        </FormCard>
    )
}

export default NodeInformationCard
