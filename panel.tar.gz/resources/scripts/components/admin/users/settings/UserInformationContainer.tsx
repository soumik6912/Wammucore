import { useFlashKey } from '@/util/useFlash'
import { FormikProvider, useFormik } from 'formik'
import { useEffect, useMemo } from 'react'
import * as yup from 'yup'

import useResellersSWR from '@/api/admin/resellers/useResellersSWR'
import updateUser from '@/api/admin/users/updateUser'
import useUserSWR from '@/api/admin/users/useUserSWR'

import Button from '@/components/elements/Button'
import FlashMessageRender from '@/components/elements/FlashMessageRenderer'
import FormCard from '@/components/elements/FormCard'
import SelectFormik from '@/components/elements/formik/SelectFormik'
import TextInputFormik from '@/components/elements/formik/TextInputFormik'
import { useStoreState } from '@/state'


const UserInformationContainer = () => {
    const actor = useStoreState(state => state.user.data)
    const canManageAdminFlags = Boolean(actor?.rootAdmin)
    const { data: user, mutate } = useUserSWR()
    const { data: resellerResponse, isLoading: isLoadingResellers } =
        useResellersSWR({ page: 1, perPage: 200 })
    const { clearFlashes, clearAndAddHttpError } = useFlashKey(
        'admin:user:settings:general'
    )

    const resellerOptions = useMemo(
        () =>
            resellerResponse?.items.map(reseller => ({
                value: reseller.id.toString(),
                label: reseller.isDefault
                    ? `${reseller.displayName} (Default)`
                    : reseller.displayName,
            })) ?? [],
        [resellerResponse]
    )

    const form = useFormik({
        enableReinitialize: true,
        initialValues: {
            name: user.name,
            email: user.email,
            password: '',
            accountType: user.rootAdmin
                ? 'root_admin'
                : user.resellerAdmin
                ? 'reseller_admin'
                : user.resellerId
                ? 'reseller_customer'
                : 'platform_user',
            rootAdmin: user.rootAdmin,
            resellerAdmin: user.resellerAdmin,
            resellerId: user.resellerId ? user.resellerId.toString() : '',
        },
        validationSchema: yup.object({
            name: yup
                .string()
                .max(191, 'Do not exceed 191 characters')
                .required('A name is required.'),
            email: yup
                .string()
                .email('Enter a valid email address')
                .required('An email address is required.'),
            password: yup
                .string()
                .matches(
                    /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
                    'Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character'
                )
                .optional(),
            accountType: yup
                .string()
                .oneOf(['platform_user', 'root_admin', 'reseller_admin', 'reseller_customer']),
            rootAdmin: yup.boolean(),
            resellerAdmin: yup.boolean(),
            resellerId: yup.string().when('accountType', {
                is: (value: string) =>
                    value === 'reseller_admin' || value === 'reseller_customer',
                then: schema => schema.required('Select a reseller.'),
                otherwise: schema => schema.optional(),
            }),
        }),
        onSubmit: async ({ password, accountType, resellerId, ...values }) => {
            clearFlashes()
            try {
                const updatedUser = await updateUser(user.id, {
                    ...values,
                    rootAdmin: accountType === 'root_admin',
                    resellerAdmin: accountType === 'reseller_admin',
                    resellerId:
                        accountType === 'reseller_admin' || accountType === 'reseller_customer'
                            ? Number(resellerId)
                            : undefined,
                    password: password.length > 0 ? password : null,
                })

                mutate(updatedUser, false)
            } catch (e) {
                clearAndAddHttpError(e as Error)
            }
        },
    })

    useEffect(() => {
        const accountType = form.values.accountType
        form.setFieldValue('rootAdmin', accountType === 'root_admin', false)
        form.setFieldValue('resellerAdmin', accountType === 'reseller_admin', false)

        if (accountType === 'platform_user' || accountType === 'root_admin') {
            form.setFieldValue('resellerId', '', false)
        }
    }, [form, form.values.accountType])

    return (
        <FormCard className='w-full'>
            <FormikProvider value={form}>
                <form onSubmit={form.handleSubmit}>
                    <FormCard.Body>
                        <FormCard.Title>User Information</FormCard.Title>
                        <div className='space-y-3 mt-3'>
                            <FlashMessageRender byKey='admin:user:settings:general' />
                            <TextInputFormik name='name' label='Name' />
                            <TextInputFormik name='email' label='Email' />
                            <TextInputFormik
                                name='password'
                                label='Password'
                                placeholder={'Override password'}
                            />
                            {canManageAdminFlags ? (
                                <SelectFormik
                                    name='accountType'
                                    label='Account Type'
                                    data={[
                                        { value: 'platform_user', label: 'Platform User' },
                                        { value: 'root_admin', label: 'Root Admin' },
                                        { value: 'reseller_admin', label: 'Reseller Admin' },
                                        { value: 'reseller_customer', label: 'Reseller Customer' },
                                    ]}
                                />
                            ) : null}
                            {(form.values.accountType === 'reseller_admin' ||
                                form.values.accountType === 'reseller_customer') ? (
                                <>
                                    <SelectFormik
                                        name='resellerId'
                                        label='Reseller'
                                        data={resellerOptions}
                                        loading={isLoadingResellers}
                                        nothingFound='No resellers available'
                                    />
                                    <p className='-mt-2 text-xs text-white/55'>
                                        Only reseller accounts should be attached here. Leave main platform users outside reseller workspaces.
                                    </p>
                                </>
                            ) : null}
                        </div>
                    </FormCard.Body>
                    <FormCard.Footer>
                        <Button
                            loading={form.isSubmitting}
                            disabled={!form.dirty}
                            type='submit'
                            variant='filled'
                            color='success'
                            size='sm'
                        >
                            Save
                        </Button>
                    </FormCard.Footer>
                </form>
            </FormikProvider>
        </FormCard>
    )
}

export default UserInformationContainer
