import { useFlashKey } from '@/util/useFlash'
import usePagination from '@/util/usePagination'
import { FormikProvider, useFormik } from 'formik'
import { useEffect, useMemo } from 'react'
import * as yup from 'yup'

import useResellersSWR from '@/api/admin/resellers/useResellersSWR'
import createUser from '@/api/admin/users/createUser'
import useUsersSWR from '@/api/admin/users/useUsersSWR'

import FlashMessageRender from '@/components/elements/FlashMessageRenderer'
import MessageBox from '@/components/elements/MessageBox'
import Modal from '@/components/elements/Modal'
import SelectFormik from '@/components/elements/formik/SelectFormik'
import TextInputFormik from '@/components/elements/formik/TextInputFormik'
import { useStoreState } from '@/state'


interface Props {
    open: boolean
    onClose: () => void
    scope: 'platform_users' | 'platform_staff' | 'reseller_admins' | 'reseller_customers' | 'all'
}

const CreateUserButton = ({ open, onClose, scope }: Props) => {
    const actor = useStoreState(state => state.user.data)
    const canManageAdminFlags = Boolean(actor?.rootAdmin)
    const [page] = usePagination()
    const { clearFlashes, clearAndAddHttpError } =
        useFlashKey('admin:users.create')
    const { data: resellerResponse, isLoading: isLoadingResellers } =
        useResellersSWR({ page: 1, perPage: 200 })
    const { mutate } = useUsersSWR({ page, scope })

    const form = useFormik({
        enableReinitialize: true,
        initialValues: {
            name: '',
            email: '',
            password: '',
            accountType: canManageAdminFlags
                ? scope === 'reseller_admins'
                    ? 'reseller_admin'
                    : scope === 'reseller_customers'
                    ? 'reseller_customer'
                    : scope === 'platform_staff'
                    ? 'root_admin'
                    : 'platform_user'
                : 'platform_user',
            rootAdmin: false,
            resellerAdmin: false,
            resellerId: '',
        },
        validationSchema: yup.object({
            name: yup
                .string()
                .max(191, 'Do not exceed 191 characters')
                .required('A name is required.'),
            email: yup
                .string()
                .email('Enter a valid email address')
                .required('An email address is required.'),
            password: yup
                .string()
                .matches(
                    /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
                    'Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character'
                )
                .required('A password is required.'),
            accountType: yup
                .string()
                .oneOf(['platform_user', 'root_admin', 'reseller_admin', 'reseller_customer']),
            rootAdmin: yup.boolean(),
            resellerAdmin: yup.boolean(),
            resellerId: yup.string().when('accountType', {
                is: (value: string) =>
                    value === 'reseller_admin' || value === 'reseller_customer',
                then: schema => schema.required('Select a reseller.'),
                otherwise: schema => schema.optional(),
            }),
        }),
        onSubmit: async ({ accountType, resellerId, ...values }) => {
            clearFlashes()
            try {
                await createUser({
                    ...values,
                    rootAdmin: accountType === 'root_admin',
                    resellerAdmin: accountType === 'reseller_admin',
                    resellerId:
                        accountType === 'reseller_admin' || accountType === 'reseller_customer'
                            ? Number(resellerId)
                            : undefined,
                })

                await mutate()

                handleClose()
            } catch (e) {
                clearAndAddHttpError(e as Error)
            }
        },
    })

    const resellerOptions = useMemo(
        () =>
            resellerResponse?.items.map(reseller => ({
                value: reseller.id.toString(),
                label: reseller.isDefault
                    ? `${reseller.displayName} (Default)`
                    : reseller.displayName,
            })) ?? [],
        [resellerResponse]
    )

    useEffect(() => {
        const accountType = form.values.accountType
        form.setFieldValue('rootAdmin', accountType === 'root_admin', false)
        form.setFieldValue('resellerAdmin', accountType === 'reseller_admin', false)

        if (accountType === 'platform_user' || accountType === 'root_admin') {
            form.setFieldValue('resellerId', '', false)
        }
    }, [form, form.values.accountType])

    const handleClose = () => {
        clearFlashes()
        form.resetForm()
        onClose()
    }

    return (
        <>
            <Modal open={open} onClose={handleClose}>
                <Modal.Header>
                    <Modal.Title>Create a User</Modal.Title>
                </Modal.Header>

                <FormikProvider value={form}>
                    <form onSubmit={form.handleSubmit}>
                        <Modal.Body>
                            <FlashMessageRender
                                className='mb-5'
                                byKey={'admin:users.create'}
                            />
                            <TextInputFormik name={'name'} label={'Name'} />
                            <TextInputFormik name={'email'} label={'Email'} />
                            <TextInputFormik
                                name={'password'}
                                label={'Password'}
                                type={'password'}
                            />
                            {canManageAdminFlags ? (
                                <SelectFormik
                                    name={'accountType'}
                                    label={'Account Type'}
                                    data={[
                                        { value: 'platform_user', label: 'Platform User' },
                                        { value: 'root_admin', label: 'Root Admin' },
                                        { value: 'reseller_admin', label: 'Reseller Admin' },
                                        { value: 'reseller_customer', label: 'Reseller Customer' },
                                    ]}
                                />
                            ) : null}
                            {(form.values.accountType === 'reseller_admin' ||
                                form.values.accountType === 'reseller_customer') ? (
                                <>
                                    <SelectFormik
                                        name={'resellerId'}
                                        label={'Reseller'}
                                        data={resellerOptions}
                                        loading={isLoadingResellers}
                                        nothingFound={'No resellers available'}
                                    />
                                    <p className='-mt-2 text-xs text-white/55'>
                                        Choose the exact reseller workspace for this account. Main platform users stay separate and should not be assigned here.
                                    </p>
                                </>
                            ) : null}
                            {canManageAdminFlags && form.values.accountType === 'root_admin' && (
                                <MessageBox type={'warning'} title={'Warning'}>
                                    You are giving this user administrator
                                    privileges
                                </MessageBox>
                            )}
                        </Modal.Body>
                        <Modal.Actions>
                            <Modal.Action type='button' onClick={handleClose}>
                                Cancel
                            </Modal.Action>
                            <Modal.Action
                                type='submit'
                                loading={form.isSubmitting}
                            >
                                Create
                            </Modal.Action>
                        </Modal.Actions>
                    </form>
                </FormikProvider>
            </Modal>
        </>
    )
}

export default CreateUserButton
