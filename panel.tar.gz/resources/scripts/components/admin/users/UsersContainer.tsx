import usePagination from '@/util/usePagination'
import { useDebouncedValue } from '@mantine/hooks'
import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'

import { httpErrorToHuman } from '@/api/http'
import getUserSsoLink from '@/api/admin/users/getUserSsoLink'
import { User } from '@/api/admin/users/getUsers'
import useUsersSWR from '@/api/admin/users/useUsersSWR'

import Menu from '@/components/elements/Menu'
import PageContentBlock from '@/components/elements/PageContentBlock'
import Pagination from '@/components/elements/Pagination'
import Spinner from '@/components/elements/Spinner'
import Table, {
    Actions,
    ColumnArray,
    RowActionsProps,
} from '@/components/elements/displays/Table'

import SearchBar from '@/components/admin/SearchBar'
import CreateUserModal from '@/components/admin/users/CreateUserModal'
import { useStoreState } from '@/state'
import useNotify from '@/util/useNotify'

type UserDirectoryScope =
    | 'platform_users'
    | 'platform_staff'
    | 'reseller_admins'
    | 'reseller_customers'
    | 'all'

const scopeOptions: Array<{ value: UserDirectoryScope; label: string }> = [
    { value: 'platform_users', label: 'Platform Users' },
    { value: 'platform_staff', label: 'Platform Staff' },
    { value: 'reseller_admins', label: 'Reseller Admins' },
    { value: 'reseller_customers', label: 'Reseller Customers' },
    { value: 'all', label: 'All Accounts' },
]

const accountTypeLabel = (user: User): string => {
    if (user.rootAdmin) {
        return 'Root Admin'
    }

    if (user.resellerAdmin) {
        return 'Reseller Admin'
    }

    if (user.resellerId) {
        return 'Reseller Customer'
    }

    return 'Platform User'
}

const canViewAsCustomer = (user: User): boolean =>
    !user.rootAdmin && !user.resellerAdmin && !user.isPlatformAdmin

const UsersContainer = () => {
    const actor = useStoreState(state => state.user.data)
    const notify = useNotify()
    const [open, setOpen] = useState(false)
    const [query, setQuery] = useState('')
    const [scope, setScope] = useState<UserDirectoryScope>('platform_users')
    const [openingUserId, setOpeningUserId] = useState<number | null>(null)
    const [debouncedQuery] = useDebouncedValue(query, 200)
    const [page, setPage] = usePagination()
    const { data } = useUsersSWR({ page, query: debouncedQuery, scope })
    const visibleScopeOptions = useMemo(
        () => (actor?.rootAdmin ? scopeOptions : scopeOptions.slice(0, 2)),
        [actor?.rootAdmin]
    )
    const createButtonLabel = useMemo(() => {
        switch (scope) {
            case 'platform_staff':
                return 'New Staff User'
            case 'reseller_admins':
                return 'New Reseller Admin'
            case 'reseller_customers':
                return 'New Reseller Customer'
            case 'all':
                return 'New User'
            case 'platform_users':
            default:
                return 'New Platform User'
        }
    }, [scope])
    const columns = useMemo<ColumnArray<User>>(() => {
        const baseColumns: ColumnArray<User> = [
            {
                accessor: 'name',
                header: 'Name',
                cell: ({ value, row }) => (
                    <Link
                        to={`/admin/users/${row.id}/settings`}
                        className='link text-foreground'
                    >
                        {value}
                    </Link>
                ),
            },
            {
                accessor: 'email',
                header: 'Email',
            },
        ]

        if (scope === 'reseller_admins' || scope === 'reseller_customers' || scope === 'all') {
            baseColumns.push({
                accessor: 'resellerDisplayName',
                header: scope === 'all' ? 'Directory' : 'Reseller',
                cell: ({ value, row }) => {
                    if (value) {
                        return value
                    }

                    return row.rootAdmin || (!row.resellerAdmin && !row.resellerId)
                        ? 'Main Platform'
                        : 'Reseller Workspace'
                },
            })
        }

        baseColumns.push(
            {
                accessor: 'rootAdmin',
                header: 'Account Type',
                align: 'center',
                cell: ({ row }) => {
                    const tone = row.rootAdmin
                        ? 'border-rose-400/35 bg-rose-500/15 text-rose-100'
                        : row.resellerAdmin
                        ? 'border-sky-400/35 bg-sky-500/15 text-sky-100'
                        : row.resellerId
                        ? 'border-indigo-400/35 bg-indigo-500/15 text-indigo-100'
                        : 'border-emerald-400/35 bg-emerald-500/15 text-emerald-100'

                    return (
                        <div className='grid place-items-center'>
                            <span className={`inline-flex rounded-full border px-3 py-1 text-[11px] font-medium uppercase tracking-[0.14em] ${tone}`}>
                                {accountTypeLabel(row)}
                            </span>
                        </div>
                    )
                },
            },
            {
                accessor: 'serversCount',
                header: 'Servers',
                align: 'center',
                cell: ({ value, row }) => (
                    <Link
                        to={`/admin/users/${row.id}/servers`}
                        className='link text-foreground'
                    >
                        {value}
                    </Link>
                ),
            }
        )

        return baseColumns
    }, [scope])

    const handleViewAsUser = async (user: User) => {
        if (!canViewAsCustomer(user)) {
            notify({
                color: 'red',
                message: 'Admin accounts cannot be opened with customer view.',
            })

            return
        }

        setOpeningUserId(user.id)

        try {
            const link = await getUserSsoLink(user.id)

            window.location.assign(link.ssoUrl)
        } catch (error) {
            setOpeningUserId(null)
            notify({ color: 'red', message: httpErrorToHuman(error) })
        }
    }

    const rowActions = ({ row: user }: RowActionsProps<User>) => {
        const disabled = !canViewAsCustomer(user) || openingUserId === user.id

        return (
            <Actions>
                <Menu.Item
                    disabled={disabled}
                    onClick={() => void handleViewAsUser(user)}
                >
                    <div className='flex items-center gap-2.5'>
                        <span className='grid h-6 w-6 place-items-center rounded-lg border border-emerald-300/30 bg-emerald-400/10 text-xs text-emerald-100'>
                            <svg className='h-3.5 w-3.5' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M13 7h4m0 0v4m0-4L7 17' />
                            </svg>
                        </span>
                        <span className='font-medium'>
                            {openingUserId === user.id ? 'Opening...' : 'View As User'}
                        </span>
                    </div>
                </Menu.Item>
                <Menu.Divider />
                <Menu.Item
                    onClick={() =>
                        window.location.assign(`/admin/users/${user.id}/settings`)
                    }
                >
                    Edit User
                </Menu.Item>
                <Menu.Item
                    onClick={() =>
                        window.location.assign(`/admin/users/${user.id}/servers`)
                    }
                >
                    View User Servers
                </Menu.Item>
            </Actions>
        )
    }

    return (
        <div className='min-h-screen bg-[#05020f]'>
            <CreateUserModal open={open} onClose={() => setOpen(false)} scope={scope} />
            <PageContentBlock title='Users' showFlashKey='admin:users'>
                <div className='mb-4 flex flex-wrap gap-2'>
                    {visibleScopeOptions.map(option => (
                        <button
                            key={option.value}
                            type='button'
                            onClick={() => setScope(option.value)}
                            className={`rounded-full border px-4 py-2 text-xs font-medium uppercase tracking-[0.14em] transition ${
                                scope === option.value
                                    ? 'border-indigo-300/40 bg-indigo-500/20 text-indigo-100 shadow-[0_0_24px_rgba(99,102,241,0.18)]'
                                    : 'border-white/10 bg-white/[0.03] text-white/65 hover:border-white/20 hover:text-white'
                            }`}
                        >
                            {option.label}
                        </button>
                    ))}
                </div>
                <div className='mb-6 rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                    <SearchBar
                        value={query}
                        onChange={e => setQuery(e.target.value)}
                        buttonText={createButtonLabel}
                        onClick={() => setOpen(true)}
                    />
                </div>
                <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                    {!data ? (
                        <div className='py-12'>
                            <Spinner />
                        </div>
                    ) : (
                        <Pagination data={data} onPageSelect={setPage}>
                            {({ items }) => (
                                <Table
                                    columns={columns}
                                    data={items}
                                    rowActions={rowActions}
                                />
                            )}
                        </Pagination>
                    )}
                </div>
            </PageContentBlock>
        </div>
    )
}

export default UsersContainer
