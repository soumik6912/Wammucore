import getPanelSettings, {
    NotificationTemplate,
} from '@/api/admin/settings/getPanelSettings'
import {
    sendPanelTestMail,
    updatePanelEmailSettings,
} from '@/api/admin/settings/updatePanelSettings'
import PageContentBlock from '@/components/elements/PageContentBlock'
import { useStoreActions, useStoreState } from '@/state'
import {
    CheckCircleIcon,
    EnvelopeIcon,
    PaperAirplaneIcon,
    SparklesIcon,
} from '@heroicons/react/24/outline'
import { useEffect, useState } from 'react'

const panelCard =
    'rounded-2xl border border-white/10 bg-[#0d1325] p-5 shadow-[0_20px_60px_rgba(0,0,0,0.22)]'
const inputClass =
    'w-full rounded-lg border border-white/15 bg-[#111a31] px-4 py-2.5 text-white placeholder:text-white/35 outline-none transition-colors focus:border-cyan-300'

const EmailSettingsContainer = () => {
    const settings = useStoreState(state => state.settings.data)
    const setSettings = useStoreActions(actions => actions.settings.setSettings)

    const [platformMail, setPlatformMail] = useState({
        enabled: false,
        configured: false,
        source: 'none' as 'panel' | 'env' | 'none',
        host: '',
        port: '587',
        encryption: 'tls' as 'tls' | 'ssl' | 'none',
        username: '',
        passwordSet: false,
        fromEmail: '',
        fromName: 'WammuHost',
        replyToEmail: '',
        ehloDomain: '',
    })
    const [platformMailPasswordDraft, setPlatformMailPasswordDraft] =
        useState('')
    const [testMailRecipient, setTestMailRecipient] = useState('')
    const [resellerEmailVerificationEnabled, setResellerEmailVerificationEnabled] =
        useState(false)
    const [
        resellerEmailVerificationAvailable,
        setResellerEmailVerificationAvailable,
    ] = useState(false)
    const [
        resellerEmailVerificationEffective,
        setResellerEmailVerificationEffective,
    ] = useState(false)
    const [passwordResetEnabled, setPasswordResetEnabled] = useState(false)
    const [passwordResetEffective, setPasswordResetEffective] = useState(false)
    const [notificationEmailEnabled, setNotificationEmailEnabled] =
        useState(false)
    const [notificationEmailEffective, setNotificationEmailEffective] =
        useState(false)
    const [notificationTemplates, setNotificationTemplates] = useState<
        NotificationTemplate[]
    >([])
    const [isLoading, setIsLoading] = useState(true)
    const [isSaving, setIsSaving] = useState(false)
    const [isSendingTestMail, setIsSendingTestMail] = useState(false)
    const [templateTestLoading, setTemplateTestLoading] = useState<
        string | null
    >(null)
    const [status, setStatus] = useState<{
        type: 'ok' | 'error'
        text: string
    } | null>(null)

    const platformMailDraftPort = Number(platformMail.port)
    const platformMailDraftReady =
        platformMail.enabled &&
        platformMail.host.trim() !== '' &&
        platformMailDraftPort > 0 &&
        platformMailDraftPort <= 65535 &&
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(platformMail.fromEmail.trim())
    const passwordResetSwitchChecked =
        passwordResetEnabled && platformMailDraftReady
    const notificationEmailSwitchChecked =
        notificationEmailEnabled && platformMailDraftReady

    const applyLoadedSettings = (data: Awaited<ReturnType<typeof getPanelSettings>>) => {
        setPlatformMail({
            enabled: Boolean(data.platformMail.enabled),
            configured: Boolean(data.platformMail.configured),
            source: data.platformMail.source || 'none',
            host: data.platformMail.host || '',
            port:
                data.platformMail.port === null
                    ? '587'
                    : String(data.platformMail.port),
            encryption: data.platformMail.encryption || 'none',
            username: data.platformMail.username || '',
            passwordSet: Boolean(data.platformMail.passwordSet),
            fromEmail: data.platformMail.fromEmail || '',
            fromName: data.platformMail.fromName || 'WammuHost',
            replyToEmail: data.platformMail.replyToEmail || '',
            ehloDomain: data.platformMail.ehloDomain || '',
        })
        setPlatformMailPasswordDraft('')
        setResellerEmailVerificationEnabled(
            Boolean(data.resellerEmailVerificationEnabled)
        )
        setResellerEmailVerificationAvailable(
            Boolean(data.resellerEmailVerificationAvailable)
        )
        setResellerEmailVerificationEffective(
            Boolean(data.resellerEmailVerificationEffective)
        )
        setPasswordResetEnabled(Boolean(data.passwordResetEnabled))
        setPasswordResetEffective(Boolean(data.passwordResetEffective))
        setNotificationEmailEnabled(Boolean(data.notificationEmailEnabled))
        setNotificationEmailEffective(Boolean(data.notificationEmailEffective))
        setNotificationTemplates(data.notificationTemplates || [])
    }

    const updateGlobalSettings = (
        updated: Awaited<ReturnType<typeof getPanelSettings>>
    ) => {
        if (!settings) {
            return
        }

        setSettings({
            ...settings,
            resellerEmailVerificationEnabled:
                updated.resellerEmailVerificationEnabled,
            resellerEmailVerificationAvailable:
                updated.resellerEmailVerificationAvailable,
            resellerEmailVerificationEffective:
                updated.resellerEmailVerificationEffective,
            passwordResetEnabled: updated.passwordResetEnabled,
            passwordResetAvailable: updated.passwordResetAvailable,
            passwordResetEffective: updated.passwordResetEffective,
            platformMail: updated.platformMail,
            notificationEmailEnabled: updated.notificationEmailEnabled,
            notificationEmailAvailable: updated.notificationEmailAvailable,
            notificationEmailEffective: updated.notificationEmailEffective,
            notificationTemplates: updated.notificationTemplates,
            clientAuth: {
                ...(settings.clientAuth || {
                    allowSelfRegistration: false,
                    enableEmail2fa: false,
                    enableEmailVerification: false,
                    mailerConfigured: false,
                    passwordResetEnabled: false,
                }),
                mailerConfigured: Boolean(updated.platformMail.configured),
                passwordResetEnabled: Boolean(updated.passwordResetEffective),
            },
        })
    }

    useEffect(() => {
        let mounted = true

        getPanelSettings()
            .then(data => {
                if (mounted) {
                    applyLoadedSettings(data)
                }
            })
            .catch(() => {
                if (mounted) {
                    setStatus({
                        type: 'error',
                        text: 'Failed to load email settings.',
                    })
                }
            })
            .finally(() => {
                if (mounted) {
                    setIsLoading(false)
                }
            })

        return () => {
            mounted = false
        }
    }, [])

    const updateNotificationTemplate = (
        key: string,
        patch: Partial<NotificationTemplate>
    ) => {
        setNotificationTemplates(current =>
            current.map(template =>
                template.key === key ? { ...template, ...patch } : template
            )
        )
    }

    const handleSave = async () => {
        setIsSaving(true)
        setStatus(null)

        try {
            const updated = await updatePanelEmailSettings({
                resellerEmailVerificationEnabled,
                passwordResetEnabled: passwordResetSwitchChecked,
                platformMail: {
                    enabled: platformMail.enabled,
                    host: platformMail.host,
                    port: platformMail.port,
                    encryption: platformMail.encryption,
                    username: platformMail.username,
                    password:
                        platformMailPasswordDraft.trim() !== ''
                            ? platformMailPasswordDraft
                            : undefined,
                    fromEmail: platformMail.fromEmail,
                    fromName: platformMail.fromName,
                    replyToEmail: platformMail.replyToEmail,
                    ehloDomain: platformMail.ehloDomain,
                },
                notificationEmailEnabled: notificationEmailSwitchChecked,
                notificationTemplates,
            })

            applyLoadedSettings(updated)
            updateGlobalSettings(updated)
            setStatus({ type: 'ok', text: 'Email settings saved.' })
        } catch {
            setStatus({
                type: 'error',
                text: 'Failed to save email settings. Check SMTP values and try again.',
            })
        } finally {
            setIsSaving(false)
        }
    }

    const handleTestMail = async () => {
        setIsSendingTestMail(true)
        setStatus(null)

        try {
            const recipient = await sendPanelTestMail(
                testMailRecipient.trim() || null
            )
            setStatus({
                type: 'ok',
                text: `Test email sent to ${recipient}.`,
            })
        } catch {
            setStatus({
                type: 'error',
                text: 'Failed to send test email. Save SMTP settings first, then try again.',
            })
        } finally {
            setIsSendingTestMail(false)
        }
    }

    const handleTemplateTest = async (templateKey: string) => {
        setTemplateTestLoading(templateKey)
        setStatus(null)

        try {
            const recipient = await sendPanelTestMail(
                testMailRecipient.trim() || null,
                templateKey
            )
            setStatus({
                type: 'ok',
                text: `Template preview sent to ${recipient}.`,
            })
        } catch {
            setStatus({
                type: 'error',
                text: 'Failed to send template preview. Save SMTP settings first, then try again.',
            })
        } finally {
            setTemplateTestLoading(null)
        }
    }

    return (
        <PageContentBlock title='Email & Templates - Admin' containerSize='wide'>
            <div className='space-y-6'>
                <div className='overflow-hidden rounded-[2rem] border border-cyan-300/20 bg-[radial-gradient(circle_at_top_left,rgba(34,211,238,0.18),transparent_34%),linear-gradient(135deg,#0b1224,#11142b)] p-6 shadow-[0_30px_100px_rgba(0,0,0,0.32)]'>
                    <div className='flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between'>
                        <div>
                            <div className='inline-flex items-center gap-2 rounded-full border border-cyan-300/20 bg-cyan-400/10 px-3 py-1 text-xs font-bold uppercase tracking-[0.24em] text-cyan-100/80'>
                                <EnvelopeIcon className='h-4 w-4' />
                                Email Delivery
                            </div>
                            <h1 className='mt-4 text-3xl font-black tracking-tight text-white'>
                                SMTP & Notification Templates
                            </h1>
                            <p className='mt-2 max-w-3xl text-sm leading-7 text-white/60'>
                                Manage platform SMTP, password reset mail,
                                reseller verification mail, and notification
                                template copy from one focused section.
                            </p>
                        </div>
                        <button
                            type='button'
                            onClick={handleSave}
                            disabled={isSaving || isLoading}
                            className='inline-flex items-center justify-center rounded-2xl bg-cyan-400 px-5 py-3 text-sm font-black text-slate-950 transition hover:bg-cyan-300 disabled:cursor-not-allowed disabled:opacity-60'
                        >
                            {isSaving ? 'Saving...' : 'Save Email Settings'}
                        </button>
                    </div>
                </div>

                {status ? (
                    <div
                        className={`rounded-2xl border px-4 py-3 text-sm ${
                            status.type === 'ok'
                                ? 'border-emerald-300/20 bg-emerald-500/10 text-emerald-100'
                                : 'border-red-300/20 bg-red-500/10 text-red-100'
                        }`}
                    >
                        {status.text}
                    </div>
                ) : null}

                {isLoading ? (
                    <div className={panelCard}>
                        <p className='text-sm text-white/60'>
                            Loading email settings...
                        </p>
                    </div>
                ) : (
                    <>
                        <div className='grid gap-4 md:grid-cols-4'>
                            {[
                                [
                                    'Effective source',
                                    platformMail.source === 'panel'
                                        ? 'Root-admin GUI'
                                        : platformMail.source === 'env'
                                        ? 'Legacy env fallback'
                                        : 'Not configured',
                                ],
                                [
                                    'SMTP readiness',
                                    platformMailDraftReady
                                        ? 'Ready'
                                        : 'Incomplete',
                                ],
                                [
                                    'Password',
                                    platformMail.passwordSet
                                        ? 'Saved securely'
                                        : 'Not stored yet',
                                ],
                                [
                                    'Templates',
                                    `${notificationTemplates.length} loaded`,
                                ],
                            ].map(([label, value]) => (
                                <div
                                    key={label}
                                    className='rounded-2xl border border-white/10 bg-[#0d1325] px-4 py-3 text-sm'
                                >
                                    <span className='block text-xs uppercase tracking-wide text-white/40'>
                                        {label}
                                    </span>
                                    <span className='mt-1 block font-bold text-white'>
                                        {value}
                                    </span>
                                </div>
                            ))}
                        </div>

                        <section className={panelCard}>
                            <div className='flex items-start gap-3'>
                                <CheckCircleIcon className='mt-0.5 h-6 w-6 text-emerald-200' />
                                <div>
                                    <h2 className='text-lg font-bold text-white'>
                                        Email Features
                                    </h2>
                                    <p className='mt-1 text-sm leading-6 text-white/55'>
                                        Turn customer-facing mail features on
                                        only after delivery is ready.
                                    </p>
                                </div>
                            </div>

                            <div className='mt-5 grid gap-4 xl:grid-cols-3'>
                                <div className='rounded-xl border border-white/10 bg-[#111a31] p-4'>
                                    <div className='flex items-start justify-between gap-3'>
                                        <div>
                                            <h3 className='text-sm font-semibold text-white'>
                                                Reseller Email Verification
                                            </h3>
                                            <p className='mt-1 text-xs leading-5 text-white/50'>
                                                Adds the verification step to
                                                reseller onboarding when mail is
                                                configured.
                                            </p>
                                        </div>
                                        <input
                                            type='checkbox'
                                            checked={
                                                resellerEmailVerificationEnabled
                                            }
                                            disabled={
                                                !resellerEmailVerificationAvailable
                                            }
                                            onChange={event =>
                                                setResellerEmailVerificationEnabled(
                                                    event.currentTarget.checked
                                                )
                                            }
                                            className='mt-1 h-4 w-4 rounded border border-white/20 bg-transparent'
                                        />
                                    </div>
                                    <p className='mt-3 text-xs text-white/45'>
                                        Effective:{' '}
                                        <span className='font-semibold text-white/75'>
                                            {resellerEmailVerificationEffective
                                                ? 'Active'
                                                : 'Skipped'}
                                        </span>
                                    </p>
                                </div>

                                <div className='rounded-xl border border-white/10 bg-[#111a31] p-4'>
                                    <div className='flex items-start justify-between gap-3'>
                                        <div>
                                            <h3 className='text-sm font-semibold text-white'>
                                                Password Reset Emails
                                            </h3>
                                            <p className='mt-1 text-xs leading-5 text-white/50'>
                                                Shows forgot-password recovery
                                                only when GUI SMTP is valid.
                                            </p>
                                        </div>
                                        <input
                                            type='checkbox'
                                            checked={passwordResetSwitchChecked}
                                            disabled={!platformMailDraftReady}
                                            onChange={event =>
                                                setPasswordResetEnabled(
                                                    event.currentTarget.checked
                                                )
                                            }
                                            className='mt-1 h-4 w-4 rounded border border-white/20 bg-transparent'
                                        />
                                    </div>
                                    <p className='mt-3 text-xs text-white/45'>
                                        Login link:{' '}
                                        <span className='font-semibold text-white/75'>
                                            {passwordResetEffective
                                                ? 'Visible'
                                                : 'Hidden'}
                                        </span>
                                    </p>
                                </div>

                                <div className='rounded-xl border border-white/10 bg-[#111a31] p-4'>
                                    <div className='flex items-start justify-between gap-3'>
                                        <div>
                                            <h3 className='text-sm font-semibold text-white'>
                                                Notification Emails
                                            </h3>
                                            <p className='mt-1 text-xs leading-5 text-white/50'>
                                                Sends platform notification
                                                templates through saved SMTP.
                                            </p>
                                        </div>
                                        <input
                                            type='checkbox'
                                            checked={
                                                notificationEmailSwitchChecked
                                            }
                                            disabled={!platformMailDraftReady}
                                            onChange={event =>
                                                setNotificationEmailEnabled(
                                                    event.currentTarget.checked
                                                )
                                            }
                                            className='mt-1 h-4 w-4 rounded border border-white/20 bg-transparent'
                                        />
                                    </div>
                                    <p className='mt-3 text-xs text-white/45'>
                                        Effective:{' '}
                                        <span className='font-semibold text-white/75'>
                                            {notificationEmailEffective
                                                ? 'Enabled'
                                                : 'Disabled'}
                                        </span>
                                    </p>
                                </div>
                            </div>
                        </section>

                        <section className={panelCard}>
                            <div className='flex flex-col gap-3 md:flex-row md:items-start md:justify-between'>
                                <div className='flex items-start gap-3'>
                                    <PaperAirplaneIcon className='mt-0.5 h-6 w-6 text-cyan-200' />
                                    <div>
                                        <h2 className='text-lg font-bold text-white'>
                                            SMTP Transport
                                        </h2>
                                        <p className='mt-1 text-sm leading-6 text-white/55'>
                                            These settings override env mail for
                                            outgoing platform email.
                                        </p>
                                    </div>
                                </div>
                                <label className='inline-flex items-center gap-3 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-white/85'>
                                    <input
                                        type='checkbox'
                                        checked={platformMail.enabled}
                                        onChange={event => {
                                            const checked =
                                                event.currentTarget.checked

                                            setPlatformMail(current => ({
                                                ...current,
                                                enabled: checked,
                                            }))

                                            if (!checked) {
                                                setPasswordResetEnabled(false)
                                                setNotificationEmailEnabled(false)
                                            }
                                        }}
                                        className='h-4 w-4 rounded border border-white/20 bg-transparent'
                                    />
                                    Use GUI SMTP
                                </label>
                            </div>

                            <div className='mt-5 grid gap-4 md:grid-cols-2'>
                                <div>
                                    <label className='mb-2 block text-sm font-medium text-white/80'>
                                        SMTP Host
                                    </label>
                                    <input
                                        type='text'
                                        value={platformMail.host}
                                        onChange={event =>
                                            setPlatformMail(current => ({
                                                ...current,
                                                host: event.target.value,
                                            }))
                                        }
                                        placeholder='smtp.yourprovider.com'
                                        className={inputClass}
                                    />
                                </div>
                                <div>
                                    <label className='mb-2 block text-sm font-medium text-white/80'>
                                        SMTP Port
                                    </label>
                                    <input
                                        type='number'
                                        min={1}
                                        max={65535}
                                        value={platformMail.port}
                                        onChange={event =>
                                            setPlatformMail(current => ({
                                                ...current,
                                                port: event.target.value,
                                            }))
                                        }
                                        placeholder='587'
                                        className={inputClass}
                                    />
                                </div>
                                <div>
                                    <label className='mb-2 block text-sm font-medium text-white/80'>
                                        Encryption
                                    </label>
                                    <select
                                        value={platformMail.encryption}
                                        onChange={event =>
                                            setPlatformMail(current => ({
                                                ...current,
                                                encryption: event.target
                                                    .value as
                                                    | 'tls'
                                                    | 'ssl'
                                                    | 'none',
                                            }))
                                        }
                                        className={inputClass}
                                    >
                                        <option value='tls'>TLS</option>
                                        <option value='ssl'>SSL</option>
                                        <option value='none'>None</option>
                                    </select>
                                </div>
                                <div>
                                    <label className='mb-2 block text-sm font-medium text-white/80'>
                                        SMTP Username
                                    </label>
                                    <input
                                        type='text'
                                        value={platformMail.username}
                                        onChange={event =>
                                            setPlatformMail(current => ({
                                                ...current,
                                                username: event.target.value,
                                            }))
                                        }
                                        placeholder='mailer@yourdomain.com'
                                        className={inputClass}
                                    />
                                </div>
                                <div>
                                    <label className='mb-2 block text-sm font-medium text-white/80'>
                                        SMTP Password
                                    </label>
                                    <input
                                        type='password'
                                        value={platformMailPasswordDraft}
                                        onChange={event =>
                                            setPlatformMailPasswordDraft(
                                                event.target.value
                                            )
                                        }
                                        placeholder={
                                            platformMail.passwordSet
                                                ? 'Leave blank to keep current password'
                                                : 'Enter SMTP password'
                                        }
                                        className={inputClass}
                                    />
                                    <p className='mt-1.5 text-xs text-white/50'>
                                        {platformMail.passwordSet
                                            ? 'A password is already stored. Enter a new one only to replace it.'
                                            : 'The password is encrypted before storage.'}
                                    </p>
                                </div>
                                <div>
                                    <label className='mb-2 block text-sm font-medium text-white/80'>
                                        EHLO Domain
                                    </label>
                                    <input
                                        type='text'
                                        value={platformMail.ehloDomain}
                                        onChange={event =>
                                            setPlatformMail(current => ({
                                                ...current,
                                                ehloDomain: event.target.value,
                                            }))
                                        }
                                        placeholder='mail.wammuhost.com'
                                        className={inputClass}
                                    />
                                </div>
                                <div>
                                    <label className='mb-2 block text-sm font-medium text-white/80'>
                                        From Email
                                    </label>
                                    <input
                                        type='email'
                                        value={platformMail.fromEmail}
                                        onChange={event =>
                                            setPlatformMail(current => ({
                                                ...current,
                                                fromEmail: event.target.value,
                                            }))
                                        }
                                        placeholder='noreply@wammuhost.com'
                                        className={inputClass}
                                    />
                                </div>
                                <div>
                                    <label className='mb-2 block text-sm font-medium text-white/80'>
                                        From Name
                                    </label>
                                    <input
                                        type='text'
                                        value={platformMail.fromName}
                                        onChange={event =>
                                            setPlatformMail(current => ({
                                                ...current,
                                                fromName: event.target.value,
                                            }))
                                        }
                                        placeholder='WammuHost'
                                        className={inputClass}
                                    />
                                </div>
                                <div className='md:col-span-2'>
                                    <label className='mb-2 block text-sm font-medium text-white/80'>
                                        Reply-To Email
                                    </label>
                                    <input
                                        type='email'
                                        value={platformMail.replyToEmail}
                                        onChange={event =>
                                            setPlatformMail(current => ({
                                                ...current,
                                                replyToEmail:
                                                    event.target.value,
                                            }))
                                        }
                                        placeholder='support@wammuhost.com'
                                        className={inputClass}
                                    />
                                </div>
                            </div>

                            <div className='mt-5 rounded-xl border border-white/10 bg-[#111a31] p-4'>
                                <div className='grid gap-3 md:grid-cols-[minmax(0,1fr)_auto]'>
                                    <div>
                                        <label className='mb-2 block text-sm font-medium text-white/80'>
                                            Test Recipient
                                        </label>
                                        <input
                                            type='email'
                                            value={testMailRecipient}
                                            onChange={event =>
                                                setTestMailRecipient(
                                                    event.target.value
                                                )
                                            }
                                            placeholder='Leave blank to send to your admin email'
                                            className={inputClass}
                                        />
                                        <p className='mt-1.5 text-xs text-white/50'>
                                            Save first, then send a test mail to
                                            verify SMTP delivery.
                                        </p>
                                    </div>
                                    <div className='flex items-end'>
                                        <button
                                            type='button'
                                            onClick={handleTestMail}
                                            disabled={
                                                isSendingTestMail ||
                                                !platformMailDraftReady
                                            }
                                            className='rounded-lg border border-emerald-300/20 bg-emerald-500/12 px-4 py-2.5 text-sm font-semibold text-emerald-100 transition hover:bg-emerald-500/20 disabled:cursor-not-allowed disabled:opacity-60'
                                        >
                                            {isSendingTestMail
                                                ? 'Sending...'
                                                : 'Send Test Mail'}
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section className={panelCard}>
                            <div className='flex items-start gap-3'>
                                <SparklesIcon className='mt-0.5 h-6 w-6 text-purple-200' />
                                <div>
                                    <h2 className='text-lg font-bold text-white'>
                                        Notification Templates
                                    </h2>
                                    <p className='mt-1 text-sm leading-6 text-white/55'>
                                        Control outgoing panel notification copy
                                        and preview each template through saved
                                        SMTP.
                                    </p>
                                </div>
                            </div>

                            {!platformMailDraftReady ? (
                                <p className='mt-4 rounded-lg border border-amber-300/20 bg-amber-500/10 px-3 py-2 text-xs text-amber-100'>
                                    Add a valid SMTP host, port, and from email
                                    before notification emails can be enabled.
                                </p>
                            ) : null}

                            <div className='mt-5 grid gap-4 xl:grid-cols-2'>
                                {notificationTemplates.map(template => (
                                    <div
                                        key={template.key}
                                        className='rounded-xl border border-white/10 bg-[#111a31] p-4'
                                    >
                                        <div className='flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between'>
                                            <div>
                                                <h3 className='text-sm font-semibold text-white'>
                                                    {template.label}
                                                </h3>
                                                <p className='mt-1 text-xs leading-5 text-white/50'>
                                                    {template.description}
                                                </p>
                                            </div>
                                            <div className='flex items-center gap-2'>
                                                <label className='inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-white/75'>
                                                    <input
                                                        type='checkbox'
                                                        checked={
                                                            template.enabled
                                                        }
                                                        disabled={
                                                            !platformMailDraftReady
                                                        }
                                                        onChange={event =>
                                                            updateNotificationTemplate(
                                                                template.key,
                                                                {
                                                                    enabled:
                                                                        event
                                                                            .currentTarget
                                                                            .checked,
                                                                }
                                                            )
                                                        }
                                                        className='h-3.5 w-3.5 rounded border border-white/20 bg-transparent'
                                                    />
                                                    Active
                                                </label>
                                                <button
                                                    type='button'
                                                    onClick={() =>
                                                        handleTemplateTest(
                                                            template.key
                                                        )
                                                    }
                                                    disabled={
                                                        !platformMailDraftReady ||
                                                        templateTestLoading !==
                                                            null
                                                    }
                                                    className='rounded-lg border border-cyan-300/20 bg-cyan-500/10 px-3 py-1.5 text-xs font-semibold text-cyan-100 transition hover:bg-cyan-500/20 disabled:cursor-not-allowed disabled:opacity-50'
                                                >
                                                    {templateTestLoading ===
                                                    template.key
                                                        ? 'Sending...'
                                                        : 'Preview'}
                                                </button>
                                            </div>
                                        </div>

                                        <div className='mt-4 grid gap-3'>
                                            <div>
                                                <label className='mb-1.5 block text-xs font-semibold uppercase tracking-wide text-white/50'>
                                                    Subject
                                                </label>
                                                <input
                                                    type='text'
                                                    value={template.subject}
                                                    onChange={event =>
                                                        updateNotificationTemplate(
                                                            template.key,
                                                            {
                                                                subject:
                                                                    event.target
                                                                        .value,
                                                            }
                                                        )
                                                    }
                                                    className={inputClass}
                                                />
                                            </div>
                                            <div>
                                                <label className='mb-1.5 block text-xs font-semibold uppercase tracking-wide text-white/50'>
                                                    Heading
                                                </label>
                                                <input
                                                    type='text'
                                                    value={template.heading}
                                                    onChange={event =>
                                                        updateNotificationTemplate(
                                                            template.key,
                                                            {
                                                                heading:
                                                                    event.target
                                                                        .value,
                                                            }
                                                        )
                                                    }
                                                    className={inputClass}
                                                />
                                            </div>
                                            <div>
                                                <label className='mb-1.5 block text-xs font-semibold uppercase tracking-wide text-white/50'>
                                                    Body
                                                </label>
                                                <textarea
                                                    value={template.body}
                                                    rows={6}
                                                    onChange={event =>
                                                        updateNotificationTemplate(
                                                            template.key,
                                                            {
                                                                body: event
                                                                    .target
                                                                    .value,
                                                            }
                                                        )
                                                    }
                                                    className={inputClass}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>

                            <p className='mt-4 text-xs leading-6 text-white/45'>
                                Available placeholders: {'{{panel_name}}'},{' '}
                                {'{{name}}'}, {'{{email}}'}, {'{{login_url}}'},{' '}
                                {'{{support_url}}'}, {'{{server_name}}'},{' '}
                                {'{{reason}}'}, {'{{action_url}}'}.
                            </p>
                        </section>
                    </>
                )}
            </div>
        </PageContentBlock>
    )
}

export default EmailSettingsContainer
