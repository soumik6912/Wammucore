import { useDebouncedValue } from '@mantine/hooks'
import { formatDistanceToNow } from 'date-fns'
import { useState } from 'react'
import { Link } from 'react-router-dom'

import suspendSecurityServer from '@/api/admin/security/suspendServer'
import {
    SecurityTrafficItem,
} from '@/api/admin/security/types'
import useTrafficSWR from '@/api/admin/security/useTrafficSWR'
import SecurityPageShell from '@/components/admin/security/SecurityPageShell'
import {
    FilterPill,
    ScoreBar,
    StatusBadge,
    cardClassName,
} from '@/components/admin/security/SecurityUi'
import Modal from '@/components/elements/Modal'
import Pagination from '@/components/elements/Pagination'
import Spinner from '@/components/elements/Spinner'
import Table, {
    Actions,
    ColumnArray,
    RowActionsProps,
} from '@/components/elements/displays/Table'
import TextInput from '@/components/elements/inputs/TextInput'
import usePagination from '@/util/usePagination'
import { useFlashKey } from '@/util/useFlash'

const columns: ColumnArray<SecurityTrafficItem> = [
    {
        accessor: 'serverName',
        header: 'Server',
        cell: ({ row }) =>
            row.serverUuid ? (
                <div>
                    <Link
                        to={`/admin/servers/${row.serverUuid}`}
                        className='font-semibold text-white transition hover:text-violet-200'
                    >
                        {row.serverName || row.serverUuid}
                    </Link>
                    <p className='mt-1 text-xs text-white/40'>
                        {row.owner || 'Unknown owner'}
                    </p>
                </div>
            ) : (
                <div>
                    <p className='font-semibold text-white'>
                        {row.serverName || 'Unknown VPS'}
                    </p>
                    <p className='mt-1 text-xs text-white/40'>
                        {row.owner || 'Unknown owner'}
                    </p>
                </div>
            ),
    },
    {
        accessor: 'ip',
        header: 'IP',
        cell: ({ value }) => value || '-',
    },
    {
        accessor: 'outboundMbps',
        header: 'Outbound Mbps',
        align: 'right',
        cell: ({ value }) => value.toFixed(2),
    },
    {
        accessor: 'score',
        header: 'Abuse Score',
        cell: ({ value }) => (
            <div className='min-w-[12rem]'>
                <ScoreBar
                    score={value}
                    warningThreshold={50}
                    throttleThreshold={80}
                    suspendThreshold={100}
                />
            </div>
        ),
        overflow: true,
    },
    {
        accessor: 'status',
        header: 'Status',
        cell: ({ value }) => <StatusBadge status={value} />,
    },
    {
        accessor: 'lastEvaluatedAt',
        header: 'Last Evaluated',
        cell: ({ value }) =>
            value
                ? formatDistanceToNow(value, { addSuffix: true })
                : 'Pending',
    },
]

const MenuLinkItem = ({ to, children }: { to: string; children: string }) => (
    <Link
        to={to}
        className='block rounded-lg px-3 py-2 text-sm font-semibold text-white transition hover:bg-violet-500/25'
    >
        {children}
    </Link>
)

const MenuActionItem = ({
    onClick,
    children,
}: {
    onClick: () => void
    children: string
}) => (
    <button
        type='button'
        onClick={onClick}
        className='block w-full rounded-lg px-3 py-2 text-left text-sm font-semibold text-white transition hover:bg-violet-500/25'
    >
        {children}
    </button>
)

const TrafficActions = ({
    row,
    onComplete,
}: RowActionsProps<SecurityTrafficItem> & { onComplete: () => void }) => {
    const [open, setOpen] = useState(false)
    const [loading, setLoading] = useState(false)
    const { clearFlashes, clearAndAddHttpError } = useFlashKey(
        'admin:security:traffic'
    )

    const handleSuspend = async () => {
        if (!row.serverUuid) return

        setLoading(true)
        clearFlashes()

        try {
            await suspendSecurityServer(row.serverUuid)
            setOpen(false)
            onComplete()
        } catch (error) {
            clearAndAddHttpError(error as Error)
        } finally {
            setLoading(false)
        }
    }

    return (
        <>
            <Modal open={open} onClose={() => setOpen(false)}>
                <Modal.Header>
                    <Modal.Title>
                        Suspend {row.serverName || 'this VPS'}?
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Modal.Description bottomMargin>
                        This immediately suspends the VPS from the security
                        panel. Use this when traffic behavior needs urgent
                        intervention.
                    </Modal.Description>
                </Modal.Body>
                <Modal.Actions>
                    <Modal.Action onClick={() => setOpen(false)}>
                        Cancel
                    </Modal.Action>
                    <Modal.Action onClick={handleSuspend} loading={loading}>
                        Suspend VPS
                    </Modal.Action>
                </Modal.Actions>
            </Modal>
            <Actions>
                {row.serverUuid ? (
                    <MenuLinkItem to={`/admin/servers/${row.serverUuid}`}>
                        View server
                    </MenuLinkItem>
                ) : null}
                {row.status !== 'suspended' && row.serverUuid ? (
                    <MenuActionItem onClick={() => setOpen(true)}>
                        Suspend VPS
                    </MenuActionItem>
                ) : null}
            </Actions>
        </>
    )
}

const TrafficMonitorContainer = () => {
    const [page, setPage] = usePagination()
    const [query, setQuery] = useState('')
    const [status, setStatus] = useState('all')
    const [debouncedQuery] = useDebouncedValue(query, 250)
    const { data, error, mutate } = useTrafficSWR({
        page,
        perPage: 25,
        query: debouncedQuery,
        status,
    })

    return (
        <SecurityPageShell
            title='Traffic Monitor'
            description='Watch per-VPS outbound traffic, isolate abnormal bandwidth patterns, and suspend risky machines before abuse spreads across a node.'
            showFlashKey='admin:security:traffic'
        >
            <section className={`${cardClassName} p-5`}>
                <div className='flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between'>
                    <div className='w-full xl:max-w-md'>
                        <TextInput
                            value={query}
                            onChange={event =>
                                setQuery(event.currentTarget.value)
                            }
                            placeholder='Search by server, owner, UUID, or IP'
                        />
                    </div>
                    <div className='flex flex-wrap gap-2'>
                        {[
                            'all',
                            'normal',
                            'warning',
                            'high',
                            'suspended',
                        ].map(option => (
                            <FilterPill
                                key={option}
                                active={status === option}
                                onClick={() => {
                                    setStatus(option)
                                    setPage(1)
                                }}
                            >
                                {option === 'all' ? 'All statuses' : option}
                            </FilterPill>
                        ))}
                    </div>
                </div>
            </section>

            <section className={`${cardClassName} overflow-hidden p-4`}>
                {!data && !error ? (
                    <div className='py-16'>
                        <Spinner />
                    </div>
                ) : error ? (
                    <div className='px-4 py-14 text-center text-sm text-rose-200'>
                        Failed to load traffic monitor data. Check security API logs and try again.
                    </div>
                ) : data ? (
                    <Pagination data={data} onPageSelect={setPage}>
                        {({ items }) =>
                            items.length ? (
                                <Table
                                    minWidth={980}
                                    columns={columns}
                                    data={items}
                                    rowActions={payload => (
                                        <TrafficActions
                                            {...payload}
                                            onComplete={() => mutate()}
                                        />
                                    )}
                                />
                            ) : (
                                <div className='px-4 py-14 text-center text-sm text-white/45'>
                                    No traffic profiles matched the current filters.
                                </div>
                            )
                        }
                    </Pagination>
                ) : null}
            </section>
        </SecurityPageShell>
    )
}

export default TrafficMonitorContainer
