import { ReactNode } from 'react'

import {
    SecurityRiskStatus,
    SecuritySeverity,
} from '@/api/admin/security/types'

export const cardClassName =
    'theme-panel rounded-2xl shadow-[0_18px_50px_rgba(3,2,14,0.32)]'

const riskStatusClassNames: Record<SecurityRiskStatus, string> = {
    normal: 'border-emerald-400/30 bg-emerald-500/10 text-emerald-200',
    warning: 'border-amber-400/30 bg-amber-500/10 text-amber-100',
    high: 'border-orange-400/30 bg-orange-500/10 text-orange-100',
    suspended: 'border-rose-400/30 bg-rose-500/10 text-rose-100',
}

const severityClassNames: Record<SecuritySeverity, string> = {
    info: 'border-sky-400/30 bg-sky-500/10 text-sky-100',
    warning: 'border-amber-400/30 bg-amber-500/10 text-amber-100',
    high: 'border-orange-400/30 bg-orange-500/10 text-orange-100',
    critical: 'border-rose-400/30 bg-rose-500/10 text-rose-100',
}

export const MetricCard = ({
    label,
    value,
    helper,
    accent,
}: {
    label: string
    value: ReactNode
    helper?: ReactNode
    accent?: ReactNode
}) => (
    <div className={`${cardClassName} overflow-hidden p-5`}>
        <div className='flex items-start justify-between gap-4'>
            <div>
                <p className='text-xs font-semibold uppercase tracking-[0.2em] text-white/45'>
                    {label}
                </p>
                <div className='mt-3 text-3xl font-semibold text-white'>
                    {value}
                </div>
            </div>
            {accent}
        </div>
        {helper ? (
            <p className='mt-3 text-sm leading-6 text-white/55'>{helper}</p>
        ) : null}
    </div>
)

export const StatusBadge = ({
    status,
}: {
    status: SecurityRiskStatus
}) => (
    <span
        className={`inline-flex items-center rounded-full border px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] ${riskStatusClassNames[status]}`}
    >
        {status}
    </span>
)

export const SeverityBadge = ({
    severity,
}: {
    severity: SecuritySeverity
}) => (
    <span
        className={`inline-flex items-center rounded-full border px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] ${severityClassNames[severity]}`}
    >
        {severity}
    </span>
)

export const FilterPill = ({
    active,
    children,
    onClick,
}: {
    active: boolean
    children: ReactNode
    onClick: () => void
}) => (
    <button
        type='button'
        onClick={onClick}
        className={`rounded-full border px-4 py-2 text-sm font-semibold transition ${
            active
                ? 'theme-pill-active'
                : 'theme-pill'
        }`}
    >
        {children}
    </button>
)

export const ScoreBar = ({
    score,
    warningThreshold,
    throttleThreshold,
    suspendThreshold,
}: {
    score: number
    warningThreshold: number
    throttleThreshold: number
    suspendThreshold: number
}) => {
    const max = Math.max(suspendThreshold, 100)
    const percent = Math.max(0, Math.min(100, (score / max) * 100))
    const tone =
        score >= suspendThreshold
            ? 'from-rose-500 to-rose-300'
            : score >= throttleThreshold
            ? 'from-orange-500 to-amber-300'
            : score >= warningThreshold
            ? 'from-amber-500 to-yellow-300'
            : 'from-emerald-500 to-cyan-300'

    return (
        <div>
            <div className='flex items-center justify-between text-xs font-medium text-white/55'>
                <span>Score</span>
                <span>{score}</span>
            </div>
            <div className='mt-2 h-2.5 overflow-hidden rounded-full bg-white/10'>
                <div
                    className={`h-full rounded-full bg-gradient-to-r ${tone}`}
                    style={{ width: `${percent}%` }}
                />
            </div>
            <div className='mt-2 flex items-center justify-between text-[11px] text-white/35'>
                <span>Warn {warningThreshold}</span>
                <span>Throttle {throttleThreshold}</span>
                <span>Suspend {suspendThreshold}</span>
            </div>
        </div>
    )
}
