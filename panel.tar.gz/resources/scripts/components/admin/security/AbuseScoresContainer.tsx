import { useDebouncedValue } from '@mantine/hooks'
import { formatDistanceToNow } from 'date-fns'
import { useState } from 'react'
import { Link } from 'react-router-dom'

import suspendSecurityServer from '@/api/admin/security/suspendServer'
import terminateSecurityServer from '@/api/admin/security/terminateServer'
import { SecurityScoreItem } from '@/api/admin/security/types'
import useScoresSWR from '@/api/admin/security/useScoresSWR'
import SecurityPageShell from '@/components/admin/security/SecurityPageShell'
import {
    FilterPill,
    ScoreBar,
    StatusBadge,
    cardClassName,
} from '@/components/admin/security/SecurityUi'
import Modal from '@/components/elements/Modal'
import Pagination from '@/components/elements/Pagination'
import Spinner from '@/components/elements/Spinner'
import TextInput from '@/components/elements/inputs/TextInput'
import usePagination from '@/util/usePagination'
import { useFlashKey } from '@/util/useFlash'

const ScoreCard = ({
    item,
    onSuspended,
}: {
    item: SecurityScoreItem
    onSuspended: () => void
}) => {
    const [open, setOpen] = useState(false)
    const [terminateOpen, setTerminateOpen] = useState(false)
    const [loading, setLoading] = useState(false)
    const { clearFlashes, clearAndAddHttpError } = useFlashKey(
        'admin:security:scores'
    )

    const handleSuspend = async () => {
        if (!item.serverUuid) return

        setLoading(true)
        clearFlashes()

        try {
            await suspendSecurityServer(item.serverUuid)
            setOpen(false)
            onSuspended()
        } catch (error) {
            clearAndAddHttpError(error as Error)
        } finally {
            setLoading(false)
        }
    }

    const handleTerminate = async () => {
        if (!item.serverUuid) return

        setLoading(true)
        clearFlashes()

        try {
            await terminateSecurityServer(item.serverUuid)
            setTerminateOpen(false)
            onSuspended()
        } catch (error) {
            clearAndAddHttpError(error as Error)
        } finally {
            setLoading(false)
        }
    }

    return (
        <>
            <Modal open={open} onClose={() => setOpen(false)}>
                <Modal.Header>
                    <Modal.Title>
                        Suspend {item.serverName || 'this VPS'}?
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Modal.Description bottomMargin>
                        This VPS is currently in the security abuse-score queue.
                        Suspending it here is an immediate admin action.
                    </Modal.Description>
                </Modal.Body>
                <Modal.Actions>
                    <Modal.Action onClick={() => setOpen(false)}>
                        Cancel
                    </Modal.Action>
                    <Modal.Action onClick={handleSuspend} loading={loading}>
                        Suspend VPS
                    </Modal.Action>
                </Modal.Actions>
            </Modal>
            <Modal open={terminateOpen} onClose={() => setTerminateOpen(false)}>
                <Modal.Header>
                    <Modal.Title>
                        Terminate {item.serverName || 'this VPS'}?
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Modal.Description bottomMargin>
                        This is a permanent abuse-enforcement action. The VPS will be queued for deletion and the event will be logged for admin and user audit trails.
                    </Modal.Description>
                </Modal.Body>
                <Modal.Actions>
                    <Modal.Action onClick={() => setTerminateOpen(false)}>
                        Cancel
                    </Modal.Action>
                    <Modal.Action onClick={handleTerminate} loading={loading}>
                        Terminate VPS
                    </Modal.Action>
                </Modal.Actions>
            </Modal>
            <article className={`${cardClassName} p-5`}>
                <div className='flex flex-wrap items-start justify-between gap-3'>
                    <div>
                        <div className='flex flex-wrap items-center gap-2'>
                            {item.serverUuid ? (
                                <Link
                                    to={`/admin/servers/${item.serverUuid}`}
                                    className='text-lg font-semibold text-white transition hover:text-violet-200'
                                >
                                    {item.serverName || item.serverUuid}
                                </Link>
                            ) : (
                                <p className='text-lg font-semibold text-white'>
                                    {item.serverName || 'Unknown VPS'}
                                </p>
                            )}
                            <StatusBadge status={item.status} />
                        </div>
                        <p className='mt-2 text-sm text-white/50'>
                            {item.owner || 'Unknown owner'}
                            {item.ip ? `  •  ${item.ip}` : ''}
                        </p>
                    </div>
                    <div className='rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3 text-right'>
                        <p className='text-xs uppercase tracking-[0.24em] text-white/35'>
                            Open alerts
                        </p>
                        <p className='mt-2 text-2xl font-semibold text-white'>
                            {item.openAlertsCount}
                        </p>
                    </div>
                </div>

                <div className='mt-5'>
                    <ScoreBar
                        score={item.score}
                        warningThreshold={item.warningThreshold}
                        throttleThreshold={item.throttleThreshold}
                        suspendThreshold={item.suspendThreshold}
                    />
                </div>

                <div className='mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4'>
                    <div className='rounded-2xl border border-white/8 bg-white/[0.03] p-4'>
                        <p className='text-xs uppercase tracking-[0.22em] text-white/35'>
                            Last outbound
                        </p>
                        <p className='mt-2 text-lg font-semibold text-white'>
                            {item.lastOutboundMbps.toFixed(2)} Mbps
                        </p>
                    </div>
                    <div className='rounded-2xl border border-white/8 bg-white/[0.03] p-4'>
                        <p className='text-xs uppercase tracking-[0.22em] text-white/35'>
                            Limit
                        </p>
                        <p className='mt-2 text-lg font-semibold text-white'>
                            {item.outboundMbpsLimit} Mbps
                        </p>
                    </div>
                    <div className='rounded-2xl border border-white/8 bg-white/[0.03] p-4'>
                        <p className='text-xs uppercase tracking-[0.22em] text-white/35'>
                            Auto suspend
                        </p>
                        <p className='mt-2 text-lg font-semibold text-white'>
                            {item.autoSuspendEnabled ? 'Enabled' : 'Disabled'}
                        </p>
                    </div>
                    <div className='rounded-2xl border border-white/8 bg-white/[0.03] p-4'>
                        <p className='text-xs uppercase tracking-[0.22em] text-white/35'>
                            Last evaluated
                        </p>
                        <p className='mt-2 text-sm font-semibold text-white'>
                            {item.lastEvaluatedAt
                                ? formatDistanceToNow(item.lastEvaluatedAt, {
                                      addSuffix: true,
                                  })
                                : 'Pending'}
                        </p>
                    </div>
                </div>

                <div className='mt-5 flex flex-wrap gap-3'>
                    {item.serverUuid ? (
                        <Link
                            to={`/admin/servers/${item.serverUuid}`}
                            className='rounded-xl border border-white/10 bg-white/[0.03] px-4 py-2 text-sm font-semibold text-white transition hover:border-white/20 hover:bg-white/[0.06]'
                        >
                            View server
                        </Link>
                    ) : null}
                    {item.serverUuid && item.status !== 'suspended' ? (
                        <button
                            type='button'
                            onClick={() => setOpen(true)}
                            className='rounded-xl border border-rose-400/20 bg-rose-500/10 px-4 py-2 text-sm font-semibold text-rose-100 transition hover:bg-rose-500/20'
                        >
                            Suspend VPS
                        </button>
                    ) : null}
                    {item.serverUuid ? (
                        <button
                            type='button'
                            onClick={() => setTerminateOpen(true)}
                            className='rounded-xl border border-rose-500/35 bg-rose-500/20 px-4 py-2 text-sm font-semibold text-rose-50 transition hover:bg-rose-500/30'
                        >
                            Terminate VPS
                        </button>
                    ) : null}
                </div>
            </article>
        </>
    )
}

const AbuseScoresContainer = () => {
    const [page, setPage] = usePagination()
    const [query, setQuery] = useState('')
    const [status, setStatus] = useState('all')
    const [debouncedQuery] = useDebouncedValue(query, 250)

    const { data, error, mutate } = useScoresSWR({
        page,
        perPage: 12,
        query: debouncedQuery,
        status,
    })

    return (
        <SecurityPageShell
            title='Abuse Score'
            description='Review the current abuse score of each VPS, compare it against warning or suspend thresholds, and intervene directly from a single view.'
            showFlashKey='admin:security:scores'
        >
            <section className={`${cardClassName} space-y-4 p-5`}>
                <TextInput
                    value={query}
                    onChange={event => setQuery(event.currentTarget.value)}
                    placeholder='Search by server, owner, UUID, or IP'
                />
                <div className='flex flex-wrap gap-2'>
                    {[
                        'all',
                        'normal',
                        'warning',
                        'high',
                        'suspended',
                    ].map(option => (
                        <FilterPill
                            key={option}
                            active={status === option}
                            onClick={() => {
                                setStatus(option)
                                setPage(1)
                            }}
                        >
                            {option === 'all' ? 'All statuses' : option}
                        </FilterPill>
                    ))}
                </div>
            </section>

            {!data && !error ? (
                <div className={`${cardClassName} py-16`}>
                    <Spinner />
                </div>
            ) : error ? (
                <div className={`${cardClassName} px-4 py-14 text-center text-sm text-rose-200`}>
                    Failed to load abuse scores. Check security API logs and try again.
                </div>
            ) : data ? (
                <Pagination data={data} onPageSelect={setPage}>
                    {({ items }) =>
                        items.length ? (
                            <div className='grid gap-5 xl:grid-cols-2'>
                                {items.map(item => (
                                    <ScoreCard
                                        key={
                                            item.serverUuid ||
                                            item.serverName ||
                                            String(item.serverId)
                                        }
                                        item={item}
                                        onSuspended={() => mutate()}
                                    />
                                ))}
                            </div>
                        ) : (
                            <div
                                className={`${cardClassName} px-4 py-14 text-center text-sm text-white/45`}
                            >
                                No abuse-score profiles matched the current filters.
                            </div>
                        )
                    }
                </Pagination>
            ) : null}
        </SecurityPageShell>
    )
}

export default AbuseScoresContainer
