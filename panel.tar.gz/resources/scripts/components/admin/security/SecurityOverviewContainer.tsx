import {
    ArrowTrendingUpIcon,
    BellAlertIcon,
    ExclamationTriangleIcon,
    ShieldCheckIcon,
} from '@heroicons/react/24/outline'
import { formatDistanceToNow } from 'date-fns'
import { FormEvent, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

import getSecuritySettings from '@/api/admin/security/getSettings'
import lookupIp, { SecurityIpLookupResult } from '@/api/admin/security/lookupIp'
import updateSecuritySettings from '@/api/admin/security/updateSettings'
import { SecurityPolicySettings } from '@/api/admin/security/types'
import useAlertsSWR from '@/api/admin/security/useAlertsSWR'
import useOverviewSWR from '@/api/admin/security/useOverviewSWR'
import useTrafficSWR from '@/api/admin/security/useTrafficSWR'
import SecurityPageShell from '@/components/admin/security/SecurityPageShell'
import {
    MetricCard,
    SeverityBadge,
    StatusBadge,
    cardClassName,
} from '@/components/admin/security/SecurityUi'
import Spinner from '@/components/elements/Spinner'
import { useStoreState } from '@/state'

const SecurityOverviewContainer = () => {
    const isRootAdmin = useStoreState(state => Boolean(state.user.data?.rootAdmin))
    const { data: overview, error: overviewError } = useOverviewSWR()
    const { data: traffic } = useTrafficSWR({
        page: 1,
        perPage: 5,
        status: 'all',
    })
    const { data: alerts } = useAlertsSWR({
        page: 1,
        perPage: 5,
        status: 'open',
    })
    const [settings, setSettings] = useState<SecurityPolicySettings | null>(null)
    const [settingsMessage, setSettingsMessage] = useState<string | null>(null)
    const [savingSettings, setSavingSettings] = useState(false)
    const [lookupIpInput, setLookupIpInput] = useState('')
    const [lookupResult, setLookupResult] = useState<SecurityIpLookupResult | null | undefined>(undefined)
    const [lookupLoading, setLookupLoading] = useState(false)

    useEffect(() => {
        if (!isRootAdmin) {
            return
        }

        void (async () => {
            try {
                setSettings(await getSecuritySettings({ showProgress: false }))
            } catch {
                setSettingsMessage(
                    'Security policy settings failed to load. Check root admin view and API permissions.'
                )
            }
        })()
    }, [isRootAdmin])

    const patchSettings = (
        updater: (current: SecurityPolicySettings) => SecurityPolicySettings
    ) => {
        setSettings(current => (current ? updater(current) : current))
    }

    const saveSettings = async (event: FormEvent<HTMLFormElement>) => {
        event.preventDefault()
        if (!settings) {
            return
        }

        setSavingSettings(true)
        setSettingsMessage(null)
        try {
            const updated = await updateSecuritySettings(settings)
            setSettings(updated)
            setSettingsMessage('Security policy saved.')
        } catch {
            setSettingsMessage('Failed to save security policy settings.')
        } finally {
            setSavingSettings(false)
        }
    }

    const runIpLookup = async (event: FormEvent<HTMLFormElement>) => {
        event.preventDefault()
        const ip = lookupIpInput.trim()
        if (!ip) {
            return
        }

        setLookupLoading(true)
        try {
            const result = await lookupIp(ip)
            setLookupResult(result)
        } catch {
            setLookupResult(null)
        } finally {
            setLookupLoading(false)
        }
    }

    return (
        <SecurityPageShell
            title='Security Overview'
            description='Track risky VPS behavior, review security automation, and jump directly into outbound traffic anomalies or unresolved abuse alerts.'
        >
            {!overview && !overviewError ? (
                <div className={`${cardClassName} py-16`}>
                    <Spinner />
                </div>
            ) : overviewError ? (
                <div className={`${cardClassName} p-6`}>
                    <h2 className='text-lg font-semibold text-white'>Unable to load security overview</h2>
                    <p className='mt-2 text-sm text-white/60'>
                        Security API request failed. Check queue workers, cron scheduler, and server logs, then refresh this page.
                    </p>
                </div>
            ) : overview ? (
                <>
                    <section className='grid gap-4 md:grid-cols-2 xl:grid-cols-5'>
                        <MetricCard
                            label='Active VPS'
                            value={overview.activeServers}
                            helper='Servers currently in normal service.'
                            accent={
                                <ShieldCheckIcon className='h-10 w-10 text-emerald-300/70' />
                            }
                        />
                        <MetricCard
                            label='Suspended VPS'
                            value={overview.suspendedServers}
                            helper='Includes security-triggered suspensions.'
                            accent={
                                <ExclamationTriangleIcon className='h-10 w-10 text-rose-300/70' />
                            }
                        />
                        <MetricCard
                            label='Open Alerts'
                            value={overview.openAlerts}
                            helper='Needs investigation or acknowledgment.'
                            accent={
                                <BellAlertIcon className='h-10 w-10 text-violet-300/70' />
                            }
                        />
                        <MetricCard
                            label='Critical Alerts'
                            value={overview.criticalAlerts}
                            helper='Highest-priority security incidents.'
                            accent={
                                <ExclamationTriangleIcon className='h-10 w-10 text-orange-300/70' />
                            }
                        />
                        <MetricCard
                            label='High-Risk VPS'
                            value={overview.highRiskServers}
                            helper='Abuse score above throttle threshold.'
                            accent={
                                <ArrowTrendingUpIcon className='h-10 w-10 text-sky-300/70' />
                            }
                        />
                    </section>

                    <section className='grid gap-6 xl:grid-cols-[1.1fr,0.9fr]'>
                        <div className={`${cardClassName} space-y-4 p-6`}>
                            <div>
                                <h2 className='text-lg font-semibold text-white'>
                                    Platform hardening posture
                                </h2>
                                <p className='mt-1 text-sm text-white/55'>
                                    Live runtime checks for RBAC, tenant isolation, trusted edge enforcement, and internal service exposure.
                                </p>
                            </div>

                            <div className='grid gap-3 md:grid-cols-2'>
                                {[
                                    ['RBAC', overview.platformHardening.rbacEnabled],
                                    ['Tenant isolation', overview.platformHardening.tenantIsolationEnabled],
                                    ['CSRF', overview.platformHardening.csrfEnabled],
                                    ['JWT rotation', overview.platformHardening.jwtRotationEnabled],
                                    ['API scopes', overview.platformHardening.apiScopesEnabled],
                                    ['Bot protection', overview.platformHardening.botProtectionEnabled],
                                    ['Trusted edge', overview.platformHardening.trustedEdgeEnabled],
                                    ['Cloudflare validation', overview.platformHardening.cloudflareValidationEnabled],
                                    ['Internal APIs private', overview.platformHardening.internalServicesPrivate],
                                    ['Internal secret', overview.platformHardening.internalSecretConfigured],
                                    ['Redis rate limits', overview.platformHardening.redisRateLimits],
                                    ['Secure session cookie', overview.platformHardening.secureSessionCookie],
                                ].map(([label, enabled]) => (
                                    <div
                                        key={String(label)}
                                        className='rounded-2xl border border-white/8 bg-white/[0.03] px-4 py-3'
                                    >
                                        <div className='flex items-center justify-between gap-3'>
                                            <span className='text-sm text-white/70'>{label}</span>
                                            <span
                                                className={`rounded-full px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] ${
                                                    enabled
                                                        ? 'border border-emerald-400/20 bg-emerald-500/10 text-emerald-200'
                                                        : 'border border-amber-400/20 bg-amber-500/10 text-amber-200'
                                                }`}
                                            >
                                                {enabled ? 'On' : 'Review'}
                                            </span>
                                        </div>
                                    </div>
                                ))}
                            </div>

                            <div className='grid gap-3 md:grid-cols-3'>
                                <div className='rounded-2xl border border-white/8 bg-white/[0.03] px-4 py-3'>
                                    <p className='text-xs uppercase tracking-[0.2em] text-white/35'>
                                        Rate-limit store
                                    </p>
                                    <p className='mt-2 text-base font-semibold text-white'>
                                        {overview.platformHardening.rateLimitStore}
                                    </p>
                                </div>
                                <div className='rounded-2xl border border-white/8 bg-white/[0.03] px-4 py-3'>
                                    <p className='text-xs uppercase tracking-[0.2em] text-white/35'>
                                        Session driver
                                    </p>
                                    <p className='mt-2 text-base font-semibold text-white'>
                                        {overview.platformHardening.sessionDriver}
                                    </p>
                                </div>
                                <div className='rounded-2xl border border-white/8 bg-white/[0.03] px-4 py-3'>
                                    <p className='text-xs uppercase tracking-[0.2em] text-white/35'>
                                        Trusted edge ranges
                                    </p>
                                    <p className='mt-2 text-base font-semibold text-white'>
                                        {overview.platformHardening.trustedEdgeCount}
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className={`${cardClassName} space-y-4 p-6`}>
                            <div>
                                <h2 className='text-lg font-semibold text-white'>
                                    Hardening follow-up
                                </h2>
                                <p className='mt-1 text-sm text-white/55'>
                                    Priority actions before opening the panel to heavy public traffic.
                                </p>
                            </div>

                            {overview.platformHardening.recommendedActions.length ? (
                                <div className='space-y-3'>
                                    {overview.platformHardening.recommendedActions.map(action => (
                                        <div
                                            key={action}
                                            className='rounded-2xl border border-amber-400/15 bg-amber-500/10 px-4 py-3 text-sm text-amber-100/90'
                                        >
                                            {action}
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <div className='rounded-2xl border border-emerald-400/15 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-100/90'>
                                    No critical hardening gaps detected from the current runtime configuration snapshot.
                                </div>
                            )}

                            {overview.platformHardening.publicProxmoxNodes.length ? (
                                <div className='space-y-3 rounded-2xl border border-rose-400/15 bg-rose-500/10 p-4'>
                                    <h3 className='text-sm font-semibold text-rose-100'>
                                        Proxmox hosts still look public
                                    </h3>
                                    {overview.platformHardening.publicProxmoxNodes.map(node => (
                                        <div key={`${node.name}-${node.fqdn}`} className='text-sm text-rose-100/85'>
                                            <p className='font-medium'>{node.name}</p>
                                            <p className='text-xs text-rose-100/70'>{node.fqdn}</p>
                                            <p className='mt-1 text-xs text-rose-100/70'>
                                                Reason: {node.reason}
                                                {node.resolvedIps.length
                                                    ? ` | ${node.resolvedIps.join(', ')}`
                                                    : ''}
                                            </p>
                                        </div>
                                    ))}
                                </div>
                            ) : null}
                        </div>
                    </section>

                    {isRootAdmin && settings ? (
                        <section className='grid gap-6 xl:grid-cols-[1.25fr,0.75fr]'>
                            <form
                                onSubmit={saveSettings}
                                className={`${cardClassName} space-y-4 p-6`}
                            >
                                <div>
                                    <h2 className='text-lg font-semibold text-white'>
                                        DDoS Policy Controls
                                    </h2>
                                    <p className='mt-1 text-sm text-white/55'>
                                        Configure warning/suspend behavior and webhook placeholders from root admin.
                                    </p>
                                </div>
                                <div className='grid gap-4 md:grid-cols-2'>
                                    <label className='flex items-center gap-2 text-sm text-white/85'>
                                        <input
                                            type='checkbox'
                                            checked={settings.ddosMonitorEnabled}
                                            onChange={event => {
                                                const checked = event.currentTarget.checked
                                                patchSettings(current => ({
                                                    ...current,
                                                    ddosMonitorEnabled: checked,
                                                }))
                                            }}
                                        />
                                        DDoS monitor enabled
                                    </label>
                                    <label className='flex items-center gap-2 text-sm text-white/85'>
                                        <input
                                            type='checkbox'
                                            checked={settings.autoSuspendEnabled}
                                            onChange={event => {
                                                const checked = event.currentTarget.checked
                                                patchSettings(current => ({
                                                    ...current,
                                                    autoSuspendEnabled: checked,
                                                }))
                                            }}
                                        />
                                        Auto suspend enabled
                                    </label>
                                    <label className='flex items-center gap-2 text-sm text-white/85'>
                                        <input
                                            type='checkbox'
                                            checked={settings.suspendCriticalImmediately}
                                            onChange={event => {
                                                const checked = event.currentTarget.checked
                                                patchSettings(current => ({
                                                    ...current,
                                                    suspendCriticalImmediately: checked,
                                                }))
                                            }}
                                        />
                                        Suspend critical spikes immediately
                                    </label>
                                    <div />
                                    <label className='text-sm text-white/85'>
                                        Warning after violations
                                        <input
                                            type='number'
                                            min={1}
                                            className='mt-1 h-10 w-full rounded border border-white/15 bg-[#0f1630] px-3 text-sm text-white'
                                            value={settings.warningAfterViolations}
                                            onChange={event => {
                                                const value = Number(event.currentTarget.value || 1)
                                                patchSettings(current => ({
                                                    ...current,
                                                    warningAfterViolations: value,
                                                }))
                                            }}
                                        />
                                    </label>
                                    <label className='text-sm text-white/85'>
                                        Suspend after violations
                                        <input
                                            type='number'
                                            min={1}
                                            className='mt-1 h-10 w-full rounded border border-white/15 bg-[#0f1630] px-3 text-sm text-white'
                                            value={settings.suspendAfterViolations}
                                            onChange={event => {
                                                const value = Number(event.currentTarget.value || 1)
                                                patchSettings(current => ({
                                                    ...current,
                                                    suspendAfterViolations: value,
                                                }))
                                            }}
                                        />
                                    </label>
                                    <label className='text-sm text-white/85 md:col-span-2'>
                                        Violation decay window (minutes)
                                        <input
                                            type='number'
                                            min={1}
                                            className='mt-1 h-10 w-full rounded border border-white/15 bg-[#0f1630] px-3 text-sm text-white'
                                            value={settings.violationDecayMinutes}
                                            onChange={event => {
                                                const value = Number(event.currentTarget.value || 1)
                                                patchSettings(current => ({
                                                    ...current,
                                                    violationDecayMinutes: value,
                                                }))
                                            }}
                                        />
                                    </label>
                                    <label className='text-sm text-white/85 md:col-span-2'>
                                        Incoming alert webhook URL
                                        <input
                                            type='url'
                                            className='mt-1 h-10 w-full rounded border border-white/15 bg-[#0f1630] px-3 text-sm text-white'
                                            value={settings.incomingAlertWebhookUrl ?? ''}
                                            onChange={event => {
                                                const value = event.currentTarget.value || null
                                                patchSettings(current => ({
                                                    ...current,
                                                    incomingAlertWebhookUrl: value,
                                                }))
                                            }}
                                            placeholder='https://example.com/webhook/incoming'
                                        />
                                    </label>
                                    <label className='text-sm text-white/85 md:col-span-2'>
                                        Outgoing alert webhook URL
                                        <input
                                            type='url'
                                            className='mt-1 h-10 w-full rounded border border-white/15 bg-[#0f1630] px-3 text-sm text-white'
                                            value={settings.outgoingAlertWebhookUrl ?? ''}
                                            onChange={event => {
                                                const value = event.currentTarget.value || null
                                                patchSettings(current => ({
                                                    ...current,
                                                    outgoingAlertWebhookUrl: value,
                                                }))
                                            }}
                                            placeholder='https://example.com/webhook/outgoing'
                                        />
                                    </label>
                                    <label className='text-sm text-white/85 md:col-span-2'>
                                        Discord webhook URL
                                        <input
                                            type='url'
                                            className='mt-1 h-10 w-full rounded border border-white/15 bg-[#0f1630] px-3 text-sm text-white'
                                            value={settings.discordWebhookUrl ?? ''}
                                            onChange={event => {
                                                const value = event.currentTarget.value || null
                                                patchSettings(current => ({
                                                    ...current,
                                                    discordWebhookUrl: value,
                                                }))
                                            }}
                                            placeholder='https://discord.com/api/webhooks/...'
                                        />
                                    </label>
                                    <label className='flex items-center gap-2 text-sm text-white/85'>
                                        <input
                                            type='checkbox'
                                            checked={settings.webhookOnWarning}
                                            onChange={event => {
                                                const checked = event.currentTarget.checked
                                                patchSettings(current => ({
                                                    ...current,
                                                    webhookOnWarning: checked,
                                                }))
                                            }}
                                        />
                                        Send webhook on warning
                                    </label>
                                    <label className='flex items-center gap-2 text-sm text-white/85'>
                                        <input
                                            type='checkbox'
                                            checked={settings.webhookOnSuspend}
                                            onChange={event => {
                                                const checked = event.currentTarget.checked
                                                patchSettings(current => ({
                                                    ...current,
                                                    webhookOnSuspend: checked,
                                                }))
                                            }}
                                        />
                                        Send webhook on suspend
                                    </label>
                                    <label className='flex items-center gap-2 text-sm text-white/85'>
                                        <input
                                            type='checkbox'
                                            checked={settings.webhookOnTerminate}
                                            onChange={event => {
                                                const checked = event.currentTarget.checked
                                                patchSettings(current => ({
                                                    ...current,
                                                    webhookOnTerminate: checked,
                                                }))
                                            }}
                                        />
                                        Send webhook on terminate
                                    </label>
                                </div>
                                <div className='flex items-center gap-3'>
                                    <button
                                        type='submit'
                                        disabled={savingSettings}
                                        className='rounded-lg bg-indigo-500 px-4 py-2 text-sm font-semibold text-white transition hover:bg-indigo-400 disabled:cursor-not-allowed disabled:opacity-60'
                                    >
                                        {savingSettings ? 'Saving...' : 'Save Security Policy'}
                                    </button>
                                    {settingsMessage ? (
                                        <p className='text-sm text-white/70'>{settingsMessage}</p>
                                    ) : null}
                                </div>
                            </form>

                            <div className={`${cardClassName} space-y-4 p-6`}>
                                <div>
                                    <h2 className='text-lg font-semibold text-white'>
                                        IP Ownership Lookup
                                    </h2>
                                    <p className='mt-1 text-sm text-white/55'>
                                        Check which reseller and customer owns a specific IP.
                                    </p>
                                </div>
                                <form onSubmit={runIpLookup} className='space-y-3'>
                                    <input
                                        type='text'
                                        className='h-10 w-full rounded border border-white/15 bg-[#0f1630] px-3 text-sm text-white'
                                        value={lookupIpInput}
                                        onChange={event => setLookupIpInput(event.currentTarget.value)}
                                        placeholder='Enter IPv4 or IPv6'
                                    />
                                    <button
                                        type='submit'
                                        disabled={lookupLoading}
                                        className='rounded-lg border border-white/20 bg-white/5 px-4 py-2 text-sm font-semibold text-white transition hover:bg-white/10 disabled:cursor-not-allowed disabled:opacity-60'
                                    >
                                        {lookupLoading ? 'Checking...' : 'Lookup IP'}
                                    </button>
                                </form>
                                {lookupResult === undefined ? null : lookupResult ? (
                                    <div className='rounded-xl border border-white/10 bg-[#111a31] p-3 text-sm text-white/85'>
                                        <p>
                                            <span className='text-white/55'>IP:</span> {lookupResult.ip}/{lookupResult.cidr}
                                        </p>
                                        <p className='mt-1'>
                                            <span className='text-white/55'>Reseller:</span>{' '}
                                            {lookupResult.reseller?.displayName || '-'}
                                        </p>
                                        <p className='mt-1'>
                                            <span className='text-white/55'>Owner:</span>{' '}
                                            {lookupResult.owner?.email || '-'}
                                        </p>
                                        <p className='mt-1'>
                                            <span className='text-white/55'>Server:</span>{' '}
                                            {lookupResult.server?.name || '-'}
                                        </p>
                                    </div>
                                ) : (
                                    <div className='rounded-xl border border-white/10 bg-[#111a31] p-3 text-sm text-white/75'>
                                        No ownership mapping found for this IP.
                                    </div>
                                )}
                            </div>
                        </section>
                    ) : null}

                    <section className='grid gap-6 xl:grid-cols-[1.2fr,0.8fr]'>
                        <div className={`${cardClassName} p-6`}>
                            <div className='flex items-center justify-between gap-4'>
                                <div>
                                    <h2 className='text-lg font-semibold text-white'>
                                        Traffic priorities
                                    </h2>
                                    <p className='mt-1 text-sm text-white/55'>
                                        Highest outbound traffic samples from the current security profile set.
                                    </p>
                                </div>
                                <Link
                                    to='/admin/security/traffic'
                                    className='rounded-xl border border-white/10 bg-white/[0.03] px-4 py-2 text-sm font-semibold text-white transition hover:border-white/20 hover:bg-white/[0.06]'
                                >
                                    Open monitor
                                </Link>
                            </div>
                            <div className='mt-5 space-y-3'>
                                {traffic?.items.length ? (
                                    traffic.items.map(item => (
                                        <div
                                            key={
                                                item.serverUuid ||
                                                item.serverName ||
                                                String(item.serverId)
                                            }
                                            className='rounded-2xl border border-white/8 bg-white/[0.03] p-4'
                                        >
                                            <div className='flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between'>
                                                <div>
                                                    <div className='flex flex-wrap items-center gap-3'>
                                                        {item.serverUuid ? (
                                                            <Link
                                                                to={`/admin/servers/${item.serverUuid}`}
                                                                className='text-base font-semibold text-white transition hover:text-violet-200'
                                                            >
                                                                {item.serverName ||
                                                                    item.serverUuid}
                                                            </Link>
                                                        ) : (
                                                            <p className='text-base font-semibold text-white'>
                                                                {item.serverName ||
                                                                    'Unknown VPS'}
                                                            </p>
                                                        )}
                                                        <StatusBadge
                                                            status={item.status}
                                                        />
                                                    </div>
                                                    <p className='mt-2 text-sm text-white/50'>
                                                        {item.owner || 'Unknown owner'}
                                                        {item.resellerName
                                                            ? `  •  ${item.resellerName}`
                                                            : ''}
                                                        {item.ip
                                                            ? `  •  ${item.ip}`
                                                            : ''}
                                                    </p>
                                                </div>
                                                <div className='text-left lg:text-right'>
                                                    <p className='text-2xl font-semibold text-white'>
                                                        {item.outboundMbps.toFixed(2)}{' '}
                                                        Mbps
                                                    </p>
                                                    <p className='text-xs uppercase tracking-[0.22em] text-white/35'>
                                                        Outbound
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    ))
                                ) : (
                                    <div className='rounded-2xl border border-dashed border-white/10 px-4 py-8 text-sm text-white/45'>
                                        No traffic data has been evaluated yet.
                                    </div>
                                )}
                            </div>
                        </div>

                        <div className={`${cardClassName} p-6`}>
                            <div className='flex items-center justify-between gap-4'>
                                <div>
                                    <h2 className='text-lg font-semibold text-white'>
                                        Latest alerts
                                    </h2>
                                    <p className='mt-1 text-sm text-white/55'>
                                        Fresh security incidents still visible to admins.
                                    </p>
                                </div>
                                <Link
                                    to='/admin/security/alerts'
                                    className='rounded-xl border border-white/10 bg-white/[0.03] px-4 py-2 text-sm font-semibold text-white transition hover:border-white/20 hover:bg-white/[0.06]'
                                >
                                    Review alerts
                                </Link>
                            </div>
                            <div className='mt-5 space-y-3'>
                                {alerts?.items.length ? (
                                    alerts.items.map(alert => (
                                        <div
                                            key={alert.id}
                                            className='rounded-2xl border border-white/8 bg-white/[0.03] p-4'
                                        >
                                            <div className='flex items-start justify-between gap-3'>
                                                <div>
                                                    <div className='flex flex-wrap items-center gap-2'>
                                                        <SeverityBadge
                                                            severity={alert.severity}
                                                        />
                                                        <span className='text-xs uppercase tracking-[0.2em] text-white/35'>
                                                            {alert.status}
                                                        </span>
                                                    </div>
                                                    <p className='mt-3 text-sm font-semibold text-white'>
                                                        {alert.title}
                                                    </p>
                                                    <p className='mt-2 text-sm leading-6 text-white/55'>
                                                        {alert.message ||
                                                            'No extra message attached.'}
                                                    </p>
                                                    <p className='mt-3 text-xs text-white/40'>
                                                        {alert.resellerName
                                                            ? `${alert.resellerName}  •  `
                                                            : ''}
                                                        {alert.serverUuid ? (
                                                            <Link
                                                                to={`/admin/servers/${alert.serverUuid}`}
                                                                className='text-violet-200 transition hover:text-white'
                                                            >
                                                                {alert.serverName ||
                                                                    alert.serverUuid}
                                                            </Link>
                                                        ) : (
                                                            alert.serverName ||
                                                            'Unknown VPS'
                                                        )}
                                                        {alert.createdAt
                                                            ? `  •  ${formatDistanceToNow(
                                                                  alert.createdAt,
                                                                  {
                                                                      addSuffix:
                                                                          true,
                                                                  }
                                                              )}`
                                                            : ''}
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    ))
                                ) : (
                                    <div className='rounded-2xl border border-dashed border-white/10 px-4 py-8 text-sm text-white/45'>
                                        No alerts found.
                                    </div>
                                )}
                            </div>
                        </div>
                    </section>
                </>
            ) : null}
        </SecurityPageShell>
    )
}

export default SecurityOverviewContainer
