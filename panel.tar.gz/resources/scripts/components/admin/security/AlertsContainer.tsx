import { useDebouncedValue } from '@mantine/hooks'
import { format } from 'date-fns'
import { useState } from 'react'
import { Link } from 'react-router-dom'

import resolveAlert from '@/api/admin/security/resolveAlert'
import suspendSecurityServer from '@/api/admin/security/suspendServer'
import terminateSecurityServer from '@/api/admin/security/terminateServer'
import { SecurityAlertItem } from '@/api/admin/security/types'
import useAlertsSWR from '@/api/admin/security/useAlertsSWR'
import SecurityPageShell from '@/components/admin/security/SecurityPageShell'
import {
    FilterPill,
    SeverityBadge,
    cardClassName,
} from '@/components/admin/security/SecurityUi'
import Pagination from '@/components/elements/Pagination'
import Spinner from '@/components/elements/Spinner'
import Table, {
    Actions,
    ColumnArray,
    RowActionsProps,
} from '@/components/elements/displays/Table'
import TextInput from '@/components/elements/inputs/TextInput'
import usePagination from '@/util/usePagination'
import { useFlashKey } from '@/util/useFlash'

const columns: ColumnArray<SecurityAlertItem> = [
    {
        accessor: 'severity',
        header: 'Severity',
        cell: ({ value }) => <SeverityBadge severity={value} />,
    },
    {
        accessor: 'title',
        header: 'Alert',
        cell: ({ value, row }) => (
            <div className='min-w-[18rem]'>
                <p className='font-semibold text-white'>{value}</p>
                <p className='mt-1 text-xs text-white/45'>
                    {row.type}
                    {row.message ? `  •  ${row.message}` : ''}
                </p>
            </div>
        ),
        overflow: true,
    },
    {
        accessor: 'serverName',
        header: 'Server',
        cell: ({ row }) =>
            row.serverUuid ? (
                <div>
                    <Link
                        to={`/admin/servers/${row.serverUuid}`}
                        className='font-semibold text-white transition hover:text-violet-200'
                    >
                        {row.serverName || row.serverUuid}
                    </Link>
                    <p className='mt-1 text-xs text-white/40'>
                        {row.owner || 'Unknown owner'}
                    </p>
                </div>
            ) : (
                row.serverName || '-'
            ),
    },
    {
        accessor: 'status',
        header: 'Status',
        cell: ({ value }) => (
            <span className='text-xs font-semibold uppercase tracking-[0.2em] text-white/65'>
                {value}
            </span>
        ),
    },
    {
        accessor: 'createdAt',
        header: 'Created',
        cell: ({ value }) => (value ? format(value, 'dd MMM yyyy HH:mm') : '-'),
    },
    {
        accessor: 'resolvedAt',
        header: 'Resolved',
        cell: ({ value }) => (value ? format(value, 'dd MMM yyyy HH:mm') : '-'),
    },
]

const AlertActions = ({
    row,
    onComplete,
}: RowActionsProps<SecurityAlertItem> & { onComplete: () => void }) => {
    const [loading, setLoading] = useState(false)
    const { clearFlashes, clearAndAddHttpError } = useFlashKey(
        'admin:security:alerts'
    )

    const handleResolve = async () => {
        setLoading(true)
        clearFlashes()

        try {
            await resolveAlert(row.id)
            onComplete()
        } catch (error) {
            clearAndAddHttpError(error as Error)
        } finally {
            setLoading(false)
        }
    }

    const handleSuspend = async () => {
        if (!row.serverUuid) return

        setLoading(true)
        clearFlashes()

        try {
            await suspendSecurityServer(row.serverUuid)
            onComplete()
        } catch (error) {
            clearAndAddHttpError(error as Error)
        } finally {
            setLoading(false)
        }
    }

    const handleTerminate = async () => {
        if (!row.serverUuid) return

        setLoading(true)
        clearFlashes()

        try {
            await terminateSecurityServer(row.serverUuid)
            onComplete()
        } catch (error) {
            clearAndAddHttpError(error as Error)
        } finally {
            setLoading(false)
        }
    }

    return (
        <Actions>
            {row.status === 'open' ? (
                <button
                    type='button'
                    onClick={handleResolve}
                    disabled={loading}
                    className='block w-full rounded-lg px-3 py-2 text-left text-sm font-semibold text-white transition hover:bg-violet-500/25 disabled:cursor-not-allowed disabled:text-white/35'
                >
                    Resolve alert
                </button>
            ) : null}
            {row.serverUuid ? (
                <Link
                    to={`/admin/servers/${row.serverUuid}`}
                    className='block rounded-lg px-3 py-2 text-sm font-semibold text-white transition hover:bg-violet-500/25'
                >
                    View server
                </Link>
            ) : null}
            {row.serverUuid && row.status === 'open' ? (
                <button
                    type='button'
                    onClick={handleSuspend}
                    disabled={loading}
                    className='block w-full rounded-lg px-3 py-2 text-left text-sm font-semibold text-rose-200 transition hover:bg-rose-500/20 disabled:cursor-not-allowed disabled:text-white/35'
                >
                    Suspend VPS
                </button>
            ) : null}
            {row.serverUuid && row.status === 'open' ? (
                <button
                    type='button'
                    onClick={handleTerminate}
                    disabled={loading}
                    className='block w-full rounded-lg px-3 py-2 text-left text-sm font-semibold text-rose-100 transition hover:bg-rose-500/30 disabled:cursor-not-allowed disabled:text-white/35'
                >
                    Terminate VPS
                </button>
            ) : null}
        </Actions>
    )
}

const AlertsContainer = () => {
    const [page, setPage] = usePagination()
    const [query, setQuery] = useState('')
    const [status, setStatus] = useState('open')
    const [severity, setSeverity] = useState('all')
    const [debouncedQuery] = useDebouncedValue(query, 250)

    const { data, error, mutate } = useAlertsSWR({
        page,
        perPage: 25,
        query: debouncedQuery,
        status,
        severity,
    })

    return (
        <SecurityPageShell
            title='Security Alerts'
            description='Resolve incident noise quickly, filter by severity, and jump directly from an alert into the affected VPS or a manual suspension flow.'
            showFlashKey='admin:security:alerts'
        >
            <section className={`${cardClassName} space-y-4 p-5`}>
                <TextInput
                    value={query}
                    onChange={event => setQuery(event.currentTarget.value)}
                    placeholder='Search alerts, event type, server, owner, or UUID'
                />
                <div className='flex flex-wrap gap-2'>
                    {['open', 'resolved', 'all'].map(option => (
                        <FilterPill
                            key={option}
                            active={status === option}
                            onClick={() => {
                                setStatus(option)
                                setPage(1)
                            }}
                        >
                            {option === 'all' ? 'All statuses' : option}
                        </FilterPill>
                    ))}
                </div>
                <div className='flex flex-wrap gap-2'>
                    {['all', 'info', 'warning', 'high', 'critical'].map(
                        option => (
                            <FilterPill
                                key={option}
                                active={severity === option}
                                onClick={() => {
                                    setSeverity(option)
                                    setPage(1)
                                }}
                            >
                                {option === 'all'
                                    ? 'All severities'
                                    : option}
                            </FilterPill>
                        )
                    )}
                </div>
            </section>

            <section className={`${cardClassName} overflow-hidden p-4`}>
                {!data && !error ? (
                    <div className='py-16'>
                        <Spinner />
                    </div>
                ) : error ? (
                    <div className='px-4 py-14 text-center text-sm text-rose-200'>
                        Failed to load security alerts. Check security API logs and try again.
                    </div>
                ) : data ? (
                    <Pagination data={data} onPageSelect={setPage}>
                        {({ items }) =>
                            items.length ? (
                                <Table
                                    minWidth={1080}
                                    columns={columns}
                                    data={items}
                                    rowActions={payload => (
                                        <AlertActions
                                            {...payload}
                                            onComplete={() => mutate()}
                                        />
                                    )}
                                />
                            ) : (
                                <div className='px-4 py-14 text-center text-sm text-white/45'>
                                    No alerts matched the current filters.
                                </div>
                            )
                        }
                    </Pagination>
                ) : null}
            </section>
        </SecurityPageShell>
    )
}

export default AlertsContainer
