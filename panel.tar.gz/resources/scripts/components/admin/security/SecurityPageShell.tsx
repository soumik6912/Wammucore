import { ReactNode } from 'react'
import { NavLink } from 'react-router-dom'

import PageContentBlock from '@/components/elements/PageContentBlock'

import { cardClassName } from '@/components/admin/security/SecurityUi'

const tabs = [
    {
        name: 'Overview',
        to: '/admin/security',
        end: true,
    },
    {
        name: 'Traffic Monitor',
        to: '/admin/security/traffic',
    },
    {
        name: 'Alerts',
        to: '/admin/security/alerts',
    },
    {
        name: 'Abuse Score',
        to: '/admin/security/scores',
    },
]

const SecurityPageShell = ({
    title,
    description,
    showFlashKey,
    children,
}: {
    title: string
    description: string
    showFlashKey?: string
    children: ReactNode
}) => {
    return (
        <div className='theme-page min-h-screen'>
            <PageContentBlock
                title={`Security - ${title}`}
                containerSize='wide'
                showFlashKey={showFlashKey}
            >
                <div className='space-y-6'>
                    <section className={`${cardClassName} overflow-hidden p-6`}>
                        <div className='flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between'>
                            <div className='max-w-3xl'>
                                <p className='theme-eyebrow text-xs font-semibold uppercase tracking-[0.32em]'>
                                    Security Engine
                                </p>
                                <h1 className='mt-3 text-3xl font-semibold tracking-tight text-white'>
                                    {title}
                                </h1>
                                <p className='mt-3 max-w-2xl text-sm leading-7 text-white/60'>
                                    {description}
                                </p>
                            </div>
                            <div className='grid gap-2 sm:grid-cols-2 xl:flex xl:flex-wrap xl:justify-end'>
                                {tabs.map(tab => (
                                    <NavLink
                                        key={tab.to}
                                        to={tab.to}
                                        end={tab.end}
                                        className={({ isActive }) =>
                                            `rounded-full border px-4 py-2 text-sm font-semibold transition ${
                                                isActive
                                                    ? 'theme-pill-active'
                                                    : 'theme-pill'
                                            }`
                                        }
                                    >
                                        {tab.name}
                                    </NavLink>
                                ))}
                            </div>
                        </div>
                    </section>
                    {children}
                </div>
            </PageContentBlock>
        </div>
    )
}

export default SecurityPageShell
