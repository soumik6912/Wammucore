import createCatalogPlan, {
    CatalogPlanUpsertPayload,
} from '@/api/admin/plans/createCatalogPlan'
import { httpErrorToHuman } from '@/api/http'
import deleteCatalogPlan from '@/api/admin/plans/deleteCatalogPlan'
import getCatalogPlans from '@/api/admin/plans/getCatalogPlans'
import getResellerPlanPrices from '@/api/admin/plans/getResellerPlanPrices'
import { ResellerCatalogPlan } from '@/api/admin/plans/types'
import updateCatalogPlan from '@/api/admin/plans/updateCatalogPlan'
import updateResellerPlanPrice from '@/api/admin/plans/updateResellerPlanPrice'
import useTenantContextSWR from '@/api/admin/tenancy/useTenantContextSWR'
import PageContentBlock from '@/components/elements/PageContentBlock'
import Spinner from '@/components/elements/Spinner'
import { useEffect, useMemo, useRef, useState } from 'react'

type PricingDraft = {
    monthlyPrice: string
    currency: string
    ipQuantity: number
    ipPriceEach: string
    paymenterCheckoutUrl: string
    isVisible: boolean
}

const emptyPlanForm = (): CatalogPlanUpsertPayload => ({
    name: '',
    slug: '',
    category: 'EPYC',
    description: null,
    cpuCores: 2,
    cpuLimit: 0,
    cpuUnits: 1024,
    cpuSockets: 1,
    ramMb: 2048,
    diskGb: 30,
    bandwidthGb: null,
    snapshotLimit: 0,
    backupLimit: 0,
    defaultIpQuantity: 1,
    sortOrder: 0,
    isActive: true,
})

const planFieldClassName =
    'w-full rounded-lg border border-white/15 bg-[#111a31] px-3 py-2 text-sm text-white'

const defaultPlanCategoryOptions = ['EPYC', 'Ryzen', 'General']

const normalizePlanCategory = (category?: string | null): string => {
    const normalized = (category || 'General').trim()

    return normalized === '' ? 'General' : normalized
}

const categorySortWeight = (category: string): number => {
    const normalized = normalizePlanCategory(category).toLowerCase()

    if (normalized === 'epyc') return 0
    if (normalized === 'ryzen') return 1
    if (normalized === 'amd') return 2
    if (normalized === 'general') return 99

    return 50
}

const PlanField = ({
    label,
    hint,
    fullWidth = false,
    children,
}: {
    label: string
    hint?: string
    fullWidth?: boolean
    children: React.ReactNode
}) => (
    <div className={fullWidth ? 'md:col-span-2' : ''}>
        <label className='mb-2 block text-sm font-medium text-white/85'>
            {label}
        </label>
        {children}
        {hint ? (
            <p className='mt-1 text-xs leading-5 text-white/50'>{hint}</p>
        ) : null}
    </div>
)

const PlanCatalogContainer = () => {
    const { data: tenantContext } = useTenantContextSWR()
    const isMasterView = tenantContext?.mode !== 'reseller'

    const [isLoading, setIsLoading] = useState(true)
    const [isPricingLoading, setIsPricingLoading] = useState(false)
    const [status, setStatus] = useState<{ type: 'ok' | 'error'; text: string } | null>(null)
    const [catalogPlans, setCatalogPlans] = useState<ResellerCatalogPlan[]>([])
    const [pricingRows, setPricingRows] = useState<ResellerCatalogPlan[]>([])
    const [pricingDrafts, setPricingDrafts] = useState<Record<number, PricingDraft>>({})
    const [editingPlanId, setEditingPlanId] = useState<number | null>(null)
    const [isSavingPlan, setIsSavingPlan] = useState(false)
    const [isSavingPricing, setIsSavingPricing] = useState<Record<number, boolean>>({})
    const [planForm, setPlanForm] = useState<CatalogPlanUpsertPayload>(emptyPlanForm())
    const [categoryDraft, setCategoryDraft] = useState('')
    const planFormRef = useRef<HTMLDivElement | null>(null)

    const scopedResellerId = tenantContext?.activeReseller?.id ?? null

    const targetResellerId = tenantContext?.mode === 'reseller' ? scopedResellerId : null

    const planCategories = useMemo(() => {
        const categories = new Set<string>(defaultPlanCategoryOptions)

        catalogPlans.forEach(plan => categories.add(normalizePlanCategory(plan.category)))
        pricingRows.forEach(row => categories.add(normalizePlanCategory(row.category)))
        categories.add(normalizePlanCategory(planForm.category))

        return Array.from(categories)
            .filter(category => category !== '')
            .sort((a, b) => {
                const weight = categorySortWeight(a) - categorySortWeight(b)

                return weight !== 0 ? weight : a.localeCompare(b)
            })
    }, [catalogPlans, pricingRows, planForm.category])

    const groupedPricingRows = useMemo(() => {
        const groups = new Map<string, ResellerCatalogPlan[]>()

        pricingRows.forEach(row => {
            const category = normalizePlanCategory(row.category)
            const rows = groups.get(category) || []
            rows.push(row)
            groups.set(category, rows)
        })

        return Array.from(groups.entries())
            .map(([category, rows]) => ({
                category,
                rows,
            }))
            .sort((a, b) => {
                const weight = categorySortWeight(a.category) - categorySortWeight(b.category)

                return weight !== 0 ? weight : a.category.localeCompare(b.category)
            })
    }, [pricingRows])

    const refreshCatalog = async () => {
        const plans = await getCatalogPlans()
        const rows = plans.map(plan => ({
            ...plan,
            pricing: {
                monthlyPrice: null,
                currency: 'USD',
                        ipQuantity: plan.defaultIpQuantity,
                        ipPriceEach: '0.00',
                        paymenterCheckoutUrl: null,
                        isVisible: true,
            },
        }))
        setCatalogPlans(rows)
    }

    const refreshPricing = async (resellerId?: number | null) => {
        setIsPricingLoading(true)
        try {
            const payload = await getResellerPlanPrices(resellerId)
            setPricingRows(payload.items)
            setPricingDrafts(
                payload.items.reduce((acc, row) => {
                    acc[row.id] = {
                        monthlyPrice: row.pricing.monthlyPrice ?? '',
                        currency: (row.pricing.currency || 'USD').toUpperCase(),
                        ipQuantity: row.pricing.ipQuantity,
                        ipPriceEach: row.pricing.ipPriceEach ?? '0.00',
                        paymenterCheckoutUrl: row.pricing.paymenterCheckoutUrl ?? '',
                        isVisible: row.pricing.isVisible,
                    }

                    return acc
                }, {} as Record<number, PricingDraft>)
            )
        } finally {
            setIsPricingLoading(false)
        }
    }

    useEffect(() => {
        let active = true

        setIsLoading(true)
        Promise.all([refreshCatalog(), refreshPricing(targetResellerId)])
            .catch(error => {
                if (active) {
                    setStatus({
                        type: 'error',
                        text: httpErrorToHuman(error) || 'Failed to load plan catalog data.',
                    })
                }
            })
            .finally(() => {
                if (active) {
                    setIsLoading(false)
                }
            })

        return () => {
            active = false
        }
    }, [targetResellerId])

    const loadPlanIntoForm = (planId: number) => {
        const plan = catalogPlans.find(item => item.id === planId)
        if (!plan) {
            return
        }

        setEditingPlanId(plan.id)
        setPlanForm({
            name: plan.name,
            slug: plan.slug,
            category: normalizePlanCategory(plan.category),
            description: plan.description,
            cpuCores: plan.cpuCores,
            cpuLimit: plan.cpuLimit,
            cpuUnits: plan.cpuUnits,
            cpuSockets: plan.cpuSockets,
            ramMb: plan.ramMb,
            diskGb: plan.diskGb,
            bandwidthGb: plan.bandwidthGb,
            snapshotLimit: plan.snapshotLimit,
            backupLimit: plan.backupLimit,
            defaultIpQuantity: plan.defaultIpQuantity,
            sortOrder: plan.sortOrder,
            isActive: plan.isActive,
        })
        setStatus({ type: 'ok', text: `Editing specs for ${plan.name}.` })
        window.setTimeout(() => {
            planFormRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
        }, 0)
    }

    const patchPlanForm = (patch: Partial<CatalogPlanUpsertPayload>) => {
        setPlanForm(current => ({
            ...current,
            ...patch,
        }))
    }

    const selectPlanCategory = (category: string) => {
        patchPlanForm({ category: normalizePlanCategory(category) })
    }

    const createPlanCategory = () => {
        const category = normalizePlanCategory(categoryDraft)

        if (category === 'General' && categoryDraft.trim() === '') {
            return
        }

        patchPlanForm({ category })
        setCategoryDraft('')
        setStatus({
            type: 'ok',
            text: `Category "${category}" selected. Save a plan in this category to keep it in the catalog.`,
        })
    }

    const patchPricingDraft = (planId: number, patch: Partial<PricingDraft>) => {
        setPricingDrafts(current => ({
            ...current,
            [planId]: {
                ...current[planId],
                ...patch,
            },
        }))
    }

    const resetPlanForm = () => {
        setEditingPlanId(null)
        setPlanForm(emptyPlanForm())
    }

    const submitPlanForm = async () => {
        setIsSavingPlan(true)
        setStatus(null)

        try {
            if (editingPlanId) {
                await updateCatalogPlan(editingPlanId, planForm)
                setStatus({ type: 'ok', text: 'Plan updated.' })
            } else {
                await createCatalogPlan(planForm)
                setStatus({ type: 'ok', text: 'Plan created.' })
            }

            await refreshCatalog()
            await refreshPricing(targetResellerId)
            resetPlanForm()
        } catch (error) {
            setStatus({
                type: 'error',
                text: httpErrorToHuman(error) || 'Failed to save plan.',
            })
        } finally {
            setIsSavingPlan(false)
        }
    }

    const removePlan = async (planId: number) => {
        if (!window.confirm('Delete this default plan?')) {
            return
        }

        setStatus(null)
        try {
            await deleteCatalogPlan(planId)
            await refreshCatalog()
            await refreshPricing(targetResellerId)
            setStatus({ type: 'ok', text: 'Plan deleted.' })
            if (editingPlanId === planId) {
                resetPlanForm()
            }
        } catch (error) {
            setStatus({
                type: 'error',
                text: httpErrorToHuman(error) || 'Failed to delete plan.',
            })
        }
    }

    const savePricingRow = async (planId: number) => {
        const draft = pricingDrafts[planId]
        if (!draft) {
            return
        }

        setIsSavingPricing(current => ({ ...current, [planId]: true }))
        setStatus(null)
        try {
            await updateResellerPlanPrice(planId, {
                monthlyPrice:
                    draft.monthlyPrice.trim() === '' ? null : draft.monthlyPrice.trim(),
                currency: draft.currency.trim().toUpperCase(),
                ipQuantity: Number(draft.ipQuantity),
                ipPriceEach: draft.ipPriceEach.trim(),
                paymenterCheckoutUrl:
                    draft.paymenterCheckoutUrl.trim() === ''
                        ? null
                        : draft.paymenterCheckoutUrl.trim(),
                isVisible: draft.isVisible,
                resellerId: targetResellerId ?? undefined,
            })
            await refreshPricing(targetResellerId)
            setStatus({
                type: 'ok',
                text: isMasterView
                    ? 'Shared reseller defaults updated.'
                    : 'Reseller pricing updated.',
            })
        } catch (error) {
            setStatus({
                type: 'error',
                text:
                    httpErrorToHuman(error) ||
                    (isMasterView
                        ? 'Failed to update shared reseller defaults.'
                        : 'Failed to update reseller pricing.'),
            })
        } finally {
            setIsSavingPricing(current => ({ ...current, [planId]: false }))
        }
    }

    if (isLoading) {
        return (
            <PageContentBlock title='Plans'>
                <Spinner />
            </PageContentBlock>
        )
    }

    return (
        <PageContentBlock title='Plans'>
            <div className='space-y-6'>
                {status ? (
                    <div
                        className={`rounded-lg border px-4 py-3 text-sm ${
                            status.type === 'ok'
                                ? 'border-green-500/40 bg-green-500/10 text-green-200'
                                : 'border-red-500/40 bg-red-500/10 text-red-200'
                        }`}
                    >
                        {status.text}
                    </div>
                ) : null}

                {isMasterView ? (
                    <div ref={planFormRef} className='rounded-xl border border-white/10 bg-[#1a1441] p-5'>
                        <h2 className='text-lg font-semibold text-white'>
                            Default Plan Catalog (Root Admin)
                        </h2>
                        <p className='mt-2 text-sm text-white/60'>
                            Root admin controls specs. Resellers can only edit price, IP quantity, and checkout link.
                        </p>

                        <div className='mt-4 rounded-2xl border border-white/10 bg-[#0d1428]/80 p-4'>
                            <div className='flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between'>
                                <div>
                                    <p className='text-xs font-semibold uppercase tracking-[0.24em] text-indigo-200/80'>
                                        Catalog Categories
                                    </p>
                                    <h3 className='mt-1 text-xl font-bold text-white'>
                                        Separate EPYC, Ryzen, and custom plan lines
                                    </h3>
                                    <p className='mt-2 max-w-2xl text-sm leading-6 text-white/60'>
                                        Pick a category before creating or editing a plan. New categories are kept when at least one plan uses them.
                                    </p>
                                </div>
                                <div className='w-full max-w-md'>
                                    <div className='flex gap-2'>
                                        <input
                                            value={categoryDraft}
                                            onChange={event => setCategoryDraft(event.currentTarget.value)}
                                            placeholder='Create category, e.g. AMD EPYC'
                                            className={planFieldClassName}
                                        />
                                        <button
                                            type='button'
                                            onClick={createPlanCategory}
                                            className='shrink-0 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-500'
                                        >
                                            Add
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <div className='mt-4 flex flex-wrap gap-2'>
                                {planCategories.map(category => {
                                    const active = normalizePlanCategory(planForm.category) === category

                                    return (
                                        <button
                                            key={category}
                                            type='button'
                                            onClick={() => selectPlanCategory(category)}
                                            className={`rounded-full border px-3 py-1.5 text-xs font-semibold transition ${
                                                active
                                                    ? 'border-indigo-300/50 bg-indigo-500/25 text-white'
                                                    : 'border-white/10 bg-white/5 text-white/70 hover:bg-white/10 hover:text-white'
                                            }`}
                                        >
                                            {category}
                                        </button>
                                    )
                                })}
                            </div>
                        </div>

                        <div className='mt-4 grid gap-3 md:grid-cols-2'>
                            <PlanField
                                label='Plan Name'
                                hint='Customer-facing plan title, like Starter VPS or Ryzen 4G.'
                            >
                                <input
                                    value={planForm.name}
                                    onChange={event => {
                                        const value = event.currentTarget.value
                                        patchPlanForm({ name: value })
                                    }}
                                    placeholder='Starter VPS'
                                    className={planFieldClassName}
                                />
                            </PlanField>
                            <PlanField
                                label='Plan Slug'
                                hint='Internal API/store identifier. Keep it short and stable.'
                            >
                                <input
                                    value={planForm.slug}
                                    onChange={event => {
                                        const value = event.currentTarget.value
                                        patchPlanForm({ slug: value })
                                    }}
                                    placeholder='starter-vps'
                                    className={planFieldClassName}
                                />
                            </PlanField>
                            <PlanField
                                label='Plan Category'
                                hint='This controls which catalog section the plan appears under.'
                            >
                                <select
                                    value={normalizePlanCategory(planForm.category)}
                                    onChange={event => {
                                        patchPlanForm({
                                            category: normalizePlanCategory(event.currentTarget.value),
                                        })
                                    }}
                                    className={planFieldClassName}
                                >
                                    {planCategories.map(category => (
                                        <option key={category} value={category}>
                                            {category}
                                        </option>
                                    ))}
                                </select>
                            </PlanField>
                            <PlanField
                                label='vCPU Cores'
                                hint='How many virtual CPU cores this VPS plan gets.'
                            >
                                <input
                                    type='number'
                                    value={planForm.cpuCores}
                                    onChange={event => {
                                        const value = Number(event.currentTarget.value)
                                        patchPlanForm({ cpuCores: value })
                                    }}
                                    className={planFieldClassName}
                                />
                            </PlanField>
                            <PlanField
                                label='CPU Limit (%)'
                                hint='Optional Proxmox CPU cap. Use 0 for no percentage cap.'
                            >
                                <input
                                    type='number'
                                    value={planForm.cpuLimit}
                                    onChange={event => {
                                        const value = Number(event.currentTarget.value)
                                        patchPlanForm({ cpuLimit: value })
                                    }}
                                    className={planFieldClassName}
                                />
                            </PlanField>
                            <PlanField
                                label='CPU Units'
                                hint='Scheduler weight for this VPS. Default is 1024.'
                            >
                                <input
                                    type='number'
                                    value={planForm.cpuUnits}
                                    onChange={event => {
                                        const value = Number(event.currentTarget.value)
                                        patchPlanForm({ cpuUnits: value })
                                    }}
                                    className={planFieldClassName}
                                />
                            </PlanField>
                            <PlanField
                                label='CPU Sockets'
                                hint='Virtual CPU socket count sent to Proxmox. Usually 1.'
                            >
                                <input
                                    type='number'
                                    value={planForm.cpuSockets}
                                    onChange={event => {
                                        const value = Number(event.currentTarget.value)
                                        patchPlanForm({ cpuSockets: value })
                                    }}
                                    className={planFieldClassName}
                                />
                            </PlanField>
                            <PlanField
                                label='RAM (MB)'
                                hint='Memory included in this plan. Example: 2048 = 2 GB.'
                            >
                                <input
                                    type='number'
                                    value={planForm.ramMb}
                                    onChange={event => {
                                        const value = Number(event.currentTarget.value)
                                        patchPlanForm({ ramMb: value })
                                    }}
                                    className={planFieldClassName}
                                />
                            </PlanField>
                            <PlanField
                                label='Disk (GB)'
                                hint='Primary disk size assigned to the VPS.'
                            >
                                <input
                                    type='number'
                                    value={planForm.diskGb}
                                    onChange={event => {
                                        const value = Number(event.currentTarget.value)
                                        patchPlanForm({ diskGb: value })
                                    }}
                                    className={planFieldClassName}
                                />
                            </PlanField>
                            <PlanField
                                label='Bandwidth (GB)'
                                hint='Optional traffic cap. Leave blank for no fixed bandwidth limit.'
                            >
                                <input
                                    type='number'
                                    value={planForm.bandwidthGb ?? ''}
                                    onChange={event => {
                                        const raw = event.currentTarget.value
                                        patchPlanForm({
                                            bandwidthGb: raw === '' ? null : Number(raw),
                                        })
                                    }}
                                    placeholder='Unlimited'
                                    className={planFieldClassName}
                                />
                            </PlanField>
                            <PlanField
                                label='Snapshot Limit'
                                hint='How many snapshots the user can keep at one time.'
                            >
                                <input
                                    type='number'
                                    value={planForm.snapshotLimit}
                                    onChange={event => {
                                        const value = Number(event.currentTarget.value)
                                        patchPlanForm({ snapshotLimit: value })
                                    }}
                                    className={planFieldClassName}
                                />
                            </PlanField>
                            <PlanField
                                label='Backup Limit'
                                hint='How many backups are included in the root plan.'
                            >
                                <input
                                    type='number'
                                    value={planForm.backupLimit}
                                    onChange={event => {
                                        const value = Number(event.currentTarget.value)
                                        patchPlanForm({ backupLimit: value })
                                    }}
                                    className={planFieldClassName}
                                />
                            </PlanField>
                            <PlanField
                                label='Included IPs'
                                hint='Default number of IPs included before extra IP pricing starts.'
                            >
                                <input
                                    type='number'
                                    value={planForm.defaultIpQuantity}
                                    onChange={event => {
                                        const value = Number(event.currentTarget.value)
                                        patchPlanForm({ defaultIpQuantity: value })
                                    }}
                                    className={planFieldClassName}
                                />
                            </PlanField>
                            <PlanField
                                label='Sort Order'
                                hint='Lower numbers show first in the catalog and store.'
                            >
                                <input
                                    type='number'
                                    value={planForm.sortOrder}
                                    onChange={event => {
                                        const value = Number(event.currentTarget.value)
                                        patchPlanForm({ sortOrder: value })
                                    }}
                                    className={planFieldClassName}
                                />
                            </PlanField>
                        </div>

                        <PlanField
                            label='Plan Description'
                            hint='Short marketing copy that explains what the plan is best for.'
                            fullWidth
                        >
                            <textarea
                                value={planForm.description ?? ''}
                                onChange={event => {
                                    const value = event.currentTarget.value || null
                                    patchPlanForm({ description: value })
                                }}
                                placeholder='Balanced VPS plan for websites, game servers, or general workloads.'
                                className='w-full rounded-lg border border-white/15 bg-[#111a31] px-3 py-2 text-sm text-white'
                                rows={3}
                            />
                        </PlanField>

                        <div className='mt-3 rounded-lg border border-white/10 bg-[#111a31] p-3'>
                            <label className='inline-flex items-center gap-2 text-sm text-white/85'>
                                <input
                                    type='checkbox'
                                    checked={planForm.isActive}
                                    onChange={event => {
                                        const checked = event.currentTarget.checked
                                        patchPlanForm({ isActive: checked })
                                    }}
                                />
                                Active plan
                            </label>
                            <p className='mt-1 text-xs text-white/50'>
                                Turn this off if you want to keep the plan saved but hidden from new sales.
                            </p>
                        </div>

                        <div className='mt-4 flex flex-wrap gap-2'>
                            <button
                                type='button'
                                onClick={submitPlanForm}
                                disabled={isSavingPlan}
                                className='rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-500 disabled:opacity-50'
                            >
                                {isSavingPlan
                                    ? 'Saving...'
                                    : editingPlanId
                                    ? 'Update Plan'
                                    : 'Create Plan'}
                            </button>
                            {editingPlanId ? (
                                <button
                                    type='button'
                                    onClick={resetPlanForm}
                                    className='rounded-lg border border-white/20 px-4 py-2 text-sm text-white/90'
                                >
                                    Cancel Edit
                                </button>
                            ) : null}
                        </div>
                    </div>
                ) : null}

                <div className='rounded-xl border border-white/10 bg-[#1a1441] p-5'>
                    <h2 className='text-lg font-semibold text-white'>
                        {isMasterView
                            ? 'Shared Reseller Store Defaults'
                            : 'Reseller Pricing And IP Options'}
                    </h2>
                    <p className='mt-2 text-sm text-white/60'>
                        {isMasterView
                            ? 'These reseller-facing defaults are shared across reseller workspaces. Root admin manages one standard pricing layer here, while the plan specs stay locked above.'
                            : 'Specs are locked from root defaults. Only price, included IP count, extra IP price, visibility, and Paymenter checkout link can be changed.'}
                    </p>

                    {isPricingLoading ? (
                        <div className='mt-6'>
                            <Spinner />
                        </div>
                    ) : pricingRows.length === 0 ? (
                        <p className='mt-4 text-sm text-white/60'>
                            {isMasterView
                                ? 'No catalog plans exist yet.'
                                : 'No reseller plan pricing is available yet.'}
                        </p>
                    ) : (
                        <div className='mt-4 space-y-5'>
                            {groupedPricingRows.map(group => (
                                <section
                                    key={group.category}
                                    className='rounded-2xl border border-white/10 bg-[#0d1428]/80 p-4'
                                >
                                    <div className='mb-4 flex flex-col gap-1 sm:flex-row sm:items-end sm:justify-between'>
                                        <div>
                                            <p className='text-xs font-semibold uppercase tracking-[0.24em] text-indigo-200/80'>
                                                Plan Category Section
                                            </p>
                                            <div className='mt-1 flex flex-wrap items-center gap-2'>
                                                <h3 className='text-xl font-bold text-white'>
                                                    {group.category}
                                                </h3>
                                                <span className={`rounded-full border px-2.5 py-1 text-[11px] font-bold uppercase tracking-[0.18em] ${
                                                    group.category.toLowerCase() === 'epyc'
                                                        ? 'border-emerald-300/25 bg-emerald-500/10 text-emerald-100'
                                                        : group.category.toLowerCase() === 'ryzen'
                                                        ? 'border-orange-300/25 bg-orange-500/10 text-orange-100'
                                                        : 'border-white/10 bg-white/5 text-white/60'
                                                }`}>
                                                    {group.category.toLowerCase() === 'epyc'
                                                        ? 'EPYC Line'
                                                        : group.category.toLowerCase() === 'ryzen'
                                                        ? 'Ryzen Line'
                                                        : 'Custom Line'}
                                                </span>
                                            </div>
                                        </div>
                                        <span className='rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs font-semibold text-white/70'>
                                            {group.rows.length} plan
                                            {group.rows.length === 1 ? '' : 's'}
                                        </span>
                                    </div>

                                    <div className='space-y-4'>
                                        {group.rows.map(row => {
                                const draft = pricingDrafts[row.id]
                                if (!draft) {
                                    return null
                                }

                                return (
                                    <div
                                        key={row.id}
                                        className='rounded-lg border border-white/10 bg-[#111a31] p-4'
                                    >
                                        <div className='flex flex-col gap-2 md:flex-row md:items-center md:justify-between'>
                                            <div>
                                                <p className='text-base font-semibold text-white'>
                                                    {row.name}
                                                </p>
                                                <p className='mt-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-indigo-200/70'>
                                                    {normalizePlanCategory(row.category)}
                                                </p>
                                                <p className='mt-1 text-[11px] font-mono text-white/45'>
                                                    Plan ID #{row.id} • Slug: {row.slug}
                                                </p>
                                                <p className='text-xs text-white/60'>
                                                    {row.cpuCores} vCPU • {row.ramMb} MB RAM •{' '}
                                                    {row.diskGb} GB Disk • Included IPs:{' '}
                                                    {row.defaultIpQuantity}
                                                </p>
                                                <p className='mt-1 text-xs text-white/45'>
                                                    CPU limit: {row.cpuLimit || 0}% • Units:{' '}
                                                    {row.cpuUnits || 1024} • Sockets:{' '}
                                                    {row.cpuSockets || 1}
                                                </p>
                                            </div>
                                            {isMasterView ? (
                                                <div className='flex gap-2'>
                                                    <button
                                                        type='button'
                                                        onClick={() => loadPlanIntoForm(row.id)}
                                                        className='rounded border border-white/20 px-3 py-1 text-xs text-white/90'
                                                    >
                                                        Edit Specs
                                                    </button>
                                                    <button
                                                        type='button'
                                                        onClick={() => removePlan(row.id)}
                                                        className='rounded border border-red-500/50 px-3 py-1 text-xs text-red-200'
                                                    >
                                                        Delete
                                                    </button>
                                                </div>
                                            ) : null}
                                        </div>

                                        <div className='mt-3 grid gap-3 md:grid-cols-2 lg:grid-cols-3'>
                                            <input
                                                value={draft.monthlyPrice}
                                                onChange={event => {
                                                    const value = event.currentTarget.value
                                                    patchPricingDraft(row.id, {
                                                        monthlyPrice: value,
                                                    })
                                                }}
                                                placeholder='Monthly price'
                                                className='rounded border border-white/15 bg-[#0c1328] px-3 py-2 text-sm text-white'
                                            />
                                            <input
                                                value={draft.currency}
                                                onChange={event => {
                                                    const value = event.currentTarget.value.toUpperCase()
                                                    patchPricingDraft(row.id, {
                                                        currency: value,
                                                    })
                                                }}
                                                placeholder='Currency (USD)'
                                                className='rounded border border-white/15 bg-[#0c1328] px-3 py-2 text-sm text-white'
                                            />
                                            <input
                                                type='number'
                                                value={draft.ipQuantity}
                                                onChange={event => {
                                                    const value = Number(event.currentTarget.value)
                                                    patchPricingDraft(row.id, {
                                                        ipQuantity: value,
                                                    })
                                                }}
                                                placeholder='Included IP quantity'
                                                className='rounded border border-white/15 bg-[#0c1328] px-3 py-2 text-sm text-white'
                                            />
                                            <input
                                                value={draft.ipPriceEach}
                                                onChange={event => {
                                                    const value = event.currentTarget.value
                                                    patchPricingDraft(row.id, {
                                                        ipPriceEach: value,
                                                    })
                                                }}
                                                placeholder='Extra IP price each'
                                                className='rounded border border-white/15 bg-[#0c1328] px-3 py-2 text-sm text-white'
                                            />
                                            <input
                                                value={draft.paymenterCheckoutUrl}
                                                onChange={event => {
                                                    const value = event.currentTarget.value
                                                    patchPricingDraft(row.id, {
                                                        paymenterCheckoutUrl: value,
                                                    })
                                                }}
                                                placeholder='Paymenter checkout URL'
                                                className='rounded border border-white/15 bg-[#0c1328] px-3 py-2 text-sm text-white md:col-span-2'
                                            />
                                            <label className='inline-flex items-center gap-2 text-sm text-white/80'>
                                                <input
                                                    type='checkbox'
                                                    checked={draft.isVisible}
                                                    onChange={event => {
                                                        const checked = event.currentTarget.checked
                                                        patchPricingDraft(row.id, {
                                                            isVisible: checked,
                                                        })
                                                    }}
                                                />
                                                Visible in store
                                            </label>
                                        </div>

                                        <div className='mt-3'>
                                            <button
                                                type='button'
                                                onClick={() => savePricingRow(row.id)}
                                                disabled={Boolean(isSavingPricing[row.id])}
                                                className='rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-500 disabled:opacity-50'
                                            >
                                                {isSavingPricing[row.id]
                                                    ? 'Saving...'
                                                    : 'Save Pricing'}
                                            </button>
                                        </div>
                                    </div>
                                )
                                        })}
                                    </div>
                                </section>
                            ))}
                        </div>
                    )}
                </div>
            </div>
        </PageContentBlock>
    )
}

export default PlanCatalogContainer
