import getPanelSettings from '@/api/admin/settings/getPanelSettings'
import { updatePanelResellerSettings } from '@/api/admin/settings/updatePanelSettings'
import PageContentBlock from '@/components/elements/PageContentBlock'
import { useStoreActions, useStoreState } from '@/state'
import {
    ArrowTopRightOnSquareIcon,
    BuildingStorefrontIcon,
    CheckCircleIcon,
    DocumentTextIcon,
} from '@heroicons/react/24/outline'
import { Link } from 'react-router-dom'
import { useEffect, useState } from 'react'

const cardClass =
    'rounded-2xl border border-white/10 bg-[#0d1325] p-5 shadow-[0_20px_60px_rgba(0,0,0,0.22)]'
const inputClass =
    'w-full rounded-lg border border-white/15 bg-[#111a31] px-4 py-2.5 text-white placeholder:text-white/35 outline-none transition-colors focus:border-purple-300'

const ResellerSettingsContainer = () => {
    const settings = useStoreState(state => state.settings.data)
    const setSettings = useStoreActions(actions => actions.settings.setSettings)

    const [termsUrl, setTermsUrl] = useState('')
    const [privacyUrl, setPrivacyUrl] = useState('')
    const [registrationEnabled, setRegistrationEnabled] = useState(false)
    const [aadhaarEnabled, setAadhaarEnabled] = useState(true)
    const [panEnabled, setPanEnabled] = useState(true)
    const [digilockerEnabled, setDigilockerEnabled] = useState(false)
    const [digilockerUrl, setDigilockerUrl] = useState('')
    const [emailVerificationEffective, setEmailVerificationEffective] =
        useState(false)
    const [emailVerificationAvailable, setEmailVerificationAvailable] =
        useState(false)
    const [isLoading, setIsLoading] = useState(true)
    const [isSaving, setIsSaving] = useState(false)
    const [status, setStatus] = useState<{
        type: 'ok' | 'error'
        text: string
    } | null>(null)

    useEffect(() => {
        let mounted = true

        getPanelSettings()
            .then(data => {
                if (!mounted) {
                    return
                }

                setTermsUrl(data.resellerRegistrationTermsUrl || '')
                setPrivacyUrl(data.resellerRegistrationPrivacyUrl || '')
                setRegistrationEnabled(
                    Boolean(data.resellerRegistrationEnabled)
                )
                setAadhaarEnabled(Boolean(data.resellerKyc.aadhaarEnabled))
                setPanEnabled(Boolean(data.resellerKyc.panEnabled))
                setDigilockerEnabled(Boolean(data.resellerKyc.digilockerEnabled))
                setDigilockerUrl(data.resellerKyc.digilockerUrl || '')
                setEmailVerificationAvailable(
                    Boolean(data.resellerEmailVerificationAvailable)
                )
                setEmailVerificationEffective(
                    Boolean(data.resellerEmailVerificationEffective)
                )
            })
            .catch(() => {
                if (mounted) {
                    setStatus({
                        type: 'error',
                        text: 'Failed to load reseller settings.',
                    })
                }
            })
            .finally(() => {
                if (mounted) {
                    setIsLoading(false)
                }
            })

        return () => {
            mounted = false
        }
    }, [])

    const handleSave = async () => {
        setIsSaving(true)
        setStatus(null)

        try {
            const updated = await updatePanelResellerSettings({
                resellerRegistrationTermsUrl: termsUrl,
                resellerRegistrationPrivacyUrl: privacyUrl,
                resellerRegistrationEnabled: registrationEnabled,
                resellerKyc: {
                    aadhaarEnabled,
                    panEnabled,
                    digilockerEnabled,
                    digilockerUrl,
                },
            })

            setTermsUrl(updated.resellerRegistrationTermsUrl || '')
            setPrivacyUrl(updated.resellerRegistrationPrivacyUrl || '')
            setRegistrationEnabled(
                Boolean(updated.resellerRegistrationEnabled)
            )
            setAadhaarEnabled(Boolean(updated.resellerKyc.aadhaarEnabled))
            setPanEnabled(Boolean(updated.resellerKyc.panEnabled))
            setDigilockerEnabled(Boolean(updated.resellerKyc.digilockerEnabled))
            setDigilockerUrl(updated.resellerKyc.digilockerUrl || '')
            setEmailVerificationAvailable(
                Boolean(updated.resellerEmailVerificationAvailable)
            )
            setEmailVerificationEffective(
                Boolean(updated.resellerEmailVerificationEffective)
            )

            if (settings) {
                setSettings({
                    ...settings,
                    resellerRegistrationTermsUrl:
                        updated.resellerRegistrationTermsUrl,
                    resellerRegistrationPrivacyUrl:
                        updated.resellerRegistrationPrivacyUrl,
                    resellerRegistrationEnabled:
                        updated.resellerRegistrationEnabled,
                    resellerKyc: updated.resellerKyc,
                    resellerEmailVerificationAvailable:
                        updated.resellerEmailVerificationAvailable,
                    resellerEmailVerificationEffective:
                        updated.resellerEmailVerificationEffective,
                })
            }

            setStatus({ type: 'ok', text: 'Reseller settings saved.' })
        } catch {
            setStatus({
                type: 'error',
                text: 'Failed to save reseller settings. Check URL values and try again.',
            })
        } finally {
            setIsSaving(false)
        }
    }

    return (
        <PageContentBlock title='Reseller Settings - Admin' containerSize='wide'>
            <div className='space-y-6'>
                <div className='overflow-hidden rounded-[2rem] border border-purple-300/20 bg-[radial-gradient(circle_at_top_left,rgba(168,85,247,0.18),transparent_34%),linear-gradient(135deg,#0b1224,#171129)] p-6 shadow-[0_30px_100px_rgba(0,0,0,0.32)]'>
                    <div className='flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between'>
                        <div>
                            <div className='inline-flex items-center gap-2 rounded-full border border-purple-300/20 bg-purple-400/10 px-3 py-1 text-xs font-bold uppercase tracking-[0.24em] text-purple-100/80'>
                                <BuildingStorefrontIcon className='h-4 w-4' />
                                Reseller Platform
                            </div>
                            <h1 className='mt-4 text-3xl font-black tracking-tight text-white'>
                                Reseller Settings
                            </h1>
                            <p className='mt-2 max-w-3xl text-sm leading-7 text-white/60'>
                                Control public reseller signup, partner legal
                                links, and onboarding status without touching
                                the main panel branding screen.
                            </p>
                        </div>
                        <button
                            type='button'
                            onClick={handleSave}
                            disabled={isSaving || isLoading}
                            className='inline-flex items-center justify-center rounded-2xl bg-purple-400 px-5 py-3 text-sm font-black text-slate-950 transition hover:bg-purple-300 disabled:cursor-not-allowed disabled:opacity-60'
                        >
                            {isSaving ? 'Saving...' : 'Save Reseller Settings'}
                        </button>
                    </div>
                </div>

                {status ? (
                    <div
                        className={`rounded-2xl border px-4 py-3 text-sm ${
                            status.type === 'ok'
                                ? 'border-emerald-300/20 bg-emerald-500/10 text-emerald-100'
                                : 'border-red-300/20 bg-red-500/10 text-red-100'
                        }`}
                    >
                        {status.text}
                    </div>
                ) : null}

                {isLoading ? (
                    <div className={cardClass}>
                        <p className='text-sm text-white/60'>
                            Loading reseller settings...
                        </p>
                    </div>
                ) : (
                    <>
                        <div className='grid gap-4 md:grid-cols-3'>
                            <div className='rounded-2xl border border-white/10 bg-[#0d1325] px-4 py-3 text-sm'>
                                <span className='block text-xs uppercase tracking-wide text-white/40'>
                                    Public signup
                                </span>
                                <span className='mt-1 block font-bold text-white'>
                                    {registrationEnabled ? 'Open' : 'Closed'}
                                </span>
                            </div>
                            <div className='rounded-2xl border border-white/10 bg-[#0d1325] px-4 py-3 text-sm'>
                                <span className='block text-xs uppercase tracking-wide text-white/40'>
                                    Register route
                                </span>
                                <span className='mt-1 block font-bold text-white'>
                                    /reseller/register
                                </span>
                            </div>
                            <div className='rounded-2xl border border-white/10 bg-[#0d1325] px-4 py-3 text-sm'>
                                <span className='block text-xs uppercase tracking-wide text-white/40'>
                                    Email verification
                                </span>
                                <span className='mt-1 block font-bold text-white'>
                                    {emailVerificationEffective
                                        ? 'Active'
                                        : emailVerificationAvailable
                                        ? 'Available'
                                        : 'Mail not ready'}
                                </span>
                            </div>
                        </div>

                        <section className={cardClass}>
                            <div className='flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between'>
                                <div className='flex items-start gap-3'>
                                    <CheckCircleIcon className='mt-0.5 h-6 w-6 text-emerald-200' />
                                    <div>
                                        <h2 className='text-lg font-bold text-white'>
                                            Public Reseller Registration
                                        </h2>
                                        <p className='mt-1 max-w-3xl text-sm leading-6 text-white/55'>
                                            Controls whether new partners can
                                            open the public reseller form and
                                            submit a reseller application.
                                        </p>
                                    </div>
                                </div>
                                <label className='inline-flex items-center gap-3 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-white/85'>
                                    <input
                                        type='checkbox'
                                        checked={registrationEnabled}
                                        onChange={event =>
                                            setRegistrationEnabled(
                                                event.currentTarget.checked
                                            )
                                        }
                                        className='h-4 w-4 rounded border border-white/20 bg-transparent'
                                    />
                                    Allow public signup
                                </label>
                            </div>

                            <div className='mt-5 grid gap-3 md:grid-cols-2'>
                                <a
                                    href='/reseller/register'
                                    target='_blank'
                                    rel='noreferrer'
                                    className='inline-flex items-center justify-between rounded-xl border border-white/10 bg-[#111a31] px-4 py-3 text-sm font-semibold text-white/80 transition hover:border-purple-300/30 hover:text-white'
                                >
                                    Open public registration page
                                    <ArrowTopRightOnSquareIcon className='h-4 w-4' />
                                </a>
                                <Link
                                    to='/admin/resellers'
                                    className='inline-flex items-center justify-between rounded-xl border border-white/10 bg-[#111a31] px-4 py-3 text-sm font-semibold text-white/80 transition hover:border-purple-300/30 hover:text-white'
                                >
                                    Review reseller applications
                                    <ArrowTopRightOnSquareIcon className='h-4 w-4' />
                                </Link>
                            </div>
                        </section>

                        <section className={cardClass}>
                            <div className='flex items-start gap-3'>
                                <DocumentTextIcon className='mt-0.5 h-6 w-6 text-cyan-200' />
                                <div>
                                    <h2 className='text-lg font-bold text-white'>
                                        Reseller KYC Documents
                                    </h2>
                                    <p className='mt-1 max-w-3xl text-sm leading-6 text-white/55'>
                                        Choose which identity proofs partners can submit during onboarding. At least one option stays enabled automatically.
                                    </p>
                                </div>
                            </div>

                            <div className='mt-5 grid gap-3 md:grid-cols-2'>
                                {[
                                    {
                                        label: 'Allow Aadhaar',
                                        description: 'Requires Aadhaar front and back upload. DigiLocker is recommended when enabled.',
                                        checked: aadhaarEnabled,
                                        setChecked: setAadhaarEnabled,
                                    },
                                    {
                                        label: 'Allow PAN',
                                        description: 'Requires PAN number and one PAN document upload.',
                                        checked: panEnabled,
                                        setChecked: setPanEnabled,
                                    },
                                ].map(option => (
                                    <label
                                        key={option.label}
                                        className='rounded-2xl border border-white/10 bg-[#111a31] p-4 text-sm text-white/80'
                                    >
                                        <span className='flex items-center justify-between gap-3'>
                                            <span className='font-bold text-white'>{option.label}</span>
                                            <input
                                                type='checkbox'
                                                checked={option.checked}
                                                onChange={event =>
                                                    option.setChecked(event.currentTarget.checked)
                                                }
                                                className='h-4 w-4 rounded border border-white/20 bg-transparent'
                                            />
                                        </span>
                                        <span className='mt-2 block text-xs leading-5 text-white/50'>
                                            {option.description}
                                        </span>
                                    </label>
                                ))}
                            </div>

                            <div className='mt-4 rounded-2xl border border-cyan-300/15 bg-cyan-500/10 p-4'>
                                <label className='inline-flex items-center gap-3 text-sm font-semibold text-cyan-50'>
                                    <input
                                        type='checkbox'
                                        checked={digilockerEnabled}
                                        onChange={event =>
                                            setDigilockerEnabled(event.currentTarget.checked)
                                        }
                                        className='h-4 w-4 rounded border border-white/20 bg-transparent'
                                    />
                                    Show DigiLocker fetch option for Aadhaar
                                </label>
                                <p className='mt-2 text-xs leading-5 text-cyan-50/60'>
                                    Add your DigiLocker OAuth/start URL after official provider approval. Without a URL, onboarding shows it as a secure manual-check hint only.
                                </p>
                                <input
                                    type='text'
                                    value={digilockerUrl}
                                    onChange={event => setDigilockerUrl(event.target.value)}
                                    placeholder='https://your-digilocker-start-url.example.com'
                                    className={`${inputClass} mt-3`}
                                />
                            </div>
                        </section>

                        <section className={cardClass}>
                            <div className='flex items-start gap-3'>
                                <DocumentTextIcon className='mt-0.5 h-6 w-6 text-purple-200' />
                                <div>
                                    <h2 className='text-lg font-bold text-white'>
                                        Registration Legal Links
                                    </h2>
                                    <p className='mt-1 max-w-3xl text-sm leading-6 text-white/55'>
                                        These links are shown on the public
                                        reseller registration form before a
                                        partner submits their details.
                                    </p>
                                </div>
                            </div>

                            <div className='mt-5 grid gap-4 lg:grid-cols-2'>
                                <div>
                                    <label className='mb-2 block text-sm font-medium text-white/80'>
                                        Reseller Registration Terms URL
                                    </label>
                                    <input
                                        type='text'
                                        value={termsUrl}
                                        onChange={event =>
                                            setTermsUrl(event.target.value)
                                        }
                                        placeholder='https://wammuhost.com/terms'
                                        className={inputClass}
                                    />
                                </div>
                                <div>
                                    <label className='mb-2 block text-sm font-medium text-white/80'>
                                        Reseller Registration Privacy URL
                                    </label>
                                    <input
                                        type='text'
                                        value={privacyUrl}
                                        onChange={event =>
                                            setPrivacyUrl(event.target.value)
                                        }
                                        placeholder='https://wammuhost.com/privacy'
                                        className={inputClass}
                                    />
                                </div>
                            </div>
                        </section>

                        <section className='rounded-2xl border border-cyan-300/20 bg-[radial-gradient(circle_at_top_left,rgba(34,211,238,0.12),transparent_35%),#0d1325] p-5'>
                            <div className='flex flex-col gap-3 md:flex-row md:items-center md:justify-between'>
                                <div>
                                    <h2 className='text-lg font-bold text-white'>
                                        Email verification moved
                                    </h2>
                                    <p className='mt-1 text-sm leading-6 text-white/55'>
                                        Reseller onboarding email verification
                                        now lives with SMTP and notification
                                        templates.
                                    </p>
                                </div>
                                <Link
                                    to='/admin/email'
                                    className='inline-flex items-center justify-center rounded-lg border border-cyan-300/25 bg-cyan-500/10 px-4 py-2.5 text-sm font-semibold text-cyan-100 transition hover:bg-cyan-500/20'
                                >
                                    Open Email & Templates
                                </Link>
                            </div>
                        </section>
                    </>
                )}
            </div>
        </PageContentBlock>
    )
}

export default ResellerSettingsContainer
