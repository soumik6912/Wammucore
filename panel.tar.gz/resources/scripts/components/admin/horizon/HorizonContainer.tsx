﻿import {
    ArrowPathIcon,
    BoltIcon,
    ChartBarSquareIcon,
    ClockIcon,
    ExclamationTriangleIcon,
    FireIcon,
    QueueListIcon,
    RocketLaunchIcon,
    Squares2X2Icon,
    ShieldExclamationIcon,
} from '@heroicons/react/24/outline'
import { useEffect, useMemo, useState } from 'react'

import runHorizonAction from '@/api/admin/horizon/runHorizonAction'
import runBulkPowerAction, { BulkPowerScope } from '@/api/admin/horizon/runBulkPowerAction'
import useHorizonSWR from '@/api/admin/horizon/useHorizonSWR'
import { HorizonAction, HorizonJob, HorizonWorkload } from '@/api/admin/horizon/types'
import { httpErrorToHuman } from '@/api/http'
import { FilterPill } from '@/components/admin/security/SecurityUi'
import PageContentBlock from '@/components/elements/PageContentBlock'
import Spinner from '@/components/elements/Spinner'
import { classNames } from '@/util/helpers'
import useNotify from '@/util/useNotify'

const shellClassName =
    'rounded-2xl border border-red-500/25 bg-[linear-gradient(180deg,rgba(30,10,13,0.96),rgba(15,7,9,0.96))] shadow-[0_12px_36px_rgba(7,2,3,0.35)]'

const panelClassName =
    'rounded-2xl border border-white/10 bg-[linear-gradient(180deg,rgba(28,12,15,0.95),rgba(17,9,11,0.95))] shadow-[0_10px_28px_rgba(4,2,3,0.28)]'

const metricClassName =
    'rounded-xl border border-white/10 bg-[linear-gradient(180deg,rgba(42,15,20,0.96),rgba(22,10,13,0.96))] shadow-[0_8px_20px_rgba(4,2,3,0.22)]'

const statusTone: Record<string, string> = {
    running: 'border-emerald-400/30 bg-emerald-500/10 text-emerald-100',
    paused: 'border-amber-400/30 bg-amber-500/10 text-amber-100',
    inactive: 'border-rose-400/30 bg-rose-500/10 text-rose-100',
}

const actionTone: Record<string, string> = {
    pause: 'border-amber-400/30 bg-amber-500/10 text-amber-100 hover:bg-amber-500/20',
    continue: 'border-emerald-400/30 bg-emerald-500/10 text-emerald-100 hover:bg-emerald-500/20',
    terminate: 'border-rose-400/30 bg-rose-500/10 text-rose-100 hover:bg-rose-500/20',
    'queue-restart': 'border-sky-400/30 bg-sky-500/10 text-sky-100 hover:bg-sky-500/20',
    snapshot: 'border-orange-400/30 bg-orange-500/10 text-orange-100 hover:bg-orange-500/20',
    'clear-metrics': 'border-red-400/30 bg-red-500/10 text-red-100 hover:bg-red-500/20',
}

const metricAccent: string[] = [
    'text-red-200/75',
    'text-orange-200/75',
    'text-amber-200/75',
    'text-rose-200/75',
    'text-red-300/75',
    'text-orange-300/75',
]

const formatSeconds = (value: number): string => {
    if (!value || value <= 0) return '-'
    if (value < 60) return `${value}s`
    if (value < 3600) return `${Math.round(value / 60)}m`
    return `${(value / 3600).toFixed(1)}h`
}

const formatNumber = (value: number): string => new Intl.NumberFormat().format(value)

const wait = (ms: number) => new Promise(resolve => window.setTimeout(resolve, ms))

const statusToneForQueue = (queue: HorizonWorkload): string => {
    if (queue.wait >= 180 || queue.length >= 250) return 'border-rose-400/20 bg-rose-500/8'
    if (queue.wait >= 60 || queue.length >= 50) return 'border-amber-400/20 bg-amber-500/8'
    return 'border-white/8 bg-white/[0.03]'
}

const JobFeed = ({ jobs }: { jobs: HorizonJob[] }) => (
    <div className='space-y-3'>
        {jobs.length ? (
            jobs.map(job => (
                <article key={`${job.status}-${job.id}`} className='rounded-xl border border-white/10 bg-black/20 p-4'>
                    <div className='flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between'>
                        <div className='min-w-0 flex-1'>
                            <div className='flex flex-wrap items-center gap-2'>
                                <span className='rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.14em] text-white/60'>
                                    {job.queue}
                                </span>
                                {job.silenced ? (
                                    <span className='rounded-full border border-amber-400/30 bg-amber-500/10 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-amber-100'>
                                        silenced
                                    </span>
                                ) : null}
                            </div>
                            <h3 className='mt-3 break-words text-base font-semibold text-white'>{job.name}</h3>
                            {job.tags.length ? (
                                <div className='mt-3 flex flex-wrap gap-2 text-xs text-white/45'>
                                    {job.tags.slice(0, 6).map(tag => (
                                        <span key={tag} className='rounded-full border border-white/10 bg-white/[0.03] px-2 py-1'>
                                            {tag}
                                        </span>
                                    ))}
                                </div>
                            ) : null}
                            {job.exception ? (
                                <p className='mt-3 rounded-2xl border border-rose-400/15 bg-rose-500/5 p-3 text-sm text-rose-100/80'>
                                    {job.exception}
                                </p>
                            ) : null}
                        </div>
                        <div className='text-xs uppercase tracking-[0.18em] text-white/35'>
                            {job.failedAt || job.completedAt || job.reservedAt || 'recent'}
                        </div>
                    </div>
                </article>
            ))
        ) : (
            <div className='rounded-3xl border border-dashed border-white/10 px-4 py-10 text-sm text-white/45'>
                No jobs in this feed right now.
            </div>
        )}
    </div>
)

const MetricShell = ({
    label,
    value,
    helper,
    accent,
}: {
    label: string
    value: React.ReactNode
    helper: string
    accent: React.ReactNode
}) => (
    <div className={`${metricClassName} overflow-hidden p-5`}>
        <div className='flex items-start justify-between gap-4'>
            <div>
                <p className='text-xs font-semibold uppercase tracking-[0.2em] text-white/45'>
                    {label}
                </p>
                <div className='mt-3 text-3xl font-semibold text-white'>
                    {value}
                </div>
            </div>
            {accent}
        </div>
        <p className='mt-3 text-sm leading-6 text-white/55'>{helper}</p>
    </div>
)

const HorizonContainer = () => {
    const { data, mutate } = useHorizonSWR()
    const notify = useNotify()
    const [runningAction, setRunningAction] = useState<string | null>(null)
    const [runningBulkAction, setRunningBulkAction] = useState<BulkPowerScope | null>(null)
    const [jobFeed, setJobFeed] = useState<'failed' | 'pending' | 'completed'>('failed')
    const [lastUpdated, setLastUpdated] = useState<Date | null>(null)

    useEffect(() => {
        if (data) {
            const parsed = data.generatedAt ? new Date(data.generatedAt) : new Date()
            setLastUpdated(Number.isNaN(parsed.getTime()) ? new Date() : parsed)
        }
    }, [data])

    const performAction = async (action: HorizonAction) => {
        try {
            setRunningAction(action.key)
            const result = await runHorizonAction(action.key)
            notify({ message: result.message, color: 'green' })
            await wait(action.key === 'terminate' ? 1500 : 800)
            await mutate()
        } catch (error) {
            notify({ message: httpErrorToHuman(error), color: 'red' })
        } finally {
            setRunningAction(null)
        }
    }

    const performBulkPowerAction = async (scope: BulkPowerScope) => {
        const isResellerOnly = scope === 'reseller-vps'
        const label = isResellerOnly ? 'stop all reseller VPS' : 'stop every VPS on the platform'
        const confirmed = window.confirm(
            `Emergency action: ${label}.\n\nThis queues force-stop jobs through Core. Already stopped VPS are skipped by the power layer. Continue?`
        )

        if (!confirmed) {
            return
        }

        try {
            setRunningBulkAction(scope)
            const result = await runBulkPowerAction(scope)
            notify({
                message: `${result.message} ${result.skippedServers ? `${result.skippedServers} non-operational VPS skipped.` : ''}`.trim(),
                color: 'green',
            })
            await mutate()
        } catch (error) {
            notify({ message: httpErrorToHuman(error), color: 'red' })
        } finally {
            setRunningBulkAction(null)
        }
    }

    const statusBadgeClass = statusTone[data?.summary.status ?? 'inactive'] ?? statusTone.inactive
    const topQueues = useMemo(() => (data?.queues ?? []).slice(0, 6), [data])
    const topTags = useMemo(() => (data?.monitoredTags ?? []).slice(0, 8), [data])

    const recommendations = useMemo(() => {
        if (!data) return []

        const hints: string[] = []

        if (data.summary.status === 'inactive') {
            hints.push('Core is not running. Check the Core queue systemd service first.')
        }
        if (data.summary.status === 'paused') {
            hints.push('Queues are paused. Resume Core to allow create, reinstall, and maintenance jobs to move again.')
        }
        if (data.summary.maxWait >= 60) {
            hints.push(`Queue wait is elevated at ${formatSeconds(data.summary.maxWait)}. Consider restarting Core or raising worker capacity carefully.`)
        }
        if (data.summary.failedJobs > 0) {
            hints.push(`There are ${formatNumber(data.summary.failedJobs)} failed jobs. Review the failed feed below before retriggering installs.`)
        }
        if (data.summary.processes >= 8) {
            hints.push('Worker count is fairly high for a small VPS. Watch RAM usage so queue workers do not compete with PHP-FPM.')
        }

        return hints.slice(0, 4)
    }, [data])

    const healthIndex = useMemo(() => {
        if (!data) return 0
        let score = 100

        if (data.summary.status === 'inactive') score -= 45
        if (data.summary.status === 'paused') score -= 25
        if (data.summary.failedJobs > 0) score -= Math.min(25, data.summary.failedJobs * 2)
        if (data.summary.maxWait >= 60) score -= Math.min(20, Math.floor(data.summary.maxWait / 30))
        if (data.summary.pendingJobs >= 100) score -= 10

        return Math.max(0, Math.min(100, score))
    }, [data])

    return (
        <div className='min-h-screen bg-[radial-gradient(circle_at_top,_rgba(127,29,29,0.22),_transparent_34%),linear-gradient(180deg,#090406_0%,#120608_48%,#080405_100%)]'>
            <PageContentBlock title='Core - Admin' containerSize='wide'>
                <div className='space-y-6'>
                    <section className={`${shellClassName} overflow-hidden p-6`}>
                        <div className='flex flex-col gap-6 xl:flex-row xl:items-end xl:justify-between'>
                            <div className='max-w-3xl'>
                                <div className='inline-flex items-center gap-2 rounded-full border border-red-400/20 bg-red-500/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.28em] text-red-100/75'>
                                    <FireIcon className='h-4 w-4' />
                                    Core Queue Engine
                                </div>
                                <h1 className='mt-4 text-3xl font-semibold tracking-tight text-white'>
                                    Core control center
                                </h1>
                                <p className='mt-3 max-w-2xl text-sm leading-6 text-white/75'>
                                    Queue operations dashboard for live status, workload, workers, and recovery actions.
                                </p>
                                <div className='mt-4 flex flex-wrap items-center gap-2 text-xs'>
                                    <span className='rounded-full border border-emerald-400/30 bg-emerald-500/10 px-3 py-1 font-semibold uppercase tracking-[0.18em] text-emerald-100'>
                                        Live
                                    </span>
                                    <span className='rounded-full border border-white/12 bg-white/[0.04] px-3 py-1 text-white/75'>
                                        {lastUpdated ? `Updated ${lastUpdated.toLocaleTimeString()}` : 'Waiting for first sample'}
                                    </span>
                                </div>
                            </div>
                            <div className='flex flex-wrap items-center gap-3'>
                                <button
                                    type='button'
                                    onClick={() => mutate()}
                                    className='inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3 text-sm font-semibold text-white transition hover:border-white/20 hover:bg-white/[0.08]'
                                >
                                    <ArrowPathIcon className='h-4 w-4' />
                                    Refresh
                                </button>
                                <a
                                    href={data?.links.dashboard ?? '/core'}
                                    target='_blank'
                                    rel='noreferrer'
                                    className='inline-flex items-center gap-2 rounded-xl border border-red-400/35 bg-red-500/15 px-4 py-2.5 text-sm font-semibold text-red-100 transition hover:bg-red-500/22'
                                >
                                    <RocketLaunchIcon className='h-4 w-4' />
                                    Open Core (Raw)
                                </a>
                            </div>
                        </div>
                    </section>

                    {!data ? (
                        <div className={`${panelClassName} py-16`}>
                            <Spinner />
                        </div>
                    ) : (
                        <>
                            <section className={`${panelClassName} p-4`}>
                                <div className='flex flex-col gap-3 md:flex-row md:items-center md:justify-between'>
                                    <div className='text-sm text-white/70'>
                                        Monitor workers, queue pressure, and failed jobs from one place.
                                    </div>
                                    <div className='rounded-lg border border-red-500/25 bg-red-500/10 px-3 py-2 text-sm text-red-100'>
                                        Core health: <span className='font-semibold text-white'>{healthIndex}%</span>
                                    </div>
                                </div>
                            </section>

                            <section id='overview' className='grid gap-4 md:grid-cols-2 xl:grid-cols-6'>
                                <MetricShell
                                    label='Status'
                                    value={<span className={classNames('inline-flex rounded-full border px-3 py-1 text-sm uppercase tracking-[0.18em]', statusBadgeClass)}>{data.summary.status}</span>}
                                    helper='Whether Core is actively running, paused, or completely offline.'
                                    accent={<BoltIcon className={`h-10 w-10 ${metricAccent[0]}`} />}
                                />
                                <MetricShell label='Processes' value={formatNumber(data.summary.processes)} helper='Active queue workers across all supervisors.' accent={<Squares2X2Icon className={`h-10 w-10 ${metricAccent[1]}`} />} />
                                <MetricShell label='Jobs / Min' value={formatNumber(data.summary.jobsPerMinute)} helper='Current processing speed from the latest snapshots.' accent={<ChartBarSquareIcon className={`h-10 w-10 ${metricAccent[2]}`} />} />
                                <MetricShell label='Pending' value={formatNumber(data.summary.pendingJobs)} helper='Jobs waiting in Redis right now.' accent={<QueueListIcon className={`h-10 w-10 ${metricAccent[3]}`} />} />
                                <MetricShell label='Failures' value={formatNumber(data.summary.failedJobs)} helper='Jobs Core has marked failed and retained.' accent={<ExclamationTriangleIcon className={`h-10 w-10 ${metricAccent[4]}`} />} />
                                <MetricShell label='Max Wait' value={formatSeconds(data.summary.maxWait)} helper='Worst queue wait currently observed.' accent={<ClockIcon className={`h-10 w-10 ${metricAccent[5]}`} />} />
                            </section>

                            <section id='actions' className='grid gap-6 xl:grid-cols-[1.15fr,0.85fr]'>
                                <div className={`${panelClassName} overflow-hidden p-5`}>
                                    <div className='flex items-center justify-between gap-3'>
                                        <div>
                                            <h2 className='text-lg font-semibold text-white'>Core actions</h2>
                                            <p className='mt-1 text-sm text-white/60'>Pause, resume, restart, and capture metrics.</p>
                                        </div>
                                        <span className='rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-white/45'>
                                            {data.summary.masterSupervisors} masters
                                        </span>
                                    </div>
                                    <div className='mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3'>
                                        {data.actions.map(action => (
                                            <button
                                                key={action.key}
                                                type='button'
                                                disabled={runningAction !== null}
                                                onClick={() => performAction(action)}
                                                className={classNames(
                                                    'rounded-2xl border px-4 py-4 text-left text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-60',
                                                    actionTone[action.key] ?? 'border-white/10 bg-white/[0.04] text-white hover:bg-white/[0.08]'
                                                )}
                                            >
                                                <div className='flex items-center justify-between gap-3'>
                                                    <span>{action.label}</span>
                                                    {runningAction === action.key ? <ArrowPathIcon className='h-4 w-4 animate-spin' /> : null}
                                                </div>
                                            </button>
                                        ))}
                                    </div>
                                    <div className='mt-5 rounded-2xl border border-rose-400/20 bg-rose-500/[0.07] p-4'>
                                        <div className='flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between'>
                                            <div>
                                                <h3 className='text-sm font-semibold uppercase tracking-[0.2em] text-rose-100'>
                                                    Emergency VPS stop
                                                </h3>
                                                <p className='mt-2 max-w-3xl text-sm leading-6 text-rose-100/70'>
                                                    Queue Core jobs to force-stop machines during abuse, overload, or maintenance incidents. These controls are root-admin-only.
                                                </p>
                                            </div>
                                            <div className='flex flex-col gap-2 sm:flex-row'>
                                                <button
                                                    type='button'
                                                    disabled={runningAction !== null || runningBulkAction !== null}
                                                    onClick={() => performBulkPowerAction('reseller-vps')}
                                                    className='inline-flex items-center justify-center gap-2 rounded-xl border border-amber-400/30 bg-amber-500/10 px-4 py-3 text-sm font-semibold text-amber-100 transition hover:bg-amber-500/20 disabled:cursor-not-allowed disabled:opacity-60'
                                                >
                                                    {runningBulkAction === 'reseller-vps' ? <ArrowPathIcon className='h-4 w-4 animate-spin' /> : null}
                                                    Stop All Reseller VPS
                                                </button>
                                                <button
                                                    type='button'
                                                    disabled={runningAction !== null || runningBulkAction !== null}
                                                    onClick={() => performBulkPowerAction('all-vps')}
                                                    className='inline-flex items-center justify-center gap-2 rounded-xl border border-rose-400/35 bg-rose-500/15 px-4 py-3 text-sm font-semibold text-rose-100 transition hover:bg-rose-500/25 disabled:cursor-not-allowed disabled:opacity-60'
                                                >
                                                    {runningBulkAction === 'all-vps' ? <ArrowPathIcon className='h-4 w-4 animate-spin' /> : null}
                                                    Stop All VPS
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className={`${panelClassName} overflow-hidden p-5`}>
                                    <div className='flex items-center gap-3'>
                                        <div className='rounded-2xl border border-red-400/20 bg-red-500/10 p-3 text-red-100'>
                                            <ShieldExclamationIcon className='h-6 w-6' />
                                        </div>
                                        <div>
                                            <h2 className='text-lg font-semibold text-white'>Operator guidance</h2>
                                            <p className='mt-1 text-sm text-white/60'>Suggested actions based on current state.</p>
                                        </div>
                                    </div>
                                    <div className='mt-4 space-y-3'>
                                        {recommendations.length ? recommendations.map(item => (
                                            <div key={item} className='rounded-2xl border border-white/8 bg-white/[0.03] px-4 py-3 text-sm leading-6 text-white/75'>
                                                {item}
                                            </div>
                                        )) : (
                                            <div className='rounded-2xl border border-emerald-400/15 bg-emerald-500/5 px-4 py-4 text-sm text-emerald-100/80'>
                                                Core looks healthy right now. No immediate operator actions are suggested.
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </section>

                            <section id='workload' className='grid gap-6 xl:grid-cols-[1.05fr,0.95fr]'>
                                <div className={`${panelClassName} overflow-hidden p-5`}>
                                    <div className='flex items-center justify-between gap-3'>
                                        <div>
                                            <h2 className='text-lg font-semibold text-white'>Queue workload</h2>
                                            <p className='mt-1 text-sm text-white/55'>Live pressure, wait time, throughput, and runtime across your queues.</p>
                                        </div>
                                        <span className='rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-white/45'>
                                            {data.workload.length} queues
                                        </span>
                                    </div>
                                    <div className='mt-4 space-y-3'>
                                        {data.workload.length ? data.workload.map(queue => (
                                            <article key={queue.name} className={classNames('rounded-xl border p-4', statusToneForQueue(queue))}>
                                                <div className='flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between'>
                                                    <div>
                                                        <h3 className='text-base font-semibold text-white'>{queue.name}</h3>
                                                        <p className='mt-1 text-sm text-white/50'>
                                                            {queue.processes} processes · {formatNumber(queue.length)} queued · {formatSeconds(queue.wait)} wait
                                                        </p>
                                                    </div>
                                                    <div className='grid gap-3 sm:grid-cols-3 lg:min-w-[22rem]'>
                                                        <div className='rounded-lg border border-white/10 bg-[#11070a] px-3 py-2'>
                                                            <div className='text-[11px] uppercase tracking-[0.18em] text-white/40'>Runtime</div>
                                                            <div className='mt-1 text-sm font-semibold text-white'>{queue.runtime} ms</div>
                                                        </div>
                                                        <div className='rounded-lg border border-white/10 bg-[#11070a] px-3 py-2'>
                                                            <div className='text-[11px] uppercase tracking-[0.18em] text-white/40'>Throughput</div>
                                                            <div className='mt-1 text-sm font-semibold text-white'>{formatNumber(queue.throughput)}</div>
                                                        </div>
                                                        <div className='rounded-lg border border-white/10 bg-[#11070a] px-3 py-2'>
                                                            <div className='text-[11px] uppercase tracking-[0.18em] text-white/40'>Splits</div>
                                                            <div className='mt-1 text-sm font-semibold text-white'>{queue.splitQueues.length || '-'}</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </article>
                                        )) : <div className='rounded-3xl border border-dashed border-white/10 px-4 py-10 text-sm text-white/45'>No active queue workload yet.</div>}
                                    </div>
                                </div>

                                <div className='space-y-6'>
                                    <section id='supervisors' className={`${panelClassName} overflow-hidden p-5`}>
                                        <div className='flex items-center justify-between gap-3'>
                                            <div>
                                                <h2 className='text-lg font-semibold text-white'>Supervisors</h2>
                                                <p className='mt-1 text-sm text-white/55'>Worker groups Core is actively managing.</p>
                                            </div>
                                            <span className='rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-white/45'>
                                                {data.supervisors.length} groups
                                            </span>
                                        </div>
                                        <div className='mt-4 space-y-3'>
                                            {data.supervisors.length ? data.supervisors.map(supervisor => (
                                                <article key={supervisor.name} className='rounded-xl border border-white/10 bg-black/20 p-4'>
                                                    <div className='flex items-start justify-between gap-3'>
                                                        <div>
                                                            <h3 className='text-base font-semibold text-white'>{supervisor.name}</h3>
                                                            <p className='mt-1 text-sm text-white/50'>Master {supervisor.master}</p>
                                                        </div>
                                                        <span className={classNames('rounded-full border px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.18em]', statusTone[supervisor.status] ?? statusTone.inactive)}>
                                                            {supervisor.status}
                                                        </span>
                                                    </div>
                                                    <div className='mt-3 flex flex-wrap gap-2 text-xs text-white/45'>
                                                        <span>{supervisor.processCount} processes</span>
                                                        <span>{supervisor.balance || 'auto'} balance</span>
                                                        {supervisor.queue.map(queue => <span key={queue}>{queue}</span>)}
                                                    </div>
                                                </article>
                                            )) : <div className='text-sm text-white/45'>No active supervisors found.</div>}
                                        </div>
                                    </section>

                                    <section className={`${panelClassName} overflow-hidden p-5`}>
                                        <div className='flex items-center justify-between gap-3'>
                                            <div>
                                                <h2 className='text-lg font-semibold text-white'>Top queue metrics</h2>
                                                <p className='mt-1 text-sm text-white/55'>Queues with the strongest recent activity.</p>
                                            </div>
                                            <span className='rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-white/45'>
                                                {data.queues.length} tracked
                                            </span>
                                        </div>
                                        <div className='mt-4 space-y-3'>
                                            {topQueues.length ? topQueues.map(queue => (
                                                <div key={queue.name} className='rounded-xl border border-white/10 bg-black/20 p-4'>
                                                    <div className='flex items-center justify-between gap-3'>
                                                        <span className='font-semibold text-white'>{queue.name}</span>
                                                        <span className='text-sm text-white/50'>{formatNumber(queue.throughput)} / min</span>
                                                    </div>
                                                    <div className='mt-2 text-sm text-white/55'>Average runtime {queue.runtime} ms</div>
                                                </div>
                                            )) : <div className='text-sm text-white/45'>No queue metrics captured yet. Run a snapshot if Core just started.</div>}
                                        </div>
                                    </section>
                                </div>
                            </section>

                            <section id='jobs' className='grid gap-6 xl:grid-cols-[1fr,0.45fr]'>
                                <section className={`${panelClassName} overflow-hidden p-5`}>
                                    <div className='flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between'>
                                        <div>
                                            <h2 className='text-lg font-semibold text-white'>Recent Core jobs</h2>
                                            <p className='mt-1 text-sm text-white/55'>Flip between failed, pending, and completed jobs without opening the raw dashboard.</p>
                                        </div>
                                        <div className='flex flex-wrap gap-2'>
                                            <FilterPill active={jobFeed === 'failed'} onClick={() => setJobFeed('failed')}>Failed</FilterPill>
                                            <FilterPill active={jobFeed === 'pending'} onClick={() => setJobFeed('pending')}>Pending</FilterPill>
                                            <FilterPill active={jobFeed === 'completed'} onClick={() => setJobFeed('completed')}>Completed</FilterPill>
                                        </div>
                                    </div>
                                    <div className='mt-4'>
                                        <JobFeed jobs={data.jobs[jobFeed]} />
                                    </div>
                                </section>

                                <section className={`${panelClassName} overflow-hidden p-5`}>
                                    <div className='flex items-center justify-between gap-3'>
                                        <div>
                                            <h2 className='text-lg font-semibold text-white'>Tracked tags</h2>
                                            <p className='mt-1 text-sm text-white/55'>High-value tag groups currently visible in Core.</p>
                                        </div>
                                        <span className='rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-white/45'>
                                            {data.monitoredTags.length}
                                        </span>
                                    </div>
                                    <div className='mt-4 flex flex-wrap gap-2'>
                                        {topTags.length ? topTags.map(item => (
                                            <span key={item.tag} className='rounded-full border border-white/10 bg-white/[0.04] px-3 py-2 text-sm text-white/75'>
                                                {item.tag} <span className='text-white/40'>({item.count})</span>
                                            </span>
                                        )) : <div className='text-sm text-white/45'>No monitored tags configured.</div>}
                                    </div>
                                </section>
                            </section>
                        </>
                    )}
                </div>
            </PageContentBlock>
        </div>
    )
}

export default HorizonContainer



