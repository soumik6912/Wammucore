import { useFlashKey } from '@/util/useFlash'
import { FormikProvider, useFormik } from 'formik'
import * as yup from 'yup'

import createReseller from '@/api/admin/resellers/createReseller'
import {
    Reseller,
    ResellerStatus,
} from '@/api/admin/resellers/getResellers'
import updateReseller from '@/api/admin/resellers/updateReseller'

import FlashMessageRender from '@/components/elements/FlashMessageRenderer'
import Modal from '@/components/elements/Modal'
import SelectFormik from '@/components/elements/formik/SelectFormik'
import TextInputFormik from '@/components/elements/formik/TextInputFormik'
import { useStoreState } from '@/state'

type Mode = 'create' | 'edit'

interface Props {
    open: boolean
    mode: Mode
    reseller: Reseller | null
    onClose: () => void
    onSaved: () => void
}

interface FormValues {
    displayName: string
    status: ResellerStatus
    domain: string
    logoUrl: string
    backendDomain: string
    liveDataDomain: string
    novncDomain: string
    cdnDomain: string
    maxRamMb: string
    maxCpuCores: string
    maxDiskGb: string
    maxVms: string
    adminEmail: string
    adminPassword: string
    adminPasswordConfirmation: string
}

const resellerAdminPasswordPattern =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/u

const toNullable = (value: string): string | null => {
    const normalized = value.trim()

    return normalized.length > 0 ? normalized : null
}

const integerField = (label: string) =>
    yup
        .string()
        .required(`${label} is required.`)
        .matches(/^[0-9]+$/, `${label} must be a number.`)
        .test('positive', `${label} must be at least 1.`, value =>
            Number(value ?? 0) >= 1
        )

const getInitialValues = (reseller: Reseller | null): FormValues => ({
    displayName: reseller?.displayName ?? '',
    status: reseller?.status ?? 'active',
    domain: reseller?.domain ?? '',
    logoUrl: reseller?.logoUrl ?? '',
    backendDomain: reseller?.backendDomain ?? '',
    liveDataDomain: reseller?.liveDataDomain ?? '',
    novncDomain: reseller?.novncDomain ?? '',
    cdnDomain: reseller?.cdnDomain ?? '',
    maxRamMb: String(reseller?.maxRamMb ?? 4096),
    maxCpuCores: String(reseller?.maxCpuCores ?? 4),
    maxDiskGb: String(reseller?.maxDiskGb ?? 40),
    maxVms: String(reseller?.maxVms ?? 10),
    adminEmail: reseller?.adminUser?.email ?? '',
    adminPassword: '',
    adminPasswordConfirmation: '',
})

const ResellerUpsertModal = ({
    open,
    mode,
    reseller,
    onClose,
    onSaved,
}: Props) => {
    const actor = useStoreState(state => state.user.data)
    const canManageSystemFields = Boolean(actor?.rootAdmin)
    const { clearFlashes, clearAndAddHttpError } = useFlashKey(
        'admin:resellers.upsert'
    )

    const form = useFormik<FormValues>({
        enableReinitialize: true,
        initialValues: getInitialValues(reseller),
        validationSchema: yup.object({
            displayName: yup
                .string()
                .max(191, 'Do not exceed 191 characters.')
                .required('Display name is required.'),
            status: yup
                .mixed<ResellerStatus>()
                .oneOf(['pending', 'active', 'suspended'])
                .required(),
            domain: yup.string().max(191, 'Do not exceed 191 characters.'),
            logoUrl: yup.string().max(191, 'Do not exceed 191 characters.'),
            backendDomain: yup
                .string()
                .max(191, 'Do not exceed 191 characters.'),
            liveDataDomain: yup
                .string()
                .max(191, 'Do not exceed 191 characters.'),
            novncDomain: yup.string().max(191, 'Do not exceed 191 characters.'),
            cdnDomain: yup.string().max(191, 'Do not exceed 191 characters.'),
            maxRamMb: integerField('Max RAM (MB)'),
            maxCpuCores: integerField('Max CPU Cores'),
            maxDiskGb: integerField('Max Disk (GB)'),
            maxVms: integerField('Max VMs'),
            adminEmail: yup
                .string()
                .trim()
                .email('Enter a valid reseller admin email.')
                .max(191, 'Do not exceed 191 characters.'),
            adminPassword: yup
                .string()
                .max(191, 'Do not exceed 191 characters.')
                .test(
                    'optional-password-format',
                    'Use at least 8 characters with an uppercase letter, lowercase letter, number, and special character.',
                    value =>
                        !value || resellerAdminPasswordPattern.test(value)
                ),
            adminPasswordConfirmation: yup.string().test(
                'password-match',
                'Password confirmation does not match.',
                function (value) {
                    return (
                        !this.parent.adminPassword ||
                        value === this.parent.adminPassword
                    )
                }
            ),
        }),
        onSubmit: async values => {
            clearFlashes()

            try {
                const payload = {
                    displayName: values.displayName.trim(),
                    domain: toNullable(values.domain),
                    logoUrl: toNullable(values.logoUrl),
                    backendDomain: toNullable(values.backendDomain),
                    liveDataDomain: toNullable(values.liveDataDomain),
                    novncDomain: toNullable(values.novncDomain),
                    cdnDomain: toNullable(values.cdnDomain),
                }
                const rootOnlyPayload = canManageSystemFields
                    ? {
                          status: values.status,
                          maxRamMb: Number(values.maxRamMb),
                          maxCpuCores: Number(values.maxCpuCores),
                          maxDiskGb: Number(values.maxDiskGb),
                          maxVms: Number(values.maxVms),
                      }
                    : {}

                if (mode === 'create') {
                    await createReseller({
                        ...payload,
                        status: values.status,
                        maxRamMb: Number(values.maxRamMb),
                        maxCpuCores: Number(values.maxCpuCores),
                        maxDiskGb: Number(values.maxDiskGb),
                        maxVms: Number(values.maxVms),
                    })
                } else if (reseller) {
                    await updateReseller({
                        id: reseller.id,
                        ...payload,
                        ...rootOnlyPayload,
                        adminEmail: values.adminEmail.trim() || undefined,
                        adminPassword: values.adminPassword || undefined,
                        adminPasswordConfirmation:
                            values.adminPasswordConfirmation || undefined,
                    })
                }

                handleClose()
                onSaved()
            } catch (error) {
                clearAndAddHttpError(error as Error)
            }
        },
    })

    const handleClose = () => {
        clearFlashes()
        form.resetForm()
        onClose()
    }

    const statusOptions: { value: ResellerStatus; label: string }[] = [
        { value: 'active', label: 'Active' },
        { value: 'pending', label: 'Pending' },
        ...(reseller?.isDefault
            ? []
            : [{ value: 'suspended' as ResellerStatus, label: 'Suspended' }]),
    ]

    return (
        <Modal open={open} onClose={handleClose} size='2xl'>
            <Modal.Header>
                <Modal.Title>
                    {mode === 'create' ? 'Create Reseller' : 'Edit Reseller'}
                </Modal.Title>
            </Modal.Header>
            <FormikProvider value={form}>
                <form onSubmit={form.handleSubmit}>
                    <Modal.Body>
                        <FlashMessageRender
                            className='mb-5'
                            byKey={'admin:resellers.upsert'}
                        />
                        <div className='grid grid-cols-1 gap-4 sm:grid-cols-2'>
                            <TextInputFormik
                                name='displayName'
                                label='Display Name'
                            />
                            {canManageSystemFields ? (
                                <SelectFormik
                                    name='status'
                                    label='Status'
                                    data={statusOptions}
                                />
                            ) : null}
                            <TextInputFormik name='domain' label='Panel Domain' />
                            <TextInputFormik name='logoUrl' label='Logo URL' />
                            <TextInputFormik
                                name='backendDomain'
                                label='Backend Domain'
                            />
                            <TextInputFormik
                                name='liveDataDomain'
                                label='Live Data Domain'
                            />
                            <TextInputFormik
                                name='novncDomain'
                                label='noVNC Domain'
                            />
                            <TextInputFormik name='cdnDomain' label='CDN Domain' />
                            {canManageSystemFields && mode === 'edit' ? (
                                <>
                                    <TextInputFormik
                                        name='adminEmail'
                                        label='Reseller Admin Email'
                                    />
                                    <TextInputFormik
                                        name='adminPassword'
                                        label='Reseller Admin Password'
                                        type='password'
                                    />
                                    <TextInputFormik
                                        name='adminPasswordConfirmation'
                                        label='Confirm Password'
                                        type='password'
                                    />
                                </>
                            ) : null}
                        </div>
                    </Modal.Body>
                    <Modal.Actions>
                        <Modal.Action type='button' onClick={handleClose}>
                            Cancel
                        </Modal.Action>
                        <Modal.Action type='submit' loading={form.isSubmitting}>
                            {mode === 'create' ? 'Create' : 'Save'}
                        </Modal.Action>
                    </Modal.Actions>
                </form>
            </FormikProvider>
        </Modal>
    )
}

export default ResellerUpsertModal
