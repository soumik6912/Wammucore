import createResellerOnboarding from '@/api/admin/resellers/createResellerOnboarding'
import getResellerOnboardingMeta from '@/api/admin/resellers/getResellerOnboardingMeta'
import Button from '@/components/elements/Button'
import PageContentBlock from '@/components/elements/PageContentBlock'
import TextInput from '@/components/elements/inputs/TextInput'
import { NavigationBarContext } from '@/components/elements/navigation/NavigationBar'
import { useContext, useEffect, useMemo, useState } from 'react'
import { Link, useLocation } from 'react-router-dom'

type Step = 'account' | 'interface' | 'done'

const normalizeDomain = (value: string): string => {
    const trimmed = value.trim().toLowerCase()
    const withoutProtocol = trimmed.replace(/^https?:\/\//, '')

    return withoutProtocol.replace(/^\/+|\/+$/g, '')
}

const ResellerCreateInterfaceContainer = () => {
    const { setRoutes, setBreadcrumb } = useContext(NavigationBarContext)
    const location = useLocation()
    const [step, setStep] = useState<Step>('account')
    const [adminEmail, setAdminEmail] = useState('')
    const [adminName, setAdminName] = useState('')
    const [adminPassword, setAdminPassword] = useState('')
    const [adminPasswordConfirmation, setAdminPasswordConfirmation] = useState('')
    const [displayName, setDisplayName] = useState('')
    const [logoUrl, setLogoUrl] = useState('')
    const [domain, setDomain] = useState('')
    const [maxRamMb, setMaxRamMb] = useState('4096')
    const [maxCpuCores, setMaxCpuCores] = useState('4')
    const [maxDiskGb, setMaxDiskGb] = useState('40')
    const [maxVms, setMaxVms] = useState('20')
    const [autoActivateIfDnsPasses, setAutoActivateIfDnsPasses] = useState(false)
    const [edgeGatewayHost, setEdgeGatewayHost] = useState('edge.wammuhost.com')
    const [verificationPrefix, setVerificationPrefix] = useState('_wammuhost-verify')
    const [defaultApiKey, setDefaultApiKey] = useState<string | null>(null)
    const [defaultApiKeyPrefix, setDefaultApiKeyPrefix] = useState<string | null>(null)
    const [domainSummary, setDomainSummary] = useState<ReturnType<typeof createDomainSummary> | null>(null)
    const [message, setMessage] = useState<string | null>(null)
    const [error, setError] = useState<string | null>(null)
    const [isLoadingMeta, setIsLoadingMeta] = useState(true)
    const [isCreating, setIsCreating] = useState(false)

    useEffect(() => {
        const currentPath =
            location.pathname === '/reseller/create'
                ? '/reseller/create'
                : '/admin/reseller/create'

        setRoutes([
            { name: 'Resellers', path: '/admin/resellers' },
            { name: 'Create reseller interface', path: currentPath },
        ])
        setBreadcrumb('Create reseller interface')

        return () => {
            setRoutes([])
            setBreadcrumb(null)
        }
    }, [setRoutes, setBreadcrumb, location.pathname])

    useEffect(() => {
        getResellerOnboardingMeta()
            .then(meta => {
                setEdgeGatewayHost(meta.edgeGatewayHost)
                setVerificationPrefix(meta.verificationPrefix)
            })
            .catch(() => {
                setEdgeGatewayHost('edge.wammuhost.com')
                setVerificationPrefix('_wammuhost-verify')
            })
            .finally(() => setIsLoadingMeta(false))
    }, [])

    const normalizedDomain = useMemo(() => normalizeDomain(domain), [domain])

    const goToInterfaceStep = () => {
        setError(null)
        setMessage(null)

        if (!adminEmail.trim() || !adminPassword.trim()) {
            setError('Admin email and password are required.')
            return
        }

        if (adminPassword !== adminPasswordConfirmation) {
            setError('Admin password confirmation does not match.')
            return
        }

        if (!displayName.trim()) {
            setDisplayName(
                adminEmail.includes('@') ? adminEmail.split('@')[0] : 'New Reseller'
            )
        }

        setStep('interface')
    }

    const createInterface = async () => {
        setError(null)
        setMessage(null)
        setDefaultApiKey(null)
        setDefaultApiKeyPrefix(null)
        setDomainSummary(null)

        if (!displayName.trim() || !normalizedDomain) {
            setError('Display name and reseller panel hostname are required.')
            return
        }

        setIsCreating(true)
        try {
            const result = await createResellerOnboarding({
                displayName: displayName.trim(),
                logoUrl: logoUrl.trim(),
                domain: normalizedDomain,
                panelDomain: normalizedDomain,
                maxRamMb: Number(maxRamMb) || undefined,
                maxCpuCores: Number(maxCpuCores) || undefined,
                maxDiskGb: Number(maxDiskGb) || undefined,
                maxVms: Number(maxVms) || undefined,
                autoActivateIfDnsPasses,
                adminEmail: adminEmail.trim(),
                adminName: adminName.trim(),
                adminPassword,
                adminPasswordConfirmation,
            })

            setMessage(result.message)
            setDefaultApiKey(result.defaultApiKey)
            setDefaultApiKeyPrefix(result.defaultApiKeyPrefix)
            setDomainSummary({
                hostname: result.customDomain.hostname,
                cnameTarget: result.customDomain.cnameTarget,
                verificationHost: result.customDomain.verificationHost,
                verificationValue: result.customDomain.verificationValue,
                probeHostname: result.customDomain.probeHostname,
                dnsStatus: result.customDomain.dnsStatus,
                sslStatus: result.customDomain.sslStatus,
                routingStatus: result.customDomain.routingStatus,
                passed: result.dnsVerification.passed,
                errors: result.dnsVerification.errors,
                cloudflareDetected: result.dnsVerification.cloudflareDetected,
            })
            setStep('done')
        } catch (err: any) {
            setError(err?.response?.data?.message || 'Failed to create reseller interface.')
        } finally {
            setIsCreating(false)
        }
    }

    return (
        <PageContentBlock title='Create reseller interface'>
            <div className='space-y-5'>
                {error ? (
                    <div className='rounded-md border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-200'>
                        {error}
                    </div>
                ) : null}
                {message ? (
                    <div className='rounded-md border border-emerald-500/30 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-200'>
                        {message}
                    </div>
                ) : null}

                {step === 'account' ? (
                    <div className='rounded-xl border border-white/10 bg-[#1a2740] p-5'>
                        <h2 className='text-xl font-semibold text-white'>
                            Register reseller admin
                        </h2>
                        <p className='mt-1 text-sm text-white/70'>
                            Create the reseller owner account first, then we will configure the white-label hostname.
                        </p>
                        <div className='mt-5 grid gap-4 md:grid-cols-2'>
                            <TextInput
                                label='Admin email'
                                placeholder='admin@example.com'
                                value={adminEmail}
                                onChange={e => setAdminEmail(e.currentTarget.value)}
                            />
                            <TextInput
                                label='Admin name (optional)'
                                placeholder='John Admin'
                                value={adminName}
                                onChange={e => setAdminName(e.currentTarget.value)}
                            />
                            <TextInput
                                label='Admin password'
                                type='password'
                                placeholder='Strong password'
                                value={adminPassword}
                                onChange={e => setAdminPassword(e.currentTarget.value)}
                            />
                            <TextInput
                                label='Confirm password'
                                type='password'
                                placeholder='Confirm password'
                                value={adminPasswordConfirmation}
                                onChange={e =>
                                    setAdminPasswordConfirmation(e.currentTarget.value)
                                }
                            />
                        </div>
                        <div className='mt-5 flex justify-end'>
                            <Button variant='filled' onClick={goToInterfaceStep}>
                                Continue
                            </Button>
                        </div>
                    </div>
                ) : null}

                {step === 'interface' || step === 'done' ? (
                    <div className='rounded-xl border border-white/10 bg-[#1a2740] p-5'>
                        <div className='mb-4 rounded-md border border-blue-300/30 bg-[#d7dfeb] px-4 py-3 text-sm text-blue-700'>
                            Reseller hostnames must use a CNAME to the shared edge gateway. Never publish an A record to infrastructure IPs.
                        </div>

                        <h3 className='text-2xl font-semibold text-white'>
                            White-label panel hostname
                        </h3>
                        <p className='mt-1 text-sm text-white/70'>
                            We will issue ownership instructions for the reseller and activate routing only after verification succeeds.
                        </p>

                        <div className='mt-5 space-y-5'>
                            <div className='grid gap-4 md:grid-cols-2'>
                                <TextInput
                                    label='Logo URL'
                                    placeholder='https://example.com/logo.png'
                                    value={logoUrl}
                                    onChange={e => setLogoUrl(e.currentTarget.value)}
                                    disabled={step === 'done'}
                                />
                                <TextInput
                                    label='Display name'
                                    placeholder='Your Hosting Name'
                                    value={displayName}
                                    onChange={e => setDisplayName(e.currentTarget.value)}
                                    disabled={step === 'done'}
                                />
                            </div>

                            <TextInput
                                label='Panel hostname'
                                placeholder='vps.clienthost.com'
                                value={domain}
                                onChange={e => setDomain(e.currentTarget.value)}
                                disabled={step === 'done'}
                            />

                            <label className='inline-flex items-center gap-2 text-sm text-white/80'>
                                <input
                                    type='checkbox'
                                    checked={autoActivateIfDnsPasses}
                                    onChange={e => setAutoActivateIfDnsPasses(e.currentTarget.checked)}
                                    disabled={step === 'done'}
                                />
                                Auto activate reseller once DNS verification succeeds
                            </label>

                            <div className='rounded-lg border border-white/10 bg-[#111a31] p-4 text-sm text-white/80'>
                                <p>
                                    Hostname: <span className='text-white'>{normalizedDomain || '-'}</span>
                                </p>
                                <p className='mt-1'>
                                    CNAME target:{' '}
                                    <span className='text-white'>
                                        {isLoadingMeta ? 'Loading...' : edgeGatewayHost}
                                    </span>
                                </p>
                                <p className='mt-1'>
                                    TXT verification prefix:{' '}
                                    <span className='text-white'>{verificationPrefix}</span>
                                </p>
                                <p className='mt-2 text-xs text-white/55'>
                                    Cloudflare proxy is supported. The reseller still needs the matching TXT ownership record before routing is activated.
                                </p>
                            </div>

                            {step === 'done' && defaultApiKey ? (
                                <div className='rounded-lg border border-amber-400/30 bg-amber-500/10 px-4 py-3 text-sm text-amber-100'>
                                    <p className='font-semibold'>Default reseller API key (shown once)</p>
                                    <p className='mt-1 break-all font-mono text-xs'>{defaultApiKey}</p>
                                    <p className='mt-1 text-xs text-amber-200/90'>
                                        Key prefix: {defaultApiKeyPrefix || '-'}
                                    </p>
                                </div>
                            ) : null}

                            {step === 'done' && domainSummary ? (
                                <div className='rounded-lg border border-white/10 bg-[#111a31] px-4 py-3 text-sm text-white/85'>
                                    <p className='font-semibold text-white'>
                                        DNS & activation summary
                                    </p>
                                    <div className='mt-3 space-y-1 text-xs'>
                                        <p>Hostname: {domainSummary.hostname}</p>
                                        <p>CNAME: {domainSummary.hostname} {'->'} {domainSummary.cnameTarget}</p>
                                        <p>TXT: {domainSummary.verificationHost}</p>
                                        <p className='break-all'>{domainSummary.verificationValue || '-'}</p>
                                        <p>Probe hostname: {domainSummary.probeHostname}</p>
                                        <p>DNS status: {domainSummary.dnsStatus}</p>
                                        <p>SSL status: {domainSummary.sslStatus}</p>
                                        <p>Routing status: {domainSummary.routingStatus}</p>
                                        <p>Cloudflare detected: {domainSummary.cloudflareDetected ? 'Yes' : 'No'}</p>
                                    </div>
                                    {domainSummary.errors.length > 0 ? (
                                        <div className='mt-3 rounded border border-rose-400/20 bg-rose-500/10 p-3 text-rose-100'>
                                            {domainSummary.errors.map(errorLine => (
                                                <p key={errorLine}>{errorLine}</p>
                                            ))}
                                        </div>
                                    ) : null}
                                </div>
                            ) : null}
                        </div>

                        {step === 'interface' ? (
                            <div className='mt-6 flex items-center justify-between'>
                                <Button onClick={() => setStep('account')} disabled={isCreating}>
                                    Back
                                </Button>
                                <Button variant='filled' onClick={createInterface} loading={isCreating}>
                                    Create
                                </Button>
                            </div>
                        ) : null}

                        {step === 'done' ? (
                            <div className='mt-6 flex justify-end'>
                                <Link
                                    to='/admin/resellers'
                                    className='rounded-md bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-500'
                                >
                                    Back to resellers
                                </Link>
                            </div>
                        ) : null}
                    </div>
                ) : null}
            </div>
        </PageContentBlock>
    )
}

const createDomainSummary = () => ({
    hostname: '',
    cnameTarget: '',
    verificationHost: '',
    verificationValue: null as string | null,
    probeHostname: '',
    dnsStatus: 'pending',
    sslStatus: 'pending',
    routingStatus: 'pending',
    passed: false,
    errors: [] as string[],
    cloudflareDetected: false,
})

export default ResellerCreateInterfaceContainer
