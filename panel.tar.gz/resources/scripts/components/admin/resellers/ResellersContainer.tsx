import approveReseller from '@/api/admin/resellers/approveReseller'
import approveResellerVerification from '@/api/admin/resellers/approveResellerVerification'
import getResellerVerification from '@/api/admin/resellers/getResellerVerification'
import getResellerImpersonationLink from '@/api/admin/resellers/getResellerImpersonationLink'
import manualOverrideResellerOnboarding from '@/api/admin/resellers/manualOverrideResellerOnboarding'
import revealResellerAadhaar from '@/api/admin/resellers/revealResellerAadhaar'
import requestResellerReverification from '@/api/admin/resellers/requestResellerReverification'
import rejectResellerVerification from '@/api/admin/resellers/rejectResellerVerification'
import suspendResellerOnboarding from '@/api/admin/resellers/suspendResellerOnboarding'
import suspendReseller from '@/api/admin/resellers/suspendReseller'
import updateResellerOwnerProfile from '@/api/admin/resellers/updateResellerOwnerProfile'
import setTenantContext from '@/api/admin/tenancy/setTenantContext'
import useTenantContextSWR from '@/api/admin/tenancy/useTenantContextSWR'
import {
    Reseller,
    ResellerStatus,
    ResellerVerificationStatus,
} from '@/api/admin/resellers/getResellers'
import useResellersSWR from '@/api/admin/resellers/useResellersSWR'
import SearchBar from '@/components/admin/SearchBar'
import DeleteResellerModal from '@/components/admin/resellers/DeleteResellerModal'
import ResellerUpsertModal from '@/components/admin/resellers/ResellerUpsertModal'
import Button from '@/components/elements/Button'
import Menu from '@/components/elements/Menu'
import Modal from '@/components/elements/Modal'
import PageContentBlock from '@/components/elements/PageContentBlock'
import Pagination from '@/components/elements/Pagination'
import Spinner from '@/components/elements/Spinner'
import Table, {
    Actions,
    ColumnArray,
    RowActionsProps,
} from '@/components/elements/displays/Table'
import { useStoreState } from '@/state'
import { useFlashKey } from '@/util/useFlash'
import usePagination from '@/util/usePagination'
import { useDebouncedValue } from '@mantine/hooks'
import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import type { ResellerVerificationDetails } from '@/api/admin/resellers/getResellerVerification'

const isImageDocument = (mime: string | null): boolean =>
    typeof mime === 'string' && mime.startsWith('image/')

interface RevealedAadhaarState {
    resellerId: number
    value: string
    secondsLeft: number
}

interface OwnerProfileFormState {
    firstName: string
    lastName: string
    contactEmail: string
    phoneNumber: string
    addressLine1: string
    addressLine2: string
    city: string
    stateName: string
    postalCode: string
    countryName: string
}

const emptyOwnerProfileForm = (): OwnerProfileFormState => ({
    firstName: '',
    lastName: '',
    contactEmail: '',
    phoneNumber: '',
    addressLine1: '',
    addressLine2: '',
    city: '',
    stateName: '',
    postalCode: '',
    countryName: '',
})

const safeInputValue = (event: { target: EventTarget | null; currentTarget?: EventTarget | null }): string => {
    const input =
        event.currentTarget instanceof HTMLInputElement
            ? event.currentTarget
            : event.target instanceof HTMLInputElement
              ? event.target
              : null

    return input?.value ?? ''
}

const formatDateTimeLabel = (value: string | null): string | null => {
    if (!value) {
        return null
    }

    const parsed = new Date(value)

    if (Number.isNaN(parsed.getTime())) {
        return null
    }

    return new Intl.DateTimeFormat('en-IN', {
        dateStyle: 'medium',
        timeStyle: 'short',
    }).format(parsed)
}

const formatStepLabel = (value: string | null): string => {
    if (!value) {
        return 'Pending'
    }

    return value
        .split('_')
        .filter(Boolean)
        .map(part => part.charAt(0).toUpperCase() + part.slice(1))
        .join(' ')
}

const getStatusClasses = (status: ResellerStatus): string => {
    switch (status) {
        case 'active':
            return 'bg-green-500/20 text-green-300 border border-green-400/40'
        case 'suspended':
            return 'bg-red-500/20 text-red-300 border border-red-400/40'
        default:
            return 'bg-amber-500/20 text-amber-300 border border-amber-400/40'
    }
}

const getVerificationClasses = (
    status: ResellerVerificationStatus
): string => {
    switch (status) {
        case 'approved':
            return 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40'
        case 'under_review':
            return 'bg-sky-500/20 text-sky-200 border border-sky-400/40'
        case 'rejected':
            return 'bg-rose-500/20 text-rose-300 border border-rose-400/40'
        case 'suspended':
            return 'bg-red-500/20 text-red-200 border border-red-400/40'
        default:
            return 'bg-amber-500/20 text-amber-300 border border-amber-400/40'
    }
}

const makeColumns = (
    onEdit: (reseller: Reseller) => void
): ColumnArray<Reseller> => [
    {
        accessor: 'displayName',
        header: 'Reseller',
        cell: ({ value, row }) => (
            <div className='flex items-center gap-2'>
                <button
                    type='button'
                    onClick={() => onEdit(row)}
                    className='max-w-[180px] truncate whitespace-nowrap rounded-md border border-cyan-300/20 bg-cyan-400/10 px-2 py-1 font-semibold text-cyan-200 transition hover:border-cyan-200/45 hover:bg-cyan-300/15 hover:text-cyan-100 focus:outline-none focus:ring-2 focus:ring-cyan-300/45'
                    title='Edit reseller email, password, domain, and status'
                >
                    {value}
                </button>
                {row.isDefault ? (
                    <span className='whitespace-nowrap rounded-full border border-indigo-400/40 bg-indigo-500/20 px-2 py-0.5 text-xs text-indigo-200'>
                        Default
                    </span>
                ) : null}
                {row.isRegistrationDraft ? (
                    <span className='whitespace-nowrap rounded-full border border-amber-300/40 bg-amber-400/15 px-2 py-0.5 text-xs text-amber-100'>
                        Draft
                    </span>
                ) : null}
            </div>
        ),
    },
    {
        accessor: 'status',
        header: 'Status',
        align: 'center',
        cell: ({ value }) => (
            <span
                className={`inline-flex rounded-full px-2 py-1 text-xs uppercase tracking-wide ${getStatusClasses(
                    value
                )} whitespace-nowrap`}
            >
                {value}
            </span>
        ),
    },
    {
        accessor: 'verificationStatus',
        header: 'KYC',
        align: 'center',
        cell: ({ value, row }) => (
            <div className='text-center'>
                <span
                className={`inline-flex rounded-full px-2 py-1 text-xs uppercase tracking-wide ${getVerificationClasses(
                    value
                )} whitespace-nowrap`}
            >
                {value}
            </span>
                {row.verification.submittedAt &&
                (value === 'pending' || value === 'under_review') ? (
                    <p className='mt-1 text-[10px] text-white/55'>
                        Submitted
                    </p>
                ) : null}
                {value === 'rejected' && row.verification.rejectionReason ? (
                    <p className='mt-1 max-w-[140px] truncate text-[10px] text-rose-200/80'>
                        {row.verification.rejectionReason}
                    </p>
                ) : null}
            </div>
        ),
    },
    {
        accessor: 'onboardingStatus',
        header: 'Onboarding',
        align: 'center',
        cell: ({ row }) => (
            <div className='text-center'>
                <span
                className={`inline-flex rounded-full px-2 py-1 text-xs uppercase tracking-wide ${getStatusClasses(
                    row.onboardingStatus === 'completed'
                        ? 'active'
                        : row.onboardingStatus === 'suspended' ||
                              row.onboardingStatus === 'rejected'
                            ? 'suspended'
                        : 'pending'
                    )} whitespace-nowrap`}
            >
                {row.onboardingStatus}
            </span>
                {row.onboardingStatus !== 'completed' && row.onboardingCurrentStep ? (
                    <p className='mt-1 max-w-[140px] truncate text-[10px] text-white/55'>
                        {formatStepLabel(row.onboardingCurrentStep)}
                    </p>
                ) : null}
                {row.isRegistrationDraft ? (
                    <p className='mt-1 max-w-[150px] truncate text-[10px] text-amber-100/75'>
                        Incomplete registration
                    </p>
                ) : null}
            </div>
        ),
    },
    {
        accessor: 'domain',
        header: 'Domain',
        cell: ({ value }) => value || '-',
    },
    {
        accessor: 'usersCount',
        header: 'Customers',
        align: 'center',
    },
    {
        accessor: 'serversCount',
        header: 'Servers',
        align: 'center',
    },
]

const ResellersContainer = () => {
    const navigate = useNavigate()
    const user = useStoreState(state => state.user.data)
    const isRootAdmin = Boolean(user?.rootAdmin)
    const { clearFlashes, clearAndAddHttpError } = useFlashKey('admin:resellers')
    const [page, setPage] = usePagination()
    const [query, setQuery] = useState('')
    const [debouncedQuery] = useDebouncedValue(query, 200)
    const [editing, setEditing] = useState<Reseller | null>(null)
    const [deleting, setDeleting] = useState<Reseller | null>(null)
    const [isSwitching, setIsSwitching] = useState(false)
    const [activeActionResellerId, setActiveActionResellerId] = useState<number | null>(null)
    const [verificationViewer, setVerificationViewer] =
        useState<ResellerVerificationDetails | null>(null)
    const [revealedAadhaar, setRevealedAadhaar] =
        useState<RevealedAadhaarState | null>(null)
    const [revealingAadhaarResellerId, setRevealingAadhaarResellerId] =
        useState<number | null>(null)
    const [editingOwnerProfile, setEditingOwnerProfile] = useState(false)
    const [ownerProfileForm, setOwnerProfileForm] =
        useState<OwnerProfileFormState>(emptyOwnerProfileForm)
    const [savingOwnerProfileResellerId, setSavingOwnerProfileResellerId] =
        useState<number | null>(null)
    const columns = useMemo(() => makeColumns(setEditing), [])

    const { data, mutate } = useResellersSWR({
        page,
        query: debouncedQuery,
    })
    const { data: tenantContext, mutate: mutateTenantContext } =
        useTenantContextSWR()
    const editableReseller = useMemo(() => {
        if (isRootAdmin || !data?.items?.length) {
            return null
        }

        const actorResellerId = user?.resellerId
        if (!actorResellerId) {
            return data.items[0] ?? null
        }

        return (
            data.items.find(reseller => reseller.id === actorResellerId) ??
            data.items[0] ??
            null
        )
    }, [data?.items, isRootAdmin, user?.resellerId])

    const mutateAll = async () => {
        await Promise.all([mutate(), mutateTenantContext()])
    }

    useEffect(() => {
        if (!verificationViewer) {
            setRevealedAadhaar(null)
            setEditingOwnerProfile(false)
            setOwnerProfileForm(emptyOwnerProfileForm())
        }
    }, [verificationViewer])

    useEffect(() => {
        if (!verificationViewer) {
            return
        }

        setOwnerProfileForm({
            firstName: verificationViewer.ownerProfile.firstName || '',
            lastName: verificationViewer.ownerProfile.lastName || '',
            contactEmail: verificationViewer.ownerProfile.contactEmail || '',
            phoneNumber: verificationViewer.ownerProfile.phoneNumber || '',
            addressLine1: verificationViewer.ownerProfile.addressLine1 || '',
            addressLine2: verificationViewer.ownerProfile.addressLine2 || '',
            city: verificationViewer.ownerProfile.city || '',
            stateName: verificationViewer.ownerProfile.stateName || '',
            postalCode: verificationViewer.ownerProfile.postalCode || '',
            countryName: verificationViewer.ownerProfile.countryName || '',
        })
    }, [verificationViewer])

    useEffect(() => {
        if (!revealedAadhaar) {
            return
        }

        const timer = window.setInterval(() => {
            setRevealedAadhaar(current => {
                if (!current || current.resellerId !== revealedAadhaar.resellerId) {
                    return current
                }

                if (current.secondsLeft <= 1) {
                    return null
                }

                return {
                    ...current,
                    secondsLeft: current.secondsLeft - 1,
                }
            })
        }, 1000)

        return () => window.clearInterval(timer)
    }, [revealedAadhaar?.resellerId])

    const switchToAll = async () => {
        if (!isRootAdmin) {
            return
        }

        clearFlashes()
        setIsSwitching(true)
        try {
            await setTenantContext({ mode: 'all' })
            await mutateAll()
        } catch (error) {
            clearAndAddHttpError(error as Error)
        } finally {
            setIsSwitching(false)
        }
    }

    const switchToPlatform = async () => {
        if (!isRootAdmin) {
            return
        }

        clearFlashes()

        setIsSwitching(true)
        try {
            await setTenantContext({ mode: 'platform' })
            await mutateAll()
        } catch (error) {
            clearAndAddHttpError(error as Error)
        } finally {
            setIsSwitching(false)
        }
    }

    const switchToReseller = async (reseller: Reseller) => {
        clearFlashes()
        setIsSwitching(true)
        try {
            const reference = reseller.uuid || reseller.slug || String(reseller.id)

            const nextContext = await setTenantContext({
                mode: 'reseller',
                resellerId: reseller.id,
                resellerRef: reference,
            })
            await mutateTenantContext(nextContext, false)

            const activeReference =
                nextContext.activeReseller?.uuid ||
                nextContext.activeReseller?.slug ||
                reference

            navigate(`/admin/reseller-panel/r/${activeReference}`)
        } catch (error) {
            clearAndAddHttpError(error as Error)
        } finally {
            setIsSwitching(false)
        }
    }

    const isMasterView = tenantContext?.mode !== 'reseller'
    const globalActionsLocked = !isMasterView

    const openImpersonationPanel = async (reseller: Reseller) => {
        clearFlashes()
        setActiveActionResellerId(reseller.id)
        try {
            const link = await getResellerImpersonationLink(reseller.id)
            if (!link.impersonationUrl) {
                throw new Error('Impersonation link was not generated.')
            }

            window.location.assign(link.impersonationUrl)
        } catch (error) {
            clearAndAddHttpError(error as Error)
        } finally {
            setActiveActionResellerId(null)
        }
    }

    const activateReseller = async (reseller: Reseller) => {
        clearFlashes()
        setActiveActionResellerId(reseller.id)
        try {
            await approveReseller(reseller.id)
            await mutate()
        } catch (error) {
            clearAndAddHttpError(error as Error)
        } finally {
            setActiveActionResellerId(null)
        }
    }

    const suspendResellerAccount = async (reseller: Reseller) => {
        clearFlashes()
        setActiveActionResellerId(reseller.id)
        try {
            await suspendReseller(reseller.id)
            await mutate()
        } catch (error) {
            clearAndAddHttpError(error as Error)
        } finally {
            setActiveActionResellerId(null)
        }
    }

    const openVerificationDocuments = async (reseller: Reseller) => {
        clearFlashes()
        setActiveActionResellerId(reseller.id)
        try {
            const details = await getResellerVerification(reseller.id)
            const availableDocuments = details.documents.items.filter(
                document => document.available && document.url
            )
            if (!availableDocuments.length && !details.ownerProfile.submitted) {
                throw new Error('No identity documents were uploaded by this reseller.')
            }
            setVerificationViewer(details)
        } catch (error) {
            clearAndAddHttpError(error as Error)
        } finally {
            setActiveActionResellerId(null)
        }
    }

    const approveVerification = async (reseller: Reseller) => {
        clearFlashes()
        setActiveActionResellerId(reseller.id)
        try {
            await approveResellerVerification(reseller.id)
            await mutate()
        } catch (error) {
            clearAndAddHttpError(error as Error)
        } finally {
            setActiveActionResellerId(null)
        }
    }

    const rejectVerification = async (reseller: Reseller) => {
        const reason = window.prompt(
            `Rejection reason for ${reseller.displayName}:`,
            reseller.verification.rejectionReason || ''
        )
        if (!reason || reason.trim().length < 3) {
            return
        }

        clearFlashes()
        setActiveActionResellerId(reseller.id)
        try {
            await rejectResellerVerification(reseller.id, reason.trim())
            await mutate()
        } catch (error) {
            clearAndAddHttpError(error as Error)
        } finally {
            setActiveActionResellerId(null)
        }
    }

    const requestReverification = async (reseller: Reseller) => {
        const reason = window.prompt(
            `Reason for requesting reverification from ${reseller.displayName}:`,
            reseller.verification.rejectionReason || ''
        )
        if (!reason || reason.trim().length < 3) {
            return
        }

        clearFlashes()
        setActiveActionResellerId(reseller.id)
        try {
            await requestResellerReverification(reseller.id, reason.trim())
            await mutate()
        } catch (error) {
            clearAndAddHttpError(error as Error)
        } finally {
            setActiveActionResellerId(null)
        }
    }

    const approveVerificationFromViewer = async () => {
        if (!verificationViewer) {
            return
        }

        clearFlashes()
        setActiveActionResellerId(verificationViewer.resellerId)
        try {
            await approveResellerVerification(verificationViewer.resellerId)
            setVerificationViewer(null)
            await mutateAll()
        } catch (error) {
            clearAndAddHttpError(error as Error)
        } finally {
            setActiveActionResellerId(null)
        }
    }

    const revealAadhaarForViewer = async () => {
        if (!verificationViewer) {
            return
        }

        clearFlashes()
        setRevealingAadhaarResellerId(verificationViewer.resellerId)
        try {
            const reveal = await revealResellerAadhaar(
                verificationViewer.resellerId
            )
            setRevealedAadhaar({
                resellerId: verificationViewer.resellerId,
                value: reveal.aadhaarFull,
                secondsLeft: reveal.visibleForSeconds,
            })
        } catch (error) {
            clearAndAddHttpError(error as Error)
        } finally {
            setRevealingAadhaarResellerId(null)
        }
    }

    const saveOwnerProfileForViewer = async () => {
        if (!verificationViewer) {
            return
        }

        const requiredFields: Array<[keyof OwnerProfileFormState, string]> = [
            ['firstName', 'First name'],
            ['lastName', 'Last name'],
            ['contactEmail', 'Contact email'],
            ['phoneNumber', 'Phone number'],
            ['addressLine1', 'Address line 1'],
            ['city', 'City'],
            ['stateName', 'State / region'],
            ['postalCode', 'Postal code'],
            ['countryName', 'Country'],
        ]
        const missingField = requiredFields.find(
            ([key]) => ownerProfileForm[key].trim() === ''
        )

        if (missingField) {
            clearAndAddHttpError(
                new Error(`${missingField[1]} is required before saving.`)
            )
            return
        }

        clearFlashes()
        setSavingOwnerProfileResellerId(verificationViewer.resellerId)
        try {
            await updateResellerOwnerProfile(
                verificationViewer.resellerId,
                ownerProfileForm
            )
            const refreshed = await getResellerVerification(
                verificationViewer.resellerId
            )
            setVerificationViewer(refreshed)
            setEditingOwnerProfile(false)
            await mutateAll()
        } catch (error) {
            clearAndAddHttpError(error as Error)
        } finally {
            setSavingOwnerProfileResellerId(null)
        }
    }

    const suspendOnboardingFlow = async (reseller: Reseller) => {
        const reason = window.prompt(
            `Suspend onboarding for ${reseller.displayName}. Reason:`,
            reseller.verification.rejectionReason || ''
        )
        if (!reason || reason.trim().length < 3) {
            return
        }

        clearFlashes()
        setActiveActionResellerId(reseller.id)
        try {
            await suspendResellerOnboarding(reseller.id, reason.trim())
            await mutate()
        } catch (error) {
            clearAndAddHttpError(error as Error)
        } finally {
            setActiveActionResellerId(null)
        }
    }

    const manualOverride = async (reseller: Reseller) => {
        const note = window.prompt(
            `Manual onboarding override note for ${reseller.displayName}:`,
            'Root admin manual approval'
        )
        if (!note || note.trim().length < 3) {
            return
        }

        clearFlashes()
        setActiveActionResellerId(reseller.id)
        try {
            await manualOverrideResellerOnboarding(reseller.id, note.trim(), {
                completeAll: true,
            })
            await mutate()
        } catch (error) {
            clearAndAddHttpError(error as Error)
        } finally {
            setActiveActionResellerId(null)
        }
    }

    const rowActions = ({ row }: RowActionsProps<Reseller>) => {
        const isViewedReseller =
            tenantContext?.mode === 'reseller' &&
            tenantContext.activeReseller?.id === row.id

        return (
            <Actions>
                {isRootAdmin ? (
                    <>
                        <Menu.Item
                            disabled={
                                globalActionsLocked ||
                                activeActionResellerId === row.id
                            }
                            onClick={() => openImpersonationPanel(row)}
                        >
                            View As Reseller
                        </Menu.Item>
                        <Menu.Item
                            disabled={isSwitching || isViewedReseller}
                            onClick={() => switchToReseller(row)}
                        >
                            {isViewedReseller
                                ? 'Currently Viewing'
                                : 'Switch Scope Only'}
                        </Menu.Item>
                        <Menu.Item
                            disabled={
                                globalActionsLocked ||
                                activeActionResellerId === row.id
                            }
                            onClick={() => openVerificationDocuments(row)}
                        >
                            View KYC Documents
                        </Menu.Item>
                        {row.verificationStatus !== 'approved' ? (
                            <Menu.Item
                                disabled={
                                    globalActionsLocked ||
                                    activeActionResellerId === row.id
                                }
                                onClick={() => approveVerification(row)}
                            >
                                Approve Verification
                            </Menu.Item>
                        ) : null}
                        {row.verificationStatus !== 'rejected' && !row.isDefault ? (
                            <Menu.Item
                                color='yellow'
                                disabled={
                                    globalActionsLocked ||
                                    activeActionResellerId === row.id
                                }
                                onClick={() => rejectVerification(row)}
                            >
                                Reject Verification
                            </Menu.Item>
                        ) : null}
                        <Menu.Item
                            disabled={
                                globalActionsLocked ||
                                activeActionResellerId === row.id
                            }
                            onClick={() => requestReverification(row)}
                        >
                            Request Reverification
                        </Menu.Item>
                        <Menu.Item
                            color='yellow'
                            disabled={
                                globalActionsLocked ||
                                activeActionResellerId === row.id
                            }
                            onClick={() => suspendOnboardingFlow(row)}
                        >
                            Suspend Onboarding
                        </Menu.Item>
                        <Menu.Item
                            disabled={
                                globalActionsLocked ||
                                activeActionResellerId === row.id
                            }
                            onClick={() => manualOverride(row)}
                        >
                            Manual Override
                        </Menu.Item>
                        {row.status !== 'active' ? (
                            <Menu.Item
                                disabled={
                                    globalActionsLocked ||
                                    activeActionResellerId === row.id
                                }
                                onClick={() => activateReseller(row)}
                            >
                                Approve / Activate
                            </Menu.Item>
                        ) : (
                            <Menu.Item
                                color='yellow'
                                disabled={
                                    globalActionsLocked ||
                                    activeActionResellerId === row.id ||
                                    row.isDefault
                                }
                                onClick={() => suspendResellerAccount(row)}
                            >
                                Suspend
                            </Menu.Item>
                        )}
                        <Menu.Item
                            disabled={globalActionsLocked}
                            onClick={() => setEditing(row)}
                        >
                            Edit
                        </Menu.Item>
                        <Menu.Divider />
                        <Menu.Item
                            color='red'
                            disabled={globalActionsLocked}
                            onClick={() => setDeleting(row)}
                        >
                            {row.isRegistrationDraft ? 'Clean Draft' : 'Delete'}
                        </Menu.Item>
                    </>
                ) : (
                    <Menu.Item onClick={() => setEditing(row)}>
                        Edit My Reseller
                    </Menu.Item>
                )}
            </Actions>
        )
    }

    const viewSummary = useMemo(() => {
        if (!tenantContext) {
            return 'Loading admin view context...'
        }

        if (tenantContext.mode === 'all') {
            return `Viewing ALL resellers. Users: ${tenantContext.global.users}, Servers: ${tenantContext.global.servers}, Nodes: ${tenantContext.global.nodes}, Resellers: ${tenantContext.global.resellers}`
        }

        if (tenantContext.mode === 'platform') {
            return `Viewing MAIN platform data. Users: ${tenantContext.scoped.users}, Servers: ${tenantContext.scoped.servers}, Nodes: ${tenantContext.scoped.nodes}`
        }

        const resellerName =
            tenantContext.activeReseller?.displayName ?? 'Unknown Reseller'

        return `Viewing reseller: ${resellerName}. Users: ${tenantContext.scoped.users}, Servers: ${tenantContext.scoped.servers}, Nodes: ${tenantContext.scoped.nodes}`
    }, [tenantContext])

    const isViewingReseller = tenantContext?.mode === 'reseller'
    const canReturnToPlatform = isViewingReseller
    const canShowAllResellers = tenantContext?.mode === 'platform'
    const verificationDocuments =
        verificationViewer?.documents.items.filter(
            document => document.available && document.url
        ) ?? []
    const isAadhaarRevealed =
        !!verificationViewer &&
        !!revealedAadhaar &&
        revealedAadhaar.resellerId === verificationViewer.resellerId

    return (
        <div className='min-h-screen bg-[#05020f]'>
            <Modal
                open={Boolean(verificationViewer)}
                onClose={() => setVerificationViewer(null)}
                size='2xl'
            >
                <Modal.Header>
                    <Modal.Title>
                        Verification Review
                        {verificationViewer ? ` - ${verificationViewer.displayName}` : ''}
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className='space-y-4'>
                        <div>
                            <p className='text-xs uppercase tracking-[0.2em] text-white/45'>
                                Personal Information
                            </p>
                        </div>
                        <div className='rounded-2xl border border-white/10 bg-[#0b1220]/85 p-4 shadow-[0_18px_50px_rgba(8,12,30,0.38)]'>
                            <div className='flex flex-col gap-3 md:flex-row md:items-start md:justify-between'>
                                <div>
                                    <p className='text-base font-semibold text-white'>
                                        Reseller Owner Details
                                    </p>
                                </div>
                                <div className='flex items-center gap-2'>
                                    <span className='rounded-full border border-emerald-400/30 bg-emerald-500/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.16em] text-emerald-100'>
                                        {verificationViewer?.ownerProfile.submitted
                                            ? 'Submitted'
                                            : 'Missing'}
                                    </span>
                                    {verificationViewer?.ownerProfile.locked ? (
                                        <span className='rounded-full border border-sky-400/30 bg-sky-500/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.16em] text-sky-100'>
                                            Locked
                                        </span>
                                    ) : null}
                                    <Button
                                        type='button'
                                        variant='outline'
                                        color='accent'
                                        onClick={() =>
                                            setEditingOwnerProfile(
                                                current => !current
                                            )
                                        }
                                    >
                                        {editingOwnerProfile
                                            ? 'Cancel Edit'
                                            : verificationViewer?.ownerProfile
                                                  .submitted
                                            ? 'Edit Details'
                                            : 'Add Details'}
                                    </Button>
                                </div>
                            </div>
                            {editingOwnerProfile ? (
                                <div className='mt-4 space-y-3'>
                                    <div className='grid gap-3 md:grid-cols-2'>
                                        {[
                                            ['firstName', 'First name'],
                                            ['lastName', 'Last name'],
                                            ['contactEmail', 'Contact email'],
                                            ['phoneNumber', 'Phone number'],
                                            ['addressLine1', 'Address line 1'],
                                            ['addressLine2', 'Address line 2 (optional)'],
                                            ['city', 'City'],
                                            ['stateName', 'State / region'],
                                            ['postalCode', 'Postal code'],
                                            ['countryName', 'Country'],
                                        ].map(([key, label]) => (
                                            <input
                                                key={key}
                                                type='text'
                                                value={
                                                    ownerProfileForm[
                                                        key as keyof OwnerProfileFormState
                                                    ]
                                                }
                                                onChange={event =>
                                                    setOwnerProfileForm(
                                                        current => ({
                                                            ...current,
                                                            [key]: safeInputValue(
                                                                event
                                                            ),
                                                        })
                                                    )
                                                }
                                                placeholder={label}
                                                className='h-11 rounded-lg border border-white/10 bg-[#050816] px-3 text-sm text-white'
                                            />
                                        ))}
                                    </div>
                                    <div className='flex justify-end'>
                                        <Button
                                            type='button'
                                            loading={
                                                savingOwnerProfileResellerId ===
                                                verificationViewer?.resellerId
                                            }
                                            onClick={saveOwnerProfileForViewer}
                                        >
                                            Save Personal Details
                                        </Button>
                                    </div>
                                </div>
                            ) : verificationViewer?.ownerProfile.submitted ? (
                                <div className='mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3'>
                                    <div className='rounded-xl border border-white/10 bg-[#050816] p-4'>
                                        <p className='text-[11px] uppercase tracking-[0.16em] text-white/45'>
                                            Full Name
                                        </p>
                                        <p className='mt-2 text-sm font-medium text-white/85'>
                                            {verificationViewer.ownerProfile.firstName}{' '}
                                            {verificationViewer.ownerProfile.lastName}
                                        </p>
                                    </div>
                                    <div className='rounded-xl border border-white/10 bg-[#050816] p-4'>
                                        <p className='text-[11px] uppercase tracking-[0.16em] text-white/45'>
                                            Contact Email
                                        </p>
                                        <p className='mt-2 break-all text-sm font-medium text-white/85'>
                                            {verificationViewer.ownerProfile.contactEmail}
                                        </p>
                                    </div>
                                    <div className='rounded-xl border border-white/10 bg-[#050816] p-4'>
                                        <p className='text-[11px] uppercase tracking-[0.16em] text-white/45'>
                                            Phone Number
                                        </p>
                                        <p className='mt-2 text-sm font-medium text-white/85'>
                                            {verificationViewer.ownerProfile.phoneNumber}
                                        </p>
                                    </div>
                                    <div className='rounded-xl border border-white/10 bg-[#050816] p-4 xl:col-span-2'>
                                        <p className='text-[11px] uppercase tracking-[0.16em] text-white/45'>
                                            Address Line 1
                                        </p>
                                        <p className='mt-2 text-sm font-medium text-white/85'>
                                            {verificationViewer.ownerProfile.addressLine1}
                                        </p>
                                    </div>
                                    {verificationViewer.ownerProfile.addressLine2 ? (
                                        <div className='rounded-xl border border-white/10 bg-[#050816] p-4'>
                                            <p className='text-[11px] uppercase tracking-[0.16em] text-white/45'>
                                                Address Line 2
                                            </p>
                                            <p className='mt-2 text-sm font-medium text-white/85'>
                                                {verificationViewer.ownerProfile.addressLine2}
                                            </p>
                                        </div>
                                    ) : null}
                                    <div className='rounded-xl border border-white/10 bg-[#050816] p-4'>
                                        <p className='text-[11px] uppercase tracking-[0.16em] text-white/45'>
                                            City
                                        </p>
                                        <p className='mt-2 text-sm font-medium text-white/85'>
                                            {verificationViewer.ownerProfile.city}
                                        </p>
                                    </div>
                                    <div className='rounded-xl border border-white/10 bg-[#050816] p-4'>
                                        <p className='text-[11px] uppercase tracking-[0.16em] text-white/45'>
                                            State / Region
                                        </p>
                                        <p className='mt-2 text-sm font-medium text-white/85'>
                                            {verificationViewer.ownerProfile.stateName}
                                        </p>
                                    </div>
                                    <div className='rounded-xl border border-white/10 bg-[#050816] p-4'>
                                        <p className='text-[11px] uppercase tracking-[0.16em] text-white/45'>
                                            Postal Code
                                        </p>
                                        <p className='mt-2 text-sm font-medium text-white/85'>
                                            {verificationViewer.ownerProfile.postalCode}
                                        </p>
                                    </div>
                                    <div className='rounded-xl border border-white/10 bg-[#050816] p-4'>
                                        <p className='text-[11px] uppercase tracking-[0.16em] text-white/45'>
                                            Country
                                        </p>
                                        <p className='mt-2 text-sm font-medium text-white/85'>
                                            {verificationViewer.ownerProfile.countryName}
                                        </p>
                                    </div>
                                    {formatDateTimeLabel(
                                        verificationViewer.ownerProfile.submittedAt
                                    ) ? (
                                        <div className='rounded-xl border border-white/10 bg-[#050816] p-4'>
                                            <p className='text-[11px] uppercase tracking-[0.16em] text-white/45'>
                                                Submitted
                                            </p>
                                            <p className='mt-2 text-sm font-medium text-white/85'>
                                                {formatDateTimeLabel(
                                                    verificationViewer.ownerProfile
                                                        .submittedAt
                                                )}
                                            </p>
                                        </div>
                                    ) : null}
                                    {formatDateTimeLabel(
                                        verificationViewer.ownerProfile.lockedAt
                                    ) ? (
                                        <div className='rounded-xl border border-white/10 bg-[#050816] p-4'>
                                            <p className='text-[11px] uppercase tracking-[0.16em] text-white/45'>
                                                Locked
                                            </p>
                                            <p className='mt-2 text-sm font-medium text-white/85'>
                                                {formatDateTimeLabel(
                                                    verificationViewer.ownerProfile
                                                        .lockedAt
                                                )}
                                            </p>
                                        </div>
                                    ) : null}
                                </div>
                            ) : (
                                <div className='mt-4 rounded-xl border border-amber-400/20 bg-amber-500/10 px-4 py-3 text-sm text-amber-100'>
                                    Personal information has not been submitted yet.
                                </div>
                            )}
                        </div>
                        <div>
                            <p className='text-xs uppercase tracking-[0.2em] text-white/45'>
                                KYC Details
                            </p>
                        </div>
                        {verificationViewer?.identity.panMasked ? (
                            <div className='rounded-xl border border-sky-400/20 bg-sky-500/10 px-4 py-3 text-sm text-sky-100'>
                                PAN: {verificationViewer.identity.panMasked}
                            </div>
                        ) : null}
                        {verificationViewer?.identity.businessRegistrationMasked ? (
                            <div className='rounded-xl border border-white/10 bg-[#0f172a] px-4 py-3 text-sm text-white/80'>
                                Business Registration: {verificationViewer.identity.businessRegistrationMasked}
                            </div>
                        ) : null}
                        {verificationViewer?.identity.businessName ? (
                            <div className='rounded-xl border border-white/10 bg-[#0f172a] px-4 py-3 text-sm text-white/80'>
                                Business Name: {verificationViewer.identity.businessName}
                            </div>
                        ) : null}
                        {verificationViewer?.identity.aadhaarMasked ? (
                            <div className='rounded-xl border border-indigo-400/20 bg-indigo-500/10 px-4 py-4 text-indigo-100'>
                                <div className='flex flex-col gap-3 md:flex-row md:items-center md:justify-between'>
                                    <div>
                                        <p className='text-xs uppercase tracking-[0.2em] text-indigo-200/70'>
                                            Aadhaar
                                        </p>
                                        <p className='mt-2 text-sm font-semibold text-indigo-50'>
                                            {isAadhaarRevealed
                                                ? revealedAadhaar?.value
                                                : verificationViewer.identity
                                                      .aadhaarMasked}
                                        </p>
                                        <p className='mt-1 text-xs text-indigo-100/70'>
                                            {isAadhaarRevealed
                                                ? `Visible to root admin only. Auto-hides in ${revealedAadhaar?.secondsLeft}s.`
                                                : 'Masked by default. Reveal temporarily for KYC review.'}
                                        </p>
                                    </div>
                                    <div className='flex items-center gap-2'>
                                        {isAadhaarRevealed ? (
                                            <Button
                                                type='button'
                                                variant='outline'
                                                color='accent'
                                                onClick={() =>
                                                    setRevealedAadhaar(null)
                                                }
                                            >
                                                Hide Now
                                            </Button>
                                        ) : (
                                            <Button
                                                type='button'
                                                variant='outline'
                                                color='success'
                                                loading={
                                                    revealingAadhaarResellerId ===
                                                    verificationViewer.resellerId
                                                }
                                                onClick={revealAadhaarForViewer}
                                            >
                                                Reveal Aadhaar
                                            </Button>
                                        )}
                                    </div>
                                </div>
                            </div>
                        ) : null}
                        <div>
                            <p className='text-xs uppercase tracking-[0.2em] text-white/45'>
                                Uploaded Documents
                            </p>
                        </div>
                        <div className='grid gap-3'>
                            {verificationDocuments.length > 0 ? (
                                verificationDocuments.map(document => (
                                    <div
                                        key={document.type}
                                        className='rounded-2xl border border-white/10 bg-[#0b1220]/85 p-4 shadow-[0_18px_50px_rgba(8,12,30,0.38)]'
                                    >
                                        <div className='flex flex-col gap-3 md:flex-row md:items-start md:justify-between'>
                                            <div>
                                                <p className='text-xs uppercase tracking-[0.2em] text-white/45'>
                                                    Verification Document
                                                </p>
                                                <p className='mt-2 text-base font-semibold text-white'>
                                                    {document.label}
                                                </p>
                                                <p className='mt-1 text-xs text-white/45'>
                                                    {document.mime || 'Secure file preview'}
                                                </p>
                                            </div>
                                            <a
                                                href={document.url as string}
                                                target='_blank'
                                                rel='noopener noreferrer'
                                                className='inline-flex items-center justify-center rounded-xl border border-emerald-400/30 bg-emerald-500/15 px-4 py-2 text-sm font-medium text-emerald-100 transition hover:bg-emerald-500/25'
                                            >
                                                Open Full Document
                                            </a>
                                        </div>
                                        <div className='mt-4 overflow-hidden rounded-2xl border border-white/10 bg-[#050816]'>
                                            {isImageDocument(document.mime) ? (
                                                <img
                                                    src={document.url as string}
                                                    alt={document.label}
                                                    className='max-h-[520px] w-full object-contain bg-[#03050e]'
                                                    loading='lazy'
                                                />
                                            ) : (
                                                <iframe
                                                    src={document.url as string}
                                                    title={document.label}
                                                    className='h-[520px] w-full bg-[#03050e]'
                                                />
                                            )}
                                        </div>
                                    </div>
                                ))
                            ) : (
                                <div className='rounded-xl border border-white/10 bg-[#0b1220]/85 px-4 py-4 text-sm text-white/70'>
                                    No KYC files are uploaded yet. Personal details can still be reviewed and corrected here before KYC submission.
                                </div>
                            )}
                        </div>
                    </div>
                </Modal.Body>
                <Modal.Actions>
                    {verificationViewer?.verificationStatus !== 'approved' &&
                    verificationDocuments.length > 0 ? (
                        <Modal.Action
                            type='button'
                            onClick={approveVerificationFromViewer}
                            disabled={
                                activeActionResellerId ===
                                verificationViewer?.resellerId
                            }
                        >
                            {activeActionResellerId ===
                            verificationViewer?.resellerId
                                ? 'Approving...'
                                : 'Approve Verification'}
                        </Modal.Action>
                    ) : null}
                    <Modal.Action
                        type='button'
                        onClick={() => setVerificationViewer(null)}
                    >
                        Close
                    </Modal.Action>
                </Modal.Actions>
            </Modal>
            <ResellerUpsertModal
                open={!!editing}
                mode='edit'
                reseller={editing}
                onClose={() => setEditing(null)}
                onSaved={() => mutate()}
            />
            <DeleteResellerModal
                reseller={deleting}
                onClose={() => setDeleting(null)}
                onDeleted={() => mutate()}
            />
            <PageContentBlock title='Resellers' showFlashKey='admin:resellers'>
                <div className='mb-4 rounded-xl border border-indigo-400/20 bg-[#1a1441] px-4 py-3'>
                    <div className='flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between'>
                        <p className='text-sm text-white/80'>{viewSummary}</p>
                        <div className='flex flex-wrap items-center gap-2'>
                            {isRootAdmin ? (
                                <>
                                    {isViewingReseller ? (
                                        <Button
                                            disabled={isSwitching}
                                            onClick={switchToAll}
                                            variant='filled'
                                        >
                                            Return to Root Admin
                                        </Button>
                                    ) : null}
                                    {canShowAllResellers ? (
                                        <Button
                                            disabled={isSwitching}
                                            onClick={switchToAll}
                                            variant='filled'
                                        >
                                            View All Resellers
                                        </Button>
                                    ) : null}
                                </>
                            ) : null}
                        </div>
                    </div>
                </div>
                <div className='mb-6 rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                    <SearchBar
                        value={query}
                        onChange={e => setQuery(e.target.value)}
                        buttonText={
                            isMasterView
                                ? 'New Reseller'
                                : isRootAdmin
                                ? 'Return to Root Admin'
                                : 'Edit My Reseller'
                        }
                        onClick={() => {
                            if (isMasterView) {
                                navigate('/admin/reseller/create')

                                return
                            }

                            if (isRootAdmin) {
                                void switchToAll()

                                return
                            }

                            if (editableReseller) {
                                setEditing(editableReseller)
                            }
                        }}
                    />
                </div>
                <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                    {!data ? (
                        <div className='py-12'>
                            <Spinner />
                        </div>
                    ) : (
                        <Pagination data={data} onPageSelect={setPage}>
                            {({ items }) => (
                                <Table
                                    columns={columns}
                                    data={items}
                                    rowActions={rowActions}
                                    minWidth={980}
                                />
                            )}
                        </Pagination>
                    )}
                </div>
            </PageContentBlock>
        </div>
    )
}

export default ResellersContainer
