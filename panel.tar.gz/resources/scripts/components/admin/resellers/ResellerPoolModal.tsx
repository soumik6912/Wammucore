import {
    getResellerPool,
    refreshResellerPool,
    updateResellerPool,
} from '@/api/admin/resellers/manageResellerPool'
import { Reseller } from '@/api/admin/resellers/getResellers'
import Modal from '@/components/elements/Modal'
import Spinner from '@/components/elements/Spinner'
import { useEffect, useMemo, useState } from 'react'

interface Props {
    reseller: Reseller | null
    onClose: () => void
    onSaved: () => void
}

interface FormState {
    maxRamMb: string
    maxCpuCores: string
    maxDiskGb: string
    maxVms: string
}

const toInteger = (value: string): number => Number.parseInt(value, 10) || 0

const formatPercent = (value: number): string => `${Math.max(0, value).toFixed(2)}%`

const ResellerPoolModal = ({ reseller, onClose, onSaved }: Props) => {
    const [loading, setLoading] = useState(false)
    const [saving, setSaving] = useState(false)
    const [refreshing, setRefreshing] = useState(false)
    const [error, setError] = useState<string | null>(null)
    const [usage, setUsage] = useState<{
        usedRamMb: number
        usedCpuCores: number
        usedDiskGb: number
        usedVms: number
        ramPct: number
        cpuPct: number
        diskPct: number
        vmsPct: number
    } | null>(null)
    const [form, setForm] = useState<FormState>({
        maxRamMb: '',
        maxCpuCores: '',
        maxDiskGb: '',
        maxVms: '',
    })

    const isOpen = !!reseller

    const loadPool = async () => {
        if (!reseller) {
            return
        }

        setLoading(true)
        setError(null)
        try {
            const pool = await getResellerPool(reseller.id)
            setForm({
                maxRamMb: String(pool.limits.maxRamMb),
                maxCpuCores: String(pool.limits.maxCpuCores),
                maxDiskGb: String(pool.limits.maxDiskGb),
                maxVms: String(pool.limits.maxVms),
            })
            setUsage({
                usedRamMb: pool.usage.usedRamMb,
                usedCpuCores: pool.usage.usedCpuCores,
                usedDiskGb: pool.usage.usedDiskGb,
                usedVms: pool.usage.usedVms,
                ramPct: pool.percentages.ram,
                cpuPct: pool.percentages.cpu,
                diskPct: pool.percentages.disk,
                vmsPct: pool.percentages.vms,
            })
        } catch (err: any) {
            setError(
                err?.response?.data?.message || 'Failed to load reseller pool.'
            )
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        if (!isOpen) {
            return
        }

        void loadPool()
    }, [isOpen, reseller?.id])

    const patchForm = (patch: Partial<FormState>) => {
        setForm(current => ({
            ...current,
            ...patch,
        }))
    }

    const save = async () => {
        if (!reseller) {
            return
        }

        setSaving(true)
        setError(null)
        try {
            const payload = {
                maxRamMb: toInteger(form.maxRamMb),
                maxCpuCores: toInteger(form.maxCpuCores),
                maxDiskGb: toInteger(form.maxDiskGb),
                maxVms: toInteger(form.maxVms),
            }

            if (
                payload.maxRamMb < 1 ||
                payload.maxCpuCores < 1 ||
                payload.maxDiskGb < 1 ||
                payload.maxVms < 1
            ) {
                setError('All pool limits must be at least 1.')
                setSaving(false)

                return
            }

            const updated = await updateResellerPool(reseller.id, payload)
            setUsage({
                usedRamMb: updated.usage.usedRamMb,
                usedCpuCores: updated.usage.usedCpuCores,
                usedDiskGb: updated.usage.usedDiskGb,
                usedVms: updated.usage.usedVms,
                ramPct: updated.percentages.ram,
                cpuPct: updated.percentages.cpu,
                diskPct: updated.percentages.disk,
                vmsPct: updated.percentages.vms,
            })
            onSaved()
            onClose()
        } catch (err: any) {
            setError(
                err?.response?.data?.message ||
                    'Failed to update reseller pool limits.'
            )
        } finally {
            setSaving(false)
        }
    }

    const refreshUsage = async () => {
        if (!reseller) {
            return
        }

        setRefreshing(true)
        setError(null)
        try {
            const refreshed = await refreshResellerPool(reseller.id)
            setUsage({
                usedRamMb: refreshed.usage.usedRamMb,
                usedCpuCores: refreshed.usage.usedCpuCores,
                usedDiskGb: refreshed.usage.usedDiskGb,
                usedVms: refreshed.usage.usedVms,
                ramPct: refreshed.percentages.ram,
                cpuPct: refreshed.percentages.cpu,
                diskPct: refreshed.percentages.disk,
                vmsPct: refreshed.percentages.vms,
            })
        } catch (err: any) {
            setError(
                err?.response?.data?.message ||
                    'Failed to refresh usage counters.'
            )
        } finally {
            setRefreshing(false)
        }
    }

    const usageRows = useMemo(
        () => [
            {
                label: 'RAM',
                used: usage?.usedRamMb ?? 0,
                limit: toInteger(form.maxRamMb),
                unit: 'MB',
                pct: usage?.ramPct ?? 0,
            },
            {
                label: 'CPU',
                used: usage?.usedCpuCores ?? 0,
                limit: toInteger(form.maxCpuCores),
                unit: 'cores',
                pct: usage?.cpuPct ?? 0,
            },
            {
                label: 'Disk',
                used: usage?.usedDiskGb ?? 0,
                limit: toInteger(form.maxDiskGb),
                unit: 'GB',
                pct: usage?.diskPct ?? 0,
            },
            {
                label: 'VMs',
                used: usage?.usedVms ?? 0,
                limit: toInteger(form.maxVms),
                unit: 'VMs',
                pct: usage?.vmsPct ?? 0,
            },
        ],
        [form, usage]
    )

    return (
        <Modal open={isOpen} onClose={onClose} size='lg'>
            <Modal.Header>
                <Modal.Title>Manage Resource Pool</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                {loading ? (
                    <Spinner />
                ) : (
                    <div className='space-y-4'>
                        <p className='text-sm text-white/70'>
                            Adjust reseller provisioning limits and review current usage.
                        </p>

                        {error ? (
                            <div className='rounded-lg border border-red-500/40 bg-red-500/10 px-3 py-2 text-sm text-red-200'>
                                {error}
                            </div>
                        ) : null}

                        <div className='grid grid-cols-1 gap-4 sm:grid-cols-2'>
                            <div>
                                <label className='mb-1 block text-sm text-white/80'>
                                    Max RAM (MB)
                                </label>
                                <input
                                    type='number'
                                    value={form.maxRamMb}
                                    onChange={event => {
                                        const value = event.currentTarget.value
                                        patchForm({ maxRamMb: value })
                                    }}
                                    className='w-full rounded-lg border border-white/15 bg-[#111a31] px-3 py-2 text-sm text-white'
                                />
                            </div>
                            <div>
                                <label className='mb-1 block text-sm text-white/80'>
                                    Max CPU Cores
                                </label>
                                <input
                                    type='number'
                                    value={form.maxCpuCores}
                                    onChange={event => {
                                        const value = event.currentTarget.value
                                        patchForm({ maxCpuCores: value })
                                    }}
                                    className='w-full rounded-lg border border-white/15 bg-[#111a31] px-3 py-2 text-sm text-white'
                                />
                            </div>
                            <div>
                                <label className='mb-1 block text-sm text-white/80'>
                                    Max Disk (GB)
                                </label>
                                <input
                                    type='number'
                                    value={form.maxDiskGb}
                                    onChange={event => {
                                        const value = event.currentTarget.value
                                        patchForm({ maxDiskGb: value })
                                    }}
                                    className='w-full rounded-lg border border-white/15 bg-[#111a31] px-3 py-2 text-sm text-white'
                                />
                            </div>
                            <div>
                                <label className='mb-1 block text-sm text-white/80'>
                                    Max VMs
                                </label>
                                <input
                                    type='number'
                                    value={form.maxVms}
                                    onChange={event => {
                                        const value = event.currentTarget.value
                                        patchForm({ maxVms: value })
                                    }}
                                    className='w-full rounded-lg border border-white/15 bg-[#111a31] px-3 py-2 text-sm text-white'
                                />
                            </div>
                        </div>

                        <div className='rounded-xl border border-white/10 bg-[#111a31] p-3'>
                            <div className='mb-2 flex items-center justify-between'>
                                <h4 className='text-sm font-semibold text-white'>
                                    Current Usage
                                </h4>
                                <button
                                    type='button'
                                    disabled={refreshing}
                                    onClick={refreshUsage}
                                    className='rounded-md border border-white/20 px-2.5 py-1 text-xs text-white/90 hover:bg-white/10 disabled:opacity-50'
                                >
                                    {refreshing ? 'Refreshing...' : 'Refresh Usage'}
                                </button>
                            </div>
                            <div className='space-y-2'>
                                {usageRows.map(item => (
                                    <div
                                        key={item.label}
                                        className='flex items-center justify-between text-sm text-white/85'
                                    >
                                        <span>{item.label}</span>
                                        <span>
                                            {item.used}/{Math.max(item.limit, 1)} {item.unit} (
                                            {formatPercent(item.pct)})
                                        </span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                )}
            </Modal.Body>
            <Modal.Actions>
                <Modal.Action type='button' onClick={onClose}>
                    Cancel
                </Modal.Action>
                <Modal.Action
                    type='button'
                    onClick={save}
                    disabled={loading || saving}
                >
                    {saving ? 'Saving...' : 'Save Limits'}
                </Modal.Action>
            </Modal.Actions>
        </Modal>
    )
}

export default ResellerPoolModal
