import setTenantContext from '@/api/admin/tenancy/setTenantContext'
import useTenantContextSWR from '@/api/admin/tenancy/useTenantContextSWR'
import useResellersSWR from '@/api/admin/resellers/useResellersSWR'
import PageContentBlock from '@/components/elements/PageContentBlock'
import Spinner from '@/components/elements/Spinner'
import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'

const ResellerPanelEntryContainer = () => {
    const navigate = useNavigate()
    const { data: tenantContext, mutate: mutateTenantContext } =
        useTenantContextSWR()
    const { data: resellers } = useResellersSWR({ page: 1, perPage: 200 })

    const [isSwitching, setIsSwitching] = useState(false)
    const [error, setError] = useState<string | null>(null)
    const [search, setSearch] = useState('')

    const [selectedResellerId, setSelectedResellerId] = useState<number | null>(
        null
    )

    const resellerOptions = useMemo(
        () => (resellers?.items || []).map(item => ({
            id: item.id,
            reference: item.uuid || item.slug || String(item.id),
            label: item.displayName,
            searchText: [
                item.displayName,
                item.uuid,
                item.slug,
                item.domain,
                item.id,
            ]
                .filter(Boolean)
                .join(' ')
                .toLowerCase(),
        })),
        [resellers?.items]
    )
    const filteredResellerOptions = useMemo(() => {
        const query = search.trim().toLowerCase()
        if (!query) {
            return resellerOptions
        }

        return resellerOptions.filter(option =>
            option.searchText.includes(query)
        )
    }, [resellerOptions, search])

    const selectedReseller = useMemo(
        () =>
            resellerOptions.find(option => option.id === selectedResellerId) ??
            null,
        [resellerOptions, selectedResellerId]
    )

    const enterResellerPanel = async () => {
        if (!selectedResellerId) {
            setError('Select a reseller first.')
            return
        }

        setError(null)
        setIsSwitching(true)

        try {
            await setTenantContext({
                mode: 'reseller',
                resellerId: selectedResellerId,
                resellerRef: selectedReseller?.reference,
            })
            await mutateTenantContext()
            navigate(
                `/admin/reseller-panel/r/${selectedReseller?.reference ?? selectedResellerId}`,
                { replace: true }
            )
        } catch (err) {
            setError(
                err instanceof Error
                    ? err.message
                    : 'Failed to switch reseller view.'
            )
        } finally {
            setIsSwitching(false)
        }
    }

    const returnToMainAdmin = async () => {
        setError(null)
        setIsSwitching(true)
        try {
            await setTenantContext({ mode: 'platform' })
            await mutateTenantContext()
            navigate('/admin', { replace: true })
        } catch (err) {
            setError(
                err instanceof Error
                    ? err.message
                    : 'Failed to return to the main admin panel.'
            )
        } finally {
            setIsSwitching(false)
        }
    }

    if (!tenantContext || !resellers) {
        return (
            <PageContentBlock title='Reseller Panel'>
                <Spinner />
            </PageContentBlock>
        )
    }

    return (
        <PageContentBlock title='Reseller Panel'>
            <div className='space-y-6'>
                <div className='theme-panel overflow-hidden rounded-3xl p-5 shadow-2xl shadow-black/25 sm:p-6'>
                    <div className='flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between'>
                        <div className='min-w-0'>
                            <p className='theme-pill-active inline-flex rounded-full px-3 py-1 text-[11px] font-bold uppercase tracking-[0.2em]'>
                                Root Support Scope
                            </p>
                            <h2 className='mt-4 break-words text-2xl font-semibold text-white'>
                                Choose reseller workspace
                            </h2>
                            <p className='theme-muted mt-2 max-w-3xl break-words text-sm leading-6'>
                                This lets root admin temporarily view a reseller-scoped admin panel for support, verification, or troubleshooting. It does not turn your root account into a reseller account.
                            </p>
                        </div>
                        <div className='theme-panel-inner rounded-2xl p-4 text-sm leading-6 lg:max-w-sm'>
                            <span className='font-semibold text-emerald-100'>Use it for:</span> checking reseller settings, customer lists, domains, billing wiring, and support cases from that reseller's isolated view.
                        </div>
                    </div>

                    <div className='mt-4 grid gap-3 md:max-w-xl'>
                        <label className='theme-muted text-sm font-semibold'>Reseller workspace</label>
                        <input
                            type='search'
                            value={search}
                            onChange={event => setSearch(event.currentTarget.value)}
                            placeholder='Search reseller by name, domain, slug, UUID, or ID'
                            className='theme-input min-h-[44px] rounded-xl px-3 py-2 text-sm transition'
                        />
                        <select
                            value={selectedResellerId ?? ''}
                            onChange={event =>
                                setSelectedResellerId(
                                    event.target.value
                                        ? Number(event.target.value)
                                        : null
                                )
                            }
                            className='theme-input min-h-[44px] rounded-xl px-3 py-2 text-sm transition'
                        >
                            <option value=''>Select reseller</option>
                            {filteredResellerOptions.map(option => (
                                <option key={option.id} value={option.id}>
                                    {option.label}
                                </option>
                            ))}
                        </select>
                        {search.trim() ? (
                            <p className='theme-muted text-xs leading-5'>
                                {filteredResellerOptions.length} reseller
                                {filteredResellerOptions.length === 1 ? '' : 's'} found.
                            </p>
                        ) : null}
                        <p className='theme-muted text-xs leading-5'>
                            Pick one reseller first. The next page uses that reseller's UUID route so refreshes and direct links stay stable.
                        </p>
                    </div>

                    <div className='mt-5 flex flex-wrap gap-3'>
                        <button
                            type='button'
                            disabled={isSwitching || !selectedResellerId}
                            onClick={enterResellerPanel}
                            className='theme-button-primary rounded-xl px-4 py-2.5 text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-50'
                        >
                            {isSwitching ? 'Switching...' : 'Enter Reseller Panel'}
                        </button>
                        {tenantContext.mode === 'reseller' ? (
                            <button
                                type='button'
                                disabled={isSwitching}
                                onClick={returnToMainAdmin}
                                className='theme-button-soft rounded-xl px-4 py-2.5 text-sm font-semibold transition disabled:opacity-50'
                            >
                                Return To Main Admin
                            </button>
                        ) : null}
                    </div>

                    {error ? (
                        <p className='mt-4 rounded-lg border border-red-500/40 bg-red-500/10 px-3 py-2 text-sm text-red-200'>
                            {error}
                        </p>
                    ) : null}
                </div>
            </div>
        </PageContentBlock>
    )
}

export default ResellerPanelEntryContainer
