import { useFlashKey } from '@/util/useFlash'

import deleteReseller from '@/api/admin/resellers/deleteReseller'
import { Reseller } from '@/api/admin/resellers/getResellers'

import FlashMessageRender from '@/components/elements/FlashMessageRenderer'
import Modal from '@/components/elements/Modal'

interface Props {
    reseller: Reseller | null
    onClose: () => void
    onDeleted: () => void
}

const DeleteResellerModal = ({ reseller, onClose, onDeleted }: Props) => {
    const { clearFlashes, clearAndAddHttpError } = useFlashKey(
        'admin:resellers.delete'
    )

    const handleClose = () => {
        clearFlashes()
        onClose()
    }

    const handleDelete = async () => {
        if (!reseller) {
            return
        }

        clearFlashes()

        try {
            await deleteReseller(reseller.id)
            handleClose()
            onDeleted()
        } catch (error) {
            clearAndAddHttpError(error as Error)
        }
    }

    return (
        <Modal open={!!reseller} onClose={handleClose}>
            <Modal.Header>
                <Modal.Title>
                    {reseller?.isRegistrationDraft
                        ? 'Clean Reseller Draft'
                        : 'Delete Reseller'}
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <FlashMessageRender
                    className='mb-5'
                    byKey={'admin:resellers.delete'}
                />
                {reseller ? (
                    <Modal.Description>
                        {reseller.isDefault
                            ? 'This is the default reseller and cannot be deleted.'
                            : reseller.isRegistrationDraft
                              ? `Clean ${reseller.displayName}? This removes only the incomplete reseller draft and its temporary owner login. It will not run for active resellers, submitted KYC, domains, servers, nodes, or customer accounts.`
                            : `Delete ${reseller.displayName}? This removes the reseller shell and reseller-admin login, but stays blocked if customer users, servers, nodes, or child resellers are assigned.`}
                    </Modal.Description>
                ) : null}
            </Modal.Body>
            <Modal.Actions>
                <Modal.Action type='button' onClick={handleClose}>
                    Cancel
                </Modal.Action>
                <Modal.Action
                    type='button'
                    onClick={handleDelete}
                    disabled={!reseller || reseller.isDefault}
                >
                    {reseller?.isRegistrationDraft ? 'Clean Draft' : 'Delete'}
                </Modal.Action>
            </Modal.Actions>
        </Modal>
    )
}

export default DeleteResellerModal
