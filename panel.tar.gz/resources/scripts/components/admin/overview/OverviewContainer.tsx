import useTenantContextSWR from '@/api/admin/tenancy/useTenantContextSWR'
import getHorizon from '@/api/admin/horizon/getHorizon'
import getResellerVerificationSummary, {
    ResellerVerificationSummary,
} from '@/api/admin/resellers/getResellerVerificationSummary'
import getPanelSettings, {
    NotificationTemplate,
} from '@/api/admin/settings/getPanelSettings'
import updatePanelSettings, {
    sendPanelTestMail,
} from '@/api/admin/settings/updatePanelSettings'
import PageContentBlock from '@/components/elements/PageContentBlock'
import SafeImage from '@/components/elements/SafeImage'
import { useStoreActions, useStoreState } from '@/state'
import { applyDocumentFavicon } from '@/util/favicon'
import { THEME_PRESETS, resolveThemePreset } from '@/util/themePresets'
import { useEffect, useState } from 'react'
import {
    BellAlertIcon,
    FireIcon,
    RocketLaunchIcon,
    StarIcon,
} from '@heroicons/react/24/outline'
import { Link } from 'react-router-dom'

const OverviewContainer = () => {
    const { data: tenantContext } = useTenantContextSWR()
    const isMasterView = tenantContext?.mode !== 'reseller'
    const isRootAdmin = useStoreState(state => Boolean(state.user.data?.rootAdmin))
    const version = useStoreState(state => state.settings.data!.version)
    const settings = useStoreState(state => state.settings.data)
    const setSettings = useStoreActions(actions => actions.settings.setSettings)

    const [panelName, setPanelName] = useState('')
    const [logoUrl, setLogoUrl] = useState('')
    const [loginBackgroundImage, setLoginBackgroundImage] = useState('')
    const [bannerImageUrl, setBannerImageUrl] = useState('')
    const [faviconUrl, setFaviconUrl] = useState('')
    const [loadingLogoUrl, setLoadingLogoUrl] = useState('')
    const [billingUrl, setBillingUrl] = useState('')
    const [platformStoreRedirectUrl, setPlatformStoreRedirectUrl] = useState('')
    const [platformUpgradeEnabled, setPlatformUpgradeEnabled] = useState(true)
    const [platformUpgradeUrlTemplate, setPlatformUpgradeUrlTemplate] =
        useState('')
    const [apiDocsUrl, setApiDocsUrl] = useState('')
    const [tutorialUrl, setTutorialUrl] = useState('')
    const [resellerRegistrationTermsUrl, setResellerRegistrationTermsUrl] =
        useState('')
    const [resellerRegistrationPrivacyUrl, setResellerRegistrationPrivacyUrl] =
        useState('')
    const [resellerRegistrationEnabled, setResellerRegistrationEnabled] =
        useState(false)
    const [
        resellerEmailVerificationEnabled,
        setResellerEmailVerificationEnabled,
    ] = useState(false)
    const [
        resellerEmailVerificationAvailable,
        setResellerEmailVerificationAvailable,
    ] = useState(false)
    const [
        resellerEmailVerificationEffective,
        setResellerEmailVerificationEffective,
    ] = useState(false)
    const [passwordResetEnabled, setPasswordResetEnabled] = useState(false)
    const [passwordResetAvailable, setPasswordResetAvailable] = useState(false)
    const [passwordResetEffective, setPasswordResetEffective] = useState(false)
    const [resourceGuard, setResourceGuard] = useState({
        enabled: true,
        thresholdPercent: '98',
    })
    const [trustpilotReview, setTrustpilotReview] = useState({
        enabled: false,
        url: '',
        viewThreshold: '10',
        delayDays: '1',
    })
    const [logRetention, setLogRetention] = useState({
        defaultDays: '10',
        adminDays: '10',
        userActivityDays: '10',
        authDays: '10',
        securityDays: '10',
        billingDays: '10',
        applicationDays: '10',
    })
    const [customDomains, setCustomDomains] = useState({
        edgeGatewayHost: 'edge.wammuhost.com',
        verificationPrefix: '_wammuhost-verify',
        autoSslEnabled: true,
        sslContactEmail: '',
    })
    const [defaultPlanCurrency, setDefaultPlanCurrency] = useState('USD')
    const [platformMail, setPlatformMail] = useState({
        enabled: false,
        configured: false,
        source: 'none' as 'panel' | 'env' | 'none',
        host: '',
        port: '587',
        encryption: 'tls' as 'tls' | 'ssl' | 'none',
        username: '',
        passwordSet: false,
        fromEmail: '',
        fromName: 'WammuHost',
        replyToEmail: '',
        ehloDomain: '',
    })
    const [platformMailPasswordDraft, setPlatformMailPasswordDraft] =
        useState('')
    const [testMailRecipient, setTestMailRecipient] = useState('')
    const [isSendingTestMail, setIsSendingTestMail] = useState(false)
    const [notificationEmailEnabled, setNotificationEmailEnabled] =
        useState(false)
    const [notificationEmailAvailable, setNotificationEmailAvailable] =
        useState(false)
    const [notificationEmailEffective, setNotificationEmailEffective] =
        useState(false)
    const [notificationTemplates, setNotificationTemplates] = useState<
        NotificationTemplate[]
    >([])
    const [templateTestLoading, setTemplateTestLoading] = useState<
        string | null
    >(null)
    const [footerText, setFooterText] = useState('WammuCore')
    const [footerUrl, setFooterUrl] = useState('https://wammuhost.com')
    const [tenantThemeKey, setTenantThemeKey] = useState('wammuhost')
    const [brandPrimaryColor, setBrandPrimaryColor] = useState('')
    const [brandSecondaryColor, setBrandSecondaryColor] = useState('')
    const [brandAccentColor, setBrandAccentColor] = useState('')
    const [customCss, setCustomCss] = useState('')
    const [isLoading, setIsLoading] = useState(true)
    const [isSaving, setIsSaving] = useState(false)
    const [status, setStatus] = useState<{ type: 'ok' | 'error'; text: string } | null>(null)
    const [queueWidget, setQueueWidget] = useState<{
        status: string
        pendingJobs: number
        throughput: number
        failedJobs: number
    } | null>(null)
    const [queueWidgetError, setQueueWidgetError] = useState<string | null>(null)
    const [resellerVerificationSummary, setResellerVerificationSummary] =
        useState<ResellerVerificationSummary | null>(null)
    const [resellerVerificationError, setResellerVerificationError] = useState<
        string | null
    >(null)
    const platformMailDraftPort = Number(platformMail.port)
    const platformMailDraftReady =
        platformMail.enabled &&
        platformMail.host.trim() !== '' &&
        platformMailDraftPort > 0 &&
        platformMailDraftPort <= 65535 &&
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(platformMail.fromEmail.trim())
    const passwordResetSwitchChecked =
        passwordResetEnabled && platformMailDraftReady
    const notificationEmailSwitchChecked =
        notificationEmailEnabled && platformMailDraftReady

    const previewPanelTheme = (
        nextThemeKey: string,
        nextPrimaryColor: string,
        nextSecondaryColor: string,
        nextAccentColor: string,
        nextCustomCss = customCss
    ) => {
        if (!settings) {
            return
        }

        setSettings({
            ...settings,
            tenantThemeKey: nextThemeKey || 'wammuhost',
            brandPrimaryColor: nextPrimaryColor || null,
            brandSecondaryColor: nextSecondaryColor || null,
            brandAccentColor: nextAccentColor || null,
            customCss: nextCustomCss || null,
        })
    }

    useEffect(() => {
        if (!isMasterView) {
            setIsLoading(false)
            setStatus(null)

            return
        }

        getPanelSettings()
            .then(data => {
                setPanelName(data.panelName || '')
                setLogoUrl(data.logoUrl || '')
                setLoginBackgroundImage(data.loginBackgroundImage || '')
                setBannerImageUrl(data.bannerImageUrl || '')
                setFaviconUrl(data.faviconUrl || '')
                setLoadingLogoUrl(data.loadingLogoUrl || '')
                setBillingUrl(data.billingUrl || '')
                setPlatformStoreRedirectUrl(data.platformStoreRedirectUrl || '')
                setPlatformUpgradeEnabled(
                    Boolean(data.platformUpgradeEnabled ?? true)
                )
                setPlatformUpgradeUrlTemplate(
                    data.platformUpgradeUrlTemplate || ''
                )
                setApiDocsUrl(data.apiDocsUrl || '')
                setTutorialUrl(data.tutorialUrl || '')
                setResellerRegistrationTermsUrl(
                    data.resellerRegistrationTermsUrl || ''
                )
                setResellerRegistrationPrivacyUrl(
                    data.resellerRegistrationPrivacyUrl || ''
                )
                setResellerRegistrationEnabled(
                    Boolean(data.resellerRegistrationEnabled)
                )
                setResellerEmailVerificationEnabled(
                    Boolean(data.resellerEmailVerificationEnabled)
                )
                setResellerEmailVerificationAvailable(
                    Boolean(data.resellerEmailVerificationAvailable)
                )
                setResellerEmailVerificationEffective(
                    Boolean(data.resellerEmailVerificationEffective)
                )
                setPasswordResetEnabled(Boolean(data.passwordResetEnabled))
                setPasswordResetAvailable(Boolean(data.passwordResetAvailable))
                setPasswordResetEffective(Boolean(data.passwordResetEffective))
                setResourceGuard({
                    enabled: Boolean(data.resourceGuard.enabled),
                    thresholdPercent: String(
                        data.resourceGuard.thresholdPercent || 98
                    ),
                })
                setTrustpilotReview({
                    enabled: Boolean(data.trustpilotReview.enabled),
                    url: data.trustpilotReview.url || '',
                    viewThreshold: String(
                        data.trustpilotReview.viewThreshold || 10
                    ),
                    delayDays: String(
                        data.trustpilotReview.delayDays ?? 1
                    ),
                })
                setLogRetention({
                    defaultDays: String(data.logRetention.defaultDays || 10),
                    adminDays: String(data.logRetention.adminDays || 10),
                    userActivityDays: String(
                        data.logRetention.userActivityDays || 10
                    ),
                    authDays: String(data.logRetention.authDays || 10),
                    securityDays: String(data.logRetention.securityDays || 10),
                    billingDays: String(data.logRetention.billingDays || 10),
                    applicationDays: String(
                        data.logRetention.applicationDays || 10
                    ),
                })
                setCustomDomains({
                    edgeGatewayHost: data.customDomains.edgeGatewayHost,
                    verificationPrefix: data.customDomains.verificationPrefix,
                    autoSslEnabled: data.customDomains.autoSslEnabled,
                    sslContactEmail: data.customDomains.sslContactEmail || '',
                })
                setDefaultPlanCurrency(data.defaultPlanCurrency || 'USD')
                setPlatformMail({
                    enabled: Boolean(data.platformMail.enabled),
                    configured: Boolean(data.platformMail.configured),
                    source: data.platformMail.source || 'none',
                    host: data.platformMail.host || '',
                    port:
                        data.platformMail.port === null
                            ? '587'
                            : String(data.platformMail.port),
                    encryption: data.platformMail.encryption || 'none',
                    username: data.platformMail.username || '',
                    passwordSet: Boolean(data.platformMail.passwordSet),
                    fromEmail: data.platformMail.fromEmail || '',
                    fromName: data.platformMail.fromName || 'WammuHost',
                    replyToEmail: data.platformMail.replyToEmail || '',
                    ehloDomain: data.platformMail.ehloDomain || '',
                })
                setPlatformMailPasswordDraft('')
                setNotificationEmailEnabled(
                    Boolean(data.notificationEmailEnabled)
                )
                setNotificationEmailAvailable(
                    Boolean(data.notificationEmailAvailable)
                )
                setNotificationEmailEffective(
                    Boolean(data.notificationEmailEffective)
                )
                setNotificationTemplates(data.notificationTemplates || [])
                setFooterText(data.footerText || 'WammuCore')
                setFooterUrl(data.footerUrl || 'https://wammuhost.com')
                setTenantThemeKey(data.tenantThemeKey || 'wammuhost')
                setBrandPrimaryColor(data.brandPrimaryColor || '')
                setBrandSecondaryColor(data.brandSecondaryColor || '')
                setBrandAccentColor(data.brandAccentColor || '')
                setCustomCss(data.customCss || '')
            })
            .catch(() => {
                setStatus({ type: 'error', text: 'Failed to load panel settings.' })
            })
            .finally(() => {
                setIsLoading(false)
            })
    }, [isMasterView])

    useEffect(() => {
        if (!isMasterView || !isRootAdmin) {
            setQueueWidget(null)
            setQueueWidgetError(null)

            return
        }

        let mounted = true

        const fetchQueueWidget = async () => {
            try {
                const data = await getHorizon({ showProgress: false })
                if (!mounted) {
                    return
                }

                setQueueWidget({
                    status: data.summary.status,
                    pendingJobs: data.summary.pendingJobs,
                    throughput: data.summary.throughput,
                    failedJobs: data.summary.failedJobs,
                })
                setQueueWidgetError(null)
            } catch {
                if (mounted) {
                    setQueueWidgetError('Unable to load live Core metrics.')
                }
            }
        }

        fetchQueueWidget()
        const timer = window.setInterval(fetchQueueWidget, 15000)

        return () => {
            mounted = false
            window.clearInterval(timer)
        }
    }, [isMasterView, isRootAdmin])

    useEffect(() => {
        if (!isMasterView || !isRootAdmin) {
            setResellerVerificationSummary(null)
            setResellerVerificationError(null)

            return
        }

        let mounted = true

        const fetchResellerVerificationSummary = async () => {
            try {
                const data = await getResellerVerificationSummary()
                if (!mounted) {
                    return
                }

                setResellerVerificationSummary(data)
                setResellerVerificationError(null)
            } catch {
                if (mounted) {
                    setResellerVerificationError(
                        'Unable to load reseller request notifications.'
                    )
                }
            }
        }

        fetchResellerVerificationSummary()
        const timer = window.setInterval(fetchResellerVerificationSummary, 30000)

        return () => {
            mounted = false
            window.clearInterval(timer)
        }
    }, [isMasterView, isRootAdmin])

    const handleSave = async () => {
        if (!isMasterView) {
            return
        }

        setIsSaving(true)
        setStatus(null)

        try {
            const updated = await updatePanelSettings({
                panelName,
                logoUrl,
                loginBackgroundImage,
                bannerImageUrl,
                faviconUrl,
                loadingLogoUrl,
                billingUrl,
                platformStoreRedirectUrl,
                platformUpgradeEnabled,
                platformUpgradeUrlTemplate,
                apiDocsUrl,
                tutorialUrl,
                resellerRegistrationTermsUrl,
                resellerRegistrationPrivacyUrl,
                resellerRegistrationEnabled,
                resellerEmailVerificationEnabled,
                passwordResetEnabled: passwordResetSwitchChecked,
                resourceGuard: {
                    enabled: resourceGuard.enabled,
                    thresholdPercent:
                        Number(resourceGuard.thresholdPercent) || 98,
                },
                trustpilotReview: {
                    enabled: trustpilotReview.enabled,
                    url: trustpilotReview.url,
                    viewThreshold: Number(trustpilotReview.viewThreshold) || 10,
                    delayDays:
                        trustpilotReview.delayDays.trim() === ''
                            ? 1
                            : Number(trustpilotReview.delayDays),
                },
                logRetention: {
                    defaultDays: Number(logRetention.defaultDays) || 10,
                    adminDays: Number(logRetention.adminDays) || 10,
                    userActivityDays:
                        Number(logRetention.userActivityDays) || 10,
                    authDays: Number(logRetention.authDays) || 10,
                    securityDays: Number(logRetention.securityDays) || 10,
                    billingDays: Number(logRetention.billingDays) || 10,
                    applicationDays:
                        Number(logRetention.applicationDays) || 10,
                },
                customDomains,
                defaultPlanCurrency,
                platformMail: {
                    enabled: platformMail.enabled,
                    host: platformMail.host,
                    port: platformMail.port,
                    encryption: platformMail.encryption,
                    username: platformMail.username,
                    password:
                        platformMailPasswordDraft.trim() !== ''
                            ? platformMailPasswordDraft
                            : undefined,
                    fromEmail: platformMail.fromEmail,
                    fromName: platformMail.fromName,
                    replyToEmail: platformMail.replyToEmail,
                    ehloDomain: platformMail.ehloDomain,
                },
                notificationEmailEnabled: notificationEmailSwitchChecked,
                notificationTemplates,
                licenseCatalog: settings?.licenseCatalog || [],
                footerText,
                footerUrl,
                tenantThemeKey,
                brandPrimaryColor,
                brandSecondaryColor,
                brandAccentColor,
                customCss,
            })

            if (settings) {
                setSettings({
                    ...settings,
                    panelName: updated.panelName,
                    logoUrl: updated.logoUrl,
                    loginBackgroundImage: updated.loginBackgroundImage,
                    bannerImageUrl: updated.bannerImageUrl,
                    faviconUrl: updated.faviconUrl,
                    loadingLogoUrl: updated.loadingLogoUrl,
                    billingUrl: updated.billingUrl,
                    platformStoreRedirectUrl:
                        updated.platformStoreRedirectUrl,
                    effectiveStorefrontUrl: updated.effectiveStorefrontUrl,
                    platformUpgradeEnabled: updated.platformUpgradeEnabled,
                    platformUpgradeUrlTemplate:
                        updated.platformUpgradeUrlTemplate,
                    upgradeButtonEnabled: updated.upgradeButtonEnabled,
                    upgradeUrlTemplate: updated.upgradeUrlTemplate,
                    apiDocsUrl: updated.apiDocsUrl,
                    tutorialUrl: updated.tutorialUrl,
                    resellerRegistrationTermsUrl:
                        updated.resellerRegistrationTermsUrl,
                    resellerRegistrationPrivacyUrl:
                        updated.resellerRegistrationPrivacyUrl,
                    resellerRegistrationEnabled:
                        updated.resellerRegistrationEnabled,
                    resellerEmailVerificationEnabled:
                        updated.resellerEmailVerificationEnabled,
                    resellerEmailVerificationAvailable:
                        updated.resellerEmailVerificationAvailable,
                    resellerEmailVerificationEffective:
                        updated.resellerEmailVerificationEffective,
                    passwordResetEnabled: updated.passwordResetEnabled,
                    passwordResetAvailable: updated.passwordResetAvailable,
                    passwordResetEffective: updated.passwordResetEffective,
                    resourceGuard: updated.resourceGuard,
                    trustpilotReview: updated.trustpilotReview,
                    clientAuth: {
                        ...(settings.clientAuth || {
                            allowSelfRegistration: false,
                            enableEmail2fa: false,
                            enableEmailVerification: false,
                            mailerConfigured: false,
                            passwordResetEnabled: false,
                        }),
                        mailerConfigured: Boolean(updated.platformMail.configured),
                        passwordResetEnabled: Boolean(
                            updated.passwordResetEffective
                        ),
                    },
                    customDomains: updated.customDomains,
                    defaultPlanCurrency: updated.defaultPlanCurrency,
                    platformMail: updated.platformMail,
                    notificationEmailEnabled:
                        updated.notificationEmailEnabled,
                    notificationEmailAvailable:
                        updated.notificationEmailAvailable,
                    notificationEmailEffective:
                        updated.notificationEmailEffective,
                    notificationTemplates: updated.notificationTemplates,
                    licenseCatalog: updated.licenseCatalog,
                    footerText: updated.footerText,
                    footerUrl: updated.footerUrl,
                    tenantThemeKey: updated.tenantThemeKey,
                    brandPrimaryColor: updated.brandPrimaryColor,
                    brandSecondaryColor: updated.brandSecondaryColor,
                    brandAccentColor: updated.brandAccentColor,
                    customCss: updated.customCss,
                })
            }

            setResellerEmailVerificationEnabled(
                Boolean(updated.resellerEmailVerificationEnabled)
            )
            setResellerRegistrationEnabled(
                Boolean(updated.resellerRegistrationEnabled)
            )
            setResellerEmailVerificationAvailable(
                Boolean(updated.resellerEmailVerificationAvailable)
            )
            setResellerEmailVerificationEffective(
                Boolean(updated.resellerEmailVerificationEffective)
            )
            setPasswordResetEnabled(Boolean(updated.passwordResetEnabled))
            setPasswordResetAvailable(Boolean(updated.passwordResetAvailable))
            setPasswordResetEffective(Boolean(updated.passwordResetEffective))
            setResourceGuard({
                enabled: Boolean(updated.resourceGuard.enabled),
                thresholdPercent: String(
                    updated.resourceGuard.thresholdPercent || 98
                ),
            })
            setTrustpilotReview({
                enabled: Boolean(updated.trustpilotReview.enabled),
                url: updated.trustpilotReview.url || '',
                viewThreshold: String(
                    updated.trustpilotReview.viewThreshold || 10
                ),
                delayDays: String(updated.trustpilotReview.delayDays ?? 1),
            })
            setLogRetention({
                defaultDays: String(updated.logRetention.defaultDays || 10),
                adminDays: String(updated.logRetention.adminDays || 10),
                userActivityDays: String(
                    updated.logRetention.userActivityDays || 10
                ),
                authDays: String(updated.logRetention.authDays || 10),
                securityDays: String(updated.logRetention.securityDays || 10),
                billingDays: String(updated.logRetention.billingDays || 10),
                applicationDays: String(
                    updated.logRetention.applicationDays || 10
                ),
            })
            setCustomDomains({
                edgeGatewayHost: updated.customDomains.edgeGatewayHost,
                verificationPrefix: updated.customDomains.verificationPrefix,
                autoSslEnabled: updated.customDomains.autoSslEnabled,
                sslContactEmail: updated.customDomains.sslContactEmail || '',
            })
            setDefaultPlanCurrency(updated.defaultPlanCurrency || 'USD')
            setPlatformMail({
                enabled: Boolean(updated.platformMail.enabled),
                configured: Boolean(updated.platformMail.configured),
                source: updated.platformMail.source || 'none',
                host: updated.platformMail.host || '',
                port:
                    updated.platformMail.port === null
                        ? '587'
                        : String(updated.platformMail.port),
                encryption: updated.platformMail.encryption || 'none',
                username: updated.platformMail.username || '',
                passwordSet: Boolean(updated.platformMail.passwordSet),
                fromEmail: updated.platformMail.fromEmail || '',
                fromName: updated.platformMail.fromName || 'WammuHost',
                replyToEmail: updated.platformMail.replyToEmail || '',
                ehloDomain: updated.platformMail.ehloDomain || '',
            })
            setNotificationEmailEnabled(
                Boolean(updated.notificationEmailEnabled)
            )
            setNotificationEmailAvailable(
                Boolean(updated.notificationEmailAvailable)
            )
            setNotificationEmailEffective(
                Boolean(updated.notificationEmailEffective)
            )
            setNotificationTemplates(updated.notificationTemplates || [])
            setPlatformMailPasswordDraft('')
            setPlatformUpgradeEnabled(Boolean(updated.platformUpgradeEnabled))
            setPlatformUpgradeUrlTemplate(
                updated.platformUpgradeUrlTemplate || ''
            )
            setFooterText(updated.footerText || 'WammuCore')
            setFooterUrl(updated.footerUrl || 'https://wammuhost.com')
            setTenantThemeKey(updated.tenantThemeKey || 'wammuhost')
            setBrandPrimaryColor(updated.brandPrimaryColor || '')
            setBrandSecondaryColor(updated.brandSecondaryColor || '')
            setBrandAccentColor(updated.brandAccentColor || '')
            setCustomCss(updated.customCss || '')

            applyDocumentFavicon(updated.faviconUrl)

            setStatus({ type: 'ok', text: 'Settings saved successfully.' })
        } catch {
            setStatus({ type: 'error', text: 'Failed to save settings. Please check values and try again.' })
        } finally {
            setIsSaving(false)
        }
    }

    const handleTestMail = async () => {
        setIsSendingTestMail(true)
        setStatus(null)

        try {
            const recipient = await sendPanelTestMail(
                testMailRecipient.trim() || null
            )
            setStatus({
                type: 'ok',
                text: `Test email sent to ${recipient}.`,
            })
        } catch {
            setStatus({
                type: 'error',
                text: 'Failed to send test email. Check SMTP settings and try again.',
            })
        } finally {
            setIsSendingTestMail(false)
        }
    }

    const updateNotificationTemplate = (
        key: string,
        patch: Partial<NotificationTemplate>
    ) => {
        setNotificationTemplates(current =>
            current.map(template =>
                template.key === key ? { ...template, ...patch } : template
            )
        )
    }

    const handleTemplateTest = async (templateKey: string) => {
        setTemplateTestLoading(templateKey)
        setStatus(null)

        try {
            const recipient = await sendPanelTestMail(
                testMailRecipient.trim() || null,
                templateKey
            )
            setStatus({
                type: 'ok',
                text: `Template preview sent to ${recipient}.`,
            })
        } catch {
            setStatus({
                type: 'error',
                text: 'Failed to send template preview. Check SMTP settings and save before testing again.',
            })
        } finally {
            setTemplateTestLoading(null)
        }
    }

    const resellerOpenRequests =
        (resellerVerificationSummary?.pending ?? 0) +
        (resellerVerificationSummary?.underReview ?? 0)

    const logRetentionFields = [
        ['defaultDays', 'Default window', 'Root logs, dashboards, and fallback cleanup'],
        ['adminDays', 'Admin logs', 'Root/admin audit and resolved alerts'],
        ['userActivityDays', 'User/VPS logs', 'Customer activity and per-VPS event logs'],
        ['authDays', 'Login logs', 'Login history, expired tokens, revoked sessions'],
        ['securityDays', 'Security logs', 'Security events and resolved abuse alerts'],
        ['billingDays', 'Billing logs', 'Paymenter/webhook/manual billing history'],
        ['applicationDays', 'App log files', 'Laravel log files in storage/logs'],
    ] as const

    return (
        <PageContentBlock title='Overview'>
            <div className='space-y-6'>
                {tenantContext && (
                    <div className='grid gap-3 sm:grid-cols-2 lg:grid-cols-4'>
                        <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                            <p className='text-xs uppercase tracking-wide text-white/50'>
                                Admin View
                            </p>
                            <p className='mt-1 text-sm font-semibold text-white'>
                                {tenantContext.mode === 'all'
                                    ? 'All Resellers'
                                    : tenantContext.mode === 'platform'
                                    ? 'Main Platform'
                                    : `Reseller: ${tenantContext.activeReseller?.displayName ?? 'Unknown'}`}
                            </p>
                        </div>
                        <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                            <p className='text-xs uppercase tracking-wide text-white/50'>
                                Users
                            </p>
                            <p className='mt-1 text-lg font-semibold text-white'>
                                {tenantContext.mode === 'all'
                                    ? tenantContext.global.users
                                    : tenantContext.scoped.users}
                            </p>
                        </div>
                        <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                            <p className='text-xs uppercase tracking-wide text-white/50'>
                                Servers
                            </p>
                            <p className='mt-1 text-lg font-semibold text-white'>
                                {tenantContext.mode === 'all'
                                    ? tenantContext.global.servers
                                    : tenantContext.scoped.servers}
                            </p>
                        </div>
                        <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                            <p className='text-xs uppercase tracking-wide text-white/50'>
                                Resellers
                            </p>
                            <p className='mt-1 text-lg font-semibold text-white'>
                                {tenantContext.global.resellers}
                            </p>
                        </div>
                    </div>
                )}

                {isMasterView && isRootAdmin ? (
                    <div className='space-y-4'>
                        <div
                            className={`rounded-[1.45rem] border p-5 shadow-[0_18px_50px_rgba(6,8,20,0.34)] ${
                                resellerOpenRequests > 0
                                    ? 'border-amber-400/30 bg-[radial-gradient(circle_at_top,rgba(251,191,36,0.16),transparent_36%),linear-gradient(180deg,rgba(37,25,6,0.98),rgba(14,10,4,0.98))]'
                                    : 'border-white/10 bg-[#1a1441]'
                            }`}
                        >
                            <div className='flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between'>
                                <div className='max-w-3xl'>
                                    <div className='inline-flex items-center gap-2 rounded-full border border-amber-400/20 bg-amber-500/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.24em] text-amber-100/80'>
                                        <BellAlertIcon className='h-4 w-4' />
                                        Reseller Requests
                                    </div>
                                    <h2 className='mt-4 text-2xl font-semibold text-white'>
                                        {resellerOpenRequests > 0
                                            ? `${resellerOpenRequests} reseller request${resellerOpenRequests === 1 ? '' : 's'} need review`
                                            : 'No reseller requests are waiting right now'}
                                    </h2>
                                    <div className='mt-3 flex flex-wrap gap-2 text-xs text-white/75'>
                                        <span className='rounded-full border border-white/10 bg-black/20 px-3 py-1'>
                                            Pending: {resellerVerificationSummary?.pending ?? 0}
                                        </span>
                                        <span className='rounded-full border border-white/10 bg-black/20 px-3 py-1'>
                                            Under review: {resellerVerificationSummary?.underReview ?? 0}
                                        </span>
                                        <span className='rounded-full border border-white/10 bg-black/20 px-3 py-1'>
                                            Rejected: {resellerVerificationSummary?.rejected ?? 0}
                                        </span>
                                        <span className='rounded-full border border-white/10 bg-black/20 px-3 py-1'>
                                            Suspended: {resellerVerificationSummary?.suspended ?? 0}
                                        </span>
                                    </div>
                                    {resellerVerificationError ? (
                                        <p className='mt-3 text-sm text-rose-200'>
                                            {resellerVerificationError}
                                        </p>
                                    ) : null}
                                </div>
                                <div className='flex flex-wrap items-center gap-3'>
                                    <Link
                                        to='/admin/resellers'
                                        className={`inline-flex items-center gap-2 rounded-2xl px-5 py-3 text-sm font-semibold transition ${
                                            resellerOpenRequests > 0
                                                ? 'border border-amber-300/35 bg-amber-500/15 text-amber-50 hover:bg-amber-500/25'
                                                : 'border border-white/10 bg-black/20 text-white/85 hover:bg-white/10'
                                        }`}
                                    >
                                        Review Requests
                                    </Link>
                                </div>
                            </div>
                        </div>
                        <div className='rounded-[1.6rem] border border-red-500/15 bg-[radial-gradient(circle_at_top,_rgba(239,68,68,0.18),_transparent_34%),linear-gradient(180deg,rgba(30,8,11,0.98),rgba(12,4,6,0.98))] p-6 shadow-[0_18px_60px_rgba(8,2,3,0.42)]'>
                            <div className='flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between'>
                                <div className='max-w-3xl'>
                                    <div className='inline-flex items-center gap-2 rounded-full border border-red-400/20 bg-red-500/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.28em] text-red-100/75'>
                                        <FireIcon className='h-4 w-4' />
                                        Core
                                    </div>
                                    <h2 className='mt-4 text-2xl font-semibold text-white'>
                                        Open the Core control center
                                    </h2>
                                    <p className='mt-3 text-sm leading-7 text-white/60'>
                                        Jump straight into queue health, worker status, failed jobs, and live control actions for the Core queue engine.
                                    </p>
                                </div>
                                <div className='flex flex-wrap items-center gap-3'>
                                    <Link
                                        to='/admin/core'
                                        className='inline-flex items-center gap-2 rounded-2xl border border-red-400/30 bg-red-500/12 px-5 py-3 text-sm font-semibold text-red-100 transition hover:bg-red-500/20'
                                    >
                                        <RocketLaunchIcon className='h-4 w-4' />
                                        Open Core
                                    </Link>
                                </div>
                            </div>
                        </div>
                        <div className='grid gap-3 sm:grid-cols-3'>
                            <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                                <p className='text-xs uppercase tracking-wide text-white/50'>Queue Pending</p>
                                <p className='mt-1 text-lg font-semibold text-white'>{queueWidget?.pendingJobs ?? '-'}</p>
                            </div>
                            <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                                <p className='text-xs uppercase tracking-wide text-white/50'>Throughput / min</p>
                                <p className='mt-1 text-lg font-semibold text-white'>{queueWidget?.throughput ?? '-'}</p>
                            </div>
                            <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                                <p className='text-xs uppercase tracking-wide text-white/50'>Failed Jobs</p>
                                <p className='mt-1 text-lg font-semibold text-white'>{queueWidget?.failedJobs ?? '-'}</p>
                            </div>
                        </div>
                        <div className='text-xs text-white/55'>
                            Status: <span className='font-medium text-white/80'>{queueWidget?.status ?? 'unknown'}</span>
                            {queueWidgetError ? <span className='ml-2 text-red-300'>{queueWidgetError}</span> : null}
                        </div>
                    </div>
                ) : isMasterView ? (
                    <div className='rounded-xl border border-amber-400/20 bg-amber-500/5 p-4 text-sm text-amber-100/80'>
                        Core queue controls and Horizon access are restricted to the root admin account only.
                    </div>
                ) : (
                    <div className='rounded-xl border border-indigo-400/20 bg-[#1a1441] p-4 text-sm text-white/70'>
                        Master-only sections (Core, IPAM, Nodes, Diagnostics, Tokens, Coterms, and global panel settings) are hidden in reseller view.
                    </div>
                )}

                {/* Version Info */}
                <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                    <p className='text-sm text-white/60'>Panel Version</p>
                    <p className='mt-1 text-lg font-semibold text-white'>{version}</p>
                </div>

                {/* Branding Settings */}
                {isMasterView ? (
                    <div className='rounded-xl border border-white/10 bg-[#1a1441] p-6'>
                        <h2 className='mb-2 text-lg font-semibold text-white'>Platform Settings</h2>
                        <p className='mb-5 text-sm text-white/55'>
                            Root-admin managed panel controls live here. Business settings stay in the GUI, while
                            low-level infrastructure and secret bootstrap values stay in env.
                        </p>

                    <div className='space-y-4'>
                        <div className='rounded-xl border border-white/10 bg-[#111a31] px-4 py-3'>
                            <h3 className='text-sm font-semibold text-white'>Platform Identity</h3>
                            <p className='mt-1 text-xs leading-6 text-white/55'>
                                Brand the main WammuHost panel, login experience, and default public links.
                            </p>
                        </div>
                        <div>
                            <label className='mb-2 block text-sm font-medium text-white/80'>
                                Panel Name
                            </label>
                            <input
                                type='text'
                                value={panelName}
                                onChange={e => setPanelName(e.target.value)}
                                placeholder='WammuCore'
                                className='w-full rounded-lg border border-white/15 bg-[#111a31] px-4 py-2.5 text-white placeholder:text-white/35 outline-none focus:border-indigo-400 transition-colors'
                            />
                        </div>

                        <div>
                            <label className='mb-2 block text-sm font-medium text-white/80'>
                                Logo URL
                            </label>
                            <input
                                type='text'
                                value={logoUrl}
                                onChange={(e) => setLogoUrl(e.target.value)}
                                placeholder='https://example.com/logo.png'
                                className='w-full rounded-lg border border-white/15 bg-[#111a31] px-4 py-2.5 text-white placeholder:text-white/35 outline-none focus:border-indigo-400 transition-colors'
                            />
                            <p className='mt-1.5 text-xs text-white/50'>
                                Used in sidebar and login page.
                            </p>
                        </div>

                        {logoUrl && (
                            <div>
                                <label className='mb-2 block text-sm font-medium text-white/80'>
                                    Preview
                                </label>
                                <div className='flex items-center justify-center rounded-lg border border-white/10 bg-[#111a31] p-4'>
                                    <SafeImage
                                        src={logoUrl} 
                                        alt='Logo preview'
                                        className='max-h-16 max-w-full object-contain'
                                        fallbackClassName='h-16 w-16'
                                        fallbackText={panelName}
                                    />
                                </div>
                            </div>
                        )}

                        <div>
                            <label className='mb-2 block text-sm font-medium text-white/80'>
                                Login Background Image URL
                            </label>
                            <input
                                type='text'
                                value={loginBackgroundImage}
                                onChange={e => setLoginBackgroundImage(e.target.value)}
                                placeholder='https://example.com/login-bg.jpg'
                                className='w-full rounded-lg border border-white/15 bg-[#111a31] px-4 py-2.5 text-white placeholder:text-white/35 outline-none focus:border-indigo-400 transition-colors'
                            />
                            <p className='mt-1.5 text-xs text-white/50'>
                                Optional background image for the login page.
                            </p>
                        </div>

                        <div>
                            <label className='mb-2 block text-sm font-medium text-white/80'>
                                Banner Image URL
                            </label>
                            <input
                                type='text'
                                value={bannerImageUrl}
                                onChange={e => setBannerImageUrl(e.target.value)}
                                placeholder='https://example.com/banner.jpg'
                                className='w-full rounded-lg border border-white/15 bg-[#111a31] px-4 py-2.5 text-white placeholder:text-white/35 outline-none focus:border-indigo-400 transition-colors'
                            />
                            <p className='mt-1.5 text-xs text-white/50'>
                                Optional banner image for login left panel.
                            </p>
                            {bannerImageUrl && (
                                <div className='mt-3 rounded-lg border border-white/10 bg-[#111a31] p-3'>
                                    <SafeImage
                                        src={bannerImageUrl}
                                        alt='Banner preview'
                                        className='w-full max-h-40 object-cover rounded'
                                        fallbackClassName='h-24 w-full rounded'
                                        fallbackText='Banner'
                                    />
                                </div>
                            )}
                        </div>

                        <div>
                            <label className='mb-2 block text-sm font-medium text-white/80'>
                                Favicon URL
                            </label>
                            <input
                                type='text'
                                value={faviconUrl}
                                onChange={e => setFaviconUrl(e.target.value)}
                                placeholder='https://example.com/favicon.png'
                                className='w-full rounded-lg border border-white/15 bg-[#111a31] px-4 py-2.5 text-white placeholder:text-white/35 outline-none focus:border-indigo-400 transition-colors'
                            />
                            <p className='mt-1.5 text-xs text-white/50'>
                                Browser tab icon. It updates immediately after saving.
                            </p>
                            {faviconUrl && (
                                <div className='mt-3 inline-flex items-center gap-3 rounded-lg border border-white/10 bg-[#111a31] px-3 py-2'>
                                    <SafeImage
                                        src={faviconUrl}
                                        alt='Favicon preview'
                                        className='h-6 w-6 rounded object-contain'
                                        fallbackClassName='h-6 w-6 rounded'
                                        fallbackText={panelName}
                                    />
                                    <a
                                        href={faviconUrl}
                                        target='_blank'
                                        rel='noreferrer'
                                        className='text-xs text-indigo-300 hover:text-indigo-200'
                                    >
                                        Open favicon URL
                                    </a>
                                </div>
                            )}
                        </div>

                        <div>
                            <label className='mb-2 block text-sm font-medium text-white/80'>
                                Loading Logo URL
                            </label>
                            <input
                                type='text'
                                value={loadingLogoUrl}
                                onChange={e => setLoadingLogoUrl(e.target.value)}
                                placeholder='https://example.com/loading-logo.png'
                                className='w-full rounded-lg border border-white/15 bg-[#111a31] px-4 py-2.5 text-white placeholder:text-white/35 outline-none focus:border-indigo-400 transition-colors'
                            />
                            <p className='mt-1.5 text-xs text-white/50'>
                                Used in full-screen loading screen.
                            </p>
                            {loadingLogoUrl && (
                                <div className='mt-3 inline-flex items-center gap-3 rounded-lg border border-white/10 bg-[#111a31] px-3 py-2'>
                                    <SafeImage
                                        src={loadingLogoUrl}
                                        alt='Loading logo preview'
                                        className='h-8 w-8 rounded object-contain'
                                        fallbackClassName='h-8 w-8 rounded'
                                        fallbackText={panelName}
                                    />
                                    <span className='text-xs text-white/55'>Loading logo preview</span>
                                </div>
                            )}
                        </div>

                        <div className='rounded-xl border border-white/10 bg-[#111a31] p-4'>
                            <div className='flex flex-col gap-3 md:flex-row md:items-start md:justify-between'>
                                <div>
                                    <h3 className='text-sm font-semibold text-white'>
                                        Default Panel Theme
                                    </h3>
                                    <p className='mt-1 text-xs leading-6 text-white/55'>
                                        Root default used by the main platform. Resellers can override it for their own brand.
                                    </p>
                                </div>
                                <select
                                    value={tenantThemeKey}
                                    onChange={event => {
                                        const theme = resolveThemePreset(event.currentTarget.value)
                                        setTenantThemeKey(theme.key)
                                        setBrandPrimaryColor(theme.primary)
                                        setBrandSecondaryColor(theme.secondary)
                                        setBrandAccentColor(theme.accent)
                                        previewPanelTheme(
                                            theme.key,
                                            theme.primary,
                                            theme.secondary,
                                            theme.accent
                                        )
                                    }}
                                    className='h-11 rounded-lg border border-white/15 bg-[#0d1325] px-3 text-sm font-semibold text-white outline-none focus:border-indigo-400'
                                >
                                    {THEME_PRESETS.map(theme => (
                                        <option key={theme.key} value={theme.key}>
                                            {theme.name}
                                        </option>
                                    ))}
                                </select>
                            </div>
                            <div className='mt-4 grid gap-4 lg:grid-cols-2 2xl:grid-cols-3'>
                                {THEME_PRESETS.map(theme => {
                                    const selected = tenantThemeKey === theme.key

                                    return (
                                        <button
                                            key={theme.key}
                                            type='button'
                                            onClick={() => {
                                                setTenantThemeKey(theme.key)
                                                setBrandPrimaryColor(theme.primary)
                                                setBrandSecondaryColor(theme.secondary)
                                                setBrandAccentColor(theme.accent)
                                                previewPanelTheme(
                                                    theme.key,
                                                    theme.primary,
                                                    theme.secondary,
                                                    theme.accent
                                                )
                                            }}
                                            className={`min-h-[168px] rounded-xl border p-4 text-left transition hover:-translate-y-0.5 ${
                                                selected
                                                    ? 'border-cyan-300/70 bg-cyan-400/10 shadow-[0_0_28px_rgba(34,211,238,0.18)]'
                                                    : 'border-white/10 bg-black/15 hover:border-white/25'
                                            }`}
                                        >
                                            <div
                                                className='h-16 rounded-lg border border-white/10'
                                                style={{
                                                    background: `radial-gradient(circle at top left, ${theme.accent}55, transparent 34%), linear-gradient(135deg, ${theme.secondary}, ${theme.background})`,
                                                }}
                                            />
                                            <div className='mt-3 flex min-h-[42px] items-start justify-between gap-3'>
                                                <span className='min-w-0 break-words text-sm font-semibold leading-5 text-white'>
                                                    {theme.name}
                                                </span>
                                                <span
                                                    className='h-4 w-4 shrink-0 rounded-full border border-white/30'
                                                    style={{ backgroundColor: theme.primary }}
                                                />
                                            </div>
                                            <p className='mt-1 text-xs leading-5 text-white/50'>
                                                {theme.description}
                                            </p>
                                        </button>
                                    )
                                })}
                            </div>
                            <div className='mt-4 grid gap-3 md:grid-cols-3'>
                                <div>
                                    <label className='mb-2 block text-xs font-semibold uppercase tracking-wide text-white/55'>
                                        Primary Color
                                    </label>
                                    <input
                                        type='text'
                                        value={brandPrimaryColor}
                                        onChange={event => {
                                            const value = event.target.value
                                            setBrandPrimaryColor(value)
                                            previewPanelTheme(
                                                tenantThemeKey,
                                                value,
                                                brandSecondaryColor,
                                                brandAccentColor
                                            )
                                        }}
                                        placeholder='#7c3aed'
                                        className='w-full rounded-lg border border-white/15 bg-[#0d1325] px-4 py-2.5 text-white placeholder:text-white/35 outline-none focus:border-indigo-400'
                                    />
                                </div>
                                <div>
                                    <label className='mb-2 block text-xs font-semibold uppercase tracking-wide text-white/55'>
                                        Secondary Color
                                    </label>
                                    <input
                                        type='text'
                                        value={brandSecondaryColor}
                                        onChange={event => {
                                            const value = event.target.value
                                            setBrandSecondaryColor(value)
                                            previewPanelTheme(
                                                tenantThemeKey,
                                                brandPrimaryColor,
                                                value,
                                                brandAccentColor
                                            )
                                        }}
                                        placeholder='#0b0430'
                                        className='w-full rounded-lg border border-white/15 bg-[#0d1325] px-4 py-2.5 text-white placeholder:text-white/35 outline-none focus:border-indigo-400'
                                    />
                                </div>
                                <div>
                                    <label className='mb-2 block text-xs font-semibold uppercase tracking-wide text-white/55'>
                                        Accent Color
                                    </label>
                                    <input
                                        type='text'
                                        value={brandAccentColor}
                                        onChange={event => {
                                            const value = event.target.value
                                            setBrandAccentColor(value)
                                            previewPanelTheme(
                                                tenantThemeKey,
                                                brandPrimaryColor,
                                                brandSecondaryColor,
                                                value
                                            )
                                        }}
                                        placeholder='#22d3ee'
                                        className='w-full rounded-lg border border-white/15 bg-[#0d1325] px-4 py-2.5 text-white placeholder:text-white/35 outline-none focus:border-indigo-400'
                                    />
                                </div>
                            </div>
                            <div className='mt-4'>
                                <label className='mb-2 block text-xs font-semibold uppercase tracking-wide text-white/55'>
                                    Global Custom CSS
                                </label>
                                <textarea
                                    value={customCss}
                                    onChange={event => {
                                        const value = event.currentTarget.value
                                        setCustomCss(value)
                                        previewPanelTheme(
                                            tenantThemeKey,
                                            brandPrimaryColor,
                                            brandSecondaryColor,
                                            brandAccentColor,
                                            value
                                        )
                                    }}
                                    placeholder='Optional CSS for advanced root branding.'
                                    className='h-28 w-full rounded-lg border border-white/15 bg-[#0d1325] px-4 py-3 text-sm text-white placeholder:text-white/35 outline-none focus:border-indigo-400'
                                />
                            </div>
                        </div>

                        <div className='rounded-xl border border-white/10 bg-[#111a31] px-4 py-3'>
                            <h3 className='text-sm font-semibold text-white'>Platform Commerce & Links</h3>
                            <p className='mt-1 text-xs leading-6 text-white/55'>
                                These links control where your own customers go for billing, store, docs, and tutorials.
                            </p>
                        </div>
                        <div>
                            <label className='mb-2 block text-sm font-medium text-white/80'>
                                Billing URL
                            </label>
                            <input
                                type='text'
                                value={billingUrl}
                                onChange={e => setBillingUrl(e.target.value)}
                                placeholder='https://billing.example.com'
                                className='w-full rounded-lg border border-white/15 bg-[#111a31] px-4 py-2.5 text-white placeholder:text-white/35 outline-none focus:border-indigo-400 transition-colors'
                            />
                            <p className='mt-1.5 text-xs text-white/50'>
                                Adds a Billing option in user sidebar/menu.
                            </p>
                        </div>

                        <div>
                            <label className='mb-2 block text-sm font-medium text-white/80'>
                                Platform Store Redirect URL
                            </label>
                            <input
                                type='text'
                                value={platformStoreRedirectUrl}
                                onChange={e =>
                                    setPlatformStoreRedirectUrl(
                                        e.target.value
                                    )
                                }
                                placeholder='https://billing.wammuhost.com/store'
                                className='w-full rounded-lg border border-white/15 bg-[#111a31] px-4 py-2.5 text-white placeholder:text-white/35 outline-none focus:border-indigo-400 transition-colors'
                            />
                            <p className='mt-1.5 text-xs text-white/50'>
                                Only main-platform users are redirected from
                                `/store` to this URL. Reseller stores are not
                                affected.
                            </p>
                        </div>

                        <div className='rounded-xl border border-white/10 bg-[#111a31] p-4'>
                            <div className='flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between'>
                                <div>
                                    <label className='block text-sm font-semibold text-white'>
                                        Platform Upgrade Button
                                    </label>
                                    <p className='mt-1 text-xs leading-5 text-white/50'>
                                        Controls whether platform users see VPS upgrade actions.
                                    </p>
                                </div>
                                <label className='inline-flex cursor-pointer items-center gap-3 rounded-full border border-white/12 bg-white/5 px-3 py-2 text-sm font-semibold text-white/80'>
                                    <input
                                        type='checkbox'
                                        checked={platformUpgradeEnabled}
                                        onChange={event =>
                                            setPlatformUpgradeEnabled(
                                                event.currentTarget.checked
                                            )
                                        }
                                        className='h-4 w-4 rounded border-white/20 bg-[#0d1325] text-indigo-500'
                                    />
                                    {platformUpgradeEnabled ? 'Enabled' : 'Disabled'}
                                </label>
                            </div>
                            <div className='mt-4'>
                                <label className='mb-2 block text-sm font-medium text-white/80'>
                                    Platform Upgrade URL Template
                                </label>
                                <input
                                    type='text'
                                    value={platformUpgradeUrlTemplate}
                                    onChange={event =>
                                        setPlatformUpgradeUrlTemplate(
                                            event.target.value
                                        )
                                    }
                                    placeholder='https://wammuhost.com/servers/services/<service_id>/upgrade'
                                    className='w-full rounded-lg border border-white/15 bg-[#0d1325] px-4 py-2.5 text-white placeholder:text-white/35 outline-none transition-colors focus:border-indigo-400'
                                />
                                <p className='mt-1.5 text-xs leading-5 text-white/50'>
                                    Use <span className='font-semibold text-cyan-200'>&lt;service_id&gt;</span> or <span className='font-semibold text-cyan-200'>&lt;s.id&gt;</span>. Example: service 5415 becomes <span className='font-semibold text-white'>/services/5415/upgrade</span>.
                                </p>
                            </div>
                        </div>

                        <div>
                            <label className='mb-2 block text-sm font-medium text-white/80'>
                                Developer API Documentation URL
                            </label>
                            <input
                                type='text'
                                value={apiDocsUrl}
                                onChange={e => setApiDocsUrl(e.target.value)}
                                placeholder='https://docs.example.com/api'
                                className='w-full rounded-lg border border-white/15 bg-[#111a31] px-4 py-2.5 text-white placeholder:text-white/35 outline-none focus:border-indigo-400 transition-colors'
                            />
                            <p className='mt-1.5 text-xs text-white/50'>
                                Shown as the developer docs button on the user API page.
                            </p>
                        </div>

                        <div>
                            <label className='mb-2 block text-sm font-medium text-white/80'>
                                Tutorials URL
                            </label>
                            <input
                                type='text'
                                value={tutorialUrl}
                                onChange={e => setTutorialUrl(e.target.value)}
                                placeholder='https://docs.example.com/tutorials'
                                className='w-full rounded-lg border border-white/15 bg-[#111a31] px-4 py-2.5 text-white placeholder:text-white/35 outline-none focus:border-indigo-400 transition-colors'
                            />
                            <p className='mt-1.5 text-xs text-white/50'>
                                Opens when users click the Tutorials button.
                            </p>
                        </div>

                        <div className='rounded-xl border border-emerald-400/20 bg-[radial-gradient(circle_at_top_left,rgba(16,185,129,0.12),transparent_36%),#111a31] p-4'>
                            <div className='flex flex-col gap-3 md:flex-row md:items-start md:justify-between'>
                                <div className='max-w-2xl'>
                                    <div className='inline-flex items-center gap-2 rounded-full border border-emerald-300/20 bg-emerald-400/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.24em] text-emerald-100/80'>
                                        <StarIcon className='h-4 w-4' />
                                        Trustpilot
                                    </div>
                                    <h3 className='mt-3 text-sm font-semibold text-white'>
                                        Customer Review Prompt
                                    </h3>
                                    <p className='mt-1 text-xs leading-6 text-white/55'>
                                        Shows a non-dismissable, once-per-account review popup to customer users only. Admin, root admin, and reseller admin accounts are excluded.
                                    </p>
                                </div>
                                <label className='inline-flex items-center gap-3 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-white/85'>
                                    <input
                                        type='checkbox'
                                        checked={trustpilotReview.enabled}
                                        onChange={event => {
                                            const checked = event.currentTarget.checked
                                            setTrustpilotReview(current => ({
                                                ...current,
                                                enabled: checked,
                                            }))
                                        }}
                                        className='h-4 w-4 rounded border border-white/20 bg-transparent'
                                    />
                                    {trustpilotReview.enabled ? 'Enabled' : 'Disabled'}
                                </label>
                            </div>

                            <div className='mt-4 grid gap-4 md:grid-cols-2'>
                                <div className='md:col-span-2'>
                                    <label className='mb-2 block text-sm font-medium text-white/80'>
                                        Trustpilot Review URL
                                    </label>
                                    <input
                                        type='text'
                                        value={trustpilotReview.url}
                                        onChange={event =>
                                            setTrustpilotReview(current => ({
                                                ...current,
                                                url: event.target.value,
                                            }))
                                        }
                                        placeholder='https://www.trustpilot.com/review/wammuhost.com'
                                        className='w-full rounded-lg border border-white/15 bg-[#0d1325] px-4 py-2.5 text-white placeholder:text-white/35 outline-none transition-colors focus:border-emerald-400'
                                    />
                                    <p className='mt-1.5 text-xs text-white/50'>
                                        The Rate us button redirects users to this page after marking the prompt complete.
                                    </p>
                                </div>
                                <div>
                                    <label className='mb-2 block text-sm font-medium text-white/80'>
                                        Show After Refreshes
                                    </label>
                                    <input
                                        type='number'
                                        min={1}
                                        max={10000}
                                        value={trustpilotReview.viewThreshold}
                                        onChange={event =>
                                            setTrustpilotReview(current => ({
                                                ...current,
                                                viewThreshold: event.target.value,
                                            }))
                                        }
                                        placeholder='10'
                                        className='w-full rounded-lg border border-white/15 bg-[#0d1325] px-4 py-2.5 text-white placeholder:text-white/35 outline-none transition-colors focus:border-emerald-400'
                                    />
                                    <p className='mt-1.5 text-xs text-white/50'>
                                        Example: set 20 to ask after the 20th customer panel load.
                                    </p>
                                </div>
                                <div>
                                    <label className='mb-2 block text-sm font-medium text-white/80'>
                                        Or After Days
                                    </label>
                                    <input
                                        type='number'
                                        min={0}
                                        max={365}
                                        value={trustpilotReview.delayDays}
                                        onChange={event =>
                                            setTrustpilotReview(current => ({
                                                ...current,
                                                delayDays: event.target.value,
                                            }))
                                        }
                                        placeholder='1'
                                        className='w-full rounded-lg border border-white/15 bg-[#0d1325] px-4 py-2.5 text-white placeholder:text-white/35 outline-none transition-colors focus:border-emerald-400'
                                    />
                                    <p className='mt-1.5 text-xs text-white/50'>
                                        Set 0 to use only the refresh threshold. Otherwise either threshold can trigger the prompt.
                                    </p>
                                </div>
                            </div>

                            <div className='mt-4 grid gap-3 md:grid-cols-3'>
                                <div className='rounded-lg border border-white/10 bg-[#0d1325] px-3 py-2 text-xs text-white/70'>
                                    <span className='block text-white/45'>Audience</span>
                                    <span className='mt-1 block font-semibold text-white/85'>
                                        Customers only
                                    </span>
                                </div>
                                <div className='rounded-lg border border-white/10 bg-[#0d1325] px-3 py-2 text-xs text-white/70'>
                                    <span className='block text-white/45'>Close behavior</span>
                                    <span className='mt-1 block font-semibold text-white/85'>
                                        Rate button required
                                    </span>
                                </div>
                                <div className='rounded-lg border border-white/10 bg-[#0d1325] px-3 py-2 text-xs text-white/70'>
                                    <span className='block text-white/45'>Per account</span>
                                    <span className='mt-1 block font-semibold text-white/85'>
                                        Shows once
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div className='rounded-xl border border-purple-300/20 bg-[radial-gradient(circle_at_top_left,rgba(168,85,247,0.12),transparent_35%),#111a31] p-4'>
                            <div className='flex flex-col gap-3 md:flex-row md:items-center md:justify-between'>
                                <div>
                                    <h3 className='text-sm font-semibold text-white'>
                                        Reseller Settings
                                    </h3>
                                    <p className='mt-1 text-xs leading-6 text-white/55'>
                                        Manage public reseller signup, registration legal links, and onboarding controls.
                                    </p>
                                </div>
                                <Link
                                    to='/admin/reseller-settings'
                                    className='inline-flex items-center justify-center rounded-lg border border-purple-300/25 bg-purple-500/10 px-4 py-2.5 text-sm font-semibold text-purple-100 transition hover:bg-purple-500/20'
                                >
                                    Open Reseller Settings
                                </Link>
                            </div>
                        </div>
                        <div className='rounded-xl border border-cyan-300/20 bg-[radial-gradient(circle_at_top_left,rgba(34,211,238,0.12),transparent_35%),#111a31] p-4'>
                            <div className='flex flex-col gap-3 md:flex-row md:items-center md:justify-between'>
                                <div>
                                    <h3 className='text-sm font-semibold text-white'>
                                        Email & Templates
                                    </h3>
                                    <p className='mt-1 text-xs leading-6 text-white/55'>
                                        Manage SMTP transport, password reset mail, reseller email verification, and notification templates.
                                    </p>
                                </div>
                                <Link
                                    to='/admin/email'
                                    className='inline-flex items-center justify-center rounded-lg border border-cyan-300/25 bg-cyan-500/10 px-4 py-2.5 text-sm font-semibold text-cyan-100 transition hover:bg-cyan-500/20'
                                >
                                    Open Email & Templates
                                </Link>
                            </div>
                        </div>
                        <div className='rounded-xl border border-white/10 bg-[#111a31] px-4 py-3'>
                            <h3 className='text-sm font-semibold text-white'>
                                Resource Usage Warnings
                            </h3>
                            <p className='mt-1 text-xs leading-6 text-white/55'>
                                Shows non-blocking CPU, RAM, disk, and bandwidth warnings to help users reduce load before service quality drops.
                            </p>
                        </div>

                        <div className='rounded-xl border border-white/10 bg-[#111a31] p-4'>
                            <div className='grid gap-4 md:grid-cols-2'>
                                <label className='inline-flex items-center gap-3 rounded-xl border border-white/10 bg-[#0d1325] px-4 py-3 text-sm text-white/85'>
                                    <input
                                        type='checkbox'
                                        checked={resourceGuard.enabled}
                                        onChange={event => {
                                            const checked = event.currentTarget.checked
                                            setResourceGuard(current => ({
                                                ...current,
                                                enabled: checked,
                                            }))
                                        }}
                                        className='h-4 w-4 rounded border border-white/20 bg-transparent'
                                    />
                                    Enable warnings
                                </label>
                                <div>
                                    <label className='mb-2 block text-sm font-medium text-white/80'>
                                        Warning threshold %
                                    </label>
                                    <input
                                        type='number'
                                        min={1}
                                        max={100}
                                        value={resourceGuard.thresholdPercent}
                                        onChange={event =>
                                            setResourceGuard(current => ({
                                                ...current,
                                                thresholdPercent:
                                                    event.target.value,
                                            }))
                                        }
                                        className='w-full rounded-lg border border-white/15 bg-[#0d1325] px-4 py-2.5 text-white outline-none focus:border-indigo-400 transition-colors'
                                    />
                                </div>
                            </div>
                            <p className='mt-3 text-xs leading-6 text-white/50'>
                                Warnings never stop, suspend, lock, or block VPS power actions. They only explain which resource is high and how to reduce usage.
                            </p>
                        </div>

                        <div className='rounded-xl border border-amber-300/20 bg-[radial-gradient(circle_at_top_left,rgba(251,191,36,0.12),transparent_34%),#111a31] p-4'>
                            <div className='flex flex-col gap-2 md:flex-row md:items-start md:justify-between'>
                                <div>
                                    <h3 className='text-sm font-semibold text-white'>
                                        Log Retention & Cleanup
                                    </h3>
                                    <p className='mt-1 text-xs leading-6 text-white/55'>
                                        Default is 10 days. The scheduler prunes old admin logs, user/VPS logs, auth history, security events, billing webhooks, and app log files so the database stays light.
                                    </p>
                                </div>
                                <span className='inline-flex rounded-full border border-amber-200/20 bg-amber-300/10 px-3 py-1 text-xs font-semibold text-amber-100'>
                                    Hourly database prune
                                </span>
                            </div>
                            <div className='mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3'>
                                {logRetentionFields.map(([field, label, helper]) => (
                                    <label
                                        key={field}
                                        className='rounded-xl border border-white/10 bg-[#0d1325] p-3'
                                    >
                                        <span className='block text-sm font-medium text-white/80'>
                                            {label}
                                        </span>
                                        <input
                                            type='number'
                                            min={1}
                                            max={3650}
                                            value={logRetention[field]}
                                            onChange={event =>
                                                setLogRetention(current => ({
                                                    ...current,
                                                    [field]: event.target.value,
                                                }))
                                            }
                                            className='mt-2 w-full rounded-lg border border-white/15 bg-[#090f20] px-3 py-2 text-sm text-white outline-none transition-colors focus:border-amber-300'
                                        />
                                        <span className='mt-1 block text-xs leading-5 text-white/45'>
                                            {helper}
                                        </span>
                                    </label>
                                ))}
                            </div>
                        </div>

                        <div className='rounded-xl border border-white/10 bg-[#111a31] px-4 py-3'>
                            <h3 className='text-sm font-semibold text-white'>Custom Domains & Plan Defaults</h3>
                            <p className='mt-1 text-xs leading-6 text-white/55'>
                                These are platform-wide reseller defaults for white-label VPS panel hostnames, TXT ownership checks, automatic SSL, and default pricing currency.
                            </p>
                        </div>

                        <div className='grid gap-4 md:grid-cols-2'>
                            <div>
                                <label className='mb-2 block text-sm font-medium text-white/80'>
                                    Edge Gateway Host
                                </label>
                                <input
                                    type='text'
                                    value={customDomains.edgeGatewayHost}
                                    onChange={e => {
                                        const value = e.target.value

                                        setCustomDomains(current => ({
                                            ...current,
                                            edgeGatewayHost: value,
                                        }))
                                    }}
                                    placeholder='edge.wammuhost.com'
                                    className='w-full rounded-lg border border-white/15 bg-[#111a31] px-4 py-2.5 text-white placeholder:text-white/35 outline-none focus:border-indigo-400 transition-colors'
                                />
                                <p className='mt-1.5 text-xs text-white/50'>
                                    Reseller custom domains should point their CNAME here. Use DNS CNAME/proxied CNAME only; URL forwarding to the edge host will break white-label routing and SSL.
                                </p>
                            </div>

                            <div>
                                <label className='mb-2 block text-sm font-medium text-white/80'>
                                    TXT Ownership Prefix
                                </label>
                                <input
                                    type='text'
                                    value={customDomains.verificationPrefix}
                                    onChange={e => {
                                        const value = e.target.value

                                        setCustomDomains(current => ({
                                            ...current,
                                            verificationPrefix: value,
                                        }))
                                    }}
                                    placeholder='_wammuhost-verify'
                                    className='w-full rounded-lg border border-white/15 bg-[#111a31] px-4 py-2.5 text-white placeholder:text-white/35 outline-none focus:border-indigo-400 transition-colors'
                                />
                                <p className='mt-1.5 text-xs text-white/50'>
                                    Users add a TXT record on their domain using this prefix. Example host/name: `_wammuhost-verify`; value: the verification token shown during domain setup.
                                </p>
                            </div>

                            <div>
                                <label className='mb-2 block text-sm font-medium text-white/80'>
                                    SSL Certificate Contact Email
                                </label>
                                <input
                                    type='email'
                                    value={customDomains.sslContactEmail}
                                    onChange={e => {
                                        const value = e.target.value

                                        setCustomDomains(current => ({
                                            ...current,
                                            sslContactEmail: value,
                                        }))
                                    }}
                                    placeholder='admin@wammuhost.com'
                                    className='w-full rounded-lg border border-white/15 bg-[#111a31] px-4 py-2.5 text-white placeholder:text-white/35 outline-none focus:border-indigo-400 transition-colors'
                                />
                                <p className='mt-1.5 text-xs text-white/50'>
                                    Fallback for SSL issuance and ACME notices. If blank, WammuCore uses the reseller owner or acting admin account email.
                                </p>
                            </div>

                            <div>
                                <label className='mb-2 block text-sm font-medium text-white/80'>
                                    Default Plan Currency
                                </label>
                                <input
                                    type='text'
                                    value={defaultPlanCurrency}
                                    onChange={e =>
                                        setDefaultPlanCurrency(
                                            e.target.value.toUpperCase()
                                        )
                                    }
                                    placeholder='USD'
                                    maxLength={3}
                                    className='w-full rounded-lg border border-white/15 bg-[#111a31] px-4 py-2.5 text-white placeholder:text-white/35 uppercase outline-none focus:border-indigo-400 transition-colors'
                                />
                            </div>

                            <div className='rounded-xl border border-white/10 bg-[#111a31] p-4'>
                                <label className='inline-flex items-center gap-3 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-white/85'>
                                    <input
                                        type='checkbox'
                                        checked={customDomains.autoSslEnabled}
                                        onChange={event => {
                                            const checked =
                                                event.currentTarget.checked

                                            setCustomDomains(current => ({
                                                ...current,
                                                autoSslEnabled: checked,
                                            }))
                                        }}
                                        className='h-4 w-4 rounded border border-white/20 bg-transparent'
                                    />
                                    Auto provision SSL after DNS passes
                                </label>
                                <p className='mt-3 text-xs leading-6 text-white/55'>
                                    Leave this on if you want verified reseller custom domains to move straight into SSL provisioning and activation.
                                </p>
                                {customDomains.autoSslEnabled && customDomains.sslContactEmail.trim() === '' ? (
                                    <p className='mt-2 rounded-lg border border-sky-300/25 bg-sky-500/10 px-3 py-2 text-xs text-sky-100'>
                                        If this is blank, SSL uses the reseller owner or acting admin email.
                                    </p>
                                ) : null}
                            </div>
                        </div>

                        <div className='rounded-xl border border-white/10 bg-[#111a31] px-4 py-3'>
                            <h3 className='text-sm font-semibold text-white'>Footer</h3>
                            <p className='mt-1 text-xs leading-6 text-white/55'>
                                Final text and link shown across the main platform panel.
                            </p>
                        </div>

                        <div>
                            <label className='mb-2 block text-sm font-medium text-white/80'>
                                Footer Text
                            </label>
                            <input
                                type='text'
                                value={footerText}
                                onChange={e => setFooterText(e.target.value)}
                                placeholder='WammuCore'
                                className='w-full rounded-lg border border-white/15 bg-[#111a31] px-4 py-2.5 text-white placeholder:text-white/35 outline-none focus:border-indigo-400 transition-colors'
                            />
                        </div>

                        <div>
                            <label className='mb-2 block text-sm font-medium text-white/80'>
                                Footer URL
                            </label>
                            <input
                                type='text'
                                value={footerUrl}
                                onChange={e => setFooterUrl(e.target.value)}
                                placeholder='https://wammuhost.com'
                                className='w-full rounded-lg border border-white/15 bg-[#111a31] px-4 py-2.5 text-white placeholder:text-white/35 outline-none focus:border-indigo-400 transition-colors'
                            />
                        </div>

                        {status && (
                            <div className={`p-3 rounded-lg text-sm ${status.type === 'ok'
                                    ? 'bg-green-900/30 text-green-400 border border-green-700'
                                    : 'bg-red-900/30 text-red-400 border border-red-700'
                            }`}>
                                {status.text}
                            </div>
                        )}

                        <div className='pt-2'>
                            <button
                                onClick={handleSave}
                                disabled={isSaving || isLoading}
                                className='rounded-lg bg-indigo-600 px-6 py-2.5 font-medium text-white transition-colors hover:bg-indigo-500 disabled:cursor-not-allowed disabled:bg-indigo-900/40'
                            >
                                {isLoading ? 'Loading...' : isSaving ? 'Saving...' : 'Save Changes'}
                            </button>
                        </div>
                    </div>
                </div>
                ) : null}
            </div>
        </PageContentBlock>
    )
}

export default OverviewContainer



