import {
    createResellerApiKey,
    getResellerApiKeys,
    ResellerApiKey,
    revokeResellerApiKey,
} from '@/api/admin/resellerPanel/manageApiKeys'
import {
    getResellerLogs,
    ResellerLogsResponse,
} from '@/api/admin/resellerPanel/manageLogs'
import getResellerOverview, {
    ResellerOverviewResponse,
} from '@/api/admin/resellerPanel/getResellerOverview'
import getResellerStatistics, {
    ResellerStatisticsResponse,
} from '@/api/admin/resellerPanel/getResellerStatistics'
import {
    getResellerCatalogOffers,
    ResellerCatalogOffer,
    ResellerPlanPoolOption,
    updateResellerCatalogOffer,
} from '@/api/admin/resellerPanel/managePlans'
import {
    cancelManualOrder,
    createManualOrder,
    getResellerOrders,
    getResellerOrdersCsvUrl,
    markManualOrderPaid,
    ResellerOrdersResponse,
    suspendManualOrder,
    unsuspendManualOrder,
    updateManualBillingSettings,
} from '@/api/admin/resellerPanel/manageOrders'
import {
    getResellerWholesaleCatalog,
    ResellerWholesaleCatalog,
} from '@/api/admin/resellerPanel/manageResources'
import {
    assignResellerDedicatedHardware,
    configureResellerDedicatedHardware,
    getResellerDedicatedHardware,
    ResellerDedicatedHardwarePlan,
    ResellerDedicatedHardwareResponse,
    updateResellerDedicatedHardwarePlans,
} from '@/api/admin/resellerPanel/manageDedicatedHardware'
import {
    createResellerTicket,
    getResellerTicket,
    getResellerTickets,
    replyToResellerTicket,
    ResellerTicket,
    ResellerTicketsResponse,
    updateResellerTicket,
} from '@/api/admin/resellerPanel/manageTickets'
import {
    createResellerSettingsDomain,
    deleteResellerSettingsDomain,
    getResellerSettings,
    regenerateResellerSettingsDomainToken,
    ResellerSettings,
    ResellerDomainVerificationResult,
    syncResellerSettingsDomains,
    updateResellerSettingsDomain,
    updateResellerSettings,
    verifyResellerSettingsDomain,
} from '@/api/admin/resellerPanel/manageResellerSettings'
import {
    getResellerPanelServices,
    getResellerServiceVnc,
    reassignResellerService,
    reinstallResellerService,
    ResellerPanelService,
    servicePowerAction,
    suspendResellerService,
    unsuspendResellerService,
} from '@/api/admin/resellerPanel/manageServices'
import { formatResourceGuardWarning } from '@/api/server/resourceGuard'
import {
    createSubReseller,
    deleteSubReseller,
    getSubResellers,
    SubReseller,
    updateSubReseller,
} from '@/api/admin/resellerPanel/manageSubResellers'
import {
    createResellerPanelUser,
    deleteResellerPanelUser,
    getResellerPanelUsers,
    ResellerPanelUser,
    resetResellerPanelUserPassword,
    updateResellerPanelUser,
} from '@/api/admin/resellerPanel/manageUsers'
import setTenantContext from '@/api/admin/tenancy/setTenantContext'
import useTenantContextSWR from '@/api/admin/tenancy/useTenantContextSWR'
import { httpErrorToHuman, PaginatedResult } from '@/api/http'
import { getResellerPrimaryRoutes } from '@/routers/resellerPrimaryRoutes'
import Button from '@/components/elements/Button'
import {
    NavigationBarContext,
    RouteDefinition,
} from '@/components/elements/navigation/NavigationBar'
import PageContentBlock from '@/components/elements/PageContentBlock'
import Spinner from '@/components/elements/Spinner'
import Checkbox from '@/components/elements/inputs/Checkbox'
import TextInput from '@/components/elements/inputs/TextInput'
import { useStoreActions, useStoreState } from '@/state'
import { applyDocumentFavicon } from '@/util/favicon'
import { appendStorefrontParams, normalizeExternalUrl } from '@/util/storefront'
import { THEME_PRESETS, resolveThemePreset } from '@/util/themePresets'
import { useDebouncedValue } from '@mantine/hooks'
import {
    ChangeEvent,
    FormEvent,
    useCallback,
    useContext,
    useEffect,
    useMemo,
    useState,
} from 'react'
import {
    Navigate,
    useLocation,
    useNavigate,
    useParams,
    useSearchParams,
} from 'react-router-dom'

type Section =
    | 'overview'
    | 'users'
    | 'services'
    | 'dedicated_hardware'
    | 'resources'
    | 'buy_servers'
    | 'buy_ips'
    | 'plans'
    | 'tickets'
    | 'logs'
    | 'settings'
    | 'sub_resellers'
    | 'api_keys'
    | 'orders'
    | 'statistics'

type FlashState = { type: 'ok' | 'error' | 'warning'; text: string } | null

type DomainStatusTone = 'success' | 'progress' | 'danger' | 'neutral'

type DomainValidationItem = {
    key: string
    label: string
    passed: boolean
    detail: string
}

type SectionNavItem = { key: Section; label: string; hint: string }

const domainInputPattern =
    /^(?:\*\.)?(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/

const reservedDomainSuffixes = [
    '.localhost',
    '.local',
    '.internal',
    '.test',
    '.invalid',
    '.example',
    '.home.arpa',
]

const normalizeDomainCandidate = (value: string): string =>
    value
        .trim()
        .toLowerCase()
        .replace(/^https?:\/\//i, '')
        .replace(/[/?#].*$/, '')
        .replace(/\.+$/, '')

const getDomainValidationItems = (
    value: string,
    existingDomains: string[],
    edgeGatewayHost: string
): DomainValidationItem[] => {
    const normalized = normalizeDomainCandidate(value)
    const wildcard = normalized.startsWith('*.')
    const internalOrReserved =
        normalized === 'localhost' ||
        reservedDomainSuffixes.some(suffix => normalized.endsWith(suffix))
    const duplicate = existingDomains.includes(normalized)
    const formatValid = normalized !== '' && domainInputPattern.test(normalized)
    const blacklisted = normalized === edgeGatewayHost

    return [
        {
            key: 'format',
            label: 'Hostname format',
            passed: formatValid,
            detail: formatValid
                ? 'Looks like a valid public hostname.'
                : 'Use a hostname like vps.clienthost.com.',
        },
        {
            key: 'duplicate',
            label: 'Duplicate check',
            passed: normalized !== '' && !duplicate,
            detail: duplicate
                ? 'This hostname is already attached to your reseller panel.'
                : 'No duplicate hostname found in your reseller workspace.',
        },
        {
            key: 'blacklist',
            label: 'Reserved domain check',
            passed: normalized !== '' && !blacklisted && !internalOrReserved,
            detail: blacklisted
                ? 'The shared edge hostname itself cannot be used as your panel hostname.'
                : internalOrReserved
                  ? 'Internal, localhost, and test-only domains are blocked.'
                  : 'Hostname is not using a blocked internal or reserved namespace.',
        },
        {
            key: 'wildcard',
            label: 'Wildcard rules',
            passed:
                normalized !== '' &&
                (!wildcard || (formatValid && normalized.split('.').length >= 3)),
            detail: wildcard
                ? 'Wildcard hostnames are allowed when they target a real subdomain base.'
                : 'Standard subdomain mode is ready.',
        },
    ]
}

const getDomainStatusMeta = (
    domain: ResellerSettings['domains'][number]
): { label: string; tone: DomainStatusTone } => {
    if (domain.routingStatus === 'active' && domain.sslStatus === 'active') {
        return { label: 'Active', tone: 'success' }
    }

    if (domain.sslStatus === 'provisioning') {
        return { label: 'SSL Provisioning', tone: 'progress' }
    }

    if (domain.dnsStatus === 'verified') {
        return { label: 'DNS Verified', tone: 'progress' }
    }

    if (domain.ownershipVerifiedAt) {
        return { label: 'Ownership Verified', tone: 'progress' }
    }

    if (domain.dnsStatus === 'failed' || domain.sslStatus === 'failed' || domain.lastError) {
        return { label: 'Failed', tone: 'danger' }
    }

    return { label: 'Pending Verification', tone: 'neutral' }
}

const getDomainStepState = (
    currentIndex: number,
    activeIndex: number,
    failed: boolean
): 'completed' | 'current' | 'pending' => {
    if (failed && currentIndex >= activeIndex) {
        return currentIndex === activeIndex ? 'current' : 'pending'
    }

    if (currentIndex < activeIndex) {
        return 'completed'
    }

    if (currentIndex === activeIndex) {
        return 'current'
    }

    return 'pending'
}

const getDomainProgress = (
    domain: ResellerSettings['domains'][number],
    verification: ResellerDomainVerificationResult | null
): Array<{ label: string; state: 'completed' | 'current' | 'pending' }> => {
    const routeIsActive = domain.routingStatus === 'active'
    const sslIsActive = domain.sslStatus === 'active'
    const cnameVerified = Boolean(
        verification?.directCnameVerified ||
            verification?.cloudflareDetected ||
            routeIsActive ||
            sslIsActive
    )
    const ownershipVerified = Boolean(
        verification?.ownershipVerified || domain.ownershipVerifiedAt
    )
    const sslProvisioned = Boolean(
        sslIsActive ||
            domain.sslStatus === 'provisioning' ||
            domain.sslProvisionedAt
    )
    const active = Boolean(
        routeIsActive && sslIsActive
    )
    const failed = Boolean(
        domain.dnsStatus === 'failed' ||
            domain.sslStatus === 'failed' ||
            domain.lastError
    )

    const activeIndex = active
        ? 4
        : sslProvisioned
          ? 3
          : ownershipVerified
            ? 2
            : cnameVerified
              ? 1
              : 0

    return [
        { label: 'Hostname Added', state: getDomainStepState(0, activeIndex, failed) },
        { label: 'CNAME Routed', state: getDomainStepState(1, activeIndex, failed) },
        { label: 'Ownership Verified', state: getDomainStepState(2, activeIndex, failed) },
        { label: 'SSL Ready', state: getDomainStepState(3, activeIndex, failed) },
        { label: 'Panel Active', state: getDomainStepState(4, activeIndex, failed) },
    ]
}

const domainBadgeToneClasses: Record<DomainStatusTone, string> = {
    success:
        'border-emerald-400/30 bg-emerald-500/15 text-emerald-100 shadow-[0_0_30px_rgba(16,185,129,0.16)]',
    progress:
        'border-cyan-400/30 bg-cyan-500/15 text-cyan-100 shadow-[0_0_30px_rgba(34,211,238,0.15)]',
    danger:
        'border-rose-400/30 bg-rose-500/15 text-rose-100 shadow-[0_0_30px_rgba(244,63,94,0.14)]',
    neutral:
        'border-white/15 bg-white/10 text-white/85 shadow-[0_0_20px_rgba(255,255,255,0.05)]',
}

const sectionGroups: Array<{ label: string; items: SectionNavItem[] }> = [
    {
        label: 'Workspace',
        items: [
            { key: 'overview', label: 'Dashboard', hint: 'Quota, billing, alerts' },
            {
                key: 'settings',
                label: 'Branding & Domains',
                hint: 'Logo, theme, footer, domains',
            },
        ],
    },
    {
        label: 'Customers',
        items: [
            { key: 'users', label: 'Customers', hint: 'Customer management' },
            { key: 'services', label: 'VPS', hint: 'Lifecycle and power actions' },
            { key: 'tickets', label: 'Support', hint: 'Ticket queue and replies' },
        ],
    },
    {
        label: 'Commerce',
        items: [
            { key: 'plans', label: 'Catalog & Pricing', hint: 'Store offers and pricing' },
            { key: 'buy_servers', label: 'Buy Servers', hint: 'Add wholesale VPS stock' },
            { key: 'buy_ips', label: 'Buy IPs', hint: 'Add reseller IP stock' },
            { key: 'orders', label: 'Billing', hint: 'Orders and revenue flow' },
        ],
    },
    {
        label: 'Infrastructure',
        items: [
            {
                key: 'dedicated_hardware',
                label: 'Dedicated Hardware',
                hint: 'Private Proxmox nodes',
            },
            { key: 'resources', label: 'Your Resources', hint: 'Purchased stock and usage' },
        ],
    },
    {
        label: 'Operations',
        items: [
            { key: 'api_keys', label: 'API Keys', hint: 'Automation credentials' },
            { key: 'logs', label: 'Security & Logs', hint: 'Protected admin trail' },
            { key: 'statistics', label: 'Analytics', hint: 'Growth and utilization' },
        ],
    },
]

const featureToggles: Array<{ key: string; label: string }> = [
    { key: 'disable_dashboard_overview', label: 'Disable dashboard overview' },
    { key: 'disable_style_changer', label: 'Disable style changer' },
    { key: 'enable_api_documentation', label: 'Enable API documentation' },
    { key: 'disable_novnc', label: 'Disable noVNC' },
    { key: 'enable_email_2fa', label: 'Enable email 2FA' },
    { key: 'allow_self_registration', label: 'Allow self registration' },
    { key: 'show_billing_link', label: 'Show billing link' },
]

type ApiScopeDefinition = {
    key: string
    label: string
    description: string
    mode: 'read' | 'write'
}

const resellerApiScopeGroups: Array<{
    label: string
    description: string
    scopes: ApiScopeDefinition[]
}> = [
    {
        label: 'Customers',
        description: 'Create reseller customers and open secure SSO flows.',
        scopes: [
            {
                key: 'users.read',
                label: 'Read customers',
                description: 'List users, view profiles, and generate customer SSO links.',
                mode: 'read',
            },
            {
                key: 'users.write',
                label: 'Manage customers',
                description: 'Create and update reseller customer accounts.',
                mode: 'write',
            },
        ],
    },
    {
        label: 'VPS Services',
        description: 'Provision and control VPS services owned by this reseller.',
        scopes: [
            {
                key: 'services.read',
                label: 'Read services',
                description: 'List VPS services, usage, VNC details, and service status.',
                mode: 'read',
            },
            {
                key: 'services.write',
                label: 'Manage services',
                description: 'Create, power, reinstall, suspend, and delete VPS services.',
                mode: 'write',
            },
        ],
    },
    {
        label: 'Store Catalog',
        description: 'Sync sellable plans and storefront metadata.',
        scopes: [
            {
                key: 'plans.read',
                label: 'Read plans',
                description: 'Fetch reseller plans, templates, prices, and locations.',
                mode: 'read',
            },
            {
                key: 'plans.write',
                label: 'Manage plans',
                description: 'Create, update, or remove reseller storefront plans.',
                mode: 'write',
            },
        ],
    },
    {
        label: 'Resource Pool',
        description: 'Check available stock before accepting orders.',
        scopes: [
            {
                key: 'pool.read',
                label: 'Read pool',
                description: 'View purchased VPS/IP stock and pool availability.',
                mode: 'read',
            },
        ],
    },
]

const resellerApiScopePresets: Array<{
    label: string
    description: string
    scopes: string[]
}> = [
    {
        label: 'Billing bridge',
        description: 'Recommended for trusted storefront provisioning.',
        scopes: [
            'users.read',
            'users.write',
            'services.read',
            'services.write',
            'plans.read',
            'pool.read',
        ],
    },
    {
        label: 'Read only',
        description: 'Safe for dashboards, audits, and reporting tools.',
        scopes: ['users.read', 'services.read', 'plans.read', 'pool.read'],
    },
    {
        label: 'Full automation',
        description: 'Use only for trusted provisioning systems.',
        scopes: resellerApiScopeGroups.flatMap(group =>
            group.scopes.map(scope => scope.key)
        ),
    },
]

const defaultApiKeyScopes = resellerApiScopePresets[0].scopes

const percentage = (used: number, max: number): number =>
    max > 0 ? Math.min(100, Math.round((used / max) * 100)) : 0

const compactNumber = (value: number): string =>
    new Intl.NumberFormat('en-US', { notation: 'compact', maximumFractionDigits: 1 }).format(
        Number.isFinite(value) ? value : 0
    )

const isResellerOnboardingLockError = (error: any): boolean => {
    const status = Number(error?.response?.status ?? 0)
    const code = String(error?.response?.data?.code ?? '')
    const message = String(error?.response?.data?.message ?? error?.message ?? '')

    return (
        status === 423 ||
        code === 'reseller_onboarding_required' ||
        /onboarding|verification|kyc/i.test(message)
    )
}

const resellerOnboardingLockedMessage =
    'This reseller has not completed onboarding yet. Operational reseller tools are locked until KYC, verification, and root-admin approval are complete.'

const formatMoney = (value: string | number | null | undefined): string => {
    const amount = Number(value ?? 0)

    if (!Number.isFinite(amount)) {
        return '0.00'
    }

    return amount.toFixed(2)
}

const normalizedPlanCategory = (category: string | null | undefined): string => {
    const value = String(category || '').trim()

    return value === '' ? 'General' : value
}

const planCategorySortWeight = (category: string): number => {
    const normalized = category.toLowerCase()

    if (normalized.includes('epyc')) return 10
    if (normalized.includes('ryzen')) return 20
    if (normalized.includes('intel')) return 90
    if (normalized === 'general') return 100

    return 50
}

const dedicatedHardwareStatusMeta = (
    status: string
): { label: string; className: string } => {
    switch (status) {
        case 'active':
            return {
                label: 'Node Active',
                className:
                    'border-emerald-400/30 bg-emerald-500/15 text-emerald-100',
            }
        case 'ready':
            return {
                label: 'Ready for Setup',
                className:
                    'border-cyan-400/30 bg-cyan-500/15 text-cyan-100',
            }
        case 'suspended':
            return {
                label: 'Suspended',
                className:
                    'border-rose-400/30 bg-rose-500/15 text-rose-100',
            }
        case 'retired':
            return {
                label: 'Retired',
                className:
                    'border-white/15 bg-white/10 text-white/60',
            }
        case 'pending':
        default:
            return {
                label: 'Pending Handover',
                className:
                    'border-amber-400/30 bg-amber-500/15 text-amber-100',
            }
    }
}

const toGbFromMb = (mb: number): string => `${(mb / 1024).toFixed(2)} GB`

const formatTimestamp = (value: string | null): string =>
    value ? new Date(value).toLocaleString() : 'Unknown'

const sidebarSections = sectionGroups.flatMap(group => group.items.map(item => item.key))

const isSidebarSection = (value: string | null): value is Section =>
    Boolean(value && sidebarSections.includes(value as Section))

const resellerRouteReference = (value?: string | null): string | null => {
    const normalized = String(value ?? '').trim().toLowerCase()

    return normalized !== '' ? normalized : null
}

const resellerAdminPathForReference = (value?: string | null): string => {
    const reference = resellerRouteReference(value)

    return reference ? `/admin/reseller-panel/r/${reference}` : '/admin/reseller-panel'
}

const resellerCustomerUrlForDomain = (
    hostname?: string | null,
    reference?: string | null
): string | null => {
    const normalizedHostname = String(hostname ?? '').trim()
    const normalizedReference = resellerRouteReference(reference)

    if (!normalizedHostname || !normalizedReference) {
        return null
    }

    const tenantPath = `/${encodeURIComponent(normalizedReference)}`

    if (/^https?:\/\//i.test(normalizedHostname)) {
        try {
            const url = new URL(normalizedHostname)
            url.pathname = tenantPath
            url.search = ''
            url.hash = ''

            return url.toString()
        } catch {
            return null
        }
    }

    const isLocalLikeHost =
        normalizedHostname === 'localhost' ||
        normalizedHostname.endsWith('.local') ||
        /^\d{1,3}(?:\.\d{1,3}){3}(?::\d+)?$/.test(normalizedHostname)

    const protocol = isLocalLikeHost ? window.location.protocol : 'https:'

    return `${protocol}//${normalizedHostname}${tenantPath}`
}

const onboardingPathForStep = (step?: string | null): string => {
    switch (step) {
        case 'email_verification':
            return '/admin/reseller-panel/onboarding/email-verification'
        case 'kyc_verification':
            return '/admin/reseller-panel/onboarding/kyc-verification'
        case 'admin_review':
            return '/admin/reseller-panel/onboarding/admin-review'
        case 'workspace_creation':
            return '/admin/reseller-panel/onboarding/workspace-creation'
        case 'branding_setup':
            return '/admin/reseller-panel/onboarding/branding-setup'
        case 'domain_setup':
            return '/admin/reseller-panel/onboarding/domain-setup'
        case 'dns_verification':
            return '/admin/reseller-panel/onboarding/dns-verification'
        case 'ssl_provisioning':
            return '/admin/reseller-panel/onboarding/ssl-provisioning'
        case 'personal_details':
        default:
            return '/admin/reseller-panel/onboarding/personal-details'
    }
}

const ResellerAdminPanelContainer = () => {
    const currentUser = useStoreState(state => state.user.data)
    const globalSettings = useStoreState(state => state.settings.data)
    const setGlobalSettings = useStoreActions(
        actions => actions.settings.setSettings
    )
    const platformBillingUrl = useStoreState(
        state => state.settings.data?.billingUrl || null
    )
    const userResellerId = currentUser?.resellerId
    const { resellerRef } = useParams()
    const location = useLocation()
    const navigate = useNavigate()
    const { setRoutes, setBreadcrumb } = useContext(NavigationBarContext)
    const [searchParams, setSearchParams] = useSearchParams()
    const { data: tenantContext, mutate: mutateTenantContext } =
        useTenantContextSWR()

    const [section, setSection] = useState<Section>('overview')
    const [flash, setFlash] = useState<FlashState>(null)
    const [loading, setLoading] = useState(false)
    const [repairingResellerContext, setRepairingResellerContext] =
        useState(false)

    const [overview, setOverview] = useState<ResellerOverviewResponse | null>(
        null
    )
    const [settings, setSettings] = useState<ResellerSettings | null>(null)
    const [domainVerificationResults, setDomainVerificationResults] = useState<
        Record<number, ResellerDomainVerificationResult>
    >({})
    const [domainChecking, setDomainChecking] = useState(false)
    const [domainActionIds, setDomainActionIds] = useState<number[]>([])
    const [lastDomainSyncAt, setLastDomainSyncAt] = useState<string | null>(null)
    const [copiedDomainField, setCopiedDomainField] = useState<string | null>(null)
    const [editingDomainId, setEditingDomainId] = useState<number | null>(null)
    const [editingDomainHostname, setEditingDomainHostname] = useState('')
    const [statistics, setStatistics] = useState<ResellerStatisticsResponse | null>(
        null
    )
    const [users, setUsers] = useState<PaginatedResult<ResellerPanelUser> | null>(
        null
    )
    const [services, setServices] = useState<
        PaginatedResult<ResellerPanelService> | null
    >(null)
    const [dedicatedHardware, setDedicatedHardware] =
        useState<ResellerDedicatedHardwareResponse | null>(null)
    const [dedicatedPlanDrafts, setDedicatedPlanDrafts] = useState<
        ResellerDedicatedHardwarePlan[]
    >([])
    const [catalog, setCatalog] = useState<ResellerCatalogOffer[]>([])
    const [catalogPoolOptions, setCatalogPoolOptions] = useState<
        ResellerPlanPoolOption[]
    >([])
    const [planDrafts, setPlanDrafts] = useState<
        Record<
            number,
            {
                planDisplayName: string
                monthlyPrice: string
                ipQuantity: number
                addressPoolId: string
                ipPriceEach: string
                backupLimitOverride: string
                isVisible: boolean
            }
        >
    >({})
    const [isSavingPlanPrice, setIsSavingPlanPrice] = useState<
        Record<number, boolean>
    >({})
    const [subResellers, setSubResellers] = useState<SubReseller[]>([])
    const [apiKeys, setApiKeys] = useState<ResellerApiKey[]>([])
    const [logsData, setLogsData] = useState<ResellerLogsResponse | null>(null)
    const [orders, setOrders] = useState<ResellerOrdersResponse | null>(null)
    const [tickets, setTickets] = useState<ResellerTicketsResponse | null>(null)
    const [selectedTicket, setSelectedTicket] = useState<ResellerTicket | null>(null)
    const [wholesaleCatalog, setWholesaleCatalog] =
        useState<ResellerWholesaleCatalog | null>(null)
    const [plainApiKey, setPlainApiKey] = useState<string | null>(null)
    const groupedWholesalePlans = useMemo(() => {
        const groups = new Map<
            string,
            NonNullable<ResellerWholesaleCatalog['plans']>
        >()

        ;(wholesaleCatalog?.plans || []).forEach(plan => {
            const category = normalizedPlanCategory(plan.category)
            const current = groups.get(category) || []
            current.push(plan)
            groups.set(category, current)
        })

        return Array.from(groups.entries())
            .map(([category, plans]) => ({
                category,
                plans: plans.sort((left, right) => left.id - right.id),
            }))
            .sort((left, right) => {
                const weighted =
                    planCategorySortWeight(left.category) -
                    planCategorySortWeight(right.category)

                return weighted !== 0
                    ? weighted
                    : left.category.localeCompare(right.category)
            })
    }, [wholesaleCatalog?.plans])

    const [usersPage, setUsersPage] = useState(1)
    const [servicesPage, setServicesPage] = useState(1)
    const [ordersPage, setOrdersPage] = useState(1)
    const [ticketsPage, setTicketsPage] = useState(1)
    const [usersQuery, setUsersQuery] = useState('')
    const [servicesQuery, setServicesQuery] = useState('')
    const [ordersQuery, setOrdersQuery] = useState('')
    const [ticketsQuery, setTicketsQuery] = useState('')
    const [ordersStatus, setOrdersStatus] = useState('')
    const [ticketsStatus, setTicketsStatus] = useState('')
    const [ticketsPriority, setTicketsPriority] = useState('')
    const [manualBillingEnabled, setManualBillingEnabled] = useState(true)
    const [manualBillingAutoSuspendEnabled, setManualBillingAutoSuspendEnabled] =
        useState(true)
    const [manualBillingGraceDays, setManualBillingGraceDays] = useState(30)
    const [manualBillingDeleteSuspendedEnabled, setManualBillingDeleteSuspendedEnabled] =
        useState(false)
    const [manualBillingDeleteSuspendedDays, setManualBillingDeleteSuspendedDays] =
        useState(3)
    const [manualCustomerName, setManualCustomerName] = useState('')
    const [manualCustomerEmail, setManualCustomerEmail] = useState('')
    const [manualCustomerPassword, setManualCustomerPassword] = useState('')
    const [manualCatalogPlanId, setManualCatalogPlanId] = useState('')
    const [manualHostname, setManualHostname] = useState('')
    const [manualOperatingSystem, setManualOperatingSystem] = useState('Ubuntu-22-04')
    const [manualRootPassword, setManualRootPassword] = useState('')
    const [manualAmount, setManualAmount] = useState('')
    const [manualCurrency, setManualCurrency] = useState('INR')
    const [manualBillingCycle, setManualBillingCycle] = useState<
        'one_time' | 'monthly' | 'quarterly' | 'semi_annually' | 'yearly'
    >('monthly')
    const [manualDueAt, setManualDueAt] = useState('')
    const [manualProvisionOnPaid, setManualProvisionOnPaid] = useState(true)
    const [manualMarkPaidNow, setManualMarkPaidNow] = useState(false)
    const [manualNotes, setManualNotes] = useState('')
    const [manualProvisionSecret, setManualProvisionSecret] = useState<{
        orderNumber: string
        rootPassword: string
    } | null>(null)
    const [debouncedUsersQuery] = useDebouncedValue(usersQuery, 250)
    const [debouncedServicesQuery] = useDebouncedValue(servicesQuery, 250)
    const [debouncedOrdersQuery] = useDebouncedValue(ordersQuery, 250)
    const [debouncedTicketsQuery] = useDebouncedValue(ticketsQuery, 250)

    useEffect(() => {
        if (settings) {
            applyDocumentFavicon(settings.faviconUrl)
        }
    }, [settings?.faviconUrl])

    useEffect(() => {
        if (dedicatedHardware) {
            setDedicatedPlanDrafts(dedicatedHardware.dedicatedPlans)
        }
    }, [dedicatedHardware?.dedicatedPlans])

    const [newUserName, setNewUserName] = useState('')
    const [newUserEmail, setNewUserEmail] = useState('')
    const [newUserPassword, setNewUserPassword] = useState('')
    const [newUserSupportPin, setNewUserSupportPin] = useState('')
    const [newUserAutoGeneratePassword, setNewUserAutoGeneratePassword] =
        useState(true)
    const [newUserMustChangePassword, setNewUserMustChangePassword] =
        useState(true)
    const [createdCustomerSecret, setCreatedCustomerSecret] = useState<{
        email: string
        password: string
    } | null>(null)
    const [newApiKeyName, setNewApiKeyName] = useState('')
    const [newApiKeyScopes, setNewApiKeyScopes] = useState<string[]>([
        ...defaultApiKeyScopes,
    ])
    const [newCustomDomain, setNewCustomDomain] = useState('')
    const [smtpPasswordDraft, setSmtpPasswordDraft] = useState('')
    const [newTicketSubject, setNewTicketSubject] = useState('')
    const [newTicketPriority, setNewTicketPriority] = useState<
        'low' | 'medium' | 'high' | 'urgent'
    >('medium')
    const [newTicketCustomerName, setNewTicketCustomerName] = useState('')
    const [newTicketCustomerEmail, setNewTicketCustomerEmail] = useState('')
    const [newTicketUserId, setNewTicketUserId] = useState('')
    const [newTicketServerId, setNewTicketServerId] = useState('')
    const [newTicketBody, setNewTicketBody] = useState('')
    const [ticketReplyBody, setTicketReplyBody] = useState('')
    const [subName, setSubName] = useState('')
    const [subDomain, setSubDomain] = useState('')
    const [subBackendDomain, setSubBackendDomain] = useState('')
    const [subLiveDataDomain, setSubLiveDataDomain] = useState('')
    const [subNovncDomain, setSubNovncDomain] = useState('')
    const [subCdnDomain, setSubCdnDomain] = useState('')
    const [subStatus, setSubStatus] = useState<'pending' | 'active' | 'suspended'>('pending')
    const [subMaxRamMb, setSubMaxRamMb] = useState('1024')
    const [subMaxCpuCores, setSubMaxCpuCores] = useState('1')
    const [subMaxDiskGb, setSubMaxDiskGb] = useState('20')
    const [subMaxVms, setSubMaxVms] = useState('5')

    const resellerName =
        overview?.reseller.displayName ||
        tenantContext?.activeReseller?.displayName ||
        'Reseller'
    const ownerImpersonating = Boolean(
        overview?.impersonation.ownerImpersonating ||
            settings?.impersonation.ownerImpersonating
    )
    const isResellerOnlyAdmin = Boolean(
        currentUser?.resellerAdmin &&
            !currentUser?.rootAdmin &&
            !currentUser?.platformAdmin
    )
    const contextResellerCanOperate = Boolean(
        tenantContext?.activeReseller?.status === 'active' &&
            tenantContext.activeReseller.verificationStatus === 'approved' &&
            tenantContext.activeReseller.onboardingStatus === 'completed'
    )
    const resellerCanOperate = Boolean(
        overview?.access.canOperate ?? contextResellerCanOperate
    )
    const resellerBlockedReason = overview?.access.blockedReason ?? null
    const verificationLocked = Boolean(overview || tenantContext?.activeReseller) && !resellerCanOperate
    const ownerCanBypassVerificationLock = Boolean(
        currentUser?.rootAdmin || ownerImpersonating
    )
    const verificationBlocksOperationalPanel =
        verificationLocked && !ownerCanBypassVerificationLock
    const operationalAccessResolved = Boolean(overview || tenantContext?.activeReseller)
    const forceOnboardingOnly = Boolean(
        isResellerOnlyAdmin && !ownerImpersonating && verificationLocked
    )
    const operationalPanelLocked =
        !operationalAccessResolved ||
        verificationBlocksOperationalPanel ||
        forceOnboardingOnly
    const forcedOnboardingPath =
        overview?.onboarding.currentPath ||
        onboardingPathForStep(tenantContext?.activeReseller?.onboardingCurrentStep)
    const subResellerCreationEnabled = Boolean(
        ownerImpersonating ||
            settings?.allowSubResellers ||
            settings?.featureFlags?.enable_subresellers
    )
    const parentPanelDomain =
        settings?.domains.find(
            domain => domain.isPrimary || domain.purpose === 'panel'
        )?.hostname ?? null
    const preferredCustomerPanelDomain = useMemo(() => {
        if (settings?.domains?.length) {
            const orderedDomains = [...settings.domains].sort((left, right) => {
                const leftScore =
                    (left.isPrimary ? 8 : 0) +
                    (left.routingStatus === 'active' ? 4 : 0) +
                    (left.sslStatus === 'active' ? 2 : 0) +
                    (left.dnsStatus === 'verified' ? 1 : 0)
                const rightScore =
                    (right.isPrimary ? 8 : 0) +
                    (right.routingStatus === 'active' ? 4 : 0) +
                    (right.sslStatus === 'active' ? 2 : 0) +
                    (right.dnsStatus === 'verified' ? 1 : 0)

                return rightScore - leftScore
            })

            const bestMatch = orderedDomains.find(
                domain => domain.hostname.trim() !== ''
            )

            if (bestMatch) {
                return bestMatch.hostname
            }
        }

        return overview?.reseller.domain?.trim() || parentPanelDomain || null
    }, [overview?.reseller.domain, parentPanelDomain, settings?.domains])
    const preferredCustomerPanelReference =
        resellerRouteReference(overview?.reseller?.uuid) ||
        resellerRouteReference(overview?.reseller?.slug) ||
        resellerRouteReference(tenantContext?.activeReseller?.uuid) ||
        resellerRouteReference(tenantContext?.activeReseller?.slug) ||
        resellerRouteReference(tenantContext?.hostReseller?.uuid) ||
        resellerRouteReference(tenantContext?.hostReseller?.slug)
    const resellerCustomerPanelUrl = useMemo(() => {
        if (!preferredCustomerPanelDomain || !preferredCustomerPanelReference) {
            return null
        }

        return resellerCustomerUrlForDomain(
            preferredCustomerPanelDomain,
            preferredCustomerPanelReference
        )
    }, [preferredCustomerPanelDomain, preferredCustomerPanelReference])
    const resellerIdentity =
        overview?.reseller ||
        tenantContext?.activeReseller ||
        tenantContext?.hostReseller ||
        null
    const resellerInternalId = resellerIdentity?.id ?? null
    const resellerImmutableReference =
        resellerRouteReference(resellerIdentity?.uuid) ||
        resellerRouteReference(resellerIdentity?.slug)
    const resellerCanonicalPath = resellerAdminPathForReference(
        resellerImmutableReference
    )
    const resellerSlug = resellerRouteReference(resellerIdentity?.slug)
    const resellerDomain = resellerIdentity?.domain?.trim() || preferredCustomerPanelDomain
    const existingResellerDomains = useMemo(
        () =>
            settings?.domains.map(domain =>
                normalizeDomainCandidate(domain.hostname)
            ) ?? [],
        [settings?.domains]
    )
    const newDomainValidation = useMemo(
        () =>
            getDomainValidationItems(
                newCustomDomain,
                existingResellerDomains,
                settings?.domainMeta.edgeGatewayHost ?? 'edge.wammuhost.com'
            ),
        [existingResellerDomains, newCustomDomain, settings?.domainMeta.edgeGatewayHost]
    )
    const canSubmitNewDomain =
        newCustomDomain.trim() !== '' && newDomainValidation.every(item => item.passed)
    const selectedApiScopes = useMemo(
        () => new Set(newApiKeyScopes),
        [newApiKeyScopes]
    )
    const canCreateApiKey =
        newApiKeyName.trim().length >= 2 && selectedApiScopes.size > 0
    const toggleApiScope = useCallback((scope: string) => {
        setNewApiKeyScopes(current => {
            const next = new Set(current)

            if (next.has(scope)) {
                next.delete(scope)
            } else {
                next.add(scope)
            }

            return Array.from(next)
        })
    }, [])
    const applyApiScopePreset = useCallback((scopes: string[]) => {
        setNewApiKeyScopes(Array.from(new Set(scopes)))
    }, [])
    const toggleApiScopeGroup = useCallback(
        (scopes: string[]) => {
            const allSelected = scopes.every(scope => selectedApiScopes.has(scope))

            setNewApiKeyScopes(current => {
                const next = new Set(current)

                scopes.forEach(scope => {
                    if (allSelected) {
                        next.delete(scope)
                    } else {
                        next.add(scope)
                    }
                })

                return Array.from(next)
            })
        },
        [selectedApiScopes]
    )
    const pendingDomainIds = useMemo(
        () =>
            settings?.domains
                .filter(
                    domain =>
                        domain.id > 0 &&
                        (
                            domain.routingStatus !== 'active' ||
                            domain.sslStatus !== 'active' ||
                            domain.dnsStatus !== 'verified' ||
                            Boolean(domain.lastError)
                        )
                )
                .map(domain => domain.id) ?? [],
        [settings?.domains]
    )
    const nestedResellerContext =
        !ownerImpersonating &&
        tenantContext?.mode === 'reseller' &&
        !!userResellerId &&
        tenantContext.activeReseller?.id !== userResellerId

    const resellerNavRoutes = useMemo<RouteDefinition[]>(
        () =>
            getResellerPrimaryRoutes({
                includeOnboarding: forceOnboardingOnly,
                operationalLocked: operationalPanelLocked,
            }),
        [forceOnboardingOnly, operationalPanelLocked]
    )

    const openSection = useCallback(
        (next: Section) => {
            if (forceOnboardingOnly) {
                navigate(forcedOnboardingPath, { replace: true })

                return
            }

            if (verificationBlocksOperationalPanel && next !== 'overview') {
                navigate(resellerCanonicalPath, { replace: true })
                setSection('overview')

                return
            }

            setSection(next)

            const nextParams = new URLSearchParams(searchParams)

            if (next === 'overview') {
                nextParams.delete('section')
            } else {
                nextParams.set('section', next)
            }

            setSearchParams(nextParams, { replace: true })
        },
        [
            forceOnboardingOnly,
            forcedOnboardingPath,
            navigate,
            resellerCanonicalPath,
            searchParams,
            setSearchParams,
            verificationBlocksOperationalPanel,
        ]
    )

    const openCustomerPanel = useCallback(() => {
        if (!resellerCustomerPanelUrl) {
            setFlash({
                type: 'error',
                text: 'Add and verify a reseller hostname first in Domains & Branding to open the customer-facing panel.',
            })
            openSection('settings')

            return
        }

        window.open(
            resellerCustomerPanelUrl,
            '_blank',
            'noopener,noreferrer'
        )
    }, [openSection, resellerCustomerPanelUrl])

    const openResourceCheckout = useCallback(
        (
            resourceType: 'vps_plan' | 'ip_pool',
            resourceId: number,
            resourceName: string
        ) => {
            const storefrontUrl = normalizeExternalUrl(platformBillingUrl)

            if (!storefrontUrl) {
                setFlash({
                    type: 'warning',
                    text: 'Set the platform billing URL before opening the reseller resource purchase page.',
                })
                openSection('settings')

                return
            }

            const target = appendStorefrontParams(storefrontUrl, {
                wammu_audience: 'reseller_resource',
                wammu_resource_type: resourceType,
                catalog_plan_id: resourceType === 'vps_plan' ? resourceId : null,
                address_pool_id: resourceType === 'ip_pool' ? resourceId : null,
                resource_name: resourceName,
            })

            window.location.assign(target)
        },
        [openSection, platformBillingUrl]
    )

    const markDomainAction = useCallback((domainId: number, busy: boolean) => {
        setDomainActionIds(current =>
            busy
                ? Array.from(new Set([...current, domainId]))
                : current.filter(id => id !== domainId)
        )
    }, [])

    const copyDomainValue = useCallback(async (key: string, value: string) => {
        try {
            await navigator.clipboard.writeText(value)
            setCopiedDomainField(key)
            window.setTimeout(() => {
                setCopiedDomainField(current => (current === key ? null : current))
            }, 1800)
            setFlash({
                type: 'ok',
                text: 'Copied to clipboard.',
            })
        } catch (error) {
            setFlash({
                type: 'error',
                text: httpErrorToHuman(error),
            })
        }
    }, [])

    const copyCreatedCustomerPassword = useCallback(async (password: string) => {
        try {
            await navigator.clipboard.writeText(password)
            setFlash({
                type: 'ok',
                text: 'Customer password copied to clipboard.',
            })
        } catch (error) {
            setFlash({
                type: 'error',
                text: httpErrorToHuman(error),
            })
        }
    }, [])

    const syncPendingCustomDomains = useCallback(
        async (silent = false) => {
            if (pendingDomainIds.length === 0) {
                return
            }

            if (!silent) {
                setDomainChecking(true)
                setFlash(null)
            }

            try {
                const result = await syncResellerSettingsDomains()
                setSettings(result.settings)
                setLastDomainSyncAt(new Date().toISOString())
                if (result.results.length > 0) {
                    setDomainVerificationResults(current => {
                        const next = { ...current }
                        result.results.forEach(item => {
                            const domain = result.settings.domains.find(
                                candidate => candidate.hostname === item.hostname
                            )

                            if (domain?.id) {
                                next[domain.id] = item
                            }
                        })

                        return next
                    })
                }

                if (!silent && result.results.length > 0) {
                    const passedCount = result.results.filter(item => item.passed).length
                    setFlash({
                        type: passedCount === result.results.length ? 'ok' : 'error',
                        text:
                            passedCount === result.results.length
                                ? 'All pending hostname checks completed successfully.'
                                : 'Live DNS check finished. Review any remaining failed items below.',
                    })
                }
            } catch (error) {
                if (!silent) {
                    setFlash({ type: 'error', text: httpErrorToHuman(error) })
                }
            } finally {
                if (!silent) {
                    setDomainChecking(false)
                }
            }
        },
        [pendingDomainIds.length]
    )

    const run = async (job: () => Promise<void>) => {
        setLoading(true)
        setFlash(null)
        try {
            await job()
        } catch (error) {
            if (isResellerOnboardingLockError(error)) {
                setFlash({
                    type: 'warning',
                    text: resellerBlockedReason || resellerOnboardingLockedMessage,
                })

                return
            }

            setFlash({ type: 'error', text: httpErrorToHuman(error) })
        } finally {
            setLoading(false)
        }
    }

    const refreshOverview = async () =>
        run(async () => setOverview(await getResellerOverview()))

    const refreshResourceMarketplace = async () =>
        run(async () => {
            const [overviewData, catalogData] = await Promise.all([
                getResellerOverview(),
                getResellerWholesaleCatalog(),
            ])

            setOverview(overviewData)
            setWholesaleCatalog(catalogData)
        })

    const refreshUsers = async () =>
        run(async () =>
            setUsers(
                await getResellerPanelUsers({
                    page: usersPage,
                    perPage: 25,
                    query: debouncedUsersQuery || undefined,
                })
            )
        )

    const refreshServices = async () =>
        run(async () =>
            setServices(
                await getResellerPanelServices({
                    page: servicesPage,
                    perPage: 25,
                    query: debouncedServicesQuery || undefined,
                })
            )
        )

    const refreshDedicatedHardware = async () =>
        run(async () => {
            const response = await getResellerDedicatedHardware()
            setDedicatedHardware(response)
            if (response.warning) {
                setFlash({ type: 'warning', text: response.warning })
            }
        })

    const refreshPlans = async () =>
        run(async () => {
            const response = await getResellerCatalogOffers()
            const offers = response.items
            setCatalog(offers)
            setCatalogPoolOptions(response.poolOptions)
            setPlanDrafts(
                offers.reduce(
                    (acc, offer) => {
                        acc[offer.catalogPlanId] = {
                            planDisplayName: offer.pricing.planDisplayName ?? '',
                            monthlyPrice: offer.pricing.monthlyPrice ?? '',
                            ipQuantity: Number(offer.pricing.ipQuantity ?? 0),
                            addressPoolId:
                                offer.pricing.addressPoolId === null
                                    ? ''
                                    : String(offer.pricing.addressPoolId),
                            ipPriceEach: String(offer.pricing.ipPriceEach ?? '0.00'),
                            backupLimitOverride:
                                offer.pricing.backupLimitOverride === null
                                    ? ''
                                    : String(offer.pricing.backupLimitOverride),
                            isVisible: Boolean(offer.pricing.isVisible),
                        }

                        return acc
                    },
                    {} as Record<
                        number,
                        {
                            planDisplayName: string
                            monthlyPrice: string
                            ipQuantity: number
                            addressPoolId: string
                            ipPriceEach: string
                            backupLimitOverride: string
                            isVisible: boolean
                        }
                    >
                )
            )
        })

    const refreshSettings = async () =>
        run(async () => setSettings(await getResellerSettings()))

    const refreshSubResellers = async () =>
        run(async () => setSubResellers(await getSubResellers()))

    const refreshApiKeys = async () =>
        run(async () => setApiKeys(await getResellerApiKeys()))

    const refreshLogs = async () =>
        run(async () => setLogsData(await getResellerLogs()))

    const refreshOrders = async () =>
        run(async () =>
            setOrders(
                await getResellerOrders({
                    page: ordersPage,
                    perPage: 25,
                    query: debouncedOrdersQuery || undefined,
                    status: ordersStatus || undefined,
                })
            )
        )

    useEffect(() => {
        if (!orders?.manualBilling) return

        setManualBillingEnabled(orders.manualBilling.enabled)
        setManualBillingAutoSuspendEnabled(
            orders.manualBilling.autoSuspendEnabled
        )
        setManualBillingGraceDays(orders.manualBilling.graceDays)
        setManualBillingDeleteSuspendedEnabled(
            orders.manualBilling.deleteSuspendedEnabled
        )
        setManualBillingDeleteSuspendedDays(
            orders.manualBilling.deleteSuspendedDays
        )
    }, [
        orders?.manualBilling?.enabled,
        orders?.manualBilling?.autoSuspendEnabled,
        orders?.manualBilling?.graceDays,
        orders?.manualBilling?.deleteSuspendedEnabled,
        orders?.manualBilling?.deleteSuspendedDays,
    ])

    const refreshTickets = async () =>
        run(async () =>
            setTickets(
                await getResellerTickets({
                    page: ticketsPage,
                    perPage: 25,
                    query: debouncedTicketsQuery || undefined,
                    status: ticketsStatus || undefined,
                    priority: ticketsPriority || undefined,
                })
            )
        )

    const refreshStats = async () =>
        run(async () => setStatistics(await getResellerStatistics()))

    useEffect(() => {
        if (tenantContext?.mode === 'reseller') {
            void refreshOverview()
        }
    }, [tenantContext?.mode, tenantContext?.activeReseller?.id])

    useEffect(() => {
        if (
            !tenantContext ||
            tenantContext.mode === 'reseller' ||
            !isResellerOnlyAdmin ||
            !userResellerId
        ) {
            return
        }

        let cancelled = false

        setRepairingResellerContext(true)
        setFlash(null)

        setTenantContext({ mode: 'reseller', resellerId: userResellerId })
            .then(async nextContext => {
                if (cancelled) {
                    return
                }

                await mutateTenantContext(nextContext, false)

                const routeReference =
                    resellerRouteReference(nextContext.activeReseller?.uuid) ||
                    resellerRouteReference(nextContext.activeReseller?.slug)

                const targetPath = resellerAdminPathForReference(routeReference)
                if (targetPath !== location.pathname) {
                    navigate(targetPath, { replace: true })
                }
            })
            .catch(error => {
                if (!cancelled) {
                    setFlash({
                        type: 'error',
                        text: httpErrorToHuman(error),
                    })
                }
            })
            .finally(() => {
                if (!cancelled) {
                    setRepairingResellerContext(false)
                }
            })

        return () => {
            cancelled = true
        }
    }, [
        isResellerOnlyAdmin,
        location.pathname,
        mutateTenantContext,
        navigate,
        tenantContext,
        userResellerId,
    ])

    useEffect(() => {
        const requestedReference = resellerRouteReference(resellerRef)
        if (!currentUser?.rootAdmin || !tenantContext || !requestedReference) {
            return
        }

        const activeReference =
            resellerRouteReference(tenantContext.activeReseller?.uuid) ||
            resellerRouteReference(tenantContext.activeReseller?.slug)

        if (
            tenantContext.mode === 'reseller' &&
            activeReference === requestedReference
        ) {
            return
        }

        let cancelled = false

        setRepairingResellerContext(true)
        setFlash(null)

        setTenantContext({
            mode: 'reseller',
            resellerRef: requestedReference,
        })
            .then(async nextContext => {
                if (!cancelled) {
                    await mutateTenantContext(nextContext, false)
                }
            })
            .catch(error => {
                if (!cancelled) {
                    setFlash({
                        type: 'error',
                        text: httpErrorToHuman(error),
                    })
                }
            })
            .finally(() => {
                if (!cancelled) {
                    setRepairingResellerContext(false)
                }
            })

        return () => {
            cancelled = true
        }
    }, [
        currentUser?.rootAdmin,
        mutateTenantContext,
        resellerRef,
        tenantContext,
    ])

    useEffect(() => {
        if (tenantContext?.mode !== 'reseller') {
            return
        }

        const activeReseller =
            tenantContext.activeReseller ||
            overview?.reseller ||
            null
        const canonicalReference =
            resellerRouteReference(activeReseller?.uuid) ||
            resellerRouteReference(activeReseller?.slug)

        if (!canonicalReference) {
            return
        }

        const currentReference = resellerRouteReference(resellerRef)
        const targetPath = resellerAdminPathForReference(canonicalReference)
        const currentPath = location.pathname.replace(/\/+$/, '')

        if (currentPath !== targetPath || currentReference !== canonicalReference) {
            navigate(`${targetPath}${location.search}`, { replace: true })
        }
    }, [
        location.pathname,
        location.search,
        navigate,
        overview?.reseller,
        resellerRef,
        tenantContext?.activeReseller,
        tenantContext?.mode,
    ])

    useEffect(() => {
        if (verificationBlocksOperationalPanel) {
            if (section !== 'overview') {
                setSection('overview')
            }

            return
        }

        const requestedSection = searchParams.get('section')

        if (isSidebarSection(requestedSection)) {
            if (requestedSection !== section) {
                setSection(requestedSection)
            }

            return
        }

        if (requestedSection) {
            const nextParams = new URLSearchParams(searchParams)
            nextParams.delete('section')
            setSearchParams(nextParams, { replace: true })

            if (section !== 'overview') {
                setSection('overview')
            }

            return
        }

        if (!requestedSection && section !== 'overview') {
            setSection('overview')
        }
    }, [verificationBlocksOperationalPanel, searchParams, section, setSearchParams])

    useEffect(() => {
        setRoutes(resellerNavRoutes)
        setBreadcrumb('Reseller Panel')

        return () => {
            setRoutes([])
            setBreadcrumb(null)
        }
    }, [resellerNavRoutes, setBreadcrumb, setRoutes])

    useEffect(() => {
        if (verificationBlocksOperationalPanel && section !== 'overview') {
            openSection('overview')
        }
    }, [verificationBlocksOperationalPanel, section, openSection])

    useEffect(() => {
        if (operationalPanelLocked) return
        if (section === 'users') void refreshUsers()
    }, [operationalPanelLocked, section, usersPage, debouncedUsersQuery])
    useEffect(() => {
        if (operationalPanelLocked) return
        if (section === 'services') void refreshServices()
    }, [operationalPanelLocked, section, servicesPage, debouncedServicesQuery])
    useEffect(() => {
        if (operationalPanelLocked) return
        if (section === 'dedicated_hardware') void refreshDedicatedHardware()
    }, [operationalPanelLocked, section])
    useEffect(() => {
        if (operationalPanelLocked) return
        if (
            section === 'resources' ||
            section === 'buy_servers' ||
            section === 'buy_ips'
        ) {
            void refreshResourceMarketplace()
        }
    }, [operationalPanelLocked, section])
    useEffect(() => {
        if (operationalPanelLocked) return
        if (section === 'plans') void refreshPlans()
    }, [operationalPanelLocked, section])
    useEffect(() => {
        if (operationalPanelLocked) return
        if (section === 'orders' && catalog.length === 0) void refreshPlans()
    }, [operationalPanelLocked, section, catalog.length])
    useEffect(() => {
        if (operationalPanelLocked) return
        if (section === 'settings') void refreshSettings()
    }, [operationalPanelLocked, section])
    useEffect(() => {
        if (operationalPanelLocked || section !== 'settings' || pendingDomainIds.length === 0) {
            return
        }

        void syncPendingCustomDomains(true)

        const interval = window.setInterval(() => {
            if (document.visibilityState === 'visible') {
                void syncPendingCustomDomains(true)
            }
        }, 12000)

        return () => window.clearInterval(interval)
    }, [operationalPanelLocked, pendingDomainIds.length, section, syncPendingCustomDomains])
    useEffect(() => {
        if (operationalPanelLocked) return
        if (section === 'sub_resellers') void refreshSubResellers()
    }, [operationalPanelLocked, section])
    useEffect(() => {
        if (operationalPanelLocked) return
        if (section === 'sub_resellers' && !settings) void refreshSettings()
    }, [operationalPanelLocked, section, settings])
    useEffect(() => {
        if (operationalPanelLocked) return
        if (section === 'api_keys') void refreshApiKeys()
    }, [operationalPanelLocked, section])
    useEffect(() => {
        if (operationalPanelLocked) return
        if (section === 'logs') void refreshLogs()
    }, [operationalPanelLocked, section])
    useEffect(() => {
        if (operationalPanelLocked) return
        if (section === 'orders') void refreshOrders()
    }, [operationalPanelLocked, section, ordersPage, debouncedOrdersQuery, ordersStatus])
    useEffect(() => {
        if (operationalPanelLocked) return
        if (section === 'tickets') void refreshTickets()
    }, [operationalPanelLocked, section, ticketsPage, debouncedTicketsQuery, ticketsStatus, ticketsPriority])
    useEffect(() => {
        if (operationalPanelLocked) return
        if (section === 'statistics') void refreshStats()
    }, [operationalPanelLocked, section])

    const saveManualBillingSettings = async () => {
        await run(async () => {
            await updateManualBillingSettings({
                enabled: manualBillingEnabled,
                autoSuspendEnabled: manualBillingAutoSuspendEnabled,
                graceDays: manualBillingGraceDays,
                deleteSuspendedEnabled: manualBillingDeleteSuspendedEnabled,
                deleteSuspendedDays: manualBillingDeleteSuspendedDays,
            })
            await refreshOrders()
            setFlash({ type: 'ok', text: 'Manual billing settings saved.' })
        })
    }

    const createManualBillingRecord = async (event: FormEvent<HTMLFormElement>) => {
        event.preventDefault()

        if (manualProvisionOnPaid && (!manualCatalogPlanId || !manualHostname.trim())) {
            setFlash({
                type: 'error',
                text: 'Select a VPS plan and hostname when provisioning is enabled.',
            })
            return
        }

        await run(async () => {
            const result = await createManualOrder({
                customerName: manualCustomerName.trim() || null,
                customerEmail: manualCustomerEmail.trim() || null,
                customerPassword: manualCustomerPassword || null,
                catalogPlanId: manualCatalogPlanId ? Number(manualCatalogPlanId) : null,
                hostname: manualHostname.trim() || null,
                operatingSystem: manualOperatingSystem.trim() || null,
                rootPassword: manualRootPassword || null,
                amount: manualAmount || '0',
                currency: manualCurrency.trim().toUpperCase() || 'USD',
                billingCycle: manualBillingCycle,
                dueAt: manualDueAt || null,
                graceDays: manualBillingGraceDays,
                autoSuspendEnabled: manualBillingAutoSuspendEnabled,
                provisionOnPaid: manualProvisionOnPaid,
                markPaidNow: manualMarkPaidNow,
                notes: manualNotes.trim() || null,
            })

            setManualCustomerName('')
            setManualCustomerEmail('')
            setManualCustomerPassword('')
            setManualHostname('')
            setManualRootPassword('')
            setManualNotes('')
            setManualMarkPaidNow(false)
            setManualProvisionSecret(
                result.provisioning?.root_password
                    ? {
                          orderNumber: result.order.orderNumber,
                          rootPassword: result.provisioning.root_password,
                      }
                    : null
            )
            await refreshOrders()
            await refreshServices()
            setFlash({
                type: 'ok',
                text: result.provisioning
                    ? 'Manual service invoice was paid and VPS provisioning started.'
                    : 'Manual invoice created.',
            })
        })
    }

    const quickMarkManualOrderPaid = async (orderId: number) => {
        await run(async () => {
            const result = await markManualOrderPaid(orderId)
            setManualProvisionSecret(
                result.provisioning?.root_password
                    ? {
                          orderNumber: result.order.orderNumber,
                          rootPassword: result.provisioning.root_password,
                      }
                    : null
            )
            await refreshOrders()
            await refreshServices()
            setFlash({ type: 'ok', text: 'Manual billing record marked paid.' })
        })
    }

    const quickSuspendManualOrder = async (orderId: number) => {
        if (!window.confirm('Suspend this manual-billed service now?')) return

        await run(async () => {
            await suspendManualOrder(orderId, 'Manual reseller billing suspension')
            await refreshOrders()
            await refreshServices()
            setFlash({ type: 'ok', text: 'Manual-billed service suspended.' })
        })
    }

    const quickUnsuspendManualOrder = async (orderId: number) => {
        await run(async () => {
            await unsuspendManualOrder(orderId)
            await refreshOrders()
            await refreshServices()
            setFlash({ type: 'ok', text: 'Manual-billed service unsuspended.' })
        })
    }

    const quickCancelManualOrder = async (orderId: number) => {
        if (!window.confirm('Cancel this manual billing record?')) return

        await run(async () => {
            await cancelManualOrder(orderId)
            await refreshOrders()
            setFlash({ type: 'ok', text: 'Manual billing record cancelled.' })
        })
    }

    const createUser = async (event: FormEvent<HTMLFormElement>) => {
        event.preventDefault()
        const name = newUserName.trim()
        const email = newUserEmail.trim()
        const supportPin = newUserSupportPin.trim()

        if (!newUserAutoGeneratePassword && newUserPassword.length < 8) {
            setFlash({
                type: 'error',
                text: 'Enter a manual password with at least 8 characters, or enable auto-generate.',
            })
            return
        }

        await run(async () => {
            const response = await createResellerPanelUser({
                name,
                email,
                password: newUserAutoGeneratePassword
                    ? undefined
                    : newUserPassword,
                autoGeneratePassword: newUserAutoGeneratePassword,
                supportPin: supportPin || null,
                mustChangePassword: newUserMustChangePassword,
            })
            setNewUserName('')
            setNewUserEmail('')
            setNewUserPassword('')
            setNewUserSupportPin('')
            setNewUserAutoGeneratePassword(true)
            setNewUserMustChangePassword(true)
            setCreatedCustomerSecret(
                response.generatedPassword
                    ? {
                          email,
                          password: response.generatedPassword,
                      }
                    : null
            )
            setFlash({
                type: 'ok',
                text: response.generatedPassword
                    ? `User created. Generated password: ${response.generatedPassword}`
                    : 'User created successfully.',
            })
            await Promise.all([refreshUsers(), refreshOverview()])
        })
    }

    const quickToggleUser = async (user: ResellerPanelUser) => {
        await run(async () => {
            await updateResellerPanelUser(user.id, {
                name: user.name,
                email: user.email,
                supportPin: user.supportPin,
                mustChangePassword: user.mustChangePassword,
                isDisabled: !user.isDisabled,
            })
            await refreshUsers()
        })
    }

    const quickDeleteUser = async (user: ResellerPanelUser) => {
        if (!window.confirm(`Delete ${user.email}?`)) {
            return
        }
        await run(async () => {
            await deleteResellerPanelUser(user.id)
            await Promise.all([refreshUsers(), refreshOverview()])
        })
    }

    const quickResetPassword = async (user: ResellerPanelUser) => {
        await run(async () => {
            const response = await resetResellerPanelUserPassword(user.id, {
                autoGeneratePassword: true,
                mustChangePassword: true,
            })
            setFlash({
                type: 'ok',
                text: response.generatedPassword
                    ? `New password for ${user.email}: ${response.generatedPassword}`
                    : `Password reset for ${user.email}.`,
            })
        })
    }

    const openUserSettings = (userId: number) => {
        navigate(`/admin/users/${userId}/settings`)
    }

    const quickServicePower = async (
        service: ResellerPanelService,
        action: 'start' | 'stop' | 'restart'
    ) => {
        await run(async () => {
            const response = await servicePowerAction(service.id, action)
            const guardMessage = formatResourceGuardWarning(
                response.resourceGuardWarning
            )
            if (guardMessage) {
                setFlash({ type: 'warning', text: guardMessage })
            }
            await refreshServices()
        })
    }

    const quickServiceSuspend = async (
        service: ResellerPanelService,
        suspend: boolean
    ) => {
        await run(async () => {
            if (suspend) {
                await suspendResellerService(service.id)
            } else {
                await unsuspendResellerService(service.id)
            }
            await refreshServices()
        })
    }

    const quickServiceReassign = async (service: ResellerPanelService) => {
        const userIdRaw = window.prompt(
            'Target user ID',
            service.user ? String(service.user.id) : ''
        )
        if (!userIdRaw) {
            return
        }
        const userId = Number(userIdRaw)
        if (!Number.isFinite(userId) || userId <= 0) {
            setFlash({ type: 'error', text: 'Invalid user ID.' })
            return
        }
        await run(async () => {
            await reassignResellerService(service.id, userId)
            await refreshServices()
        })
    }

    const quickServiceReinstall = async (service: ResellerPanelService) => {
        const templateUuid = window.prompt('Template UUID')
        if (!templateUuid) {
            return
        }
        const password = window.prompt('New account password')
        if (!password) {
            return
        }
        await run(async () => {
            await reinstallResellerService(service.id, {
                templateUuid,
                accountPassword: password,
                startOnCompletion: true,
            })
            setFlash({
                type: 'ok',
                text: `Reinstall queued for ${service.name}.`,
            })
        })
    }

    const quickServiceVnc = async (service: ResellerPanelService) => {
        await run(async () => {
            const session = await getResellerServiceVnc(service.id)
            const scheme = session.isTlsEnabled ? 'wss' : 'ws'
            const url = `${scheme}://${session.fqdn}:${session.port}/?token=${encodeURIComponent(session.token)}`
            window.open(url, '_blank', 'noopener,noreferrer')
        })
    }

    const patchDedicatedPlanDraft = (
        index: number,
        patch: Partial<ResellerDedicatedHardwarePlan>
    ) => {
        setDedicatedPlanDrafts(current =>
            current.map((plan, planIndex) =>
                planIndex === index ? { ...plan, ...patch } : plan
            )
        )
    }

    const addDedicatedPlanDraft = () => {
        setDedicatedPlanDrafts(current => [
            ...current,
            {
                id: `dedicated-${Date.now()}`,
                name: 'Dedicated Hardware',
                slug: 'dedicated-hardware',
                description: 'Dedicated Proxmox hardware for reseller-owned VPS capacity.',
                currency: 'INR',
                monthlyPrice: '0.00',
                setupFee: '0.00',
                cpuCores: 0,
                ramGb: 0,
                diskGb: 0,
                bandwidthTb: 0,
                sortOrder: current.length + 1,
                isActive: true,
            },
        ])
    }

    const removeDedicatedPlanDraft = (index: number) => {
        setDedicatedPlanDrafts(current =>
            current.filter((_, planIndex) => planIndex !== index)
        )
    }

    const saveDedicatedPlanDrafts = async () => {
        await run(async () => {
            const plans = await updateResellerDedicatedHardwarePlans(
                dedicatedPlanDrafts
            )
            setDedicatedPlanDrafts(plans)
            setDedicatedHardware(current =>
                current ? { ...current, dedicatedPlans: plans } : current
            )
            setFlash({
                type: 'ok',
                text: 'Dedicated hardware specs and pricing saved separately from VPS stock.',
            })
        })
    }

    const assignDedicatedHardware = async (
        event: FormEvent<HTMLFormElement>
    ) => {
        event.preventDefault()
        const form = event.currentTarget
        const formData = new FormData(form)

        await run(async () => {
            await assignResellerDedicatedHardware({
                name: String(formData.get('name') || ''),
                providerOrderRef: String(formData.get('provider_order_ref') || ''),
                paymenterServiceId: String(formData.get('paymenter_service_id') || ''),
                proxmoxHost: String(formData.get('proxmox_host') || ''),
                proxmoxPort: Number(formData.get('proxmox_port') || 8006),
                proxmoxUsername: String(formData.get('proxmox_username') || ''),
                proxmoxPassword: String(formData.get('proxmox_password') || ''),
                status: 'ready',
                publicNotes: String(formData.get('public_notes') || ''),
                internalNotes: String(formData.get('internal_notes') || ''),
            })

            form.reset()
            setFlash({
                type: 'ok',
                text: 'Dedicated hardware assigned. The reseller can now create their private location and node.',
            })
            await refreshDedicatedHardware()
        })
    }

    const configureDedicatedHardwareNode = async (
        hardwareId: number,
        event: FormEvent<HTMLFormElement>
    ) => {
        event.preventDefault()
        const form = event.currentTarget
        const formData = new FormData(form)

        await run(async () => {
            await configureResellerDedicatedHardware(hardwareId, {
                locationShortCode: String(formData.get('location_short_code') || ''),
                locationDescription: String(
                    formData.get('location_description') || ''
                ),
                nodeName: String(formData.get('node_name') || ''),
                cluster: String(formData.get('cluster') || ''),
                apiTokenId: String(formData.get('api_token_id') || ''),
                apiTokenSecret: String(formData.get('api_token_secret') || ''),
                verifyTls: formData.get('verify_tls') === 'on',
                memoryGb: Number(formData.get('memory_gb') || 1),
                memoryOverallocate: Number(
                    formData.get('memory_overallocate') || 0
                ),
                diskGb: Number(formData.get('disk_gb') || 1),
                diskOverallocate: Number(formData.get('disk_overallocate') || 0),
                vmStorage: String(formData.get('vm_storage') || ''),
                backupStorage: String(formData.get('backup_storage') || ''),
                isoStorage: String(formData.get('iso_storage') || ''),
                network: String(formData.get('network') || ''),
                provisioningEnabled:
                    formData.get('provisioning_enabled') === 'on',
                maintenanceMode: false,
                provisioningPriority: Number(
                    formData.get('provisioning_priority') || 100
                ),
                provisioningMemoryThresholdPercent: Number(
                    formData.get('provisioning_memory_threshold_percent') || 95
                ),
                provisioningDiskThresholdPercent: Number(
                    formData.get('provisioning_disk_threshold_percent') || 95
                ),
                reinstallLimitPerWeek: Number(
                    formData.get('reinstall_limit_per_week') || 2
                ),
            })

            form.reset()
            setFlash({
                type: 'ok',
                text: 'Dedicated Proxmox hardware is connected and added as a reseller-owned node.',
            })
            await Promise.all([refreshDedicatedHardware(), refreshOverview()])
        })
    }

    const updatePlanDraft = (
        catalogPlanId: number,
        patch: Partial<{
            planDisplayName: string
            monthlyPrice: string
            ipQuantity: number
            addressPoolId: string
            ipPriceEach: string
            backupLimitOverride: string
            isVisible: boolean
        }>
    ) => {
        setPlanDrafts(current => ({
            ...current,
            [catalogPlanId]: {
                ...current[catalogPlanId],
                ...patch,
            },
        }))
    }

    const patchSettings = (
        updater: (current: ResellerSettings) => ResellerSettings
    ) => {
        setSettings(current => (current ? updater(current) : current))
    }

    const previewResellerTheme = (
        nextThemeKey: string,
        nextPrimaryColor: string | null,
        nextSecondaryColor: string | null,
        nextAccentColor: string | null,
        nextCustomCss = settings?.customCss || null
    ) => {
        if (!globalSettings) {
            return
        }

        setGlobalSettings({
            ...globalSettings,
            tenantThemeKey: nextThemeKey || 'wammuhost',
            brandPrimaryColor: nextPrimaryColor,
            brandSecondaryColor: nextSecondaryColor,
            brandAccentColor: nextAccentColor,
            customCss: nextCustomCss,
        })
    }

    const patchSmtpSettings = (
        updater: (
            smtp: ResellerSettings['smtp']
        ) => ResellerSettings['smtp']
    ) => {
        patchSettings(current => ({
            ...current,
            smtp: updater(current.smtp),
        }))
    }

    const patchOauthSettings = (
        updater: (
            oauth: ResellerSettings['oauth']
        ) => ResellerSettings['oauth']
    ) => {
        patchSettings(current => ({
            ...current,
            oauth: updater(current.oauth),
        }))
    }

    const saveCatalogOfferPricing = async (offer: ResellerCatalogOffer) => {
        const draft = planDrafts[offer.catalogPlanId]
        if (!draft) {
            return
        }

        setIsSavingPlanPrice(current => ({
            ...current,
            [offer.catalogPlanId]: true,
        }))

        await run(async () => {
            const parsedIpQuantity = Number.isFinite(Number(draft.ipQuantity))
                ? Math.max(0, Number(draft.ipQuantity))
                : 0
            const backupOverrideRaw = draft.backupLimitOverride.trim()
            let backupLimitOverride: number | null = null
            if (offer.allowResellerBackupOverride && backupOverrideRaw !== '') {
                backupLimitOverride = Math.max(
                    0,
                    Math.min(offer.backupLimit, Number(backupOverrideRaw) || 0)
                )
            }

            await updateResellerCatalogOffer(offer.catalogPlanId, {
                monthlyPrice:
                    draft.monthlyPrice.trim() === ''
                        ? null
                        : draft.monthlyPrice.trim(),
                planDisplayName:
                    draft.planDisplayName.trim() === ''
                        ? null
                        : draft.planDisplayName.trim(),
                ipQuantity: parsedIpQuantity,
                addressPoolId:
                    draft.addressPoolId.trim() === ''
                        ? null
                        : Number(draft.addressPoolId),
                ipPriceEach:
                    draft.ipPriceEach.trim() === ''
                        ? '0.00'
                        : draft.ipPriceEach.trim(),
                backupLimitOverride,
                isVisible: Boolean(draft.isVisible),
            })

            await refreshPlans()
            setFlash({
                type: 'ok',
                text: `Saved pricing overrides for ${offer.name} (Plan ID ${offer.catalogPlanId}).`,
            })
        })

        setIsSavingPlanPrice(current => ({
            ...current,
            [offer.catalogPlanId]: false,
        }))
    }

    const savePanelSettings = async (event: FormEvent<HTMLFormElement>) => {
        event.preventDefault()
        if (!settings) {
            return
        }
        await run(async () => {
            const updated = await updateResellerSettings({
                displayName: settings.displayName,
                logoUrl: settings.logoUrl,
                faviconUrl: settings.faviconUrl,
                loadingLogoUrl: settings.loadingLogoUrl,
                supportUrl: settings.supportUrl,
                billingUrl: settings.billingUrl,
                tosUrl: settings.tosUrl,
                privacyUrl: settings.privacyUrl,
                footerText: settings.footerText,
                footerUrl: settings.footerUrl,
                upgradeButtonEnabled: settings.upgradeButtonEnabled,
                upgradeUrlTemplate: settings.upgradeUrlTemplate,
                primaryColor: settings.primaryColor,
                secondaryColor: settings.secondaryColor,
                accentColor: settings.accentColor,
                themeKey: settings.themeKey,
                customNameservers: settings.customNameservers,
                customCss: settings.customCss,
                oauthGithubClientId: settings.oauth.githubClientId,
                oauthDiscordClientId: settings.oauth.discordClientId,
                smtp: {
                    enabled: settings.smtp.enabled,
                    host: settings.smtp.host,
                    port: settings.smtp.port,
                    encryption: settings.smtp.encryption,
                    username: settings.smtp.username,
                    ...(smtpPasswordDraft.trim() !== ''
                        ? { password: smtpPasswordDraft.trim() }
                        : {}),
                    fromEmail: settings.smtp.fromEmail,
                    fromName: settings.smtp.fromName,
                    replyToEmail: settings.smtp.replyToEmail,
                },
                featureFlags: settings.featureFlags,
                allowSubResellers: settings.allowSubResellers,
            })
            setSettings(updated)
            if (globalSettings) {
                setGlobalSettings({
                    ...globalSettings,
                    panelName: updated.displayName,
                    logoUrl: updated.logoUrl,
                    faviconUrl: updated.faviconUrl,
                    loadingLogoUrl: updated.loadingLogoUrl,
                    billingUrl: updated.billingUrl,
                    footerText: updated.footerText || updated.displayName,
                    footerUrl: updated.footerUrl || updated.supportUrl,
                    brandPrimaryColor: updated.primaryColor,
                    brandSecondaryColor: updated.secondaryColor,
                    brandAccentColor: updated.accentColor,
                    customCss: updated.customCss,
                    tenantThemeKey: updated.themeKey || 'wammuhost',
                })
            }
            applyDocumentFavicon(updated.faviconUrl)
            setSmtpPasswordDraft('')
            setFlash({
                type: 'ok',
                text: 'Branding, theme, footer, and integration settings saved.',
            })
        })
    }

    const addCustomDomain = async () => {
        if (!newCustomDomain.trim()) {
            setFlash({ type: 'error', text: 'Enter a hostname first.' })
            return
        }

        if (!canSubmitNewDomain) {
            setFlash({
                type: 'error',
                text: 'Fix the hostname checks first before adding this white-label domain.',
            })
            return
        }

        await run(async () => {
            const updated = await createResellerSettingsDomain({
                hostname: normalizeDomainCandidate(newCustomDomain),
                isPrimary: !(settings?.domains.length || 0),
            })
            setSettings(updated)
            setNewCustomDomain('')
            setLastDomainSyncAt(new Date().toISOString())
            setFlash({
                type: 'ok',
                text: 'Hostname added. Publish the CNAME and TXT records below, then start live verification.',
            })
        })
    }

    const openTicket = async (ticketId: number) => {
        await run(async () => {
            const ticket = await getResellerTicket(ticketId)
            setSelectedTicket(ticket)
        })
    }

    const createTicket = async (event: FormEvent<HTMLFormElement>) => {
        event.preventDefault()
        await run(async () => {
            const ticket = await createResellerTicket({
                subject: newTicketSubject,
                priority: newTicketPriority,
                customerName: newTicketCustomerName || null,
                customerEmail: newTicketCustomerEmail || null,
                userId: newTicketUserId.trim()
                    ? Number(newTicketUserId) || undefined
                    : undefined,
                serverId: newTicketServerId.trim()
                    ? Number(newTicketServerId) || undefined
                    : undefined,
                body: newTicketBody,
            })
            setNewTicketSubject('')
            setNewTicketPriority('medium')
            setNewTicketCustomerName('')
            setNewTicketCustomerEmail('')
            setNewTicketUserId('')
            setNewTicketServerId('')
            setNewTicketBody('')
            setSelectedTicket(ticket)
            await Promise.all([refreshTickets(), refreshOverview()])
            setFlash({
                type: 'ok',
                text: `Ticket ${ticket.ticketNumber} created successfully.`,
            })
        })
    }

    const quickUpdateTicketStatus = async (
        ticket: ResellerTicket,
        status: string
    ) => {
        await run(async () => {
            const updated = await updateResellerTicket(ticket.id, { status })
            setSelectedTicket(updated)
            await Promise.all([refreshTickets(), refreshOverview()])
        })
    }

    const sendTicketReply = async (event: FormEvent<HTMLFormElement>) => {
        event.preventDefault()
        if (!selectedTicket) {
            return
        }

        await run(async () => {
            const updated = await replyToResellerTicket(selectedTicket.id, {
                body: ticketReplyBody,
                status: 'pending_customer',
            })
            setSelectedTicket(updated)
            setTicketReplyBody('')
            await Promise.all([refreshTickets(), refreshOverview()])
        })
    }

    const quickVerifyCustomDomain = async (domainId: number) => {
        if (domainId <= 0) {
            setFlash({
                type: 'error',
                text: 'This hostname is still syncing. Refresh once and try again.',
            })

            return
        }

        markDomainAction(domainId, true)
        setDomainChecking(true)

        try {
            const result = await verifyResellerSettingsDomain(domainId)
            setSettings(result.settings)
            setLastDomainSyncAt(new Date().toISOString())
            if (result.verification) {
                setDomainVerificationResults(current => ({
                    ...current,
                    [domainId]: result.verification!,
                }))
            }
            setFlash({
                type: result.verification?.passed ? 'ok' : 'error',
                text: result.verification?.passed
                    ? 'DNS ownership verified. SSL and secure routing are now ready.'
                    : (result.verification?.errors || []).join(' ') ||
                      'Hostname verification failed.',
            })
        } catch (error) {
            setFlash({ type: 'error', text: httpErrorToHuman(error) })
        } finally {
            markDomainAction(domainId, false)
            setDomainChecking(false)
        }
    }

    const quickPromoteCustomDomain = async (
        domainId: number,
        hostname: string
    ) => {
        if (domainId <= 0) {
            setFlash({
                type: 'error',
                text: 'This hostname is still syncing. Refresh once and try again.',
            })

            return
        }

        markDomainAction(domainId, true)
        try {
            const updated = await updateResellerSettingsDomain(domainId, {
                hostname,
                isPrimary: true,
            })
            setSettings(updated)
            setEditingDomainId(null)
            setEditingDomainHostname('')
            setFlash({
                type: 'ok',
                text: `${hostname} is now the primary reseller hostname.`,
            })
        } catch (error) {
            setFlash({ type: 'error', text: httpErrorToHuman(error) })
        } finally {
            markDomainAction(domainId, false)
        }
    }

    const quickRenameCustomDomain = async (
        domainId: number,
        nextHostname: string,
        isPrimary: boolean
    ) => {
        if (domainId <= 0) {
            setFlash({
                type: 'error',
                text: 'This hostname is still syncing. Refresh once and try again.',
            })

            return
        }

        if (!nextHostname.trim()) {
            setFlash({ type: 'error', text: 'Enter a hostname first.' })
            return
        }

        markDomainAction(domainId, true)
        try {
            const updated = await updateResellerSettingsDomain(domainId, {
                hostname: normalizeDomainCandidate(nextHostname),
                isPrimary,
            })
            setSettings(updated)
            setDomainVerificationResults(current => {
                const next = { ...current }
                delete next[domainId]
                return next
            })
            setEditingDomainId(null)
            setEditingDomainHostname('')
            setLastDomainSyncAt(new Date().toISOString())
            setFlash({
                type: 'ok',
                text: 'Hostname updated. Publish the new records and run verification again.',
            })
        } catch (error) {
            setFlash({ type: 'error', text: httpErrorToHuman(error) })
        } finally {
            markDomainAction(domainId, false)
        }
    }

    const quickDeleteCustomDomain = async (domainId: number, hostname: string) => {
        if (domainId <= 0) {
            setFlash({
                type: 'error',
                text: 'This hostname is still syncing. Refresh once and try again.',
            })

            return
        }

        if (!window.confirm(`Remove hostname ${hostname}?`)) {
            return
        }

        markDomainAction(domainId, true)
        try {
            const updated = await deleteResellerSettingsDomain(domainId)
            setSettings(updated)
            setDomainVerificationResults(current => {
                const next = { ...current }
                delete next[domainId]
                return next
            })
            setFlash({
                type: 'ok',
                text: `${hostname} was removed.`,
            })
        } catch (error) {
            setFlash({ type: 'error', text: httpErrorToHuman(error) })
        } finally {
            markDomainAction(domainId, false)
        }
    }

    const quickRegenerateDomainToken = async (domainId: number) => {
        if (domainId <= 0) {
            setFlash({
                type: 'error',
                text: 'This hostname is still syncing. Refresh once and try again.',
            })

            return
        }

        markDomainAction(domainId, true)
        try {
            const result = await regenerateResellerSettingsDomainToken(domainId)
            setSettings(result.settings)
            setLastDomainSyncAt(new Date().toISOString())
            if (result.domain) {
                setDomainVerificationResults(current => {
                    const next = { ...current }
                    delete next[domainId]
                    return next
                })
            }
            setFlash({
                type: 'ok',
                text: 'A fresh TXT ownership token was issued. Update the DNS record, then run verification again.',
            })
        } catch (error) {
            setFlash({ type: 'error', text: httpErrorToHuman(error) })
        } finally {
            markDomainAction(domainId, false)
        }
    }

    const createChildReseller = async (event: FormEvent<HTMLFormElement>) => {
        event.preventDefault()
        if (!subResellerCreationEnabled) {
            setFlash({
                type: 'error',
                text: 'Enable sub-resellers in Settings before creating child reseller tenants.',
            })

            return
        }

        await run(async () => {
            await createSubReseller({
                displayName: subName,
                domain: subDomain,
                backendDomain: subBackendDomain || null,
                liveDataDomain: subLiveDataDomain || null,
                novncDomain: subNovncDomain || null,
                cdnDomain: subCdnDomain || null,
                status: subStatus,
                maxRamMb: Number(subMaxRamMb) || 1,
                maxCpuCores: Number(subMaxCpuCores) || 1,
                maxDiskGb: Number(subMaxDiskGb) || 1,
                maxVms: Number(subMaxVms) || 1,
            })
            setSubName('')
            setSubDomain('')
            setSubBackendDomain('')
            setSubLiveDataDomain('')
            setSubNovncDomain('')
            setSubCdnDomain('')
            setSubStatus('pending')
            setSubMaxRamMb('1024')
            setSubMaxCpuCores('1')
            setSubMaxDiskGb('20')
            setSubMaxVms('5')
            await refreshSubResellers()
        })
    }

    const quickSwitchToSubReseller = async (item: SubReseller) => {
        await run(async () => {
            const nextContext = await setTenantContext({
                mode: 'reseller',
                resellerId: item.id,
                resellerRef: String(item.id),
            })
            await mutateTenantContext(nextContext, false)

            const routeReference =
                resellerRouteReference(nextContext.activeReseller?.uuid) ||
                resellerRouteReference(nextContext.activeReseller?.slug) ||
                String(item.id)
            navigate(
                `${resellerAdminPathForReference(routeReference)}${location.search}`,
                { replace: true }
            )
            await refreshOverview()
            setFlash({
                type: 'ok',
                text: `Now viewing reseller context: ${item.displayName}`,
            })
        })
    }

    const quickToggleSubResellerStatus = async (item: SubReseller) => {
        const nextStatus = item.status === 'suspended' ? 'active' : 'suspended'
        await run(async () => {
            await updateSubReseller(item.id, {
                displayName: item.displayName,
                status: nextStatus,
                maxRamMb: item.maxRamMb,
                maxCpuCores: item.maxCpuCores,
                maxDiskGb: item.maxDiskGb,
                maxVms: item.maxVms,
            })
            await refreshSubResellers()
        })
    }

    const quickResizeSubReseller = async (item: SubReseller) => {
        const ramRaw = window.prompt('Max RAM (MB)', String(item.maxRamMb))
        const cpuRaw = window.prompt('Max CPU Cores', String(item.maxCpuCores))
        const diskRaw = window.prompt('Max Disk (GB)', String(item.maxDiskGb))
        const vmsRaw = window.prompt('Max VMs', String(item.maxVms))

        if (!ramRaw || !cpuRaw || !diskRaw || !vmsRaw) {
            return
        }

        await run(async () => {
            await updateSubReseller(item.id, {
                displayName: item.displayName,
                status: item.status,
                maxRamMb: Math.max(Number(ramRaw) || item.maxRamMb, 1),
                maxCpuCores: Math.max(Number(cpuRaw) || item.maxCpuCores, 1),
                maxDiskGb: Math.max(Number(diskRaw) || item.maxDiskGb, 1),
                maxVms: Math.max(Number(vmsRaw) || item.maxVms, 1),
            })
            await refreshSubResellers()
        })
    }

    const quickDeleteSubReseller = async (item: SubReseller) => {
        if (!window.confirm(`Delete sub-reseller ${item.displayName}?`)) {
            return
        }
        await run(async () => {
            await deleteSubReseller(item.id)
            await refreshSubResellers()
        })
    }

    const createApiKey = async (event: FormEvent<HTMLFormElement>) => {
        event.preventDefault()
        const scopes = Array.from(selectedApiScopes)

        if (!canCreateApiKey) {
            setFlash({
                type: 'error',
                text: 'Enter a key name and choose at least one API scope.',
            })

            return
        }

        await run(async () => {
            const created = await createResellerApiKey({
                name: newApiKeyName.trim(),
                scopes,
            })
            setPlainApiKey(created.plainTextKey || null)
            setNewApiKeyName('')
            setNewApiKeyScopes([...defaultApiKeyScopes])
            await refreshApiKeys()
        })
    }

    const quickRevokeApiKey = async (key: ResellerApiKey) => {
        await run(async () => {
            await revokeResellerApiKey(key.id)
            await refreshApiKeys()
        })
    }

    if (!tenantContext) {
        return (
            <PageContentBlock title='Reseller Admin Panel'>
                <Spinner />
            </PageContentBlock>
        )
    }

    if (tenantContext.mode !== 'reseller') {
        if (currentUser?.rootAdmin && resellerRouteReference(resellerRef)) {
            return (
                <PageContentBlock title='Reseller Admin Panel'>
                    <div className='theme-panel rounded-xl p-5 shadow-[0_18px_50px_rgba(0,0,0,0.24)]'>
                        <div className='flex items-center gap-3 text-white'>
                            {repairingResellerContext ? <Spinner /> : null}
                            <div>
                                <p className='font-semibold'>
                                    Opening reseller workspace
                                </p>
                                <p className='mt-1 text-sm text-white/65'>
                                    Loading the reseller attached to this immutable link.
                                </p>
                            </div>
                        </div>
                        {flash ? (
                            <p className='mt-4 rounded-lg border border-red-500/40 bg-red-500/10 px-3 py-2 text-sm text-red-100'>
                                {flash.text}
                            </p>
                        ) : null}
                    </div>
                </PageContentBlock>
            )
        }

        if (isResellerOnlyAdmin && userResellerId) {
            return (
                <PageContentBlock title='Reseller Admin Panel'>
                    <div className='theme-panel rounded-xl p-5 shadow-[0_18px_50px_rgba(0,0,0,0.24)]'>
                        <div className='flex items-center gap-3 text-white'>
                            <span className='h-5 w-5 shrink-0 animate-spin rounded-full border-2 border-cyan-400/25 border-t-cyan-100' />
                            <div>
                                <p className='font-semibold'>
                                    Opening your reseller workspace
                                </p>
                                <p className='mt-1 text-sm text-white/65'>
                                    Securing the reseller scope for this session.
                                </p>
                            </div>
                        </div>
                        {flash ? (
                            <p className='mt-4 rounded-lg border border-red-500/40 bg-red-500/10 px-3 py-2 text-sm text-red-100'>
                                {flash.text}
                            </p>
                        ) : null}
                    </div>
                </PageContentBlock>
            )
        }

        return (
            <PageContentBlock title='Reseller Admin Panel'>
                <div className='theme-panel rounded-xl p-5'>
                    <p className='text-white/80'>
                        Switch to reseller view first, then open this panel.
                    </p>
                    <div className='mt-4'>
                        <Button
                            variant='filled'
                            loading={loading}
                            onClick={() =>
                                run(async () => {
                                    window.location.assign('/reseller/panel')
                                })
                            }
                        >
                            Choose Reseller View
                        </Button>
                    </div>
                </div>
            </PageContentBlock>
        )
    }

    if (forceOnboardingOnly) {
        return <Navigate to={forcedOnboardingPath} replace />
    }

    if (
        overview &&
        !ownerCanBypassVerificationLock &&
        !overview.onboarding.completed
    ) {
        return <Navigate to={overview.onboarding.currentPath} replace />
    }

    if (verificationBlocksOperationalPanel) {
        const currentStep =
            overview?.onboarding.currentStep ||
            tenantContext.activeReseller?.onboardingCurrentStep ||
            'pending'
        const currentPath =
            overview?.onboarding.currentPath || forcedOnboardingPath

        return (
            <PageContentBlock title={`Reseller Panel - ${resellerName}`}>
                <div className='space-y-4'>
                    <div className='theme-panel rounded-xl p-4'>
                        <div className='flex flex-wrap items-center justify-between gap-3'>
                            <div>
                                <p className='text-xs uppercase text-white/60'>
                                    Reseller Admin Panel
                                </p>
                                <h1 className='text-2xl font-semibold text-white'>
                                    {resellerName}
                                </h1>
                                <div className='mt-3 flex flex-wrap gap-2 text-xs text-white/75'>
                                    <span className='theme-pill-active rounded-full px-3 py-1 font-medium'>
                                        Internal ID #{resellerInternalId ?? 'pending'}
                                    </span>
                                    {resellerImmutableReference ? (
                                        <span className='rounded-full border border-emerald-300/25 bg-emerald-400/10 px-3 py-1 font-mono text-emerald-100'>
                                            {resellerImmutableReference}
                                        </span>
                                    ) : null}
                                    {resellerDomain ? (
                                        <span className='rounded-full border border-white/15 bg-white/10 px-3 py-1'>
                                            Domain {resellerDomain}
                                        </span>
                                    ) : null}
                                </div>
                            </div>
                            {currentUser?.rootAdmin || currentUser?.platformAdmin ? (
                                <Button
                                    type='button'
                                    variant='outline'
                                    onClick={() => navigate('/admin/resellers')}
                                >
                                    Back to resellers
                                </Button>
                            ) : null}
                        </div>
                    </div>

                    {flash ? (
                        <div
                            className={`rounded-lg border px-4 py-3 text-sm ${
                                flash.type === 'ok'
                                    ? 'border-emerald-400/40 bg-emerald-500/10 text-emerald-200'
                                    : flash.type === 'warning'
                                      ? 'border-amber-400/40 bg-amber-500/10 text-amber-100'
                                      : 'border-red-400/40 bg-red-500/10 text-red-200'
                            }`}
                        >
                            {flash.text}
                        </div>
                    ) : null}

                    <section className='theme-panel rounded-3xl p-6 shadow-[0_18px_50px_rgba(0,0,0,0.24)]'>
                        <div className='flex flex-col gap-5 md:flex-row md:items-start md:justify-between'>
                            <div className='max-w-2xl'>
                                <p className='text-xs font-semibold uppercase tracking-[0.24em] text-amber-100/75'>
                                    Verification pending
                                </p>
                                <h2 className='mt-3 text-2xl font-semibold text-white'>
                                    Reseller tools are locked
                                </h2>
                                <p className='mt-3 text-sm leading-6 text-amber-50/85'>
                                    {resellerBlockedReason ||
                                        resellerOnboardingLockedMessage}
                                </p>
                                <p className='mt-3 text-xs capitalize text-amber-100/70'>
                                    Current step: {currentStep.replace(/_/g, ' ')}
                                </p>
                            </div>

                            {isResellerOnlyAdmin ? (
                                <Button
                                    type='button'
                                    variant='filled'
                                    onClick={() =>
                                        window.location.assign(currentPath)
                                    }
                                >
                                    Continue Onboarding
                                </Button>
                            ) : null}
                        </div>
                    </section>
                </div>
            </PageContentBlock>
        )
    }

    return (
        <PageContentBlock title={`Reseller Panel - ${resellerName}`}>
            <div className='space-y-4'>
                <div className='theme-panel relative z-20 rounded-xl p-4'>
                    <div className='flex flex-wrap items-center justify-between gap-3'>
                        <div>
                            <p className='text-xs uppercase text-white/60'>
                                Reseller Admin Panel
                            </p>
                            <h1 className='text-2xl font-semibold text-white'>
                                {resellerName}
                            </h1>
                            <div className='mt-3 flex flex-wrap gap-2 text-xs text-white/75'>
                                <span className='theme-pill-active rounded-full px-3 py-1 font-medium'>
                                    Internal ID #{resellerInternalId ?? 'pending'}
                                </span>
                                <span className='rounded-full border border-emerald-300/25 bg-emerald-400/10 px-3 py-1 font-mono text-emerald-100'>
                                    {resellerImmutableReference ?? 'identity-pending'}
                                </span>
                                {resellerSlug ? (
                                    <span className='rounded-full border border-white/15 bg-white/10 px-3 py-1'>
                                        Slug {resellerSlug}
                                    </span>
                                ) : null}
                                {resellerDomain ? (
                                    <span className='rounded-full border border-white/15 bg-white/10 px-3 py-1'>
                                        Domain {resellerDomain}
                                    </span>
                                ) : null}
                            </div>
                            <p className='mt-2 break-all font-mono text-[11px] text-white/45'>
                                Route {resellerCanonicalPath}
                            </p>
                        </div>
                        <div className='flex flex-wrap gap-2'>
                            <Button type='button' onClick={() => void refreshOverview()}>
                                Refresh
                            </Button>
                            {!verificationLocked ? (
                                <Button
                                    type='button'
                                    variant='filled'
                                    onClick={openCustomerPanel}
                                >
                                    Open Customer Panel
                                </Button>
                            ) : null}
                            {ownerImpersonating ? (
                                <Button
                                    type='button'
                                    variant='filled'
                                    loading={loading}
                                    onClick={() =>
                                        run(async () => {
                                            await setTenantContext({
                                                mode: 'all',
                                            })
                                            await mutateTenantContext()
                                            window.location.assign('/admin')
                                        })
                                    }
                                >
                                    Return To Root Admin
                                </Button>
                            ) : null}
                            {nestedResellerContext ? (
                                <Button
                                    variant='filled'
                                    loading={loading}
                                    onClick={() =>
                                        run(async () => {
                                            await setTenantContext({
                                                mode: 'reseller',
                                                resellerId: userResellerId as number,
                                            })
                                            await Promise.all([
                                                mutateTenantContext(),
                                                refreshOverview(),
                                            ])
                                        })
                                    }
                                >
                                    Back To Parent Reseller
                                </Button>
                            ) : null}
                        </div>
                    </div>
                </div>

                {flash ? (
                    <div
                        className={`rounded-lg border px-4 py-3 text-sm ${
                            flash.type === 'ok'
                                ? 'border-emerald-400/40 bg-emerald-500/10 text-emerald-200'
                                : flash.type === 'warning'
                                  ? 'border-amber-400/40 bg-amber-500/10 text-amber-100'
                                  : 'border-red-400/40 bg-red-500/10 text-red-200'
                        }`}
                    >
                        {flash.text}
                    </div>
                ) : null}

                    <div className='space-y-4'>
                {verificationLocked ? (
                    <div className='rounded-xl border border-amber-400/35 bg-amber-500/10 px-4 py-4 text-sm text-amber-100'>
                        <div className='flex flex-col gap-3 md:flex-row md:items-start md:justify-between'>
                            <div>
                                <p className='font-semibold'>
                                    Reseller onboarding is not complete
                                </p>
                                <p className='mt-1 text-amber-100/90'>
                                    {resellerBlockedReason ||
                                        resellerOnboardingLockedMessage}
                                </p>
                                {overview ? (
                                    <p className='mt-2 text-xs capitalize text-amber-100/70'>
                                        Current step:{' '}
                                        {overview.onboarding.currentStep.replace(
                                            /_/g,
                                            ' '
                                        )}
                                    </p>
                                ) : null}
                            </div>
                            {overview?.onboarding.currentPath ? (
                                <Button
                                    type='button'
                                    variant='filled'
                                    onClick={() =>
                                        window.location.assign(
                                            overview.onboarding.currentPath
                                        )
                                    }
                                >
                                    Open Onboarding
                                </Button>
                            ) : null}
                        </div>
                    </div>
                ) : null}

                {section === 'overview' &&
                overview &&
                overview.reseller.verificationStatus !== 'approved' ? (
                    <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                        <div className='flex flex-col gap-2 md:flex-row md:items-start md:justify-between'>
                            <div>
                                <h3 className='text-lg font-semibold text-white'>
                                    Identity Verification
                                </h3>
                                <p className='mt-1 text-sm text-white/70'>
                                    Complete the secure onboarding flow to submit Aadhaar or PAN identity proof and your core business details. Root admin reviews that KYC queue before reseller actions are unlocked.
                                </p>
                            </div>
                            <span
                                className={`inline-flex rounded-full px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide ${
                                    overview.reseller.verificationStatus === 'rejected' ||
                                    overview.reseller.verificationStatus === 'suspended'
                                        ? 'border border-rose-400/40 bg-rose-500/20 text-rose-200'
                                        : 'border border-amber-400/40 bg-amber-500/20 text-amber-200'
                                }`}
                            >
                                {overview.reseller.verificationStatus}
                            </span>
                        </div>

                        {overview.reseller.verificationRejectionReason ? (
                            <div className='mt-3 rounded-lg border border-rose-400/30 bg-rose-500/10 px-3 py-2 text-sm text-rose-100'>
                                Rejection reason: {overview.reseller.verificationRejectionReason}
                            </div>
                        ) : null}

                        <div className='mt-4 flex flex-wrap items-center justify-between gap-3'>
                            <p className='text-xs text-white/55'>
                                Current uploaded KYC files: {overview.reseller.documents.count ?? 0}
                            </p>
                            <Button
                                variant='filled'
                                onClick={() =>
                                    window.location.assign(
                                        overview.onboarding.currentPath
                                    )
                                }
                            >
                                Continue Secure Onboarding
                            </Button>
                        </div>
                    </div>
                ) : null}

                {section === 'overview' && !overview ? (
                    <div className='rounded-2xl border border-white/10 bg-[#1a1441] p-5 text-white'>
                        <div className='flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between'>
                            <div>
                                <p className='text-xs font-semibold uppercase tracking-[0.24em] text-white/45'>
                                    Reseller Dashboard
                                </p>
                                <h3 className='mt-2 text-2xl font-semibold'>
                                    Loading live reseller status
                                </h3>
                                <p className='mt-2 max-w-2xl text-sm leading-6 text-white/62'>
                                    The dashboard uses live reseller, resource, billing,
                                    queue, support, and security data. If the API is slow
                                    or temporarily unavailable, this safe shell stays open
                                    so you are not left on a blank page.
                                </p>
                            </div>
                            <Button onClick={() => void refreshOverview()} loading={loading}>
                                Retry Dashboard
                            </Button>
                        </div>
                        {tenantContext?.activeReseller ? (
                            <div className='mt-5 grid gap-3 md:grid-cols-3'>
                                {[
                                    {
                                        label: 'Reseller',
                                        value: tenantContext.activeReseller.displayName,
                                    },
                                    {
                                        label: 'Status',
                                        value: tenantContext.activeReseller.status,
                                    },
                                    {
                                        label: 'Onboarding',
                                        value: tenantContext.activeReseller.onboardingStatus,
                                    },
                                ].map(item => (
                                    <div
                                        key={item.label}
                                        className='rounded-xl border border-white/10 bg-white/[0.04] p-4'
                                    >
                                        <p className='text-xs uppercase tracking-wide text-white/45'>
                                            {item.label}
                                        </p>
                                        <p className='mt-2 break-words text-lg font-semibold capitalize'>
                                            {String(item.value || 'pending').replace(/_/g, ' ')}
                                        </p>
                                    </div>
                                ))}
                            </div>
                        ) : null}
                    </div>
                ) : null}

                {section === 'overview' && overview ? (
                    <div className='space-y-4'>
                        {(() => {
                            const planStockTotal = overview.resources.plans.reduce(
                                (total, plan) => total + plan.quantityTotal,
                                0
                            )
                            const planStockUsed = overview.resources.plans.reduce(
                                (total, plan) => total + plan.quantityUsed,
                                0
                            )
                            const planStockAvailable = overview.resources.plans.reduce(
                                (total, plan) => total + plan.quantityAvailable,
                                0
                            )
                            const ipStockTotal = overview.resources.ipPools.reduce(
                                (total, pool) => total + pool.quantityTotal,
                                0
                            )
                            const ipStockUsed = overview.resources.ipPools.reduce(
                                (total, pool) => total + pool.quantityUsed,
                                0
                            )
                            const ipStockAvailable = overview.resources.ipPools.reduce(
                                (total, pool) => total + pool.quantityAvailable,
                                0
                            )
                            const queueActive =
                                overview.queueHealth.building +
                                overview.queueHealth.deleting
                            const billingProblemCount =
                                (overview.billing.countsByStatus.pending ?? 0) +
                                (overview.billing.countsByStatus.failed ?? 0)
                            const primaryDomainLabel =
                                overview.reseller.domain || preferredCustomerPanelDomain || 'Not configured'
                            const dashboardSignals = [
                                {
                                    label: 'Panel access',
                                    value: overview.access.canOperate ? 'Operational' : 'Locked',
                                    detail: overview.access.canOperate
                                        ? 'All reseller tools are unlocked.'
                                        : overview.access.blockedReason ||
                                          'Onboarding approval is still required.',
                                    tone: overview.access.canOperate
                                        ? 'border-emerald-300/25 bg-emerald-400/10 text-emerald-100'
                                        : 'border-amber-300/25 bg-amber-400/10 text-amber-100',
                                },
                                {
                                    label: 'KYC',
                                    value: overview.reseller.verificationStatus.replace(/_/g, ' '),
                                    detail: `${overview.reseller.documents.count ?? 0} secure file(s) on record.`,
                                    tone:
                                        overview.reseller.verificationStatus === 'approved'
                                            ? 'border-emerald-300/25 bg-emerald-400/10 text-emerald-100'
                                            : 'border-amber-300/25 bg-amber-400/10 text-amber-100',
                                },
                                {
                                    label: 'Custom domain',
                                    value: overview.reseller.domain ? 'Configured' : 'Pending',
                                    detail: primaryDomainLabel,
                                    tone: overview.reseller.domain
                                        ? 'border-cyan-300/25 bg-cyan-400/10 text-cyan-100'
                                        : 'border-white/10 bg-white/[0.04] text-white/75',
                                },
                                {
                                    label: 'Automation',
                                    value:
                                        queueActive > 0
                                            ? `${queueActive} running`
                                            : overview.queueHealth.errors > 0
                                              ? `${overview.queueHealth.errors} errors`
                                              : 'Healthy',
                                    detail: `${overview.queueHealth.building} building, ${overview.queueHealth.deleting} deleting, ${overview.failedTasks.count} failed tasks.`,
                                    tone:
                                        overview.queueHealth.errors > 0 || overview.failedTasks.count > 0
                                            ? 'border-rose-300/25 bg-rose-400/10 text-rose-100'
                                            : 'border-emerald-300/25 bg-emerald-400/10 text-emerald-100',
                                },
                            ]
                            const nextActions = [
                                {
                                    label: 'Branding & Domains',
                                    detail: 'Logo, favicon, loading screen, footer, theme, DNS and SSL.',
                                    section: 'settings' as Section,
                                },
                                {
                                    label: 'Buy VPS Stock',
                                    detail: 'Purchase reseller VPS plan quantity before selling to customers.',
                                    section: 'buy_servers' as Section,
                                },
                                {
                                    label: 'Buy IP Stock',
                                    detail: 'Purchase reseller IP stock from enabled platform pools.',
                                    section: 'buy_ips' as Section,
                                },
                                {
                                    label: 'Dedicated Hardware',
                                    detail: 'Configure reseller-owned Proxmox nodes with private location and capacity.',
                                    section: 'dedicated_hardware' as Section,
                                },
                            ]

                            return (
                                <section className='overflow-hidden rounded-2xl border border-white/10 bg-[linear-gradient(135deg,rgba(18,24,51,0.96),rgba(28,20,64,0.92))] p-5 text-white shadow-[0_20px_70px_rgba(0,0,0,0.24)]'>
                                    <div className='flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between'>
                                        <div className='min-w-0'>
                                            <p className='text-xs font-semibold uppercase tracking-[0.26em] text-cyan-100/65'>
                                                Reseller Command Center
                                            </p>
                                            <h3 className='mt-2 break-words text-2xl font-semibold'>
                                                {overview.reseller.displayName}
                                            </h3>
                                            <p className='mt-2 max-w-3xl text-sm leading-6 text-white/62'>
                                                Live overview for onboarding, stock, customers,
                                                VPS services, billing, support, abuse signals,
                                                queue health, and domain readiness.
                                            </p>
                                            <div className='mt-3 flex flex-wrap gap-2 text-[11px] font-semibold uppercase tracking-wide'>
                                                <span className='rounded-full border border-white/10 bg-white/[0.06] px-3 py-1 text-white/70'>
                                                    {overview.reseller.status}
                                                </span>
                                                <span className='rounded-full border border-white/10 bg-white/[0.06] px-3 py-1 text-white/70'>
                                                    {overview.onboarding.status.replace(/_/g, ' ')}
                                                </span>
                                                <span className='rounded-full border border-white/10 bg-white/[0.06] px-3 py-1 text-white/70'>
                                                    {overview.reseller.uuid || `ID ${overview.reseller.id}`}
                                                </span>
                                            </div>
                                        </div>
                                        <div className='grid min-w-0 gap-2 sm:grid-cols-2 xl:min-w-[420px]'>
                                            {[
                                                {
                                                    label: 'Customers',
                                                    value: compactNumber(overview.stats.activeUsers),
                                                    detail: `${overview.stats.suspendedUsers} suspended`,
                                                },
                                                {
                                                    label: 'VPS',
                                                    value: compactNumber(overview.stats.totalVms),
                                                    detail: `${overview.pool.usedVms}/${overview.pool.maxVms} quota`,
                                                },
                                                {
                                                    label: 'VPS stock',
                                                    value: compactNumber(planStockAvailable),
                                                    detail: `${planStockUsed}/${planStockTotal} used`,
                                                },
                                                {
                                                    label: 'IP stock',
                                                    value: compactNumber(ipStockAvailable),
                                                    detail: `${ipStockUsed}/${ipStockTotal} used`,
                                                },
                                            ].map(item => (
                                                <div
                                                    key={item.label}
                                                    className='rounded-xl border border-white/10 bg-white/[0.045] p-3'
                                                >
                                                    <p className='text-[11px] uppercase tracking-wide text-white/45'>
                                                        {item.label}
                                                    </p>
                                                    <p className='mt-1 text-2xl font-semibold'>
                                                        {item.value}
                                                    </p>
                                                    <p className='mt-1 text-xs text-white/55'>
                                                        {item.detail}
                                                    </p>
                                                </div>
                                            ))}
                                        </div>
                                    </div>

                                    <div className='mt-5 grid gap-3 lg:grid-cols-4'>
                                        {dashboardSignals.map(item => (
                                            <div
                                                key={item.label}
                                                className={`rounded-xl border p-4 ${item.tone}`}
                                            >
                                                <p className='text-[11px] font-semibold uppercase tracking-[0.2em] opacity-70'>
                                                    {item.label}
                                                </p>
                                                <p className='mt-2 text-lg font-semibold capitalize'>
                                                    {item.value}
                                                </p>
                                                <p className='mt-2 break-words text-xs leading-5 opacity-75'>
                                                    {item.detail}
                                                </p>
                                            </div>
                                        ))}
                                    </div>

                                    <div className='mt-5 grid gap-4 xl:grid-cols-2'>
                                        <div className='rounded-xl border border-white/10 bg-black/15 p-4'>
                                            <div className='flex items-center justify-between gap-3'>
                                                <div>
                                                    <h4 className='text-sm font-semibold uppercase tracking-wide text-white/80'>
                                                        VPS plan stock
                                                    </h4>
                                                    <p className='mt-1 text-xs text-white/50'>
                                                        Purchased plan quantity, used quantity, and remaining sellable stock.
                                                    </p>
                                                </div>
                                                <Button size='sm' onClick={() => openSection('resources')}>
                                                    Manage
                                                </Button>
                                            </div>
                                            <div className='mt-4 space-y-2'>
                                                {overview.resources.plans.slice(0, 4).map(plan => {
                                                    const pct = percentage(
                                                        plan.quantityUsed,
                                                        plan.quantityTotal
                                                    )

                                                    return (
                                                        <div
                                                            key={plan.catalogPlanId}
                                                            className='rounded-lg border border-white/10 bg-white/[0.04] p-3'
                                                        >
                                                            <div className='flex flex-wrap items-center justify-between gap-2'>
                                                                <p className='font-semibold text-white'>
                                                                    {plan.name}
                                                                </p>
                                                                <span className='text-xs text-white/60'>
                                                                    {plan.quantityAvailable} in stock
                                                                </span>
                                                            </div>
                                                            <div className='mt-2 h-2 rounded bg-white/10'>
                                                                <div
                                                                    className='h-2 rounded bg-cyan-300'
                                                                    style={{ width: `${pct}%` }}
                                                                />
                                                            </div>
                                                            <p className='mt-2 text-xs text-white/50'>
                                                                {plan.specs.cpuCores} CPU, {toGbFromMb(plan.specs.ramMb)}, {plan.specs.diskGb} GB disk
                                                            </p>
                                                        </div>
                                                    )
                                                })}
                                                {overview.resources.plans.length === 0 ? (
                                                    <p className='rounded-lg border border-dashed border-white/15 p-4 text-sm text-white/55'>
                                                        No VPS stock purchased yet.
                                                    </p>
                                                ) : null}
                                            </div>
                                        </div>

                                        <div className='rounded-xl border border-white/10 bg-black/15 p-4'>
                                            <div className='flex items-center justify-between gap-3'>
                                                <div>
                                                    <h4 className='text-sm font-semibold uppercase tracking-wide text-white/80'>
                                                        IP pool stock
                                                    </h4>
                                                    <p className='mt-1 text-xs text-white/50'>
                                                        IP allocation visibility for this reseller. Additional IPs can be assigned by the provider when needed.
                                                    </p>
                                                </div>
                                                <Button size='sm' onClick={() => openSection('resources')}>
                                                    View stock
                                                </Button>
                                            </div>
                                            <div className='mt-4 space-y-2'>
                                                {overview.resources.ipPools.slice(0, 4).map(pool => {
                                                    const pct = percentage(
                                                        pool.quantityUsed,
                                                        pool.quantityTotal
                                                    )

                                                    return (
                                                        <div
                                                            key={pool.addressPoolId}
                                                            className='rounded-lg border border-white/10 bg-white/[0.04] p-3'
                                                        >
                                                            <div className='flex flex-wrap items-center justify-between gap-2'>
                                                                <p className='font-semibold text-white'>
                                                                    {pool.name}
                                                                </p>
                                                                <span className='text-xs text-white/60'>
                                                                    {pool.quantityAvailable} in stock
                                                                </span>
                                                            </div>
                                                            <div className='mt-2 h-2 rounded bg-white/10'>
                                                                <div
                                                                    className='h-2 rounded bg-emerald-300'
                                                                    style={{ width: `${pct}%` }}
                                                                />
                                                            </div>
                                                            <p className='mt-2 text-xs text-white/50'>
                                                                Base cost {formatMoney(pool.priceEach)} per IP.
                                                            </p>
                                                        </div>
                                                    )
                                                })}
                                                {overview.resources.ipPools.length === 0 ? (
                                                    <p className='rounded-lg border border-dashed border-white/15 p-4 text-sm text-white/55'>
                                                        No IP stock purchased yet.
                                                    </p>
                                                ) : null}
                                            </div>
                                        </div>
                                    </div>

                                    {overview.access.canOperate ? (
                                        <div className='mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-4'>
                                            {nextActions.map(item => (
                                                <button
                                                    key={item.label}
                                                    type='button'
                                                    onClick={() => openSection(item.section)}
                                                    className='rounded-xl border border-white/10 bg-white/[0.04] p-4 text-left transition hover:border-cyan-300/35 hover:bg-cyan-400/10'
                                                >
                                                    <p className='font-semibold text-white'>
                                                        {item.label}
                                                    </p>
                                                    <p className='mt-2 text-xs leading-5 text-white/55'>
                                                        {item.detail}
                                                    </p>
                                                </button>
                                            ))}
                                        </div>
                                    ) : (
                                        <div className='mt-5 flex flex-col gap-3 rounded-xl border border-amber-300/25 bg-amber-400/10 p-4 text-amber-100 md:flex-row md:items-center md:justify-between'>
                                            <div>
                                                <p className='font-semibold'>
                                                    Operational tools are locked
                                                </p>
                                                <p className='mt-1 text-sm text-amber-100/75'>
                                                    Finish the current onboarding step before the dashboard unlocks customer, VPS, billing, API, and domain controls.
                                                </p>
                                            </div>
                                            <Button
                                                type='button'
                                                variant='filled'
                                                onClick={() =>
                                                    window.location.assign(
                                                        overview.onboarding.currentPath
                                                    )
                                                }
                                            >
                                                Continue Onboarding
                                            </Button>
                                        </div>
                                    )}

                                    {billingProblemCount > 0 ? (
                                        <div className='mt-5 rounded-xl border border-amber-300/25 bg-amber-400/10 p-4 text-sm text-amber-100'>
                                            {billingProblemCount} billing item(s) are pending or failed. Open Billing to review renewals and delivery state.
                                        </div>
                                    ) : null}
                                </section>
                            )
                        })()}

                        <div className='grid gap-3 md:grid-cols-2 xl:grid-cols-5'>
                            {[
                                {
                                    label: 'Active Customers',
                                    value: compactNumber(overview.stats.activeUsers),
                                    hint: `${overview.stats.suspendedUsers} suspended`,
                                },
                                {
                                    label: 'Managed VPS',
                                    value: compactNumber(overview.stats.totalVms),
                                    hint: `${overview.queueHealth.building} building now`,
                                },
                                {
                                    label: 'Billing Orders',
                                    value: compactNumber(overview.stats.orders),
                                    hint: `${overview.billing.countsByStatus.active ?? 0} active`,
                                },
                                {
                                    label: 'Open Tickets',
                                    value: compactNumber(overview.tickets.openTotal),
                                    hint: `${overview.tickets.urgentTotal} urgent/high`,
                                },
                                {
                                    label: 'Abuse Alerts',
                                    value: compactNumber(overview.alerts.openTotal),
                                    hint: `${overview.alerts.criticalTotal} critical`,
                                },
                            ].map(card => (
                                <div
                                    key={card.label}
                                    className='rounded-xl border border-white/10 bg-[#1a1441] p-4 text-white'
                                >
                                    <p className='text-xs uppercase tracking-wide text-white/55'>
                                        {card.label}
                                    </p>
                                    <p className='mt-2 text-2xl font-semibold'>
                                        {card.value}
                                    </p>
                                    <p className='mt-2 text-xs text-white/60'>
                                        {card.hint}
                                    </p>
                                </div>
                            ))}
                        </div>

                        <div className='grid gap-4 xl:grid-cols-[minmax(0,1.5fr)_minmax(0,1fr)]'>
                            <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                                <div className='flex items-center justify-between'>
                                    <div>
                                        <h3 className='text-sm font-semibold uppercase tracking-wide text-white/80'>
                                            Resource Quota Tracking
                                        </h3>
                                        <p className='mt-1 text-xs text-white/55'>
                                            Keep reseller capacity below hard pool limits.
                                        </p>
                                    </div>
                                    <span className='rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-white/65'>
                                        {overview.pool.usedVms}/{overview.pool.maxVms} VPS
                                    </span>
                                </div>
                                <div className='mt-4 grid gap-3 md:grid-cols-2'>
                                    {[
                                        {
                                            key: 'RAM',
                                            used: `${toGbFromMb(overview.pool.usedRamMb)}`,
                                            max: `${toGbFromMb(overview.pool.maxRamMb)}`,
                                            pct: overview.pool.percentages.ram,
                                        },
                                        {
                                            key: 'CPU',
                                            used: `${overview.pool.usedCpuCores}`,
                                            max: `${overview.pool.maxCpuCores}`,
                                            pct: overview.pool.percentages.cpu,
                                        },
                                        {
                                            key: 'Disk',
                                            used: `${overview.pool.usedDiskGb} GB`,
                                            max: `${overview.pool.maxDiskGb} GB`,
                                            pct: overview.pool.percentages.disk,
                                        },
                                        {
                                            key: 'VMs',
                                            used: `${overview.pool.usedVms}`,
                                            max: `${overview.pool.maxVms}`,
                                            pct: overview.pool.percentages.vms,
                                        },
                                    ].map(item => (
                                        <div
                                            key={item.key}
                                            className='rounded-lg border border-white/10 bg-[#111a31] p-3'
                                        >
                                            <div className='flex items-center justify-between text-xs text-white/65'>
                                                <span>{item.key}</span>
                                                <span>{item.used} / {item.max}</span>
                                            </div>
                                            <div className='mt-2 h-2 rounded bg-white/10'>
                                                <div
                                                    className={`h-2 rounded ${
                                                        item.pct >= 90
                                                            ? 'bg-rose-400'
                                                            : item.pct >= 70
                                                              ? 'bg-amber-400'
                                                              : 'bg-emerald-400'
                                                    }`}
                                                    style={{
                                                        width: `${Math.min(item.pct, 100)}%`,
                                                    }}
                                                />
                                            </div>
                                            <p className='mt-2 text-xs text-white/55'>
                                                {item.pct.toFixed(2)}% consumed
                                            </p>
                                        </div>
                                    ))}
                                </div>
                            </div>

                            <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                                <h3 className='text-sm font-semibold uppercase tracking-wide text-white/80'>
                                    Billing Snapshot
                                </h3>
                                <div className='mt-4 space-y-3'>
                                    <div className='rounded-lg border border-white/10 bg-[#111a31] p-3 text-sm text-white/80'>
                                        <p className='text-xs uppercase tracking-wide text-white/55'>
                                            Settled Revenue
                                        </p>
                                        <div className='mt-2 space-y-1'>
                                            {(overview.billing.settledRevenueByCurrency.length
                                                ? overview.billing.settledRevenueByCurrency
                                                : overview.billing.grossRevenueByCurrency
                                            ).map(item => (
                                                <p key={`settled-${item.currency}`}>
                                                    {item.currency} {item.total.toFixed(2)}
                                                </p>
                                            ))}
                                            {overview.billing.grossRevenueByCurrency.length === 0 ? (
                                                <p className='text-white/55'>No order revenue yet.</p>
                                            ) : null}
                                        </div>
                                    </div>
                                    <div className='grid gap-3 md:grid-cols-2'>
                                        <div className='rounded-lg border border-white/10 bg-[#111a31] p-3 text-sm text-white/80'>
                                            <p className='text-xs uppercase tracking-wide text-white/55'>
                                                Paid / Active
                                            </p>
                                            <p className='mt-2 text-xl font-semibold text-white'>
                                                {(overview.billing.countsByStatus.paid ?? 0) +
                                                    (overview.billing.countsByStatus.active ?? 0)}
                                            </p>
                                        </div>
                                        <div className='rounded-lg border border-white/10 bg-[#111a31] p-3 text-sm text-white/80'>
                                            <p className='text-xs uppercase tracking-wide text-white/55'>
                                                Pending / Failed
                                            </p>
                                            <p className='mt-2 text-xl font-semibold text-white'>
                                                {(overview.billing.countsByStatus.pending ?? 0) +
                                                    (overview.billing.countsByStatus.failed ?? 0)}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className='grid gap-4 xl:grid-cols-3'>
                            <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                                <h3 className='text-sm font-semibold uppercase tracking-wide text-white/80'>
                                    Queue Health
                                </h3>
                                <div className='mt-4 grid gap-3'>
                                    {[
                                        ['Building', overview.queueHealth.building],
                                        ['Deleting', overview.queueHealth.deleting],
                                        ['Errors', overview.queueHealth.errors],
                                    ].map(([label, total]) => (
                                        <div
                                            key={String(label)}
                                            className='rounded-lg border border-white/10 bg-[#111a31] px-3 py-2 text-sm text-white/80'
                                        >
                                            <div className='flex items-center justify-between'>
                                                <span>{label}</span>
                                                <span className='font-semibold text-white'>
                                                    {total}
                                                </span>
                                            </div>
                                        </div>
                                    ))}
                                    <p className='text-xs text-white/55'>
                                        7-day provisioning: {overview.timeline.serversCreatedLast7Days
                                            .map(item => `${item.day.split('-').slice(1).join('/')}=${item.total}`)
                                            .join(' | ') || 'No recent provisioning'}
                                    </p>
                                </div>
                            </div>

                            <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                                <div className='flex items-center justify-between'>
                                    <h3 className='text-sm font-semibold uppercase tracking-wide text-white/80'>
                                        Recent Support Tickets
                                    </h3>
                                    <Button size='sm' onClick={() => openSection('tickets')}>
                                        Open Support
                                    </Button>
                                </div>
                                <div className='mt-4 space-y-2'>
                                    {overview.tickets.items.length === 0 ? (
                                        <p className='rounded-lg border border-dashed border-white/15 px-3 py-4 text-sm text-white/55'>
                                            No reseller tickets yet.
                                        </p>
                                    ) : (
                                        overview.tickets.items.map(item => (
                                            <button
                                                key={item.id}
                                                type='button'
                                                className='block w-full rounded-lg border border-white/10 bg-[#111a31] p-3 text-left transition hover:border-indigo-400/30 hover:bg-indigo-500/10'
                                                onClick={() => {
                                                    openSection('tickets')
                                                    void openTicket(item.id)
                                                }}
                                            >
                                                <div className='flex items-center justify-between gap-3'>
                                                    <p className='text-sm font-semibold text-white'>
                                                        {item.ticketNumber}
                                                    </p>
                                                    <span className='text-[11px] uppercase tracking-wide text-white/50'>
                                                        {item.priority}
                                                    </span>
                                                </div>
                                                <p className='mt-1 text-sm text-white/80'>
                                                    {item.subject}
                                                </p>
                                                <p className='mt-1 text-xs text-white/55'>
                                                    {item.customerEmail}
                                                </p>
                                            </button>
                                        ))
                                    )}
                                </div>
                            </div>

                            <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                                <div className='flex items-center justify-between'>
                                    <h3 className='text-sm font-semibold uppercase tracking-wide text-white/80'>
                                        Abuse Alerts
                                    </h3>
                                    <span className='rounded-full border border-rose-400/20 bg-rose-500/10 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide text-rose-100'>
                                        {overview.alerts.openTotal} open
                                    </span>
                                </div>
                                <div className='mt-4 space-y-2'>
                                    {overview.alerts.items.length === 0 ? (
                                        <p className='rounded-lg border border-dashed border-white/15 px-3 py-4 text-sm text-white/55'>
                                            No open abuse signals for this reseller.
                                        </p>
                                    ) : (
                                        overview.alerts.items.map(item => (
                                            <div
                                                key={item.id}
                                                className='rounded-lg border border-white/10 bg-[#111a31] p-3'
                                            >
                                                <div className='flex items-center justify-between gap-3'>
                                                    <p className='text-sm font-semibold text-white'>
                                                        {item.title}
                                                    </p>
                                                    <span className='text-[11px] uppercase tracking-wide text-white/50'>
                                                        {item.severity}
                                                    </span>
                                                </div>
                                                <p className='mt-1 text-xs text-white/60'>
                                                    {item.serverName} · {item.customerEmail}
                                                </p>
                                            </div>
                                        ))
                                    )}
                                </div>
                            </div>
                        </div>

                        <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4 text-white'>
                            <h3 className='text-sm font-semibold uppercase tracking-wide text-white/80'>
                                Failed Provisioning Tasks
                            </h3>
                            <div className='mt-3 space-y-2'>
                                {(overview.failedTasks.items || []).slice(0, 4).map(item => (
                                    <div
                                        key={`${item.id}-${item.uuid}`}
                                        className='rounded-lg border border-white/10 bg-[#111a31] p-3 text-xs text-white/80'
                                    >
                                        <p className='font-semibold text-white/90'>{item.name}</p>
                                        <p className='mt-1 text-white/60'>
                                            {item.error || 'Failed with no message.'}
                                        </p>
                                    </div>
                                ))}
                                {overview.failedTasks.count === 0 ? (
                                    <p className='text-xs text-white/60'>
                                        No recent failed jobs for this reseller.
                                    </p>
                                ) : null}
                            </div>
                        </div>
                    </div>
                ) : null}

                {section === 'users' ? (
                    <div className='space-y-4'>
                        <form
                            className='rounded-xl border border-white/10 bg-[#1a1441] p-4'
                            onSubmit={createUser}
                        >
                            <h3 className='text-lg font-semibold text-white'>
                                Create Customer
                            </h3>
                            <p className='mt-1 text-sm text-white/60'>
                                Create a customer inside this reseller tenant only. Set a manual password or let WammuCore generate one.
                            </p>
                            <div className='mt-3 grid gap-3 md:grid-cols-2'>
                                <TextInput
                                    label='Name'
                                    required
                                    value={newUserName}
                                    onChange={event =>
                                        setNewUserName(event.currentTarget.value)
                                    }
                                />
                                <TextInput
                                    label='Email'
                                    required
                                    type='email'
                                    value={newUserEmail}
                                    onChange={event =>
                                        setNewUserEmail(event.currentTarget.value)
                                    }
                                />
                                <TextInput
                                    label='Support PIN'
                                    description='Optional. Leave empty to auto-generate.'
                                    value={newUserSupportPin}
                                    onChange={event =>
                                        setNewUserSupportPin(event.currentTarget.value)
                                    }
                                />
                                <div className='rounded-lg border border-white/10 bg-white/[0.03] p-3'>
                                    <Checkbox
                                        label='Auto-generate secure password'
                                        checked={newUserAutoGeneratePassword}
                                        onChange={event =>
                                            setNewUserAutoGeneratePassword(
                                                event.currentTarget.checked
                                            )
                                        }
                                    />
                                    <p className='mt-2 text-xs text-white/50'>
                                        If enabled, the generated password is shown once after creation.
                                    </p>
                                </div>
                                {!newUserAutoGeneratePassword ? (
                                    <TextInput
                                        label='Customer Password'
                                        required
                                        type='password'
                                        autoComplete='new-password'
                                        description='Minimum 8 characters.'
                                        value={newUserPassword}
                                        onChange={event =>
                                            setNewUserPassword(event.currentTarget.value)
                                        }
                                    />
                                ) : null}
                                <div className='rounded-lg border border-white/10 bg-white/[0.03] p-3'>
                                    <Checkbox
                                        label='Require password change on first login'
                                        checked={newUserMustChangePassword}
                                        onChange={event =>
                                            setNewUserMustChangePassword(
                                                event.currentTarget.checked
                                            )
                                        }
                                    />
                                    <p className='mt-2 text-xs text-white/50'>
                                        Recommended for generated or temporary passwords.
                                    </p>
                                </div>
                            </div>
                            {createdCustomerSecret ? (
                                <div className='mt-3 rounded-xl border border-emerald-400/30 bg-emerald-500/10 p-3 text-sm text-emerald-50'>
                                    <div className='flex flex-col gap-3 md:flex-row md:items-center md:justify-between'>
                                        <div>
                                            <p className='font-semibold'>
                                                Password generated for {createdCustomerSecret.email}
                                            </p>
                                            <p className='mt-1 break-all font-mono text-emerald-100'>
                                                {createdCustomerSecret.password}
                                            </p>
                                            <p className='mt-1 text-xs text-emerald-100/70'>
                                                Copy it now. This password is not shown again.
                                            </p>
                                        </div>
                                        <Button
                                            type='button'
                                            size='sm'
                                            onClick={() =>
                                                void copyCreatedCustomerPassword(
                                                    createdCustomerSecret.password
                                                )
                                            }
                                        >
                                            Copy Password
                                        </Button>
                                    </div>
                                </div>
                            ) : null}
                            <div className='mt-3'>
                                <Button type='submit' variant='filled'>
                                    Create Customer
                                </Button>
                            </div>
                        </form>

                        <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                            <div className='mb-3 grid gap-3 md:grid-cols-2'>
                                <TextInput
                                    label='Search'
                                    value={usersQuery}
                                    onChange={event => {
                                        setUsersPage(1)
                                        setUsersQuery(event.currentTarget.value)
                                    }}
                                />
                            </div>
                            <div className='overflow-x-auto'>
                                <table className='w-full min-w-[900px]'>
                                    <thead>
                                        <tr className='text-left text-xs uppercase text-white/60'>
                                            <th className='py-2'>ID</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Services</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {(users?.items || []).map(user => (
                                            <tr
                                                key={user.id}
                                                className='border-t border-white/10 text-sm text-white/90'
                                            >
                                                <td className='py-2'>{user.id}</td>
                                                <td>
                                                    <button
                                                        type='button'
                                                        onClick={() => openUserSettings(user.id)}
                                                        className='font-semibold text-sky-100 underline decoration-sky-300/40 underline-offset-4 transition hover:text-white hover:decoration-sky-100'
                                                        title='Edit customer email, password, and access'
                                                    >
                                                        {user.name}
                                                    </button>
                                                </td>
                                                <td>
                                                    <button
                                                        type='button'
                                                        onClick={() => openUserSettings(user.id)}
                                                        className='text-sky-100 underline decoration-sky-300/40 underline-offset-4 transition hover:text-white hover:decoration-sky-100'
                                                        title='Edit customer email, password, and access'
                                                    >
                                                        {user.email}
                                                    </button>
                                                </td>
                                                <td>{user.serversCount}</td>
                                                <td>
                                                    {user.isDisabled
                                                        ? 'Disabled'
                                                        : 'Active'}
                                                </td>
                                                <td>
                                                    <div className='flex flex-wrap gap-1 py-1'>
                                                        <Button
                                                            size='sm'
                                                            onClick={() =>
                                                                openUserSettings(user.id)
                                                            }
                                                        >
                                                            Edit
                                                        </Button>
                                                        <Button
                                                            size='sm'
                                                            onClick={() =>
                                                                void quickToggleUser(
                                                                    user
                                                                )
                                                            }
                                                        >
                                                            {user.isDisabled
                                                                ? 'Enable'
                                                                : 'Disable'}
                                                        </Button>
                                                        <Button
                                                            size='sm'
                                                            onClick={() =>
                                                                void quickResetPassword(
                                                                    user
                                                                )
                                                            }
                                                        >
                                                            Reset Password
                                                        </Button>
                                                        <Button
                                                            size='sm'
                                                            color='danger'
                                                            onClick={() =>
                                                                void quickDeleteUser(
                                                                    user
                                                                )
                                                            }
                                                        >
                                                            Delete
                                                        </Button>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                            <div className='mt-3 flex gap-2'>
                                <Button
                                    size='sm'
                                    disabled={!users || usersPage <= 1}
                                    onClick={() =>
                                        setUsersPage(current =>
                                            Math.max(1, current - 1)
                                        )
                                    }
                                >
                                    Prev
                                </Button>
                                <Button
                                    size='sm'
                                    disabled={
                                        !users ||
                                        usersPage >= users.pagination.totalPages
                                    }
                                    onClick={() =>
                                        setUsersPage(current => current + 1)
                                    }
                                >
                                    Next
                                </Button>
                            </div>
                        </div>
                    </div>
                ) : null}

                {section === 'services' ? (
                    <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                        <TextInput
                            label='Search'
                            value={servicesQuery}
                            onChange={event => {
                                setServicesPage(1)
                                setServicesQuery(event.currentTarget.value)
                            }}
                        />
                        <div className='mt-3 overflow-x-auto'>
                            <table className='w-full min-w-[1100px]'>
                                <thead>
                                    <tr className='text-left text-xs uppercase text-white/60'>
                                        <th className='py-2'>Service</th>
                                        <th>User</th>
                                        <th>Node</th>
                                        <th>Status</th>
                                        <th>IP</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {(services?.items || []).map(service => (
                                        <tr
                                            key={service.id}
                                            className='border-t border-white/10 text-sm text-white/90'
                                        >
                                            <td className='py-2'>
                                                {service.name}
                                                <p className='text-xs text-white/60'>
                                                    {service.hostname}
                                                </p>
                                            </td>
                                            <td>
                                                {service.user ? (
                                                    <button
                                                        type='button'
                                                        onClick={() =>
                                                            openUserSettings(service.user!.id)
                                                        }
                                                        className='text-sky-100 underline decoration-sky-300/40 underline-offset-4 transition hover:text-white hover:decoration-sky-100'
                                                        title='Edit this customer'
                                                    >
                                                        {service.user.email}
                                                    </button>
                                                ) : (
                                                    '-'
                                                )}
                                            </td>
                                            <td>{service.node?.name || '-'}</td>
                                            <td>{service.status || '-'}</td>
                                            <td>
                                                {service.addresses
                                                    .map(item => item.address)
                                                    .join(', ') || '-'}
                                            </td>
                                            <td>
                                                <div className='flex flex-wrap gap-1 py-1'>
                                                    <Button
                                                        size='sm'
                                                        onClick={() =>
                                                            void quickServicePower(
                                                                service,
                                                                'start'
                                                            )
                                                        }
                                                    >
                                                        Start
                                                    </Button>
                                                    <Button
                                                        size='sm'
                                                        onClick={() =>
                                                            void quickServicePower(
                                                                service,
                                                                'stop'
                                                            )
                                                        }
                                                    >
                                                        Stop
                                                    </Button>
                                                    <Button
                                                        size='sm'
                                                        onClick={() =>
                                                            void quickServicePower(
                                                                service,
                                                                'restart'
                                                            )
                                                        }
                                                    >
                                                        Restart
                                                    </Button>
                                                    <Button
                                                        size='sm'
                                                        onClick={() =>
                                                            void quickServiceSuspend(
                                                                service,
                                                                true
                                                            )
                                                        }
                                                    >
                                                        Suspend
                                                    </Button>
                                                    <Button
                                                        size='sm'
                                                        onClick={() =>
                                                            void quickServiceSuspend(
                                                                service,
                                                                false
                                                            )
                                                        }
                                                    >
                                                        Unsuspend
                                                    </Button>
                                                    <Button
                                                        size='sm'
                                                        onClick={() =>
                                                            void quickServiceReassign(
                                                                service
                                                            )
                                                        }
                                                    >
                                                        Reassign
                                                    </Button>
                                                    <Button
                                                        size='sm'
                                                        onClick={() =>
                                                            void quickServiceReinstall(
                                                                service
                                                            )
                                                        }
                                                    >
                                                        Reinstall
                                                    </Button>
                                                    <Button
                                                        size='sm'
                                                        onClick={() =>
                                                            void quickServiceVnc(
                                                                service
                                                            )
                                                        }
                                                    >
                                                        VNC
                                                    </Button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                ) : null}

                {section === 'dedicated_hardware' ? (
                    <div className='space-y-4'>
                        <section className='overflow-hidden rounded-3xl border border-cyan-300/20 bg-[radial-gradient(circle_at_top_left,rgba(34,211,238,0.18),transparent_36%),linear-gradient(135deg,rgba(13,30,55,0.96),rgba(27,20,74,0.92))] p-5 text-white shadow-[0_0_45px_rgba(34,211,238,0.12)]'>
                            <div className='flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between'>
                                <div className='min-w-0'>
                                    <p className='text-xs font-semibold uppercase tracking-[0.26em] text-cyan-100/70'>
                                        Dedicated Hardware
                                    </p>
                                    <h3 className='mt-2 text-2xl font-semibold'>
                                        Reseller-owned Proxmox nodes
                                    </h3>
                                    <p className='mt-2 max-w-3xl text-sm leading-6 text-white/68'>
                                        Use this when a reseller buys dedicated hardware from
                                        you. Root admin assigns the Proxmox access here, then the
                                        reseller creates their own location and node using a
                                        secure Proxmox API token. This capacity is private to
                                        that reseller and does not consume normal shared VPS
                                        stock; it is limited only by the dedicated node capacity
                                        and safety thresholds configured below.
                                    </p>
                                </div>
                                <div className='grid grid-cols-3 gap-2 text-center text-xs sm:min-w-[320px]'>
                                    <div className='rounded-2xl border border-white/10 bg-white/8 p-3'>
                                        <p className='text-white/50'>Assigned</p>
                                        <p className='mt-1 text-xl font-semibold'>
                                            {dedicatedHardware?.items.length ?? 0}
                                        </p>
                                    </div>
                                    <div className='rounded-2xl border border-emerald-300/20 bg-emerald-400/10 p-3'>
                                        <p className='text-emerald-100/70'>Active</p>
                                        <p className='mt-1 text-xl font-semibold'>
                                            {(dedicatedHardware?.items || []).filter(
                                                item => item.status === 'active'
                                            ).length}
                                        </p>
                                    </div>
                                    <div className='rounded-2xl border border-amber-300/20 bg-amber-400/10 p-3'>
                                        <p className='text-amber-100/70'>Setup</p>
                                        <p className='mt-1 text-xl font-semibold'>
                                            {(dedicatedHardware?.items || []).filter(
                                                item =>
                                                    !item.node &&
                                                    ['pending', 'ready'].includes(
                                                        item.status
                                                    )
                                            ).length}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section className='rounded-2xl border border-white/10 bg-[#111a31]/95 p-5 text-white'>
                            <div className='flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between'>
                                <div>
                                    <p className='text-xs font-semibold uppercase tracking-[0.22em] text-cyan-100/65'>
                                        Dedicated plan system
                                    </p>
                                    <h4 className='mt-2 text-lg font-semibold'>
                                        Dedicated specs and pricing
                                    </h4>
                                    <p className='mt-2 max-w-3xl text-sm leading-6 text-white/60'>
                                        These plans are only for reseller-owned dedicated
                                        hardware. They stay separate from shared EPYC/Ryzen VPS
                                        stock, IP pool pricing, and customer VPS catalog plans.
                                    </p>
                                </div>
                                {dedicatedHardware?.canManageDedicatedPlans ? (
                                    <div className='flex flex-wrap gap-2'>
                                        <Button type='button' variant='outline' onClick={addDedicatedPlanDraft}>
                                            Add Dedicated Plan
                                        </Button>
                                        <Button
                                            type='button'
                                            loading={loading}
                                            onClick={() => void saveDedicatedPlanDrafts()}
                                        >
                                            Save Dedicated Plans
                                        </Button>
                                    </div>
                                ) : null}
                            </div>

                            <div className='mt-5 grid gap-4'>
                                {dedicatedPlanDrafts.map((plan, index) => (
                                    <div
                                        key={`${plan.id}-${index}`}
                                        className='rounded-2xl border border-white/10 bg-black/15 p-4'
                                    >
                                        <div className='flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between'>
                                            <div>
                                                <p className='text-xs font-semibold uppercase tracking-[0.2em] text-white/45'>
                                                    Dedicated Plan #{index + 1}
                                                </p>
                                                <h5 className='mt-1 text-base font-semibold text-white'>
                                                    {plan.name || 'Dedicated Hardware'}
                                                </h5>
                                            </div>
                                            {dedicatedHardware?.canManageDedicatedPlans ? (
                                                <label className='flex items-center gap-2 text-sm text-white/70'>
                                                    <input
                                                        type='checkbox'
                                                        checked={plan.isActive}
                                                        onChange={event =>
                                                            patchDedicatedPlanDraft(index, {
                                                                isActive: event.currentTarget.checked,
                                                            })
                                                        }
                                                    />
                                                    Active
                                                </label>
                                            ) : (
                                                <span className='w-fit rounded-full border border-emerald-300/25 bg-emerald-400/10 px-3 py-1 text-xs font-semibold text-emerald-100'>
                                                    {plan.isActive ? 'Active' : 'Hidden'}
                                                </span>
                                            )}
                                        </div>

                                        <div className='mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-4'>
                                            <input
                                                className='theme-input rounded-xl px-3 py-2 text-sm'
                                                value={plan.name}
                                                disabled={!dedicatedHardware?.canManageDedicatedPlans}
                                                onChange={event => patchDedicatedPlanDraft(index, { name: event.currentTarget.value })}
                                                placeholder='Plan name'
                                            />
                                            <input
                                                className='theme-input rounded-xl px-3 py-2 text-sm'
                                                value={plan.currency}
                                                disabled={!dedicatedHardware?.canManageDedicatedPlans}
                                                onChange={event => patchDedicatedPlanDraft(index, { currency: event.currentTarget.value.toUpperCase().slice(0, 3) })}
                                                placeholder='INR'
                                            />
                                            <input
                                                className='theme-input rounded-xl px-3 py-2 text-sm'
                                                value={plan.monthlyPrice}
                                                disabled={!dedicatedHardware?.canManageDedicatedPlans}
                                                onChange={event => patchDedicatedPlanDraft(index, { monthlyPrice: event.currentTarget.value })}
                                                placeholder='Monthly price'
                                            />
                                            <input
                                                className='theme-input rounded-xl px-3 py-2 text-sm'
                                                value={plan.setupFee}
                                                disabled={!dedicatedHardware?.canManageDedicatedPlans}
                                                onChange={event => patchDedicatedPlanDraft(index, { setupFee: event.currentTarget.value })}
                                                placeholder='Setup fee'
                                            />
                                            <input
                                                className='theme-input rounded-xl px-3 py-2 text-sm'
                                                type='number'
                                                value={plan.cpuCores}
                                                disabled={!dedicatedHardware?.canManageDedicatedPlans}
                                                onChange={event => patchDedicatedPlanDraft(index, { cpuCores: Number(event.currentTarget.value || 0) })}
                                                placeholder='CPU cores'
                                            />
                                            <input
                                                className='theme-input rounded-xl px-3 py-2 text-sm'
                                                type='number'
                                                value={plan.ramGb}
                                                disabled={!dedicatedHardware?.canManageDedicatedPlans}
                                                onChange={event => patchDedicatedPlanDraft(index, { ramGb: Number(event.currentTarget.value || 0) })}
                                                placeholder='RAM GB'
                                            />
                                            <input
                                                className='theme-input rounded-xl px-3 py-2 text-sm'
                                                type='number'
                                                value={plan.diskGb}
                                                disabled={!dedicatedHardware?.canManageDedicatedPlans}
                                                onChange={event => patchDedicatedPlanDraft(index, { diskGb: Number(event.currentTarget.value || 0) })}
                                                placeholder='Disk GB'
                                            />
                                            <input
                                                className='theme-input rounded-xl px-3 py-2 text-sm'
                                                type='number'
                                                value={plan.bandwidthTb}
                                                disabled={!dedicatedHardware?.canManageDedicatedPlans}
                                                onChange={event => patchDedicatedPlanDraft(index, { bandwidthTb: Number(event.currentTarget.value || 0) })}
                                                placeholder='Bandwidth TB'
                                            />
                                        </div>
                                        <textarea
                                            className='theme-input mt-3 min-h-[78px] w-full rounded-xl px-3 py-2 text-sm'
                                            value={plan.description}
                                            disabled={!dedicatedHardware?.canManageDedicatedPlans}
                                            onChange={event => patchDedicatedPlanDraft(index, { description: event.currentTarget.value })}
                                            placeholder='Dedicated hardware description'
                                        />
                                        {dedicatedHardware?.canManageDedicatedPlans ? (
                                            <div className='mt-3 flex justify-end'>
                                                <Button
                                                    type='button'
                                                    variant='outline'
                                                    onClick={() => removeDedicatedPlanDraft(index)}
                                                >
                                                    Remove
                                                </Button>
                                            </div>
                                        ) : null}
                                    </div>
                                ))}
                                {dedicatedPlanDrafts.length === 0 ? (
                                    <p className='rounded-xl border border-dashed border-white/15 p-4 text-sm text-white/55'>
                                        No dedicated hardware plans configured yet. Root admin can
                                        add dedicated specs and pricing here.
                                    </p>
                                ) : null}
                            </div>
                        </section>

                        {dedicatedHardware?.canAssign ? (
                            <form
                                onSubmit={assignDedicatedHardware}
                                className='rounded-2xl border border-white/10 bg-[#16133a]/95 p-5 text-white'
                            >
                                <div className='flex flex-col gap-2 md:flex-row md:items-start md:justify-between'>
                                    <div>
                                        <p className='text-xs font-semibold uppercase tracking-[0.22em] text-white/45'>
                                            Root admin handover
                                        </p>
                                        <h4 className='mt-1 text-lg font-semibold'>
                                            Assign purchased hardware
                                        </h4>
                                        <p className='mt-1 text-sm text-white/58'>
                                            Add the Proxmox host details after the billing purchase.
                                            Password is stored encrypted and never shown back in the
                                            panel.
                                        </p>
                                    </div>
                                    <Button type='submit' variant='filled' loading={loading}>
                                        Assign Hardware
                                    </Button>
                                </div>
                                <div className='mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-3'>
                                    <TextInput name='name' label='Hardware name' placeholder='Dedicated Ryzen Node 1' required />
                                    <TextInput name='paymenter_service_id' label='Billing service ID' placeholder='Optional external service id' />
                                    <TextInput name='provider_order_ref' label='Order reference' placeholder='Invoice, order, or ticket ref' />
                                    <TextInput name='proxmox_host' label='Proxmox IP / hostname' placeholder='203.0.113.10' required />
                                    <TextInput name='proxmox_port' label='Proxmox port' defaultValue='8006' required />
                                    <TextInput name='proxmox_username' label='Login username' placeholder='root@pam' />
                                    <TextInput name='proxmox_password' label='Login password' type='password' placeholder='Stored encrypted' />
                                    <TextInput name='public_notes' label='Note for reseller' placeholder='Use this host to create your API token.' />
                                    <TextInput name='internal_notes' label='Internal note' placeholder='Root admin only' />
                                </div>
                            </form>
                        ) : null}

                        <div className='grid gap-4 xl:grid-cols-2'>
                            {(dedicatedHardware?.items || []).map(item => {
                                const status = dedicatedHardwareStatusMeta(item.status)

                                return (
                                    <article
                                        key={item.id}
                                        className='rounded-2xl border border-white/10 bg-[#111a31]/95 p-5 text-white shadow-[0_0_30px_rgba(99,102,241,0.10)]'
                                    >
                                        <div className='flex flex-col gap-4 md:flex-row md:items-start md:justify-between'>
                                            <div className='min-w-0'>
                                                <p className='text-xs uppercase tracking-[0.2em] text-white/45'>
                                                    Hardware #{item.id}
                                                </p>
                                                <h4 className='mt-1 break-words text-xl font-semibold'>
                                                    {item.name}
                                                </h4>
                                                <p className='mt-1 break-all font-mono text-xs text-cyan-100/70'>
                                                    {item.proxmoxHost}:{item.proxmoxPort}
                                                </p>
                                            </div>
                                            <span
                                                className={`w-fit rounded-full border px-3 py-1 text-xs font-semibold ${status.className}`}
                                            >
                                                {status.label}
                                            </span>
                                        </div>

                                        <div className='mt-4 grid gap-3 sm:grid-cols-2'>
                                            <div className='rounded-xl border border-white/10 bg-white/5 p-3'>
                                                <p className='text-xs text-white/45'>Access</p>
                                                <p className='mt-1 text-sm font-semibold'>
                                                    {item.proxmoxUsername || 'Not provided'}
                                                </p>
                                                <p className='mt-1 text-xs text-white/50'>
                                                    Password {item.proxmoxPasswordSet ? 'stored securely' : 'not stored'}
                                                </p>
                                            </div>
                                            <div className='rounded-xl border border-white/10 bg-white/5 p-3'>
                                                <p className='text-xs text-white/45'>Billing service</p>
                                                <p className='mt-1 break-all text-sm font-semibold'>
                                                    {item.paymenterServiceId || 'Manual / pending'}
                                                </p>
                                                <p className='mt-1 break-all text-xs text-white/50'>
                                                    {item.providerOrderRef || 'No order reference'}
                                                </p>
                                            </div>
                                            <div className='rounded-xl border border-white/10 bg-white/5 p-3'>
                                                <p className='text-xs text-white/45'>Location</p>
                                                <p className='mt-1 text-sm font-semibold'>
                                                    {item.location?.shortCode || 'Not created'}
                                                </p>
                                                <p className='mt-1 text-xs text-white/50'>
                                                    {item.location?.description || 'Create below'}
                                                </p>
                                            </div>
                                            <div className='rounded-xl border border-white/10 bg-white/5 p-3'>
                                                <p className='text-xs text-white/45'>Node</p>
                                                <p className='mt-1 text-sm font-semibold'>
                                                    {item.node?.name || 'Not attached'}
                                                </p>
                                                <p className='mt-1 break-all text-xs text-white/50'>
                                                    {item.node
                                                        ? `${item.node.cluster} @ ${item.node.fqdn}`
                                                        : 'Waiting for setup'}
                                                </p>
                                            </div>
                                        </div>

                                        {item.publicNotes ? (
                                            <p className='mt-4 rounded-xl border border-cyan-300/15 bg-cyan-400/5 p-3 text-sm text-cyan-50/80'>
                                                {item.publicNotes}
                                            </p>
                                        ) : null}

                                        {!item.node && ['pending', 'ready'].includes(item.status) ? (
                                            <form
                                                onSubmit={event =>
                                                    configureDedicatedHardwareNode(
                                                        item.id,
                                                        event
                                                    )
                                                }
                                                className='mt-5 rounded-2xl border border-cyan-300/15 bg-cyan-400/5 p-4'
                                            >
                                                <div className='flex flex-col gap-2 md:flex-row md:items-start md:justify-between'>
                                                    <div>
                                                        <p className='text-xs font-semibold uppercase tracking-[0.22em] text-cyan-100/70'>
                                                            Create location & node
                                                        </p>
                                                        <p className='mt-1 text-sm text-white/62'>
                                                            Create a Proxmox API token on this hardware, then paste the token here. This makes the node reseller-owned and keeps it isolated from platform nodes.
                                                        </p>
                                                    </div>
                                                    <Button type='submit' variant='filled' loading={loading}>
                                                        Create Node
                                                    </Button>
                                                </div>
                                                <div className='mt-4 rounded-xl border border-emerald-300/20 bg-emerald-400/10 p-3 text-sm text-emerald-50/82'>
                                                    Dedicated hardware creates a reseller-owned
                                                    location and node. Customer VPS provisioning on
                                                    this node uses the node capacity directly, not
                                                    the shared reseller VPS-stock counter.
                                                </div>
                                                <div className='mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-3'>
                                                    <TextInput name='location_short_code' label='Location code' placeholder='mumbai-dedi' required />
                                                    <TextInput name='location_description' label='Location name' placeholder='Mumbai Dedicated' />
                                                    <TextInput name='node_name' label='Node display name' defaultValue={item.name} required />
                                                    <TextInput name='cluster' label='Proxmox node name' placeholder='pve' required />
                                                    <TextInput name='api_token_id' label='API token ID' placeholder='root@pam!wammucore' required />
                                                    <TextInput name='api_token_secret' label='API token secret' type='password' required />
                                                    <TextInput name='memory_gb' label='Total RAM (GiB)' defaultValue='64' required />
                                                    <TextInput name='disk_gb' label='Total disk (GiB)' defaultValue='1000' required />
                                                    <TextInput name='memory_overallocate' label='RAM overallocate (%)' defaultValue='0' required />
                                                    <TextInput name='disk_overallocate' label='Disk overallocate (%)' defaultValue='0' required />
                                                    <TextInput name='vm_storage' label='VM storage' defaultValue='local-lvm' required />
                                                    <TextInput name='backup_storage' label='Backup storage' defaultValue='local' required />
                                                    <TextInput name='iso_storage' label='ISO storage' defaultValue='local' required />
                                                    <TextInput name='network' label='Bridge / network' defaultValue='vmbr0' required />
                                                    <TextInput name='provisioning_priority' label='Provisioning priority' defaultValue='100' required />
                                                    <TextInput name='provisioning_memory_threshold_percent' label='RAM threshold (%)' defaultValue='95' required />
                                                    <TextInput name='provisioning_disk_threshold_percent' label='Disk threshold (%)' defaultValue='95' required />
                                                    <TextInput name='reinstall_limit_per_week' label='Reinstall limit / week' defaultValue='2' required />
                                                </div>
                                                <div className='mt-4 flex flex-wrap gap-4 text-sm text-white/75'>
                                                    <label className='inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2'>
                                                        <input name='verify_tls' type='checkbox' defaultChecked />
                                                        Verify TLS certificate
                                                    </label>
                                                    <label className='inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2'>
                                                        <input name='provisioning_enabled' type='checkbox' defaultChecked />
                                                        Enable provisioning
                                                    </label>
                                                </div>
                                            </form>
                                        ) : null}
                                    </article>
                                )
                            })}
                        </div>

                        {(dedicatedHardware?.items || []).length === 0 ? (
                            <div className='rounded-2xl border border-dashed border-white/15 bg-[#111a31]/90 p-6 text-sm text-white/65'>
                                No dedicated hardware has been assigned yet. After a
                                billing purchase, root admin can add the Proxmox
                                host here and the reseller can finish node setup.
                            </div>
                        ) : null}
                    </div>
                ) : null}

                {section === 'resources' ||
                section === 'buy_servers' ||
                section === 'buy_ips' ? (
                    <div className='space-y-4'>
                        <div className='rounded-2xl border border-cyan-300/20 bg-gradient-to-br from-[#10233f]/95 via-[#171449]/90 to-[#071423]/95 p-5 text-white shadow-[0_0_45px_rgba(34,211,238,0.12)]'>
                            <div className='flex flex-col gap-3 md:flex-row md:items-center md:justify-between'>
                                <div>
                                    <p className='text-xs uppercase tracking-[0.22em] text-cyan-100/70'>
                                        {section === 'buy_servers'
                                            ? 'Buy VPS Stock'
                                            : section === 'buy_ips'
                                                ? 'Buy IP Stock'
                                                : 'Your Resources'}
                                    </p>
                                    <h3 className='mt-1 text-xl font-semibold'>
                                        {section === 'buy_servers'
                                            ? 'Available reseller VPS plans'
                                            : section === 'buy_ips'
                                                ? 'Available reseller IP pools'
                                                : 'Wholesale stock owned by this reseller'}
                                    </h3>
                                    <p className='mt-2 max-w-3xl text-sm text-white/65'>
                                        {section === 'buy_servers'
                                            ? 'Pick a platform VPS plan and buy stock for your reseller account. Stock appears in Your Resources after billing confirms payment.'
                                            : section === 'buy_ips'
                                                ? 'Buy IP quantity from reseller-enabled pools. Only free IPv4 inventory is shown as available for new purchase.'
                                                : 'Track the VPS plan units and IP pool stock already assigned to this reseller account.'}
                                    </p>
                                </div>
                                <div className='flex flex-wrap gap-2'>
                                    <Button size='sm' onClick={() => openSection('buy_servers')}>
                                        Buy Servers
                                    </Button>
                                    <Button size='sm' onClick={() => openSection('buy_ips')}>
                                        Buy IPs
                                    </Button>
                                    <Button size='sm' onClick={() => openSection('resources')}>
                                        Your Resources
                                    </Button>
                                </div>
                            </div>
                        </div>

                        {section === 'resources' ? (
                            <div className='grid gap-4 xl:grid-cols-2'>
                                <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                                    <h4 className='text-lg font-semibold text-white'>
                                        VPS Plan Stock
                                    </h4>
                                    <div className='mt-4 space-y-3'>
                                        {(overview?.resources.plans || []).map(plan => (
                                            <div
                                                key={plan.catalogPlanId}
                                                className='rounded-lg border border-white/10 bg-[#111a31] p-3 text-white'
                                            >
                                                <div className='flex flex-wrap items-start justify-between gap-3'>
                                                    <div>
                                                        <p className='font-semibold'>
                                                            {plan.name}
                                                        </p>
                                                        <p className='mt-1 text-xs text-white/60'>
                                                            {plan.specs.cpuCores} CPU /{' '}
                                                            {plan.specs.ramMb} MB RAM /{' '}
                                                            {plan.specs.diskGb} GB Disk
                                                        </p>
                                                    </div>
                                                    <span className='rounded-full border border-emerald-300/30 bg-emerald-400/10 px-3 py-1 text-xs font-semibold text-emerald-100'>
                                                        {plan.quantityAvailable} in stock
                                                    </span>
                                                </div>
                                                <div className='mt-3 grid grid-cols-3 gap-2 text-center text-xs'>
                                                    <div className='rounded bg-white/5 p-2'>
                                                        <p className='text-white/55'>Owned</p>
                                                        <p className='text-base font-semibold'>
                                                            {plan.quantityTotal}
                                                        </p>
                                                    </div>
                                                    <div className='rounded bg-white/5 p-2'>
                                                        <p className='text-white/55'>Used</p>
                                                        <p className='text-base font-semibold'>
                                                            {plan.quantityUsed}
                                                        </p>
                                                    </div>
                                                    <div className='rounded bg-white/5 p-2'>
                                                        <p className='text-white/55'>Free</p>
                                                        <p className='text-base font-semibold'>
                                                            {plan.quantityAvailable}
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                        {(overview?.resources.plans || []).length === 0 ? (
                                            <p className='rounded-lg border border-dashed border-white/15 p-4 text-sm text-white/60'>
                                                No VPS plan stock has been purchased yet.
                                            </p>
                                        ) : null}
                                    </div>
                                </div>

                                <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                                    <h4 className='text-lg font-semibold text-white'>
                                        IP Pool Stock
                                    </h4>
                                    <div className='mt-4 space-y-3'>
                                        {(overview?.resources.ipPools || []).map(pool => (
                                            <div
                                                key={pool.addressPoolId}
                                                className='rounded-lg border border-white/10 bg-[#111a31] p-3 text-white'
                                            >
                                                <div className='flex flex-wrap items-start justify-between gap-3'>
                                                    <div>
                                                        <p className='font-semibold'>
                                                            {pool.name}
                                                        </p>
                                                        <p className='mt-1 text-xs text-white/60'>
                                                            Provider cost {formatMoney(pool.priceEach)} / IP
                                                        </p>
                                                    </div>
                                                    <span className='rounded-full border border-cyan-300/30 bg-cyan-400/10 px-3 py-1 text-xs font-semibold text-cyan-100'>
                                                        {pool.quantityAvailable} in stock
                                                    </span>
                                                </div>
                                                <div className='mt-3 grid grid-cols-3 gap-2 text-center text-xs'>
                                                    <div className='rounded bg-white/5 p-2'>
                                                        <p className='text-white/55'>Owned</p>
                                                        <p className='text-base font-semibold'>
                                                            {pool.quantityTotal}
                                                        </p>
                                                    </div>
                                                    <div className='rounded bg-white/5 p-2'>
                                                        <p className='text-white/55'>Used</p>
                                                        <p className='text-base font-semibold'>
                                                            {pool.quantityUsed}
                                                        </p>
                                                    </div>
                                                    <div className='rounded bg-white/5 p-2'>
                                                        <p className='text-white/55'>Free</p>
                                                        <p className='text-base font-semibold'>
                                                            {pool.quantityAvailable}
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                        {(overview?.resources.ipPools || []).length === 0 ? (
                                            <p className='rounded-lg border border-dashed border-white/15 p-4 text-sm text-white/60'>
                                                No IP stock has been purchased yet.
                                            </p>
                                        ) : null}
                                    </div>
                                </div>
                            </div>
                        ) : null}

                        {section === 'buy_servers' ? (
                            <div className='space-y-6'>
                                {groupedWholesalePlans.map(group => (
                                    <section
                                        key={group.category}
                                        className='rounded-3xl border border-white/10 bg-white/[0.025] p-4'
                                    >
                                        <div className='mb-4 flex flex-wrap items-center justify-between gap-3'>
                                            <div>
                                                <p className='text-xs font-semibold uppercase tracking-[0.22em] text-cyan-100/65'>
                                                    VPS Stock Category
                                                </p>
                                                <h4 className='mt-1 text-xl font-semibold text-white'>
                                                    {group.category}
                                                </h4>
                                            </div>
                                            <span className='rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs font-semibold text-white/60'>
                                                {group.plans.length} plans
                                            </span>
                                        </div>
                                        <div className='grid gap-4 lg:grid-cols-2'>
                                            {group.plans.map(plan => (
                                                <div
                                                    key={plan.id}
                                                    className='rounded-2xl border border-white/10 bg-[#111a31]/95 p-5 text-white shadow-[0_0_30px_rgba(99,102,241,0.12)]'
                                                >
                                                    <div className='flex flex-col gap-4 md:flex-row md:items-start md:justify-between'>
                                                        <div>
                                                            <p className='text-xs uppercase tracking-[0.2em] text-white/45'>
                                                                Plan ID #{plan.id}
                                                            </p>
                                                            <h5 className='mt-1 text-2xl font-semibold'>
                                                                {plan.name}
                                                            </h5>
                                                            <p className='mt-2 text-sm text-white/60'>
                                                                {plan.description || 'Platform-managed reseller VPS stock.'}
                                                            </p>
                                                        </div>
                                                        <span className='w-fit rounded-full border border-emerald-300/30 bg-emerald-400/10 px-3 py-1 text-xs font-semibold text-emerald-100'>
                                                            In stock
                                                        </span>
                                                    </div>
                                                    <div className='mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4'>
                                                        <div className='rounded-xl border border-white/10 bg-white/5 p-3'>
                                                            <p className='text-xs text-white/45'>CPU</p>
                                                            <p className='mt-1 text-lg font-semibold'>
                                                                {plan.cpuCores} cores
                                                            </p>
                                                        </div>
                                                        <div className='rounded-xl border border-white/10 bg-white/5 p-3'>
                                                            <p className='text-xs text-white/45'>RAM</p>
                                                            <p className='mt-1 text-lg font-semibold'>
                                                                {plan.ramMb} MB
                                                            </p>
                                                        </div>
                                                        <div className='rounded-xl border border-white/10 bg-white/5 p-3'>
                                                            <p className='text-xs text-white/45'>Disk</p>
                                                            <p className='mt-1 text-lg font-semibold'>
                                                                {plan.diskGb} GB
                                                            </p>
                                                        </div>
                                                        <div className='rounded-xl border border-white/10 bg-white/5 p-3'>
                                                            <p className='text-xs text-white/45'>Default IPs</p>
                                                            <p className='mt-1 text-lg font-semibold'>
                                                                {plan.defaultIpQuantity}
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div className='mt-5 flex flex-col gap-3 rounded-xl border border-cyan-300/15 bg-cyan-400/5 p-4 md:flex-row md:items-center md:justify-between'>
                                                        <div>
                                                            <p className='text-sm font-semibold text-cyan-100'>
                                                                Price
                                                            </p>
                                                            <p className='text-xl font-semibold text-white'>
                                                                {plan.currency} {formatMoney(plan.priceEach)}
                                                                <span className='ml-2 text-sm font-medium text-white/55'>
                                                                    / month
                                                                </span>
                                                            </p>
                                                        </div>
                                                        <Button
                                                            onClick={() =>
                                                                openResourceCheckout(
                                                                    'vps_plan',
                                                                    plan.id,
                                                                    plan.name
                                                                )
                                                            }
                                                        >
                                                            Buy VPS Stock
                                                        </Button>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </section>
                                ))}
                                {(wholesaleCatalog?.plans || []).length === 0 ? (
                                    <p className='rounded-xl border border-dashed border-white/15 bg-[#111a31] p-5 text-sm text-white/60'>
                                        No reseller VPS plans are enabled yet.
                                    </p>
                                ) : null}
                            </div>
                        ) : null}

                        {section === 'buy_ips' ? (
                            <div className='grid gap-4 lg:grid-cols-2'>
                                {(wholesaleCatalog?.ipPools || []).map(pool => (
                                    <div
                                        key={pool.id}
                                        className='rounded-2xl border border-white/10 bg-[#111a31]/95 p-5 text-white shadow-[0_0_30px_rgba(34,211,238,0.10)]'
                                    >
                                        <div className='flex flex-col gap-4 md:flex-row md:items-start md:justify-between'>
                                            <div>
                                                <p className='text-xs uppercase tracking-[0.2em] text-white/45'>
                                                    IP Pool #{pool.id}
                                                </p>
                                                <h4 className='mt-1 text-2xl font-semibold'>
                                                    {pool.name}
                                                </h4>
                                                <p className='mt-2 text-sm text-white/60'>
                                                    {pool.exclusiveResellerId
                                                        ? 'Exclusive pool assigned to a reseller.'
                                                        : 'Shared reseller-enabled IP pool.'}
                                                </p>
                                            </div>
                                            <span
                                                className={`w-fit rounded-full border px-3 py-1 text-xs font-semibold ${
                                                    pool.inStock > 0
                                                        ? 'border-emerald-300/30 bg-emerald-400/10 text-emerald-100'
                                                        : 'border-amber-300/30 bg-amber-400/10 text-amber-100'
                                                }`}
                                            >
                                                {pool.inStock} in stock
                                            </span>
                                        </div>
                                        <div className='mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4'>
                                            <div className='rounded-xl border border-white/10 bg-white/5 p-3'>
                                                <p className='text-xs text-white/45'>Per IP Cost</p>
                                                <p className='mt-1 text-lg font-semibold'>
                                                    {formatMoney(pool.priceEach)}
                                                </p>
                                            </div>
                                            <div className='rounded-xl border border-white/10 bg-white/5 p-3'>
                                                <p className='text-xs text-white/45'>IPv4 Stock</p>
                                                <p className='mt-1 text-lg font-semibold'>
                                                    {pool.availableIpv4}
                                                </p>
                                            </div>
                                            <div className='rounded-xl border border-white/10 bg-white/5 p-3'>
                                                <p className='text-xs text-white/45'>Claimed</p>
                                                <p className='mt-1 text-lg font-semibold'>
                                                    {pool.resellerClaimedIpv4}
                                                </p>
                                            </div>
                                            <div className='rounded-xl border border-white/10 bg-white/5 p-3'>
                                                <p className='text-xs text-white/45'>In VPS Use</p>
                                                <p className='mt-1 text-lg font-semibold'>
                                                    {pool.attachedToVpsIpv4}
                                                </p>
                                            </div>
                                        </div>
                                        <div className='mt-5 flex flex-col gap-3 rounded-xl border border-cyan-300/15 bg-cyan-400/5 p-4 md:flex-row md:items-center md:justify-between'>
                                            <div>
                                                <p className='text-sm font-semibold text-cyan-100'>
                                                    Purchase IP quantity
                                                </p>
                                                <p className='text-sm text-white/60'>
                                                    After payment, random free IPs from this pool are reserved to this reseller.
                                                </p>
                                            </div>
                                            <Button
                                                disabled={pool.inStock <= 0}
                                                onClick={() =>
                                                    openResourceCheckout(
                                                        'ip_pool',
                                                        pool.id,
                                                        pool.name
                                                    )
                                                }
                                            >
                                                Buy IPs
                                            </Button>
                                        </div>
                                    </div>
                                ))}
                                {(wholesaleCatalog?.ipPools || []).length === 0 ? (
                                    <p className='rounded-xl border border-dashed border-white/15 bg-[#111a31] p-5 text-sm text-white/60'>
                                        No reseller-enabled IP pools are available yet.
                                    </p>
                                ) : null}
                            </div>
                        ) : null}
                    </div>
                ) : null}
                {section === 'plans' ? (
                    <div className='space-y-4'>
                        <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                            <h3 className='text-lg font-semibold text-white'>
                                Plan Catalog Overrides
                            </h3>
                            <p className='mt-2 text-sm text-white/65'>
                                Root admin controls CPU, RAM, disk, bandwidth, and snapshot specs.
                                Resellers can only manage store-facing values per plan:
                                custom display name, pricing, IP pool, IP options, backup override (if allowed),
                                and visibility.
                            </p>

                            <div className='mt-4 space-y-4'>
                                {catalog.map(offer => {
                                    const draft = planDrafts[offer.catalogPlanId]
                                    if (!draft) {
                                        return null
                                    }

                                    const isSaving = Boolean(
                                        isSavingPlanPrice[offer.catalogPlanId]
                                    )
                                    const lockInputs =
                                        verificationBlocksOperationalPanel || isSaving
                                    const selectedPool = draft.addressPoolId
                                        ? catalogPoolOptions.find(
                                              pool =>
                                                  pool.id === Number(draft.addressPoolId)
                                          ) ?? null
                                        : null

                                    return (
                                        <div
                                            key={offer.catalogPlanId}
                                            className='rounded-lg border border-white/10 bg-[#111a31] p-4'
                                        >
                                            <div className='flex flex-col gap-1 md:flex-row md:items-center md:justify-between'>
                                                <div>
                                                    <p className='text-base font-semibold text-white'>
                                                        {offer.name}
                                                    </p>
                                                    <p className='text-xs text-white/60'>
                                                        Plan ID: {offer.catalogPlanId} | Slug: {offer.slug}
                                                    </p>
                                                    <p className='mt-1 text-xs text-white/60'>
                                                        Locked Specs: {offer.cpuCores} CPU | {offer.ramMb} MB RAM | {offer.diskGb} GB Disk
                                                        {offer.bandwidthGb !== null
                                                            ? ` | ${offer.bandwidthGb} GB BW`
                                                            : ''}
                                                    </p>
                                                </div>
                                                <div className='mt-2 md:mt-0'>
                                                    <span
                                                        className={`inline-flex rounded-full px-2 py-1 text-[10px] uppercase tracking-wide ${
                                                            draft.isVisible
                                                                ? 'border border-emerald-400/40 bg-emerald-500/20 text-emerald-300'
                                                                : 'border border-amber-400/40 bg-amber-500/20 text-amber-300'
                                                        }`}
                                                    >
                                                        {draft.isVisible ? 'Enabled in Store' : 'Hidden in Store'}
                                                    </span>
                                                </div>
                                            </div>

                                            <div className='mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3'>
                                                <div>
                                                    <label className='mb-1 block text-xs font-semibold uppercase tracking-wide text-white/70'>
                                                        Custom Plan Name (Optional)
                                                    </label>
                                                    <input
                                                        value={draft.planDisplayName}
                                                        onChange={event =>
                                                            updatePlanDraft(offer.catalogPlanId, {
                                                                planDisplayName: event.target.value,
                                                            })
                                                        }
                                                        disabled={lockInputs}
                                                        placeholder={offer.catalogName}
                                                        className='w-full rounded border border-white/15 bg-[#0c1328] px-3 py-2 text-sm text-white disabled:opacity-60'
                                                    />
                                                </div>
                                                <div>
                                                    <label className='mb-1 block text-xs font-semibold uppercase tracking-wide text-white/70'>
                                                        Monthly Price
                                                    </label>
                                                    <input
                                                        value={draft.monthlyPrice}
                                                        onChange={event =>
                                                            updatePlanDraft(offer.catalogPlanId, {
                                                                monthlyPrice: event.target.value,
                                                            })
                                                        }
                                                        disabled={lockInputs}
                                                        placeholder='0.00'
                                                        className='w-full rounded border border-white/15 bg-[#0c1328] px-3 py-2 text-sm text-white disabled:opacity-60'
                                                    />
                                                </div>
                                                <div>
                                                    <label className='mb-1 block text-xs font-semibold uppercase tracking-wide text-white/70'>
                                                        Included IP Quantity
                                                    </label>
                                                    <input
                                                        type='number'
                                                        value={draft.ipQuantity}
                                                        min={0}
                                                        onChange={event =>
                                                            updatePlanDraft(offer.catalogPlanId, {
                                                                ipQuantity: Math.max(
                                                                    Number(event.target.value) || 0,
                                                                    0
                                                                ),
                                                            })
                                                        }
                                                        disabled={lockInputs}
                                                        className='w-full rounded border border-white/15 bg-[#0c1328] px-3 py-2 text-sm text-white disabled:opacity-60'
                                                    />
                                                </div>
                                                <div>
                                                    <label className='mb-1 block text-xs font-semibold uppercase tracking-wide text-white/70'>
                                                        IP Pool
                                                    </label>
                                                    <select
                                                        value={draft.addressPoolId}
                                                        onChange={event =>
                                                            updatePlanDraft(offer.catalogPlanId, {
                                                                addressPoolId: event.target.value,
                                                            })
                                                        }
                                                        disabled={lockInputs}
                                                        className='w-full rounded border border-white/15 bg-[#0c1328] px-3 py-2 text-sm text-white disabled:opacity-60'
                                                    >
                                                        <option value=''>No specific pool</option>
                                                        {catalogPoolOptions.map(pool => (
                                                            <option key={pool.id} value={pool.id}>
                                                                #{pool.id} • {pool.name} ({pool.resellerIpPriceEach}/IP base,{' '}
                                                                {pool.resellerAccessMode === 'exclusive'
                                                                    ? `dedicated`
                                                                    : 'shared'})
                                                            </option>
                                                        ))}
                                                    </select>
                                                    <p className='mt-1 text-[11px] text-white/50'>
                                                        {catalogPoolOptions.length > 0
                                                            ? 'Choose which reseller-enabled pool this plan should use for IP sales.'
                                                            : 'No reseller-enabled shared or dedicated pools are available yet.'}
                                                    </p>
                                                </div>
                                                <div>
                                                    <label className='mb-1 block text-xs font-semibold uppercase tracking-wide text-white/70'>
                                                        Customer IP Price Each
                                                    </label>
                                                    <input
                                                        value={draft.ipPriceEach}
                                                        onChange={event =>
                                                            updatePlanDraft(offer.catalogPlanId, {
                                                                ipPriceEach: event.target.value,
                                                            })
                                                        }
                                                        disabled={lockInputs}
                                                        placeholder='0.00'
                                                        className='w-full rounded border border-white/15 bg-[#0c1328] px-3 py-2 text-sm text-white disabled:opacity-60'
                                                    />
                                                    <p className='mt-1 text-[11px] text-white/50'>
                                                        {selectedPool
                                                            ? `Root pool cost: ${selectedPool.resellerIpPriceEach} per IP. Set your own customer sell price here.`
                                                            : 'Set the per-IP sell price for your own customers.'}
                                                    </p>
                                                </div>
                                                <div>
                                                    <label className='mb-1 block text-xs font-semibold uppercase tracking-wide text-white/70'>
                                                        Backup Per Plan
                                                    </label>
                                                    <input
                                                        type='number'
                                                        value={draft.backupLimitOverride}
                                                        min={0}
                                                        max={offer.backupLimit}
                                                        onChange={event =>
                                                            updatePlanDraft(offer.catalogPlanId, {
                                                                backupLimitOverride:
                                                                    event.target.value,
                                                            })
                                                        }
                                                        disabled={
                                                            lockInputs ||
                                                            !offer.allowResellerBackupOverride
                                                        }
                                                        placeholder={
                                                            offer.allowResellerBackupOverride
                                                                ? `Max ${offer.backupLimit}`
                                                                : 'Locked by root admin'
                                                        }
                                                        className='w-full rounded border border-white/15 bg-[#0c1328] px-3 py-2 text-sm text-white disabled:opacity-60'
                                                    />
                                                    {!offer.allowResellerBackupOverride ? (
                                                        <p className='mt-1 text-[11px] text-white/50'>
                                                            Backup override is disabled by root admin for this plan.
                                                        </p>
                                                    ) : null}
                                                </div>
                                            </div>

                                            <div className='mt-4 flex flex-wrap items-center justify-between gap-3'>
                                                <div className='flex flex-wrap items-center gap-4'>
                                                    <label className='inline-flex items-center gap-2 text-sm text-white/80'>
                                                        <input
                                                            type='checkbox'
                                                            checked={draft.isVisible}
                                                            onChange={event =>
                                                                updatePlanDraft(offer.catalogPlanId, {
                                                                    isVisible:
                                                                        event.target.checked,
                                                                })
                                                            }
                                                            disabled={lockInputs}
                                                        />
                                                        Enable this plan in reseller store
                                                    </label>
                                                </div>
                                                <Button
                                                    variant='filled'
                                                    disabled={lockInputs}
                                                    loading={isSaving}
                                                    onClick={() =>
                                                        void saveCatalogOfferPricing(offer)
                                                    }
                                                >
                                                    Save Plan Overrides
                                                </Button>
                                            </div>
                                        </div>
                                    )
                                })}
                            </div>
                        </div>
                    </div>
                ) : null}

                {section === 'settings' && settings ? (
                    <form
                        className='rounded-xl border border-white/10 bg-[#1a1441] p-4'
                        onSubmit={savePanelSettings}
                    >
                        <h3 className='text-lg font-semibold text-white'>
                            Branding & Settings
                        </h3>
                        <div className='mt-4 grid gap-3 lg:grid-cols-3'>
                            <button
                                type='button'
                                onClick={() =>
                                    document
                                        .getElementById('reseller-branding-settings')
                                        ?.scrollIntoView({
                                            behavior: 'smooth',
                                            block: 'start',
                                        })
                                }
                                className='rounded-2xl border border-cyan-400/20 bg-cyan-400/10 p-4 text-left transition hover:border-cyan-300/45 hover:bg-cyan-400/15'
                            >
                                <p className='text-xs uppercase tracking-[0.18em] text-cyan-100/70'>
                                    Brand Controls
                                </p>
                                <h4 className='mt-2 text-lg font-semibold text-white'>
                                    Logo, favicon, loading screen
                                </h4>
                                <p className='mt-2 text-sm leading-5 text-white/60'>
                                    Set the reseller customer panel name, logo URL,
                                    browser icon, support links, and footer.
                                </p>
                            </button>
                            <button
                                type='button'
                                onClick={() =>
                                    document
                                        .getElementById('reseller-theme-settings')
                                        ?.scrollIntoView({
                                            behavior: 'smooth',
                                            block: 'start',
                                        })
                                }
                                className='rounded-2xl border border-emerald-400/20 bg-emerald-400/10 p-4 text-left transition hover:border-emerald-300/45 hover:bg-emerald-400/15'
                            >
                                <p className='text-xs uppercase tracking-[0.18em] text-emerald-100/70'>
                                    Theme Controls
                                </p>
                                <h4 className='mt-2 text-lg font-semibold text-white'>
                                    Presets, colors, custom CSS
                                </h4>
                                <p className='mt-2 text-sm leading-5 text-white/60'>
                                    Choose a professional theme preset or adjust
                                    primary, secondary, and accent colors.
                                </p>
                            </button>
                            <button
                                type='button'
                                onClick={() =>
                                    document
                                        .getElementById('reseller-domain-settings')
                                        ?.scrollIntoView({
                                            behavior: 'smooth',
                                            block: 'start',
                                        })
                                }
                                className='rounded-2xl border border-indigo-400/20 bg-indigo-400/10 p-4 text-left transition hover:border-indigo-300/45 hover:bg-indigo-400/15'
                            >
                                <p className='text-xs uppercase tracking-[0.18em] text-indigo-100/70'>
                                    Domain Controls
                                </p>
                                <h4 className='mt-2 text-lg font-semibold text-white'>
                                    White-label hostnames
                                </h4>
                                <p className='mt-2 text-sm leading-5 text-white/60'>
                                    Add reseller domains, verify DNS ownership,
                                    and monitor SSL/routing status.
                                </p>
                            </button>
                        </div>
                        <div className='mt-4 space-y-4'>
                            <div
                                id='reseller-domain-settings'
                                className='relative overflow-hidden rounded-[28px] border border-cyan-400/15 bg-[radial-gradient(circle_at_top_left,_rgba(56,189,248,0.18),_transparent_38%),radial-gradient(circle_at_top_right,_rgba(129,140,248,0.18),_transparent_35%),linear-gradient(135deg,_rgba(15,23,42,0.92),_rgba(17,24,39,0.84))] p-6 shadow-[0_24px_90px_rgba(8,15,35,0.45)] backdrop-blur-xl'
                            >
                                <div className='pointer-events-none absolute -left-12 top-0 h-36 w-36 rounded-full bg-cyan-400/12 blur-3xl' />
                                <div className='pointer-events-none absolute right-0 top-0 h-40 w-40 rounded-full bg-indigo-400/12 blur-3xl' />
                                <div className='relative grid gap-6 xl:grid-cols-[minmax(0,1.6fr)_minmax(320px,0.9fr)]'>
                                    <div>
                                        <div className='inline-flex items-center gap-2 rounded-full border border-white/12 bg-white/6 px-3 py-1 text-[11px] uppercase tracking-[0.24em] text-cyan-100/90'>
                                            White-label Domains
                                        </div>
                                        <h4 className='mt-4 text-2xl font-semibold text-white sm:text-3xl'>
                                            Connect your own domain and launch a fully branded VPS panel.
                                        </h4>
                                        <p className='mt-3 max-w-3xl text-sm leading-6 text-white/70'>
                                            Every reseller hostname routes through the secure edge gateway at{' '}
                                            <span className='font-semibold text-white'>
                                                {settings.domainMeta.edgeGatewayHost}
                                            </span>
                                            . Publish the guided DNS records below, then verify and launch the reseller URL.
                                        </p>
                                        <div className='mt-5 flex flex-wrap gap-2'>
                                            {[
                                                'CNAME only routing',
                                                'Cloudflare compatible',
                                                'TXT ownership proof',
                                                'Automatic SSL checks',
                                            ].map(label => (
                                                <span
                                                    key={label}
                                                    className='rounded-full border border-white/12 bg-white/8 px-3 py-1 text-xs text-white/75 backdrop-blur'
                                                >
                                                    {label}
                                                </span>
                                            ))}
                                        </div>
                                    </div>
                                    <div className='rounded-[24px] border border-white/12 bg-white/7 p-5 backdrop-blur-xl'>
                                        <div className='flex items-center justify-between gap-3'>
                                            <div>
                                                <p className='text-xs uppercase tracking-[0.22em] text-white/45'>
                                                    Live DNS Monitor
                                                </p>
                                                <p className='mt-2 text-lg font-semibold text-white'>
                                                    {pendingDomainIds.length > 0
                                                        ? 'Watching pending hostname checks'
                                                        : 'All current hostnames are settled'}
                                                </p>
                                            </div>
                                            <span className='inline-flex items-center gap-2 rounded-full border border-emerald-400/20 bg-emerald-500/12 px-3 py-1 text-xs font-medium text-emerald-100'>
                                                <span className='h-2 w-2 rounded-full bg-emerald-300 shadow-[0_0_12px_rgba(110,231,183,0.85)]' />
                                                Auto-check every 12s
                                            </span>
                                        </div>
                                        <div className='mt-4 grid gap-3 sm:grid-cols-2'>
                                            <div className='rounded-2xl border border-white/10 bg-[#0b1326]/80 p-4'>
                                                <p className='text-[11px] uppercase tracking-[0.2em] text-white/45'>
                                                    Pending hostnames
                                                </p>
                                                <p className='mt-2 text-3xl font-semibold text-white'>
                                                    {pendingDomainIds.length}
                                                </p>
                                            </div>
                                            <div className='rounded-2xl border border-white/10 bg-[#0b1326]/80 p-4'>
                                                <p className='text-[11px] uppercase tracking-[0.2em] text-white/45'>
                                                    Last live sync
                                                </p>
                                                <p className='mt-2 text-sm font-medium text-white'>
                                                    {lastDomainSyncAt
                                                        ? formatTimestamp(lastDomainSyncAt)
                                                        : 'Waiting for first sync'}
                                                </p>
                                            </div>
                                        </div>
                                        <div className='mt-4 flex flex-wrap gap-2'>
                                            <Button
                                                type='button'
                                                size='sm'
                                                loading={domainChecking}
                                                disabled={pendingDomainIds.length === 0}
                                                onClick={() => void syncPendingCustomDomains(false)}
                                            >
                                                Check DNS Now
                                            </Button>
                                            {preferredCustomerPanelDomain ? (
                                                <span className='inline-flex items-center rounded-full border border-cyan-400/20 bg-cyan-500/10 px-3 py-1 text-xs text-cyan-100'>
                                                    Preferred live panel: {preferredCustomerPanelDomain}
                                                </span>
                                            ) : null}
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className='rounded-[24px] border border-white/10 bg-white/5 p-5 shadow-[0_18px_60px_rgba(6,11,27,0.38)] backdrop-blur-xl'>
                                <div className='grid gap-6 xl:grid-cols-[minmax(0,1.3fr)_360px]'>
                                    <div>
                                        <p className='text-xs uppercase tracking-[0.22em] text-white/45'>
                                            Step 1 of 4
                                        </p>
                                        <h5 className='mt-2 text-xl font-semibold text-white'>
                                            Add your reseller hostname
                                        </h5>
                                        <p className='mt-2 max-w-2xl text-sm leading-6 text-white/65'>
                                            Use a public hostname like <span className='text-white'>vps.clienthost.com</span>.
                                            We will generate a CNAME target, issue a TXT ownership token, and then live-check DNS until secure routing is ready.
                                        </p>
                                        <div className='mt-5 flex flex-col gap-3 lg:flex-row'>
                                            <input
                                                type='text'
                                                value={newCustomDomain}
                                                onChange={event => setNewCustomDomain(event.currentTarget.value)}
                                                placeholder='vps.clienthost.com or *.clienthost.com'
                                                className='h-12 flex-1 rounded-2xl border border-white/12 bg-[#091224]/90 px-4 text-sm text-white outline-none transition focus:border-cyan-300/40 focus:ring-2 focus:ring-cyan-400/15'
                                            />
                                            <Button
                                                type='button'
                                                variant='filled'
                                                loading={loading}
                                                disabled={!canSubmitNewDomain}
                                                onClick={() => void addCustomDomain()}
                                            >
                                                Add Hostname
                                            </Button>
                                        </div>
                                        <div className='mt-4 grid gap-3 md:grid-cols-2'>
                                            {newDomainValidation.map(item => (
                                                <div
                                                    key={item.key}
                                                    className={`rounded-2xl border px-4 py-3 text-sm backdrop-blur ${
                                                        item.passed
                                                            ? 'border-emerald-400/20 bg-emerald-500/8 text-emerald-100'
                                                            : 'border-white/10 bg-[#0b1326]/85 text-white/72'
                                                    }`}
                                                >
                                                    <div className='flex items-center gap-3'>
                                                        <span
                                                            className={`h-2.5 w-2.5 rounded-full ${
                                                                item.passed
                                                                    ? 'bg-emerald-300 shadow-[0_0_12px_rgba(110,231,183,0.85)]'
                                                                    : 'bg-white/35'
                                                            }`}
                                                        />
                                                        <p className='font-medium text-white'>{item.label}</p>
                                                    </div>
                                                    <p className='mt-2 text-xs leading-5 opacity-90'>
                                                        {item.detail}
                                                    </p>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                    <div className='rounded-[22px] border border-white/10 bg-[#0b1326]/88 p-5'>
                                        <p className='text-xs uppercase tracking-[0.22em] text-white/45'>
                                            DNS Rules
                                        </p>
                                        <div className='mt-4 space-y-4 text-sm text-white/72'>
                                            <div className='rounded-2xl border border-white/10 bg-white/5 p-4'>
                                                <p className='font-medium text-white'>CNAME only</p>
                                                <p className='mt-2 leading-6'>
                                                    Point the reseller hostname to{' '}
                                                    <span className='font-semibold text-cyan-100'>
                                                        {settings.domainMeta.edgeGatewayHost}
                                                    </span>
                                                    . Use the exact hostname and target shown in the wizard.
                                                </p>
                                            </div>
                                            <div className='rounded-2xl border border-white/10 bg-white/5 p-4'>
                                                <p className='font-medium text-white'>Ownership proof</p>
                                                <p className='mt-2 leading-6'>
                                                    Publish the TXT token exactly as issued so the platform can prove domain ownership before activation.
                                                </p>
                                            </div>
                                            <div className='rounded-2xl border border-amber-400/15 bg-amber-500/8 p-4 text-amber-50/90'>
                                                Changing a hostname later will reset DNS verification, SSL, and routing back to pending until the new records pass again.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className='grid gap-4'>
                                {settings.domains.length === 0 ? (
                                    <div className='rounded-[24px] border border-dashed border-white/12 bg-white/4 px-6 py-10 text-center text-sm text-white/60 backdrop-blur-xl'>
                                        No custom hostnames yet. Add one above to start the white-label VPS panel activation flow.
                                    </div>
                                ) : (
                                    settings.domains.map(domain => {
                                        const domainReady = domain.id > 0
                                        const statusMeta = getDomainStatusMeta(domain)
                                        const verificationMeta = domainReady
                                            ? domainVerificationResults[domain.id] ?? null
                                            : null
                                        const progress = getDomainProgress(domain, verificationMeta)
                                        const domainBusy =
                                            domainChecking || domainActionIds.includes(domain.id)
                                        const domainBeingEdited = editingDomainId === domain.id
                                        const renameValidation = getDomainValidationItems(
                                            domainBeingEdited ? editingDomainHostname : domain.hostname,
                                            existingResellerDomains.filter(
                                                item =>
                                                    item !== normalizeDomainCandidate(domain.hostname)
                                            ),
                                            settings.domainMeta.edgeGatewayHost
                                        )
                                        const canSaveRename =
                                            editingDomainHostname.trim() !== '' &&
                                            renameValidation.every(item => item.passed)
                                        const domainCustomerUrl = resellerCustomerUrlForDomain(
                                            domain.hostname,
                                            resellerImmutableReference
                                        )

                                        return (
                                            <div
                                                key={domainReady ? domain.id : domain.hostname}
                                                className='overflow-hidden rounded-[26px] border border-white/10 bg-[linear-gradient(180deg,rgba(255,255,255,0.06),rgba(255,255,255,0.03))] shadow-[0_18px_60px_rgba(6,11,27,0.34)] backdrop-blur-xl'
                                            >
                                                <div className='border-b border-white/8 px-5 py-4 sm:px-6'>
                                                    <div className='flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between'>
                                                        <div>
                                                            <div className='flex flex-wrap items-center gap-2'>
                                                                <p className='text-lg font-semibold text-white'>
                                                                    {domain.hostname}
                                                                </p>
                                                                <span
                                                                    className={`inline-flex items-center gap-2 rounded-full border px-3 py-1 text-[11px] font-medium uppercase tracking-[0.18em] ${domainBadgeToneClasses[statusMeta.tone]}`}
                                                                >
                                                                    <span className='h-2 w-2 rounded-full bg-current opacity-90' />
                                                                    {statusMeta.label}
                                                                </span>
                                                                {domain.isPrimary ? (
                                                                    <span className='rounded-full border border-emerald-400/20 bg-emerald-500/10 px-3 py-1 text-[11px] font-medium uppercase tracking-[0.16em] text-emerald-100'>
                                                                        Primary
                                                                    </span>
                                                                ) : null}
                                                                {domain.isWildcard ? (
                                                                    <span className='rounded-full border border-indigo-400/20 bg-indigo-500/10 px-3 py-1 text-[11px] font-medium uppercase tracking-[0.16em] text-indigo-100'>
                                                                        Wildcard
                                                                    </span>
                                                                ) : null}
                                                            </div>
                                                            <p className='mt-2 text-sm leading-6 text-white/65'>
                                                                Use the DNS wizard below. Confirm the hostname, publish CNAME, publish TXT, verify SSL, then share the final reseller URL.
                                                            </p>
                                                        </div>
                                                        <div className='grid gap-3 sm:grid-cols-3 xl:min-w-[360px]'>
                                                            <div className='rounded-2xl border border-white/10 bg-[#0b1326]/88 px-4 py-3 text-sm text-white/78'>
                                                                <p className='text-[11px] uppercase tracking-[0.2em] text-white/42'>
                                                                    DNS
                                                                </p>
                                                                <p className='mt-2 font-medium text-white'>
                                                                    {domain.dnsStatus}
                                                                </p>
                                                            </div>
                                                            <div className='rounded-2xl border border-white/10 bg-[#0b1326]/88 px-4 py-3 text-sm text-white/78'>
                                                                <p className='text-[11px] uppercase tracking-[0.2em] text-white/42'>
                                                                    SSL
                                                                </p>
                                                                <p className='mt-2 font-medium text-white'>
                                                                    {domain.sslStatus}
                                                                </p>
                                                            </div>
                                                            <div className='rounded-2xl border border-white/10 bg-[#0b1326]/88 px-4 py-3 text-sm text-white/78'>
                                                                <p className='text-[11px] uppercase tracking-[0.2em] text-white/42'>
                                                                    Routing
                                                                </p>
                                                                <p className='mt-2 font-medium text-white'>
                                                                    {domain.routingStatus}
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className='mt-5 grid gap-3 lg:grid-cols-5'>
                                                        {progress.map((step, index) => (
                                                            <div
                                                                key={`${domain.hostname}-${step.label}`}
                                                                className={`rounded-2xl border px-4 py-3 text-sm transition ${
                                                                    step.state === 'completed'
                                                                        ? 'border-emerald-400/20 bg-emerald-500/10 text-emerald-100'
                                                                        : step.state === 'current'
                                                                          ? 'border-cyan-300/40 bg-cyan-500/15 text-cyan-50 shadow-[0_0_28px_rgba(34,211,238,0.12)]'
                                                                          : 'border-white/10 bg-[#0b1326]/78 text-white/55'
                                                                }`}
                                                            >
                                                                <p className='text-[11px] uppercase tracking-[0.18em]'>
                                                                    Step {index + 1}
                                                                </p>
                                                                <p className='mt-2 font-medium'>{step.label}</p>
                                                                <p className='mt-1 text-xs opacity-80'>
                                                                    {step.state === 'completed'
                                                                        ? 'Done'
                                                                        : step.state === 'current'
                                                                          ? 'Do this now'
                                                                          : 'Waiting'}
                                                                </p>
                                                            </div>
                                                        ))}
                                                    </div>
                                                </div>

                                                <div className='grid gap-4 px-5 py-5 sm:px-6 xl:grid-cols-[minmax(0,1.2fr)_minmax(320px,0.85fr)]'>
                                                    <div className='space-y-4'>
                                                        {domainBeingEdited ? (
                                                            <div className='rounded-[22px] border border-cyan-400/18 bg-cyan-500/8 p-4'>
                                                                <div className='flex flex-col gap-3 lg:flex-row'>
                                                                    <input
                                                                        type='text'
                                                                        value={editingDomainHostname}
                                                                        onChange={event =>
                                                                            setEditingDomainHostname(
                                                                                event.currentTarget.value
                                                                            )
                                                                        }
                                                                        className='h-11 flex-1 rounded-2xl border border-white/12 bg-[#08101f] px-4 text-sm text-white outline-none transition focus:border-cyan-300/40 focus:ring-2 focus:ring-cyan-400/15'
                                                                        placeholder='vps.clienthost.com'
                                                                    />
                                                                    <div className='flex gap-2'>
                                                                        <Button
                                                                            type='button'
                                                                            size='sm'
                                                                            loading={domainBusy}
                                                                            disabled={!canSaveRename || domainBusy}
                                                                            onClick={() =>
                                                                                void quickRenameCustomDomain(
                                                                                    domain.id,
                                                                                    editingDomainHostname,
                                                                                    domain.isPrimary
                                                                                )
                                                                            }
                                                                        >
                                                                            Save Hostname
                                                                        </Button>
                                                                        <Button
                                                                            type='button'
                                                                            size='sm'
                                                                            onClick={() => {
                                                                                setEditingDomainId(null)
                                                                                setEditingDomainHostname('')
                                                                            }}
                                                                        >
                                                                            Cancel
                                                                        </Button>
                                                                    </div>
                                                                </div>
                                                                <div className='mt-3 grid gap-3 sm:grid-cols-2'>
                                                                    {renameValidation.map(item => (
                                                                        <div
                                                                            key={`${domain.hostname}-${item.key}`}
                                                                            className={`rounded-2xl border px-4 py-3 text-xs ${
                                                                                item.passed
                                                                                    ? 'border-emerald-400/20 bg-emerald-500/8 text-emerald-100'
                                                                                    : 'border-white/10 bg-[#0b1326]/80 text-white/65'
                                                                            }`}
                                                                        >
                                                                            <p className='font-medium text-white'>
                                                                                {item.label}
                                                                            </p>
                                                                            <p className='mt-1 leading-5 opacity-90'>
                                                                                {item.detail}
                                                                            </p>
                                                                        </div>
                                                                    ))}
                                                                </div>
                                                            </div>
                                                        ) : null}

                                                        <div className='rounded-[24px] border border-cyan-400/18 bg-cyan-500/8 p-4'>
                                                            <div className='flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between'>
                                                                <div>
                                                                    <p className='text-[11px] uppercase tracking-[0.2em] text-cyan-100/65'>
                                                                        Start DNS Wizard
                                                                    </p>
                                                                    <h6 className='mt-2 text-lg font-semibold text-white'>
                                                                        First confirm this is your final reseller hostname.
                                                                    </h6>
                                                                    <p className='mt-2 text-sm leading-6 text-white/70'>
                                                                        If this domain is wrong, click <span className='font-semibold text-white'>Change Hostname</span> before adding DNS records. Changing later resets CNAME, TXT, SSL, and routing checks.
                                                                    </p>
                                                                </div>
                                                                <div className='flex flex-wrap gap-2'>
                                                                    <Button
                                                                        type='button'
                                                                        size='sm'
                                                                        disabled={!domainReady || domainBusy}
                                                                        onClick={() => {
                                                                            setEditingDomainId(domain.id)
                                                                            setEditingDomainHostname(domain.hostname)
                                                                        }}
                                                                    >
                                                                        Edit first
                                                                    </Button>
                                                                    <Button
                                                                        type='button'
                                                                        size='sm'
                                                                        loading={domainBusy}
                                                                        disabled={!domainReady || domainBusy}
                                                                        onClick={() => void quickVerifyCustomDomain(domain.id)}
                                                                    >
                                                                        Domain is final, check DNS
                                                                    </Button>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div className='grid gap-4 lg:grid-cols-2'>
                                                            <div className={`rounded-[22px] border p-4 ${verificationMeta?.directCnameVerified || verificationMeta?.cloudflareDetected || domain.routingStatus === 'active' || domain.sslStatus === 'active' ? 'border-emerald-400/18 bg-emerald-500/8' : 'border-cyan-400/18 bg-[#0b1326]/88'}`}>
                                                                <div className='flex items-start justify-between gap-3'>
                                                                    <div>
                                                                        <p className='text-[11px] uppercase tracking-[0.2em] text-white/42'>
                                                                            Step 2 · Add CNAME
                                                                        </p>
                                                                        <p className='mt-2 text-sm font-medium text-white'>
                                                                            {domain.hostname}
                                                                        </p>
                                                                        <p className='mt-2 break-all text-sm text-cyan-100'>
                                                                            {'->'} {domain.cnameTarget}
                                                                        </p>
                                                                        <p className='mt-2 text-xs leading-5 text-white/55'>
                                                                            In DNS, create a CNAME for this hostname pointing to the edge target.
                                                                        </p>
                                                                    </div>
                                                                    <Button
                                                                        type='button'
                                                                        size='sm'
                                                                        onClick={() =>
                                                                            void copyDomainValue(
                                                                                `cname-${domain.id}`,
                                                                                domain.cnameTarget
                                                                            )
                                                                        }
                                                                    >
                                                                        {copiedDomainField === `cname-${domain.id}`
                                                                            ? 'Copied'
                                                                            : 'Copy'}
                                                                    </Button>
                                                                </div>
                                                            </div>
                                                            <div className={`rounded-[22px] border p-4 ${verificationMeta?.ownershipVerified || domain.ownershipVerifiedAt ? 'border-emerald-400/18 bg-emerald-500/8' : 'border-indigo-400/18 bg-[#0b1326]/88'}`}>
                                                                <div className='flex items-start justify-between gap-3'>
                                                                    <div>
                                                                        <p className='text-[11px] uppercase tracking-[0.2em] text-white/42'>
                                                                            Step 3 · Add TXT ownership
                                                                        </p>
                                                                        <p className='mt-2 break-all text-sm font-medium text-white'>
                                                                            {domain.verificationHost}
                                                                        </p>
                                                                        <p className='mt-2 break-all text-sm text-cyan-100'>
                                                                            {domain.verificationValue || '-'}
                                                                        </p>
                                                                        <p className='mt-2 text-xs leading-5 text-white/55'>
                                                                            Add this exact TXT value. DNS may take a few minutes to update.
                                                                        </p>
                                                                    </div>
                                                                    <Button
                                                                        type='button'
                                                                        size='sm'
                                                                        onClick={() =>
                                                                            void copyDomainValue(
                                                                                `txt-${domain.id}`,
                                                                                domain.verificationValue || ''
                                                                            )
                                                                        }
                                                                    >
                                                                        {copiedDomainField === `txt-${domain.id}`
                                                                            ? 'Copied'
                                                                            : 'Copy'}
                                                                    </Button>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div className='grid gap-4 lg:grid-cols-2'>
                                                            <div className='rounded-[22px] border border-white/10 bg-white/5 p-4'>
                                                                <p className='text-[11px] uppercase tracking-[0.2em] text-white/42'>
                                                                    Step 4 · Live verification
                                                                </p>
                                                                <div className='mt-3 space-y-2 text-sm text-white/72'>
                                                                    <div className='flex items-center justify-between gap-3'>
                                                                        <span>CNAME detected</span>
                                                                        <span
                                                                            className={
                                                                                verificationMeta?.directCnameVerified ||
                                                                                verificationMeta?.cloudflareDetected ||
                                                                                domain.routingStatus === 'active' ||
                                                                                domain.sslStatus === 'active'
                                                                                    ? 'text-emerald-200'
                                                                                    : 'text-white/55'
                                                                            }
                                                                        >
                                                                            {verificationMeta?.directCnameVerified ||
                                                                            verificationMeta?.cloudflareDetected ||
                                                                            domain.routingStatus === 'active' ||
                                                                            domain.sslStatus === 'active'
                                                                                ? 'Ready'
                                                                                : 'Waiting'}
                                                                        </span>
                                                                    </div>
                                                                    <div className='flex items-center justify-between gap-3'>
                                                                        <span>TXT ownership match</span>
                                                                        <span className={verificationMeta?.ownershipVerified || domain.ownershipVerifiedAt ? 'text-emerald-200' : 'text-white/55'}>
                                                                            {verificationMeta?.ownershipVerified || domain.ownershipVerifiedAt ? 'Verified' : 'Pending'}
                                                                        </span>
                                                                    </div>
                                                                    <div className='flex items-center justify-between gap-3'>
                                                                        <span>Cloudflare edge detected</span>
                                                                        <span className={verificationMeta?.cloudflareDetected ? 'text-cyan-200' : 'text-white/55'}>
                                                                            {verificationMeta?.cloudflareDetected ? 'Proxy ON' : 'Direct CNAME'}
                                                                        </span>
                                                                    </div>
                                                                    <div className='flex items-center justify-between gap-3'>
                                                                        <span>Last check</span>
                                                                        <span className='text-white/60'>
                                                                            {domain.lastCheckedAt
                                                                                ? formatTimestamp(domain.lastCheckedAt)
                                                                                : 'Not checked yet'}
                                                                        </span>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div className='rounded-[22px] border border-white/10 bg-white/5 p-4'>
                                                                <p className='text-[11px] uppercase tracking-[0.2em] text-white/42'>
                                                                    Step 5 · SSL and launch
                                                                </p>
                                                                <div className='mt-3 space-y-2 text-sm leading-6 text-white/70'>
                                                                    <p>
                                                                        All routing flows through{' '}
                                                                        <span className='font-medium text-white'>
                                                                            {domain.edgeGatewayHost}
                                                                        </span>
                                                                        .
                                                                    </p>
                                                                    {domain.isWildcard ? (
                                                                        <p>
                                                                            Wildcard probe hostname:{' '}
                                                                            <span className='break-all text-cyan-100'>
                                                                                {domain.probeHostname}
                                                                            </span>
                                                                        </p>
                                                                    ) : null}
                                                                    {domain.sslStatus === 'active' ? (
                                                                        <p className='text-emerald-200'>
                                                                            SSL certificate issued successfully.
                                                                        </p>
                                                                    ) : (
                                                                        <p>
                                                                            SSL starts automatically after CNAME and TXT both pass. Keep this page open or click Retry Verification after DNS updates.
                                                                        </p>
                                                                    )}
                                                                </div>
                                                            </div>
                                                        </div>

                                                        {domainCustomerUrl ? (
                                                            <div className='rounded-[22px] border border-emerald-400/15 bg-emerald-500/8 p-4'>
                                                                <div className='flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between'>
                                                                    <div>
                                                                        <p className='text-[11px] uppercase tracking-[0.2em] text-emerald-100/65'>
                                                                            Step 6 · Share reseller URL
                                                                        </p>
                                                                        <p className='mt-2 break-all text-sm font-semibold text-emerald-50'>
                                                                            {domainCustomerUrl}
                                                                        </p>
                                                                        <p className='mt-2 text-xs leading-5 text-emerald-100/75'>
                                                                            Share this full URL with customers after DNS, TXT, SSL, and routing are ready. The bare domain is not a customer login URL.
                                                                        </p>
                                                                    </div>
                                                                    <Button
                                                                        type='button'
                                                                        size='sm'
                                                                        onClick={() =>
                                                                            void copyDomainValue(
                                                                                `reseller-url-${domain.id}`,
                                                                                domainCustomerUrl
                                                                            )
                                                                        }
                                                                    >
                                                                        {copiedDomainField === `reseller-url-${domain.id}`
                                                                            ? 'Copied'
                                                                            : 'Copy'}
                                                                    </Button>
                                                                </div>
                                                            </div>
                                                        ) : null}

                                                        {domain.lastError ? (
                                                            <div className='rounded-[22px] border border-rose-400/18 bg-rose-500/8 px-4 py-4 text-sm text-rose-100'>
                                                                <p className='font-medium text-white'>
                                                                    Verification issue
                                                                </p>
                                                                <p className='mt-2 leading-6 text-rose-100/90'>
                                                                    {domain.lastError}
                                                                </p>
                                                            </div>
                                                        ) : null}
                                                    </div>

                                                    <div className='space-y-4'>
                                                        <div className='rounded-[22px] border border-white/10 bg-[#0b1326]/88 p-4'>
                                                            <p className='text-[11px] uppercase tracking-[0.2em] text-white/42'>
                                                                Action center
                                                            </p>
                                                            <div className='mt-4 grid gap-2 sm:grid-cols-2'>
                                                                <Button
                                                                    type='button'
                                                                    size='sm'
                                                                    loading={domainBusy}
                                                                    disabled={!domainReady || domainBusy}
                                                                    onClick={() => void quickVerifyCustomDomain(domain.id)}
                                                                >
                                                                    Retry Verification
                                                                </Button>
                                                                <Button
                                                                    type='button'
                                                                    size='sm'
                                                                    disabled={!domainReady || domainBusy}
                                                                    onClick={() =>
                                                                        void quickRegenerateDomainToken(domain.id)
                                                                    }
                                                                >
                                                                    Regenerate TXT
                                                                </Button>
                                                                {!domain.isPrimary ? (
                                                                    <Button
                                                                        type='button'
                                                                        size='sm'
                                                                        disabled={!domainReady || domainBusy}
                                                                        onClick={() =>
                                                                            void quickPromoteCustomDomain(
                                                                                domain.id,
                                                                                domain.hostname
                                                                            )
                                                                        }
                                                                    >
                                                                        Set Primary
                                                                    </Button>
                                                                ) : (
                                                                    <Button
                                                                        type='button'
                                                                        size='sm'
                                                                        disabled
                                                                    >
                                                                        Primary Locked
                                                                    </Button>
                                                                )}
                                                                <Button
                                                                    type='button'
                                                                    size='sm'
                                                                    disabled={!domainReady || domainBusy}
                                                                    onClick={() => {
                                                                        setEditingDomainId(domain.id)
                                                                        setEditingDomainHostname(domain.hostname)
                                                                    }}
                                                                >
                                                                    Change Hostname
                                                                </Button>
                                                                <Button
                                                                    type='button'
                                                                    size='sm'
                                                                    color='danger'
                                                                    disabled={!domainReady || domainBusy}
                                                                    onClick={() =>
                                                                        void quickDeleteCustomDomain(
                                                                            domain.id,
                                                                            domain.hostname
                                                                        )
                                                                    }
                                                                >
                                                                    Remove
                                                                </Button>
                                                            </div>
                                                            {!domainReady ? (
                                                                <p className='mt-3 text-[11px] text-amber-200/85'>
                                                                    Syncing hostname record...
                                                                </p>
                                                            ) : null}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        )
                                    })
                                )}
                            </div>
                        </div>
                        <div className='mt-4 grid gap-4 xl:grid-cols-2'>
                            <div
                                id='reseller-branding-settings'
                                className='scroll-mt-6 rounded-xl border border-white/10 bg-[#111a31] p-4'
                            >
                                <h4 className='text-sm font-semibold uppercase tracking-wide text-white/80'>
                                    Login & Panel Branding
                                </h4>
                                <p className='mt-1 text-xs text-white/50'>
                                    These values control the reseller customer login page, loading screen, favicon, and panel header.
                                </p>
                                <div className='mt-4 grid gap-3 md:grid-cols-2'>
                                    <TextInput
                                        label='Display Name'
                                        value={settings.displayName}
                                        onChange={event => {
                                            const value = event.currentTarget.value
                                            patchSettings(current => ({
                                                ...current,
                                                displayName: value,
                                            }))
                                        }}
                                    />
                                    <TextInput
                                        label='Login & Header Logo URL'
                                        value={settings.logoUrl || ''}
                                        onChange={event => {
                                            const value = event.currentTarget.value || null
                                            patchSettings(current => ({
                                                ...current,
                                                logoUrl: value,
                                            }))
                                        }}
                                    />
                                    <TextInput
                                        label='Favicon URL'
                                        value={settings.faviconUrl || ''}
                                        onChange={event => {
                                            const value = event.currentTarget.value || null
                                            patchSettings(current => ({
                                                ...current,
                                                faviconUrl: value,
                                            }))
                                        }}
                                    />
                                    <TextInput
                                        label='Loading Screen Logo URL'
                                        value={settings.loadingLogoUrl || ''}
                                        onChange={event => {
                                            const value = event.currentTarget.value || null
                                            patchSettings(current => ({
                                                ...current,
                                                loadingLogoUrl: value,
                                            }))
                                        }}
                                        placeholder={settings.logoUrl || 'https://example.com/loading-logo.png'}
                                    />
                                    <TextInput
                                        label='Support URL'
                                        value={settings.supportUrl || ''}
                                        onChange={event => {
                                            const value = event.currentTarget.value || null
                                            patchSettings(current => ({
                                                ...current,
                                                supportUrl: value,
                                            }))
                                        }}
                                    />
                                    <TextInput
                                        label='Customer Billing URL'
                                        value={settings.billingUrl || ''}
                                        onChange={event => {
                                            const value = event.currentTarget.value || null
                                            patchSettings(current => ({
                                                ...current,
                                                billingUrl: value,
                                            }))
                                        }}
                                        placeholder='https://billing.yourbrand.com'
                                    />
                                    <TextInput
                                        label='Footer Text'
                                        value={settings.footerText || ''}
                                        onChange={event => {
                                            const value = event.currentTarget.value || null
                                            patchSettings(current => ({
                                                ...current,
                                                footerText: value,
                                            }))
                                        }}
                                        placeholder={settings.displayName}
                                    />
                                    <TextInput
                                        label='Footer URL'
                                        value={settings.footerUrl || ''}
                                        onChange={event => {
                                            const value = event.currentTarget.value || null
                                            patchSettings(current => ({
                                                ...current,
                                                footerUrl: value,
                                            }))
                                        }}
                                        placeholder='https://example.com'
                                    />
                                    <div className='rounded-xl border border-white/10 bg-white/[0.03] p-4 md:col-span-2'>
                                        <div className='flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between'>
                                            <div>
                                                <p className='text-sm font-bold text-white'>
                                                    Customer Upgrade Button
                                                </p>
                                                <p className='mt-1 text-xs leading-5 text-white/55'>
                                                    If disabled, reseller customers will not see upgrade buttons.
                                                </p>
                                            </div>
                                            <label className='inline-flex cursor-pointer items-center gap-3 rounded-full border border-white/12 bg-white/5 px-3 py-2 text-sm font-semibold text-white/80'>
                                                <input
                                                    type='checkbox'
                                                    checked={settings.upgradeButtonEnabled}
                                                    onChange={event => {
                                                        const enabled =
                                                            event.currentTarget.checked
                                                        patchSettings(current => ({
                                                            ...current,
                                                            upgradeButtonEnabled: enabled,
                                                        }))
                                                    }}
                                                    className='h-4 w-4 rounded border-white/20 bg-[#0d1325] text-cyan-500'
                                                />
                                                {settings.upgradeButtonEnabled
                                                    ? 'Enabled'
                                                    : 'Disabled'}
                                            </label>
                                        </div>
                                        <div className='mt-4'>
                                            <TextInput
                                                label='Customer Upgrade URL Template'
                                                value={settings.upgradeUrlTemplate || ''}
                                                onChange={event => {
                                                    const value =
                                                        event.currentTarget.value || null
                                                    patchSettings(current => ({
                                                        ...current,
                                                        upgradeUrlTemplate: value,
                                                    }))
                                                }}
                                                placeholder='https://billing.yourbrand.com/services/<service_id>/upgrade'
                                            />
                                            <p className='mt-1.5 text-xs leading-5 text-white/50'>
                                                Use <span className='font-semibold text-cyan-200'>&lt;service_id&gt;</span> or <span className='font-semibold text-cyan-200'>&lt;s.id&gt;</span>. Example: service 5415 becomes <span className='font-semibold text-white'>/services/5415/upgrade</span>.
                                            </p>
                                        </div>
                                    </div>
                                    <TextInput
                                        label='Privacy Policy URL'
                                        value={settings.privacyUrl || ''}
                                        onChange={event => {
                                            const value = event.currentTarget.value || null
                                            patchSettings(current => ({
                                                ...current,
                                                privacyUrl: value,
                                            }))
                                        }}
                                    />
                                    <TextInput
                                        label='Terms of Service URL'
                                        value={settings.tosUrl || ''}
                                        onChange={event => {
                                            const value = event.currentTarget.value || null
                                            patchSettings(current => ({
                                                ...current,
                                                tosUrl: value,
                                            }))
                                        }}
                                    />
                                    <TextInput
                                        label='Primary Color'
                                        value={settings.primaryColor || ''}
                                        onChange={event => {
                                            const value = event.currentTarget.value || null
                                            patchSettings(current => ({
                                                ...current,
                                                primaryColor: value,
                                            }))
                                            previewResellerTheme(
                                                settings.themeKey || 'wammuhost',
                                                value,
                                                settings.secondaryColor,
                                                settings.accentColor
                                            )
                                        }}
                                        placeholder='#16a34a'
                                    />
                                    <TextInput
                                        label='Secondary Color'
                                        value={settings.secondaryColor || ''}
                                        onChange={event => {
                                            const value = event.currentTarget.value || null
                                            patchSettings(current => ({
                                                ...current,
                                                secondaryColor: value,
                                            }))
                                            previewResellerTheme(
                                                settings.themeKey || 'wammuhost',
                                                settings.primaryColor,
                                                value,
                                                settings.accentColor
                                            )
                                        }}
                                        placeholder='#0f172a'
                                    />
                                    <TextInput
                                        label='Accent Color'
                                        value={settings.accentColor || ''}
                                        onChange={event => {
                                            const value = event.currentTarget.value || null
                                            patchSettings(current => ({
                                                ...current,
                                                accentColor: value,
                                            }))
                                            previewResellerTheme(
                                                settings.themeKey || 'wammuhost',
                                                settings.primaryColor,
                                                settings.secondaryColor,
                                                value
                                            )
                                        }}
                                        placeholder='#38bdf8'
                                    />
                                    <div
                                        id='reseller-theme-settings'
                                        className='scroll-mt-6 md:col-span-2'
                                    >
                                        <label className='mb-2 block text-sm font-bold text-white'>
                                            Theme Preset
                                        </label>
                                        <select
                                            className='h-10 w-full rounded border border-accent-300 bg-background px-3 text-sm text-white'
                                            value={settings.themeKey || 'wammuhost'}
                                            onChange={event => {
                                                const theme = resolveThemePreset(
                                                    event.currentTarget.value
                                                )
                                                patchSettings(current => ({
                                                    ...current,
                                                    themeKey: theme.key,
                                                    primaryColor: theme.primary,
                                                    secondaryColor: theme.secondary,
                                                    accentColor: theme.accent,
                                                }))
                                                previewResellerTheme(
                                                    theme.key,
                                                    theme.primary,
                                                    theme.secondary,
                                                    theme.accent
                                                )
                                            }}
                                        >
                                            {THEME_PRESETS.map(theme => (
                                                <option key={theme.key} value={theme.key}>
                                                    {theme.name}
                                                </option>
                                            ))}
                                        </select>
                                        <div className='mt-3 grid gap-4 lg:grid-cols-2 2xl:grid-cols-3'>
                                            {THEME_PRESETS.map(theme => {
                                                const selected =
                                                    (settings.themeKey || 'wammuhost') === theme.key

                                                return (
                                                    <button
                                                        key={theme.key}
                                                        type='button'
                                                        onClick={() => {
                                                            patchSettings(current => ({
                                                                ...current,
                                                                themeKey: theme.key,
                                                                primaryColor: theme.primary,
                                                                secondaryColor: theme.secondary,
                                                                accentColor: theme.accent,
                                                            }))
                                                            previewResellerTheme(
                                                                theme.key,
                                                                theme.primary,
                                                                theme.secondary,
                                                                theme.accent
                                                            )
                                                        }}
                                                        className={`min-h-[160px] rounded-xl border p-4 text-left transition hover:-translate-y-0.5 ${
                                                            selected
                                                                ? 'border-cyan-300/70 bg-cyan-400/10 shadow-[0_0_24px_rgba(34,211,238,0.18)]'
                                                                : 'border-white/10 bg-black/15 hover:border-white/25'
                                                        }`}
                                                    >
                                                        <div
                                                            className='h-14 rounded-lg border border-white/10'
                                                            style={{
                                                                background: `radial-gradient(circle at top left, ${theme.accent}55, transparent 34%), linear-gradient(135deg, ${theme.secondary}, ${theme.background})`,
                                                            }}
                                                        />
                                                        <div className='mt-3 flex min-h-[42px] items-start justify-between gap-3'>
                                                            <span className='min-w-0 break-words text-xs font-semibold leading-5 text-white'>
                                                                {theme.name}
                                                            </span>
                                                            <span
                                                                className='h-4 w-4 shrink-0 rounded-full border border-white/30'
                                                                style={{
                                                                    backgroundColor: theme.primary,
                                                                }}
                                                            />
                                                        </div>
                                                        <p className='mt-1 text-[11px] leading-4 text-white/50'>
                                                            {theme.description}
                                                        </p>
                                                    </button>
                                                )
                                            })}
                                        </div>
                                    </div>
                                </div>
                                <div className='mt-3'>
                                    <label className='mb-2 block text-sm font-bold text-white'>
                                        Custom CSS
                                    </label>
                                    <textarea
                                        className='h-32 w-full rounded-md border border-white/10 bg-[#0f172a] px-3 py-2 text-sm text-white outline-none transition focus:border-emerald-400/50'
                                        value={settings.customCss || ''}
                                        onChange={event => {
                                            const value = event.currentTarget.value || null
                                            patchSettings(current => ({
                                                ...current,
                                                customCss: value,
                                            }))
                                            previewResellerTheme(
                                                settings.themeKey || 'wammuhost',
                                                settings.primaryColor,
                                                settings.secondaryColor,
                                                settings.accentColor,
                                                value
                                            )
                                        }}
                                        placeholder='Optional CSS injected into your white-label tenant.'
                                    />
                                </div>
                            </div>

                            <div className='rounded-xl border border-white/10 bg-[#111a31] p-4'>
                                <h4 className='text-sm font-semibold uppercase tracking-wide text-white/80'>
                                    SMTP & Platform Links
                                </h4>
                                <div className='mt-4 grid gap-3 md:grid-cols-2'>
                                    <label className='inline-flex items-center gap-2 text-sm text-white/80 md:col-span-2'>
                                        <input
                                            type='checkbox'
                                            checked={settings.smtp.enabled}
                                            onChange={event => {
                                                const checked = event.currentTarget.checked
                                                patchSmtpSettings(current => ({
                                                    ...current,
                                                    enabled: checked,
                                                }))
                                            }}
                                        />
                                        Enable reseller SMTP
                                    </label>
                                    <TextInput
                                        label='SMTP Host'
                                        value={settings.smtp.host || ''}
                                        onChange={event => {
                                            const value = event.currentTarget.value || null
                                            patchSmtpSettings(current => ({
                                                ...current,
                                                host: value,
                                            }))
                                        }}
                                    />
                                    <TextInput
                                        label='SMTP Port'
                                        value={
                                            settings.smtp.port === null
                                                ? ''
                                                : String(settings.smtp.port)
                                        }
                                        onChange={event => {
                                            const raw = event.currentTarget.value
                                            patchSmtpSettings(current => ({
                                                ...current,
                                                port: raw ? Number(raw) || null : null,
                                            }))
                                        }}
                                    />
                                    <div>
                                        <label className='mb-2 block text-sm font-bold text-white'>
                                            Encryption
                                        </label>
                                        <select
                                            className='h-10 w-full rounded border border-accent-300 bg-background px-3 text-sm text-white'
                                            value={settings.smtp.encryption || 'none'}
                                            onChange={event => {
                                                const value = event.currentTarget.value
                                                patchSmtpSettings(current => ({
                                                    ...current,
                                                    encryption: value === 'none' ? null : value,
                                                }))
                                            }}
                                        >
                                            <option value='none'>None</option>
                                            <option value='ssl'>SSL</option>
                                            <option value='tls'>TLS</option>
                                            <option value='starttls'>STARTTLS</option>
                                        </select>
                                    </div>
                                    <TextInput
                                        label='SMTP Username'
                                        value={settings.smtp.username || ''}
                                        onChange={event => {
                                            const value = event.currentTarget.value || null
                                            patchSmtpSettings(current => ({
                                                ...current,
                                                username: value,
                                            }))
                                        }}
                                    />
                                    <TextInput
                                        label='SMTP Password'
                                        value={smtpPasswordDraft}
                                        onChange={event =>
                                            setSmtpPasswordDraft(
                                                event.currentTarget.value
                                            )
                                        }
                                        placeholder={
                                            settings.smtp.passwordSet
                                                ? 'Stored. Enter to replace.'
                                                : 'Enter SMTP password'
                                        }
                                    />
                                    <TextInput
                                        label='From Email'
                                        value={settings.smtp.fromEmail || ''}
                                        onChange={event => {
                                            const value = event.currentTarget.value || null
                                            patchSmtpSettings(current => ({
                                                ...current,
                                                fromEmail: value,
                                            }))
                                        }}
                                    />
                                    <TextInput
                                        label='From Name'
                                        value={settings.smtp.fromName || ''}
                                        onChange={event => {
                                            const value = event.currentTarget.value || null
                                            patchSmtpSettings(current => ({
                                                ...current,
                                                fromName: value,
                                            }))
                                        }}
                                    />
                                    <TextInput
                                        label='Reply-To Email'
                                        value={settings.smtp.replyToEmail || ''}
                                        onChange={event => {
                                            const value = event.currentTarget.value || null
                                            patchSmtpSettings(current => ({
                                                ...current,
                                                replyToEmail: value,
                                            }))
                                        }}
                                    />
                                    <TextInput
                                        label='GitHub OAuth Client ID'
                                        value={settings.oauth.githubClientId || ''}
                                        onChange={event => {
                                            const value = event.currentTarget.value || null
                                            patchOauthSettings(current => ({
                                                ...current,
                                                githubClientId: value,
                                            }))
                                        }}
                                    />
                                    <TextInput
                                        label='Discord OAuth Client ID'
                                        value={settings.oauth.discordClientId || ''}
                                        onChange={event => {
                                            const value = event.currentTarget.value || null
                                            patchOauthSettings(current => ({
                                                ...current,
                                                discordClientId: value,
                                            }))
                                        }}
                                    />
                                </div>
                            </div>
                        </div>

                        <div className='mt-4 rounded-xl border border-white/10 bg-[#111a31] p-4'>
                            <h4 className='text-sm font-semibold uppercase tracking-wide text-white/80'>
                                Nameservers & Feature Toggles
                            </h4>
                            <div className='mt-4'>
                                <label className='mb-2 block text-sm font-bold text-white'>
                                    Custom Nameservers
                                </label>
                                <textarea
                                    className='h-28 w-full rounded-md border border-white/10 bg-[#0f172a] px-3 py-2 text-sm text-white outline-none transition focus:border-emerald-400/50'
                                    value={settings.customNameservers.join('\n')}
                                    onChange={event => {
                                        const values = event.currentTarget.value
                                            .split(/\r?\n|,/)
                                            .map(value => value.trim())
                                            .filter(Boolean)
                                        patchSettings(current => ({
                                            ...current,
                                            customNameservers: values,
                                        }))
                                    }}
                                    placeholder={'ns1.clienthost.com\nns2.clienthost.com'}
                                />
                                <p className='mt-2 text-xs text-white/55'>
                                    These nameservers appear in the reseller shell and custom domain guidance.
                                </p>
                            </div>
                            <div className='mt-4 grid gap-2 md:grid-cols-2 xl:grid-cols-3'>
                                {featureToggles.map(item => (
                                    <label
                                        key={item.key}
                                        className='inline-flex items-center gap-2 text-sm text-white/80'
                                    >
                                        <input
                                            type='checkbox'
                                            checked={Boolean(
                                                settings.featureFlags[item.key]
                                            )}
                                            onChange={event => {
                                                const checked = event.currentTarget.checked
                                                patchSettings(current => ({
                                                    ...current,
                                                    featureFlags: {
                                                        ...current.featureFlags,
                                                        [item.key]: checked,
                                                    },
                                                }))
                                            }}
                                        />
                                        {item.label}
                                    </label>
                                ))}
                            </div>
                        </div>
                        <div className='mt-4'>
                            <Button type='submit' variant='filled'>
                                Save Branding & Settings
                            </Button>
                        </div>
                    </form>
                ) : null}

                {section === 'sub_resellers' ? (
                    <div className='space-y-4'>
                        {!subResellerCreationEnabled ? (
                            <div className='rounded-md border border-amber-400/30 bg-amber-500/10 px-4 py-3 text-sm text-amber-100'>
                                Enable <strong>Sub-Resellers</strong> in
                                Settings before creating child tenants.
                            </div>
                        ) : null}
                        <form
                            className='rounded-xl border border-white/10 bg-[#1a1441] p-4'
                            onSubmit={createChildReseller}
                        >
                            <h3 className='text-lg font-semibold text-white'>
                                Create Sub-Reseller
                            </h3>
                            <div className='mt-3 grid gap-3 md:grid-cols-2'>
                                <TextInput
                                    label='Display Name'
                                    value={subName}
                                    onChange={event =>
                                        setSubName(event.currentTarget.value)
                                    }
                                />
                                <TextInput
                                    label='Domain'
                                    value={subDomain}
                                    onChange={event =>
                                        setSubDomain(event.currentTarget.value)
                                    }
                                    placeholder={
                                        parentPanelDomain
                                            ? `child.${parentPanelDomain}`
                                            : 'child.vps.example.com'
                                    }
                                />
                                <TextInput
                                    label='Backend domain (optional)'
                                    value={subBackendDomain}
                                    onChange={event =>
                                        setSubBackendDomain(
                                            event.currentTarget.value
                                        )
                                    }
                                />
                                <TextInput
                                    label='Live data domain (optional)'
                                    value={subLiveDataDomain}
                                    onChange={event =>
                                        setSubLiveDataDomain(
                                            event.currentTarget.value
                                        )
                                    }
                                />
                                <TextInput
                                    label='noVNC domain (optional)'
                                    value={subNovncDomain}
                                    onChange={event =>
                                        setSubNovncDomain(
                                            event.currentTarget.value
                                        )
                                    }
                                />
                                <TextInput
                                    label='CDN domain (optional)'
                                    value={subCdnDomain}
                                    onChange={event =>
                                        setSubCdnDomain(event.currentTarget.value)
                                    }
                                />
                            </div>
                            <div className='mt-3 grid gap-3 md:grid-cols-5'>
                                <TextInput
                                    label='Max RAM (MB)'
                                    type='number'
                                    value={subMaxRamMb}
                                    onChange={event =>
                                        setSubMaxRamMb(event.currentTarget.value)
                                    }
                                />
                                <TextInput
                                    label='Max CPU'
                                    type='number'
                                    value={subMaxCpuCores}
                                    onChange={event =>
                                        setSubMaxCpuCores(
                                            event.currentTarget.value
                                        )
                                    }
                                />
                                <TextInput
                                    label='Max Disk (GB)'
                                    type='number'
                                    value={subMaxDiskGb}
                                    onChange={event =>
                                        setSubMaxDiskGb(event.currentTarget.value)
                                    }
                                />
                                <TextInput
                                    label='Max VMs'
                                    type='number'
                                    value={subMaxVms}
                                    onChange={event =>
                                        setSubMaxVms(event.currentTarget.value)
                                    }
                                />
                                <div>
                                    <label className='mb-2 block text-sm font-bold text-white'>
                                        Status
                                    </label>
                                    <select
                                        className='h-10 w-full rounded border border-accent-300 bg-background px-3 text-sm text-white'
                                        value={subStatus}
                                        onChange={event =>
                                            setSubStatus(
                                                event.currentTarget.value as
                                                    | 'pending'
                                                    | 'active'
                                                    | 'suspended'
                                            )
                                        }
                                    >
                                        <option value='pending'>Pending</option>
                                        <option value='active'>Active</option>
                                        <option value='suspended'>
                                            Suspended
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div className='mt-3'>
                                <Button
                                    type='submit'
                                    variant='filled'
                                    disabled={!subResellerCreationEnabled}
                                >
                                    Create
                                </Button>
                            </div>
                        </form>

                        <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                            <div className='space-y-2'>
                                {subResellers.map(item => (
                                    <div
                                        key={item.id}
                                        className='rounded-lg border border-white/10 bg-[#111a31] p-3 text-sm text-white/85'
                                    >
                                        <p className='font-semibold'>
                                            {item.displayName}
                                        </p>
                                        <p className='text-xs text-white/65'>
                                            {item.domain || '-'} | {item.status}
                                        </p>
                                        <p className='text-xs text-white/65'>
                                            Pool: {item.usedVms}/{item.maxVms}{' '}
                                            VMs, {item.usedRamMb}/{item.maxRamMb}{' '}
                                            MB RAM, {item.usedCpuCores}/
                                            {item.maxCpuCores} CPU,{' '}
                                            {item.usedDiskGb}/{item.maxDiskGb} GB
                                        </p>
                                        <div className='mt-2'>
                                            <Button
                                                size='sm'
                                                className='mr-2'
                                                onClick={() =>
                                                    void quickSwitchToSubReseller(
                                                        item
                                                    )
                                                }
                                            >
                                                View
                                            </Button>
                                            <Button
                                                size='sm'
                                                className='mr-2'
                                                onClick={() =>
                                                    void quickResizeSubReseller(
                                                        item
                                                    )
                                                }
                                            >
                                                Edit Limits
                                            </Button>
                                            <Button
                                                size='sm'
                                                className='mr-2'
                                                onClick={() =>
                                                    void quickToggleSubResellerStatus(
                                                        item
                                                    )
                                                }
                                            >
                                                {item.status === 'suspended'
                                                    ? 'Unsuspend'
                                                    : 'Suspend'}
                                            </Button>
                                            <Button
                                                size='sm'
                                                color='danger'
                                                onClick={() =>
                                                    void quickDeleteSubReseller(
                                                        item
                                                    )
                                                }
                                            >
                                                Delete
                                            </Button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                ) : null}

                {section === 'logs' ? (
                    <div className='space-y-4'>
                        <div className='rounded-xl border border-sky-400/20 bg-sky-500/10 p-4 text-sm text-sky-100'>
                            <p className='font-semibold'>Protected Reseller Logs</p>
                            <p className='mt-1 text-sky-100/85'>
                                Internal infrastructure references are masked here automatically. Real Proxmox IPs, internal routes, backend hosts, and secrets never appear in reseller-facing logs.
                            </p>
                        </div>

                        {logsData ? (
                            <>
                                <div className='grid gap-3 md:grid-cols-2 xl:grid-cols-4'>
                                    <div className='rounded-lg border border-white/10 bg-[#1a1441] p-4 text-white'>
                                        <p className='text-xs uppercase tracking-wide text-white/55'>
                                            Actions Today
                                        </p>
                                        <p className='mt-2 text-2xl font-semibold'>
                                            {logsData.metrics.actionsToday}
                                        </p>
                                    </div>
                                    <div className='rounded-lg border border-white/10 bg-[#1a1441] p-4 text-white'>
                                        <p className='text-xs uppercase tracking-wide text-white/55'>
                                            Failed 48h
                                        </p>
                                        <p className='mt-2 text-2xl font-semibold text-amber-200'>
                                            {logsData.metrics.failedActions48h}
                                        </p>
                                    </div>
                                    <div className='rounded-lg border border-white/10 bg-[#1a1441] p-4 text-white'>
                                        <p className='text-xs uppercase tracking-wide text-white/55'>
                                            Admin Sign-ins 48h
                                        </p>
                                        <p className='mt-2 text-2xl font-semibold text-emerald-200'>
                                            {logsData.metrics.adminSignins48h}
                                        </p>
                                    </div>
                                    <div className='rounded-lg border border-white/10 bg-[#1a1441] p-4 text-white'>
                                        <p className='text-xs uppercase tracking-wide text-white/55'>
                                            Suspicious 48h
                                        </p>
                                        <p className='mt-2 text-2xl font-semibold text-rose-200'>
                                            {logsData.metrics.suspiciousSignins48h}
                                        </p>
                                    </div>
                                </div>

                                <div className='grid gap-4 xl:grid-cols-[1.15fr_0.85fr]'>
                                    <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                                        <div className='flex items-center justify-between gap-3'>
                                            <div>
                                                <h3 className='text-lg font-semibold text-white'>
                                                    Admin Action Trail
                                                </h3>
                                                <p className='mt-1 text-sm text-white/60'>
                                                    Latest reseller control actions with secured field masking.
                                                </p>
                                            </div>
                                            <Button size='sm' onClick={() => void refreshLogs()}>
                                                Refresh Logs
                                            </Button>
                                        </div>

                                        <div className='mt-4 space-y-3'>
                                            {logsData.auditItems.map(item => (
                                                <div
                                                    key={item.id}
                                                    className='rounded-lg border border-white/10 bg-[#111a31] p-4 text-sm text-white/85'
                                                >
                                                    <div className='flex flex-col gap-2 md:flex-row md:items-start md:justify-between'>
                                                        <div>
                                                            <div className='flex flex-wrap items-center gap-2'>
                                                                <p className='font-semibold text-white'>
                                                                    {item.actionLabel}
                                                                </p>
                                                                <span
                                                                    className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${
                                                                        item.statusTone === 'success'
                                                                            ? 'border border-emerald-400/35 bg-emerald-500/15 text-emerald-200'
                                                                            : item.statusTone === 'warning'
                                                                              ? 'border border-amber-400/35 bg-amber-500/15 text-amber-200'
                                                                              : item.statusTone === 'danger'
                                                                                ? 'border border-rose-400/35 bg-rose-500/15 text-rose-200'
                                                                                : 'border border-white/15 bg-white/5 text-white/60'
                                                                    }`}
                                                                >
                                                                    {item.statusCode ?? 'N/A'}
                                                                </span>
                                                            </div>
                                                            <p className='mt-1 text-xs text-white/55'>
                                                                {item.actorLabel} • {item.area} • {item.targetLabel}
                                                            </p>
                                                            {item.description ? (
                                                                <p className='mt-2 text-sm text-white/75'>
                                                                    {item.description}
                                                                </p>
                                                            ) : null}
                                                        </div>
                                                        <div className='text-xs text-white/50 md:text-right'>
                                                            <p>{formatTimestamp(item.createdAt)}</p>
                                                            <p className='mt-1'>
                                                                {item.requestMethod ?? 'ACTION'} • {item.path ?? '-'}
                                                            </p>
                                                            <p className='mt-1'>
                                                                Request IP: {item.ipAddress ?? 'Hidden'}
                                                            </p>
                                                        </div>
                                                    </div>

                                                    {item.changedFields.length > 0 ? (
                                                        <div className='mt-3 flex flex-wrap gap-2'>
                                                            {item.changedFields.map(field => (
                                                                <span
                                                                    key={`${item.id}-${field}`}
                                                                    className='rounded-full border border-white/10 bg-white/[0.05] px-2.5 py-1 text-[11px] text-white/70'
                                                                >
                                                                    {field}
                                                                </span>
                                                            ))}
                                                        </div>
                                                    ) : null}

                                                    {item.errorMessage ? (
                                                        <div className='mt-3 rounded-lg border border-rose-400/25 bg-rose-500/10 px-3 py-2 text-xs text-rose-100'>
                                                            {item.errorMessage}
                                                        </div>
                                                    ) : null}
                                                </div>
                                            ))}

                                            {logsData.auditItems.length === 0 ? (
                                                <div className='rounded-lg border border-dashed border-white/10 bg-[#111a31] p-4 text-sm text-white/55'>
                                                    No reseller admin actions have been recorded yet.
                                                </div>
                                            ) : null}
                                        </div>
                                    </div>

                                    <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                                        <h3 className='text-lg font-semibold text-white'>
                                            Admin Sign-in History
                                        </h3>
                                        <p className='mt-1 text-sm text-white/60'>
                                            Sign-in events for reseller admin accounts with masked IP visibility.
                                        </p>

                                        <div className='mt-4 space-y-3'>
                                            {logsData.loginItems.map(item => (
                                                <div
                                                    key={item.id}
                                                    className='rounded-lg border border-white/10 bg-[#111a31] p-3 text-sm text-white/85'
                                                >
                                                    <div className='flex items-start justify-between gap-3'>
                                                        <div>
                                                            <p className='font-semibold text-white'>
                                                                {item.eventLabel}
                                                            </p>
                                                            <p className='mt-1 text-xs text-white/55'>
                                                                {item.email || 'Unknown admin'} • {item.role}
                                                            </p>
                                                        </div>
                                                        {item.isSuspicious ? (
                                                            <span className='rounded-full border border-rose-400/35 bg-rose-500/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-rose-200'>
                                                                Suspicious
                                                            </span>
                                                        ) : (
                                                            <span className='rounded-full border border-emerald-400/35 bg-emerald-500/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-emerald-200'>
                                                                Normal
                                                            </span>
                                                        )}
                                                    </div>
                                                    <div className='mt-3 space-y-1 text-xs text-white/60'>
                                                        <p>Time: {formatTimestamp(item.createdAt)}</p>
                                                        <p>IP: {item.ipAddress || 'Hidden'}</p>
                                                        <p>Location: {item.locationLabel || 'Unknown'}</p>
                                                        <p>Device: {item.userAgent || 'Unknown device'}</p>
                                                        {item.reason ? <p>Reason: {item.reason}</p> : null}
                                                    </div>
                                                </div>
                                            ))}

                                            {logsData.loginItems.length === 0 ? (
                                                <div className='rounded-lg border border-dashed border-white/10 bg-[#111a31] p-4 text-sm text-white/55'>
                                                    No reseller admin sign-in history is available yet.
                                                </div>
                                            ) : null}
                                        </div>
                                    </div>
                                </div>
                            </>
                        ) : (
                            <div className='rounded-lg border border-white/10 bg-[#1a1441] p-4 text-sm text-white/60'>
                                Loading protected reseller logs...
                            </div>
                        )}
                    </div>
                ) : null}

                {section === 'api_keys' ? (
                    <div className='space-y-4'>
                        <form
                            className='theme-panel overflow-hidden rounded-2xl shadow-[0_18px_50px_rgba(0,0,0,0.24)]'
                            onSubmit={createApiKey}
                        >
                            <div className='theme-panel-soft border-b p-5'>
                                <div className='flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between'>
                                    <div>
                                        <p className='theme-eyebrow text-xs font-bold uppercase tracking-[0.24em]'>
                                            Reseller API Access
                                        </p>
                                        <h3 className='mt-2 text-2xl font-semibold text-white'>
                                            Generate API Key
                                        </h3>
                                        <p className='mt-2 max-w-2xl text-sm leading-6 text-white/65'>
                                            Pick exact permissions for this integration. Keys are tenant-scoped to this reseller and the secret is shown once.
                                        </p>
                                    </div>
                                    <div className='theme-panel-inner rounded-2xl px-4 py-3 text-sm shadow-[0_0_28px_rgba(0,0,0,0.18)]'>
                                        <p className='theme-eyebrow text-xs uppercase tracking-[0.2em]'>
                                            Selected
                                        </p>
                                        <p className='mt-1 text-2xl font-bold'>
                                            {selectedApiScopes.size}
                                            <span className='theme-muted ml-1 text-sm font-medium'>
                                                scopes
                                            </span>
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <div className='p-5'>
                                <div className='grid gap-4 xl:grid-cols-[minmax(0,0.95fr)_minmax(0,1.25fr)]'>
                                    <div className='space-y-4'>
                                        <div className='theme-panel-inner rounded-xl p-4'>
                                            <TextInput
                                                label='Key Name'
                                                value={newApiKeyName}
                                                onChange={event =>
                                                    setNewApiKeyName(event.currentTarget.value)
                                                }
                                                placeholder='Billing integration key'
                                            />
                                            <p className='theme-muted mt-2 text-xs leading-5'>
                                                Use a name that tells you where this key is installed.
                                            </p>
                                        </div>

                                        <div className='theme-panel-inner rounded-xl p-4'>
                                            <p className='text-sm font-semibold text-white'>
                                                Quick presets
                                            </p>
                                            <div className='mt-3 space-y-2'>
                                                {resellerApiScopePresets.map(preset => {
                                                    const active =
                                                        preset.scopes.length === selectedApiScopes.size &&
                                                        preset.scopes.every(scope =>
                                                            selectedApiScopes.has(scope)
                                                        )

                                                    return (
                                                        <button
                                                            key={preset.label}
                                                            type='button'
                                                            onClick={() =>
                                                                applyApiScopePreset(preset.scopes)
                                                            }
                                                            className={`w-full rounded-xl border px-4 py-3 text-left transition ${
                                                                active
                                                                    ? 'theme-pill-active'
                                                                    : 'theme-pill'
                                                            }`}
                                                        >
                                                            <span className='block text-sm font-semibold'>
                                                                {preset.label}
                                                            </span>
                                                            <span className='theme-muted mt-1 block text-xs leading-5'>
                                                                {preset.description}
                                                            </span>
                                                        </button>
                                                    )
                                                })}
                                            </div>
                                        </div>
                                    </div>

                                    <div className='space-y-4'>
                                        {resellerApiScopeGroups.map(group => {
                                            const groupScopeKeys = group.scopes.map(scope => scope.key)
                                            const groupSelected = groupScopeKeys.every(scope =>
                                                selectedApiScopes.has(scope)
                                            )

                                            return (
                                                <div
                                                    key={group.label}
                                                    className='theme-panel-inner rounded-xl p-4'
                                                >
                                                    <div className='flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between'>
                                                        <div>
                                                            <p className='font-semibold text-white'>
                                                                {group.label}
                                                            </p>
                                                            <p className='theme-muted mt-1 text-xs leading-5'>
                                                                {group.description}
                                                            </p>
                                                        </div>
                                                        <button
                                                            type='button'
                                                            onClick={() =>
                                                                toggleApiScopeGroup(groupScopeKeys)
                                                            }
                                                            className={`rounded-full border px-3 py-1 text-xs font-semibold transition ${
                                                                groupSelected
                                                                    ? 'theme-pill-active'
                                                                    : 'theme-pill'
                                                            }`}
                                                        >
                                                            {groupSelected ? 'Selected' : 'Select group'}
                                                        </button>
                                                    </div>

                                                    <div className='mt-4 grid gap-3 md:grid-cols-2'>
                                                        {group.scopes.map(scope => {
                                                            const active = selectedApiScopes.has(scope.key)

                                                            return (
                                                                <button
                                                                    key={scope.key}
                                                                    type='button'
                                                                    onClick={() => toggleApiScope(scope.key)}
                                                                    className={`rounded-xl border p-3 text-left transition ${
                                                                        active
                                                                            ? 'theme-pill-active'
                                                                            : 'theme-pill'
                                                                    }`}
                                                                >
                                                                    <span className='flex items-center justify-between gap-2'>
                                                                        <span className='text-sm font-semibold text-white'>
                                                                            {scope.label}
                                                                        </span>
                                                                        <span
                                                                            className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide ${
                                                                                scope.mode === 'write'
                                                                                    ? 'bg-amber-400/15 text-amber-100'
                                                                                    : 'bg-white/10 text-white/80'
                                                                            }`}
                                                                        >
                                                                            {scope.mode}
                                                                        </span>
                                                                    </span>
                                                                    <span className='theme-accent-text mt-2 block font-mono text-xs'>
                                                                        {scope.key}
                                                                    </span>
                                                                    <span className='theme-muted mt-2 block text-xs leading-5'>
                                                                        {scope.description}
                                                                    </span>
                                                                </button>
                                                            )
                                                        })}
                                                    </div>
                                                </div>
                                            )
                                        })}
                                    </div>
                                </div>

                                <div className='theme-panel-inner mt-5 flex flex-col gap-3 rounded-xl p-4 sm:flex-row sm:items-center sm:justify-between'>
                                    <div>
                                        <p className='text-sm font-semibold text-white'>
                                            Final scopes
                                        </p>
                                        <div className='mt-2 flex flex-wrap gap-2'>
                                            {newApiKeyScopes.length > 0 ? (
                                                newApiKeyScopes.map(scope => (
                                                    <span
                                                        key={scope}
                                                        className='theme-pill-active rounded-full px-3 py-1 font-mono text-xs'
                                                    >
                                                        {scope}
                                                    </span>
                                                ))
                                            ) : (
                                                <span className='text-xs text-rose-100'>
                                                    Choose at least one scope.
                                                </span>
                                            )}
                                        </div>
                                    </div>
                                    <Button
                                        type='submit'
                                        variant='filled'
                                        disabled={!canCreateApiKey}
                                    >
                                        Create Key
                                    </Button>
                                </div>
                            </div>

                            {plainApiKey ? (
                                <div className='mx-5 mb-5 rounded-xl border border-emerald-300/30 bg-emerald-400/10 p-4 text-sm text-emerald-50 shadow-[0_0_35px_rgba(16,185,129,0.10)]'>
                                    <div className='flex flex-col gap-3 md:flex-row md:items-center md:justify-between'>
                                        <div>
                                            <p className='font-semibold'>
                                                API key created
                                            </p>
                                            <p className='mt-1 text-xs text-emerald-100/70'>
                                                Save this secret now. It will not be shown again.
                                            </p>
                                        </div>
                                        <Button
                                            type='button'
                                            size='sm'
                                            variant='outline'
                                            onClick={() =>
                                                void copyDomainValue(
                                                    'reseller-api-key',
                                                    plainApiKey
                                                )
                                            }
                                        >
                                            Copy Key
                                        </Button>
                                    </div>
                                    <p className='mt-3 break-all rounded-lg border border-white/10 bg-black/20 p-3 font-mono text-xs text-emerald-100'>
                                        {plainApiKey}
                                    </p>
                                </div>
                            ) : null}
                        </form>

                        <div className='theme-panel rounded-2xl p-4'>
                            <div className='mb-4 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between'>
                                <div>
                                    <h3 className='text-lg font-semibold text-white'>
                                        Active API Keys
                                    </h3>
                                    <p className='text-sm text-white/55'>
                                        Revoke keys immediately when an integration is removed.
                                    </p>
                                </div>
                                <Button
                                    type='button'
                                    size='sm'
                                    variant='outline'
                                    onClick={() => void refreshApiKeys()}
                                >
                                    Refresh
                                </Button>
                            </div>
                            <div className='space-y-3'>
                                {apiKeys.map(item => (
                                    <div
                                        key={item.id}
                                        className='theme-panel-inner rounded-xl p-4 text-sm'
                                    >
                                        <div className='flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between'>
                                            <div>
                                                <div className='flex flex-wrap items-center gap-2'>
                                                    <p className='font-semibold text-white'>
                                                        {item.name}
                                                    </p>
                                                    <span
                                                        className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide ${
                                                            item.revokedAt
                                                                ? 'bg-rose-400/15 text-rose-100'
                                                                : 'bg-emerald-400/15 text-emerald-100'
                                                        }`}
                                                    >
                                                        {item.revokedAt ? 'Revoked' : 'Live'}
                                                    </span>
                                                </div>
                                                <p className='mt-1 font-mono text-xs text-white/55'>
                                                    Prefix: {item.keyPrefix}
                                                </p>
                                                <div className='mt-3 flex flex-wrap gap-2'>
                                                    {item.scopes.map(scope => (
                                                        <span
                                                            key={scope}
                                                            className='theme-pill rounded-full px-2.5 py-1 font-mono text-[11px]'
                                                        >
                                                            {scope}
                                                        </span>
                                                    ))}
                                                </div>
                                            </div>
                                            <Button
                                                size='sm'
                                                color='danger'
                                                disabled={Boolean(item.revokedAt)}
                                                onClick={() =>
                                                    void quickRevokeApiKey(item)
                                                }
                                            >
                                                Revoke
                                            </Button>
                                        </div>
                                    </div>
                                ))}
                                {apiKeys.length === 0 ? (
                                    <div className='rounded-xl border border-dashed border-white/15 bg-[#071322]/70 p-5 text-sm text-white/55'>
                                        No reseller API keys have been created yet.
                                    </div>
                                ) : null}
                            </div>
                        </div>
                    </div>
                ) : null}

                {section === 'orders' ? (
                    <div className='space-y-4'>
                        <div className='grid gap-3 md:grid-cols-4'>
                            <div className='rounded-xl border border-white/10 bg-[#111a31] p-4 text-white'>
                                <p className='text-xs uppercase tracking-wide text-white/55'>Active Billing</p>
                                <p className='mt-2 text-2xl font-semibold'>
                                    {orders?.summary.countsByStatus.active ?? 0}
                                </p>
                            </div>
                            <div className='rounded-xl border border-white/10 bg-[#111a31] p-4 text-white'>
                                <p className='text-xs uppercase tracking-wide text-white/55'>Pending Invoices</p>
                                <p className='mt-2 text-2xl font-semibold'>
                                    {orders?.summary.countsByStatus.pending ?? 0}
                                </p>
                            </div>
                            <div className='rounded-xl border border-white/10 bg-[#111a31] p-4 text-white'>
                                <p className='text-xs uppercase tracking-wide text-white/55'>Suspended</p>
                                <p className='mt-2 text-2xl font-semibold text-rose-100'>
                                    {orders?.summary.countsByStatus.suspended ?? 0}
                                </p>
                            </div>
                            <div className='rounded-xl border border-white/10 bg-[#111a31] p-4 text-white'>
                                <p className='text-xs uppercase tracking-wide text-white/55'>Revenue</p>
                                <div className='mt-2 flex flex-wrap gap-2'>
                                    {(orders?.summary.totalsByCurrency ?? []).map(item => (
                                        <span key={`revenue-${item.currency}`} className='rounded-full border border-emerald-400/20 bg-emerald-500/10 px-3 py-1 text-sm font-semibold text-emerald-100'>
                                            {item.currency} {item.total.toFixed(2)}
                                        </span>
                                    ))}
                                    {(orders?.summary.totalsByCurrency ?? []).length === 0 ? (
                                        <span className='text-sm text-white/55'>No revenue yet.</span>
                                    ) : null}
                                </div>
                            </div>
                        </div>

                        <div className='rounded-2xl border border-cyan-300/15 bg-[linear-gradient(135deg,rgba(10,20,42,0.96),rgba(20,15,55,0.92))] p-5 text-white'>
                            <div className='flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between'>
                                <div>
                                    <p className='text-xs font-bold uppercase tracking-[0.26em] text-cyan-100/70'>Built-in Manual Billing</p>
                                    <h3 className='mt-2 text-xl font-semibold'>Invoices, orders, users, and services without Paymenter/WHMCS</h3>
                                    <p className='mt-2 max-w-3xl text-sm leading-6 text-white/65'>
                                        Create pending invoices, mark them paid manually or by API, then WammuCore creates the customer VPS service and links it to the selected user. External API-created services stay managed by their billing system.
                                    </p>
                                </div>
                                <Button type='button' variant='filled' onClick={() => void saveManualBillingSettings()}>
                                    Save Manual Billing
                                </Button>
                            </div>
                            <div className='mt-4 grid gap-3 md:grid-cols-5'>
                                <label className='flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.05] p-3 text-sm text-white/80'>
                                    <input type='checkbox' checked={manualBillingEnabled} onChange={event => setManualBillingEnabled(event.currentTarget.checked)} />
                                    Manual billing enabled
                                </label>
                                <label className='flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.05] p-3 text-sm text-white/80'>
                                    <input type='checkbox' checked={manualBillingAutoSuspendEnabled} onChange={event => setManualBillingAutoSuspendEnabled(event.currentTarget.checked)} />
                                    Auto suspend overdue services
                                </label>
                                <TextInput
                                    type='number'
                                    label='Grace days before suspend'
                                    value={String(manualBillingGraceDays)}
                                    onChange={event => setManualBillingGraceDays(Math.max(0, Number(event.currentTarget.value || 0)))}
                                />
                                <label className='flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.05] p-3 text-sm text-white/80'>
                                    <input
                                        type='checkbox'
                                        checked={manualBillingDeleteSuspendedEnabled}
                                        onChange={event => setManualBillingDeleteSuspendedEnabled(event.currentTarget.checked)}
                                    />
                                    Delete suspended VPS
                                </label>
                                <TextInput
                                    type='number'
                                    label='Delete after days'
                                    value={String(manualBillingDeleteSuspendedDays)}
                                    onChange={event => setManualBillingDeleteSuspendedDays(Math.max(1, Number(event.currentTarget.value || 1)))}
                                    disabled={!manualBillingDeleteSuspendedEnabled}
                                />
                            </div>
                            <p className='mt-3 text-xs leading-5 text-amber-100/75'>
                                Deletion only applies to manual-billed VPS that WammuCore already suspended for overdue payment. Paymenter/WHMCS/API-managed services are not deleted by this setting.
                            </p>
                        </div>

                        {manualProvisionSecret ? (
                            <div className='rounded-xl border border-emerald-300/25 bg-emerald-400/10 p-4 text-sm text-emerald-50'>
                                <p className='font-semibold'>VPS provisioning started for {manualProvisionSecret.orderNumber}</p>
                                <p className='mt-1 text-emerald-100/75'>Save this generated root password now. It will not be shown again.</p>
                                <p className='mt-3 break-all rounded-lg border border-white/10 bg-black/20 p-3 font-mono text-xs'>{manualProvisionSecret.rootPassword}</p>
                            </div>
                        ) : null}

                        <form className='rounded-2xl border border-white/10 bg-[#1a1441] p-5 text-white' onSubmit={createManualBillingRecord}>
                            <div className='flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between'>
                                <div>
                                    <p className='text-xs font-bold uppercase tracking-[0.24em] text-white/50'>Create Manual Invoice / Service</p>
                                    <h3 className='mt-2 text-xl font-semibold'>Monthly customer billing</h3>
                                    <p className='mt-1 text-sm text-white/60'>
                                        Leave "Mark paid now" off to create a pending invoice. Turn it on to move it into orders and provision the VPS immediately.
                                    </p>
                                </div>
                                <Button type='submit' variant='filled' disabled={!manualBillingEnabled}>
                                    Create Invoice
                                </Button>
                            </div>
                            <div className='mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-4'>
                                <TextInput label='Customer name' value={manualCustomerName} onChange={event => setManualCustomerName(event.currentTarget.value)} placeholder='Customer Name' />
                                <TextInput label='Customer email' value={manualCustomerEmail} onChange={event => setManualCustomerEmail(event.currentTarget.value)} placeholder='customer@example.com' />
                                <TextInput label='Customer password optional' type='password' value={manualCustomerPassword} onChange={event => setManualCustomerPassword(event.currentTarget.value)} placeholder='Auto-generated if blank' />
                                <div>
                                    <label className='mb-2 block text-sm font-bold text-white'>VPS plan</label>
                                    <select
                                        className='h-10 w-full rounded border border-accent-300 bg-background px-3 text-sm text-white'
                                        value={manualCatalogPlanId}
                                        onChange={event => {
                                            const value = event.currentTarget.value
                                            setManualCatalogPlanId(value)
                                            const plan = catalog.find(item => String(item.catalogPlanId) === value)
                                            if (plan?.pricing.monthlyPrice) setManualAmount(plan.pricing.monthlyPrice)
                                            if (plan?.pricing.currency) setManualCurrency(plan.pricing.currency)
                                        }}
                                    >
                                        <option value=''>Invoice only / no VPS</option>
                                        {catalog.filter(plan => plan.isActive && plan.pricing.isVisible).map(plan => (
                                            <option key={plan.catalogPlanId} value={plan.catalogPlanId}>
                                                {plan.name} - {plan.pricing.currency} {plan.pricing.monthlyPrice ?? '0.00'}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <TextInput label='Hostname' value={manualHostname} onChange={event => setManualHostname(event.currentTarget.value)} placeholder='vps.customer.com' />
                                <TextInput label='OS / template' value={manualOperatingSystem} onChange={event => setManualOperatingSystem(event.currentTarget.value)} placeholder='Ubuntu-22-04 or template UUID' />
                                <TextInput label='Root password optional' type='password' value={manualRootPassword} onChange={event => setManualRootPassword(event.currentTarget.value)} placeholder='Generated if blank' />
                                <TextInput label='Amount' value={manualAmount} onChange={event => setManualAmount(event.currentTarget.value)} placeholder='299.00' />
                                <TextInput label='Currency' value={manualCurrency} onChange={event => setManualCurrency(event.currentTarget.value.toUpperCase())} placeholder='INR' />
                                <div>
                                    <label className='mb-2 block text-sm font-bold text-white'>Billing cycle</label>
                                    <select className='h-10 w-full rounded border border-accent-300 bg-background px-3 text-sm text-white' value={manualBillingCycle} onChange={event => setManualBillingCycle(event.currentTarget.value as typeof manualBillingCycle)}>
                                        <option value='monthly'>Monthly</option>
                                        <option value='quarterly'>Quarterly</option>
                                        <option value='semi_annually'>Semi annually</option>
                                        <option value='yearly'>Yearly</option>
                                        <option value='one_time'>One time</option>
                                    </select>
                                </div>
                                <TextInput type='date' label='First due date' value={manualDueAt} onChange={event => setManualDueAt(event.currentTarget.value)} />
                                <TextInput label='Internal notes' value={manualNotes} onChange={event => setManualNotes(event.currentTarget.value)} placeholder='Payment ref, UPI note, bank transfer id...' />
                            </div>
                            <div className='mt-4 flex flex-wrap gap-3'>
                                <label className='inline-flex items-center gap-2 rounded-lg border border-white/10 bg-[#111a31] px-3 py-2 text-sm text-white/80'>
                                    <input type='checkbox' checked={manualProvisionOnPaid} onChange={event => setManualProvisionOnPaid(event.currentTarget.checked)} />
                                    Provision VPS after payment
                                </label>
                                <label className='inline-flex items-center gap-2 rounded-lg border border-white/10 bg-[#111a31] px-3 py-2 text-sm text-white/80'>
                                    <input type='checkbox' checked={manualMarkPaidNow} onChange={event => setManualMarkPaidNow(event.currentTarget.checked)} />
                                    Mark paid now
                                </label>
                            </div>
                        </form>

                        <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                            <div className='mb-3 grid gap-3 md:grid-cols-3'>
                                <TextInput
                                    label='Search'
                                    value={ordersQuery}
                                    onChange={event => {
                                        setOrdersPage(1)
                                        setOrdersQuery(event.currentTarget.value)
                                    }}
                                />
                                <div>
                                    <label className='mb-2 block text-sm font-bold text-white'>Status</label>
                                    <select className='h-10 w-full rounded border border-accent-300 bg-background px-3 text-sm text-white' value={ordersStatus} onChange={event => {
                                        setOrdersPage(1)
                                        setOrdersStatus(event.currentTarget.value)
                                    }}>
                                        <option value=''>All statuses</option>
                                        <option value='pending'>Pending</option>
                                        <option value='paid'>Paid</option>
                                        <option value='processing'>Processing</option>
                                        <option value='active'>Active</option>
                                        <option value='suspended'>Suspended</option>
                                        <option value='cancelled'>Cancelled</option>
                                        <option value='failed'>Failed</option>
                                    </select>
                                </div>
                                <div className='flex items-end'>
                                    <a href={getResellerOrdersCsvUrl()} className='inline-flex h-10 items-center rounded border border-indigo-400/40 bg-indigo-500/10 px-4 text-sm font-semibold text-indigo-100 transition hover:bg-indigo-500/20'>
                                        Export CSV
                                    </a>
                                </div>
                            </div>
                            <div className='overflow-x-auto'>
                                <table className='w-full min-w-[1180px]'>
                                    <thead>
                                        <tr className='text-left text-xs uppercase text-white/60'>
                                            <th className='py-2'>Invoice</th>
                                            <th>Customer</th>
                                            <th>Plan / Service</th>
                                            <th>Source</th>
                                            <th>Status</th>
                                            <th>Due</th>
                                            <th>Total</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {(orders?.items || []).map(item => (
                                            <tr key={item.id} className='border-t border-white/10 align-top text-sm text-white/90'>
                                                <td className='py-3'>
                                                    <p className='font-semibold'>{item.orderNumber}</p>
                                                    <p className='mt-1 text-xs text-white/45'>{formatTimestamp(item.createdAt)}</p>
                                                </td>
                                                <td>
                                                    <p>{item.user?.name || '-'}</p>
                                                    <p className='mt-1 text-xs text-white/50'>{item.user?.email || '-'}</p>
                                                </td>
                                                <td>
                                                    <p>{item.plan?.name || 'Invoice only'}</p>
                                                    <p className='mt-1 text-xs text-white/50'>{item.server ? `${item.server.hostname} (${item.server.status || 'unknown'})` : 'No VPS linked'}</p>
                                                </td>
                                                <td>
                                                    <span className={`rounded-full px-2 py-1 text-xs font-semibold ${item.billingSource === 'manual' ? 'bg-cyan-400/15 text-cyan-100' : 'bg-white/10 text-white/60'}`}>
                                                        {item.billingSource === 'manual' ? 'Manual' : 'External/API'}
                                                    </span>
                                                </td>
                                                <td className='capitalize'>{item.status}</td>
                                                <td>
                                                    <p>{item.dueAt ? formatTimestamp(item.dueAt) : '-'}</p>
                                                    {item.billingSource === 'manual' ? (
                                                        <p className='mt-1 text-xs text-white/50'>
                                                            Grace: {item.graceDays}d - {item.autoSuspendEnabled ? 'auto suspend on' : 'manual only'}
                                                        </p>
                                                    ) : null}
                                                </td>
                                                <td>{item.totalAmount} {item.currency}</td>
                                                <td>
                                                    {item.billingSource === 'manual' ? (
                                                        <div className='flex flex-wrap gap-2'>
                                                            {!['active', 'paid', 'processing', 'cancelled'].includes(item.status) ? (
                                                                <Button size='sm' onClick={() => void quickMarkManualOrderPaid(item.id)}>Mark Paid</Button>
                                                            ) : null}
                                                            {['active', 'paid'].includes(item.status) ? (
                                                                <Button size='sm' color='danger' onClick={() => void quickSuspendManualOrder(item.id)}>Suspend</Button>
                                                            ) : null}
                                                            {item.status === 'suspended' ? (
                                                                <Button size='sm' onClick={() => void quickUnsuspendManualOrder(item.id)}>Unsuspend</Button>
                                                            ) : null}
                                                            {item.status !== 'cancelled' ? (
                                                                <Button size='sm' variant='outline' onClick={() => void quickCancelManualOrder(item.id)}>Cancel</Button>
                                                            ) : null}
                                                        </div>
                                                    ) : (
                                                        <span className='text-xs text-white/45'>Managed externally</span>
                                                    )}
                                                </td>
                                            </tr>
                                        ))}
                                        {(orders?.items || []).length === 0 ? (
                                            <tr>
                                                <td colSpan={8} className='py-8 text-center text-sm text-white/55'>
                                                    No billing records matched your filters.
                                                </td>
                                            </tr>
                                        ) : null}
                                    </tbody>
                                </table>
                            </div>
                            {orders ? (
                                <div className='mt-4 flex gap-2'>
                                    <Button size='sm' disabled={orders.pagination.currentPage <= 1} onClick={() => setOrdersPage(page => Math.max(1, page - 1))}>
                                        Prev
                                    </Button>
                                    <Button size='sm' disabled={orders.pagination.currentPage >= orders.pagination.totalPages} onClick={() => setOrdersPage(page => page + 1)}>
                                        Next
                                    </Button>
                                </div>
                            ) : null}
                        </div>
                    </div>
                ) : null}

                {section === 'tickets' ? (
                    <div className='grid gap-4 xl:grid-cols-[minmax(0,1.05fr)_minmax(0,1.35fr)]'>
                        <div className='space-y-4'>
                            <form
                                className='rounded-xl border border-white/10 bg-[#1a1441] p-4'
                                onSubmit={createTicket}
                            >
                                <h3 className='text-lg font-semibold text-white'>
                                    Open Support Ticket
                                </h3>
                                <div className='mt-3 grid gap-3 md:grid-cols-2'>
                                    <TextInput
                                        label='Subject'
                                        value={newTicketSubject}
                                        onChange={event =>
                                            setNewTicketSubject(
                                                event.currentTarget.value
                                            )
                                        }
                                    />
                                    <div>
                                        <label className='mb-2 block text-sm font-bold text-white'>
                                            Priority
                                        </label>
                                        <select
                                            className='h-10 w-full rounded border border-accent-300 bg-background px-3 text-sm text-white'
                                            value={newTicketPriority}
                                            onChange={event =>
                                                setNewTicketPriority(
                                                    event.currentTarget.value as
                                                        | 'low'
                                                        | 'medium'
                                                        | 'high'
                                                        | 'urgent'
                                                )
                                            }
                                        >
                                            <option value='low'>Low</option>
                                            <option value='medium'>Medium</option>
                                            <option value='high'>High</option>
                                            <option value='urgent'>Urgent</option>
                                        </select>
                                    </div>
                                    <TextInput
                                        label='Customer Name'
                                        value={newTicketCustomerName}
                                        onChange={event =>
                                            setNewTicketCustomerName(
                                                event.currentTarget.value
                                            )
                                        }
                                    />
                                    <TextInput
                                        label='Customer Email'
                                        value={newTicketCustomerEmail}
                                        onChange={event =>
                                            setNewTicketCustomerEmail(
                                                event.currentTarget.value
                                            )
                                        }
                                    />
                                    <TextInput
                                        label='Customer User ID (optional)'
                                        value={newTicketUserId}
                                        onChange={event =>
                                            setNewTicketUserId(
                                                event.currentTarget.value
                                            )
                                        }
                                    />
                                    <TextInput
                                        label='Service ID (optional)'
                                        value={newTicketServerId}
                                        onChange={event =>
                                            setNewTicketServerId(
                                                event.currentTarget.value
                                            )
                                        }
                                    />
                                </div>
                                <div className='mt-3'>
                                    <label className='mb-2 block text-sm font-bold text-white'>
                                        First Message
                                    </label>
                                    <textarea
                                        className='h-28 w-full rounded-md border border-white/10 bg-[#0f172a] px-3 py-2 text-sm text-white outline-none transition focus:border-emerald-400/50'
                                        value={newTicketBody}
                                        onChange={event =>
                                            setNewTicketBody(
                                                event.currentTarget.value
                                            )
                                        }
                                    />
                                </div>
                                <div className='mt-4'>
                                    <Button type='submit' variant='filled'>
                                        Create Ticket
                                    </Button>
                                </div>
                            </form>

                            <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                                <div className='mb-4 grid gap-3 md:grid-cols-2'>
                                    <div className='rounded-lg border border-white/10 bg-[#111a31] p-3 text-white'>
                                        <p className='text-xs uppercase tracking-wide text-white/55'>
                                            Open Queue
                                        </p>
                                        <p className='mt-2 text-xl font-semibold'>
                                            {tickets?.summary.countsByStatus.open ?? 0}
                                        </p>
                                    </div>
                                    <div className='rounded-lg border border-white/10 bg-[#111a31] p-3 text-white'>
                                        <p className='text-xs uppercase tracking-wide text-white/55'>
                                            Urgent / High
                                        </p>
                                        <p className='mt-2 text-xl font-semibold'>
                                            {(tickets?.summary.countsByPriority.urgent ?? 0) +
                                                (tickets?.summary.countsByPriority.high ?? 0)}
                                        </p>
                                    </div>
                                </div>

                                <div className='mb-3 grid gap-3 md:grid-cols-3'>
                                    <TextInput
                                        label='Search'
                                        value={ticketsQuery}
                                        onChange={event => {
                                            setTicketsPage(1)
                                            setTicketsQuery(
                                                event.currentTarget.value
                                            )
                                        }}
                                    />
                                    <div>
                                        <label className='mb-2 block text-sm font-bold text-white'>
                                            Status
                                        </label>
                                        <select
                                            className='h-10 w-full rounded border border-accent-300 bg-background px-3 text-sm text-white'
                                            value={ticketsStatus}
                                            onChange={event => {
                                                setTicketsPage(1)
                                                setTicketsStatus(
                                                    event.currentTarget.value
                                                )
                                            }}
                                        >
                                            <option value=''>All statuses</option>
                                            <option value='open'>Open</option>
                                            <option value='pending_reseller'>
                                                Pending Reseller
                                            </option>
                                            <option value='pending_customer'>
                                                Pending Customer
                                            </option>
                                            <option value='resolved'>Resolved</option>
                                            <option value='closed'>Closed</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label className='mb-2 block text-sm font-bold text-white'>
                                            Priority
                                        </label>
                                        <select
                                            className='h-10 w-full rounded border border-accent-300 bg-background px-3 text-sm text-white'
                                            value={ticketsPriority}
                                            onChange={event => {
                                                setTicketsPage(1)
                                                setTicketsPriority(
                                                    event.currentTarget.value
                                                )
                                            }}
                                        >
                                            <option value=''>All priorities</option>
                                            <option value='low'>Low</option>
                                            <option value='medium'>Medium</option>
                                            <option value='high'>High</option>
                                            <option value='urgent'>Urgent</option>
                                        </select>
                                    </div>
                                </div>

                                <div className='space-y-2'>
                                    {(tickets?.items || []).map(ticket => (
                                        <button
                                            key={ticket.id}
                                            type='button'
                                            className={`block w-full rounded-lg border p-3 text-left transition ${
                                                selectedTicket?.id === ticket.id
                                                    ? 'border-indigo-300/60 bg-indigo-500/15'
                                                    : 'border-white/10 bg-[#111a31] hover:border-indigo-400/35 hover:bg-indigo-500/10'
                                            }`}
                                            onClick={() => void openTicket(ticket.id)}
                                        >
                                            <div className='flex items-center justify-between gap-3'>
                                                <div>
                                                    <p className='text-sm font-semibold text-white'>
                                                        {ticket.ticketNumber}
                                                    </p>
                                                    <p className='text-xs text-white/55'>
                                                        {ticket.customerEmail ||
                                                            ticket.user?.email ||
                                                            '-'}
                                                    </p>
                                                </div>
                                                <span className='text-[11px] uppercase tracking-wide text-white/50'>
                                                    {ticket.priority}
                                                </span>
                                            </div>
                                            <p className='mt-2 text-sm text-white/80'>
                                                {ticket.subject}
                                            </p>
                                        </button>
                                    ))}
                                    {(tickets?.items || []).length === 0 ? (
                                        <div className='rounded-lg border border-dashed border-white/15 px-4 py-5 text-sm text-white/55'>
                                            No support tickets matched your filters.
                                        </div>
                                    ) : null}
                                </div>

                                <div className='mt-3 flex gap-2'>
                                    <Button
                                        size='sm'
                                        disabled={!tickets || ticketsPage <= 1}
                                        onClick={() =>
                                            setTicketsPage(current =>
                                                Math.max(1, current - 1)
                                            )
                                        }
                                    >
                                        Prev
                                    </Button>
                                    <Button
                                        size='sm'
                                        disabled={
                                            !tickets ||
                                            ticketsPage >=
                                                tickets.pagination.totalPages
                                        }
                                        onClick={() =>
                                            setTicketsPage(current => current + 1)
                                        }
                                    >
                                        Next
                                    </Button>
                                </div>
                            </div>
                        </div>

                        <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                            {selectedTicket ? (
                                <>
                                    <div className='flex flex-col gap-3 md:flex-row md:items-start md:justify-between'>
                                        <div>
                                            <p className='text-xs uppercase tracking-wide text-white/55'>
                                                {selectedTicket.ticketNumber}
                                            </p>
                                            <h3 className='mt-1 text-lg font-semibold text-white'>
                                                {selectedTicket.subject}
                                            </h3>
                                            <p className='mt-1 text-sm text-white/60'>
                                                {selectedTicket.customerEmail ||
                                                    selectedTicket.user?.email ||
                                                    '-'}
                                            </p>
                                        </div>
                                        <div className='flex flex-wrap gap-2'>
                                            {[
                                                'open',
                                                'pending_reseller',
                                                'pending_customer',
                                                'resolved',
                                                'closed',
                                            ].map(status => (
                                                <Button
                                                    key={`${selectedTicket.id}-${status}`}
                                                    size='sm'
                                                    onClick={() =>
                                                        void quickUpdateTicketStatus(
                                                            selectedTicket,
                                                            status
                                                        )
                                                    }
                                                >
                                                    {status}
                                                </Button>
                                            ))}
                                        </div>
                                    </div>

                                    <div className='mt-4 grid gap-3 md:grid-cols-3'>
                                        <div className='rounded-lg border border-white/10 bg-[#111a31] p-3 text-sm text-white/80'>
                                            <p className='text-xs uppercase tracking-wide text-white/55'>
                                                Priority
                                            </p>
                                            <p className='mt-2 font-semibold text-white'>
                                                {selectedTicket.priority}
                                            </p>
                                        </div>
                                        <div className='rounded-lg border border-white/10 bg-[#111a31] p-3 text-sm text-white/80'>
                                            <p className='text-xs uppercase tracking-wide text-white/55'>
                                                Status
                                            </p>
                                            <p className='mt-2 font-semibold text-white'>
                                                {selectedTicket.status}
                                            </p>
                                        </div>
                                        <div className='rounded-lg border border-white/10 bg-[#111a31] p-3 text-sm text-white/80'>
                                            <p className='text-xs uppercase tracking-wide text-white/55'>
                                                Linked Service
                                            </p>
                                            <p className='mt-2 font-semibold text-white'>
                                                {selectedTicket.serverId || '-'}
                                            </p>
                                        </div>
                                    </div>

                                    <div className='mt-4 space-y-3'>
                                        {selectedTicket.messages.map(message => (
                                            <div
                                                key={message.id}
                                                className='rounded-lg border border-white/10 bg-[#111a31] p-3'
                                            >
                                                <div className='flex items-center justify-between gap-3'>
                                                    <p className='text-sm font-semibold text-white'>
                                                        {message.actorType}
                                                    </p>
                                                    <p className='text-xs text-white/50'>
                                                        {message.createdAt || '-'}
                                                    </p>
                                                </div>
                                                <p className='mt-2 whitespace-pre-wrap text-sm text-white/85'>
                                                    {message.body}
                                                </p>
                                            </div>
                                        ))}
                                    </div>

                                    <form className='mt-4' onSubmit={sendTicketReply}>
                                        <label className='mb-2 block text-sm font-bold text-white'>
                                            Reply
                                        </label>
                                        <textarea
                                            className='h-32 w-full rounded-md border border-white/10 bg-[#0f172a] px-3 py-2 text-sm text-white outline-none transition focus:border-emerald-400/50'
                                            value={ticketReplyBody}
                                            onChange={event =>
                                                setTicketReplyBody(
                                                    event.currentTarget.value
                                                )
                                            }
                                        />
                                        <div className='mt-3'>
                                            <Button type='submit' variant='filled'>
                                                Send Reply
                                            </Button>
                                        </div>
                                    </form>
                                </>
                            ) : (
                                <div className='flex h-full min-h-[420px] items-center justify-center rounded-xl border border-dashed border-white/15 bg-[#111a31] px-6 text-center text-sm text-white/55'>
                                    Select a ticket from the left to review the thread and reply.
                                </div>
                            )}
                        </div>
                    </div>
                ) : null}

                {section === 'statistics' && statistics
                    ? (() => {
                          const trend = statistics.trends.createdChangePercent
                          const isTrendPositive = trend >= 0
                          const growth = statistics.charts.serverGrowth || []
                          const maxGrowthValue = Math.max(
                              1,
                              ...growth.map(item => item.total)
                          )
                          const recentGrowth = growth.slice(-14)

                          return (
                              <div className='space-y-4'>
                                  <div className='grid gap-3 md:grid-cols-2 xl:grid-cols-3'>
                                      <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4 text-white'>
                                          <p className='text-xs uppercase tracking-wide text-white/60'>
                                              Total Services
                                          </p>
                                          <p className='mt-2 text-2xl font-semibold'>
                                              {compactNumber(statistics.aggregate.servers)}
                                          </p>
                                          <p className='mt-1 text-xs text-white/60'>
                                              Active reseller VPS inventory
                                          </p>
                                      </div>

                                      <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4 text-white'>
                                          <p className='text-xs uppercase tracking-wide text-white/60'>
                                              New Services ({statistics.trends.windowDays}d)
                                          </p>
                                          <p className='mt-2 text-2xl font-semibold'>
                                              {compactNumber(
                                                  statistics.trends.createdCurrentWindow
                                              )}
                                          </p>
                                          <p
                                              className={`mt-1 text-xs ${
                                                  isTrendPositive
                                                      ? 'text-emerald-300'
                                                      : 'text-rose-300'
                                              }`}
                                          >
                                              {isTrendPositive ? '+' : ''}
                                              {trend.toFixed(2)}% vs previous{' '}
                                              {statistics.trends.windowDays}d
                                          </p>
                                      </div>

                                      <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4 text-white'>
                                          <p className='text-xs uppercase tracking-wide text-white/60'>
                                              Average Per VPS
                                          </p>
                                          <p className='mt-2 text-sm font-semibold text-white/90'>
                                              CPU: {statistics.aggregate.avgCpuPerServer}
                                          </p>
                                          <p className='mt-1 text-sm text-white/85'>
                                              RAM: {toGbFromMb(statistics.aggregate.avgMemoryMbPerServer)}
                                          </p>
                                          <p className='mt-1 text-sm text-white/85'>
                                              Disk: {statistics.aggregate.avgDiskGbPerServer.toFixed(2)} GB
                                          </p>
                                      </div>

                                      <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4 text-white'>
                                          <p className='text-xs uppercase tracking-wide text-white/60'>
                                              Lifetime Bandwidth
                                          </p>
                                          <p className='mt-2 text-2xl font-semibold'>
                                              {compactNumber(
                                                  statistics.aggregate.bandwidthUsedMbTotal
                                              )}{' '}
                                              MB
                                          </p>
                                          <p className='mt-1 text-xs text-white/60'>
                                              Avg/VPS:{' '}
                                              {statistics.aggregate.avgBandwidthMbPerServer.toFixed(2)} MB
                                          </p>
                                      </div>

                                      <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4 text-white'>
                                          <p className='text-xs uppercase tracking-wide text-white/60'>
                                              Total Customers
                                          </p>
                                          <p className='mt-2 text-2xl font-semibold'>
                                              {compactNumber(statistics.aggregate.customers)}
                                          </p>
                                          <p className='mt-1 text-xs text-white/60'>
                                              Tenant customer footprint
                                          </p>
                                      </div>

                                      <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4 text-white'>
                                          <p className='text-xs uppercase tracking-wide text-white/60'>
                                              Open Abuse Alerts
                                          </p>
                                          <p className='mt-2 text-2xl font-semibold'>
                                              {compactNumber(statistics.aggregate.openAlerts)}
                                          </p>
                                          <p className='mt-1 text-xs text-white/60'>
                                              Security incidents needing attention
                                          </p>
                                      </div>
                                  </div>

                                  <div className='grid gap-4 xl:grid-cols-3'>
                                      <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4 xl:col-span-2'>
                                          <div className='flex items-center justify-between'>
                                              <h3 className='text-sm font-semibold uppercase tracking-wide text-white/80'>
                                                  Daily Provisioning Trend (Last 14 Days)
                                              </h3>
                                              <span className='text-xs text-white/60'>
                                                  Peak: {maxGrowthValue}/day
                                              </span>
                                          </div>
                                          <div className='mt-4 flex items-end gap-1 rounded-lg border border-white/10 bg-[#111a31] p-3'>
                                              {recentGrowth.map(point => (
                                                  <div
                                                      key={point.day}
                                                      className='group relative flex-1'
                                                      title={`${point.day}: ${point.total}`}
                                                  >
                                                      <div
                                                          className='w-full rounded-sm bg-indigo-500/80 transition hover:bg-indigo-400'
                                                          style={{
                                                              height: `${Math.max(
                                                                  (point.total / maxGrowthValue) * 140,
                                                                  point.total > 0 ? 8 : 3
                                                              )}px`,
                                                          }}
                                                      />
                                                  </div>
                                              ))}
                                          </div>
                                      </div>

                                      <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                                          <h3 className='text-sm font-semibold uppercase tracking-wide text-white/80'>
                                              Pool Utilization
                                          </h3>
                                          {[
                                              {
                                                  key: 'VMs',
                                                  used: statistics.capacity.used.vms,
                                                  max: statistics.capacity.max.vms,
                                                  pct: statistics.capacity.percentages.vms,
                                              },
                                              {
                                                  key: 'RAM',
                                                  used: statistics.capacity.used.ramMb,
                                                  max: statistics.capacity.max.ramMb,
                                                  pct: statistics.capacity.percentages.ram,
                                              },
                                              {
                                                  key: 'CPU',
                                                  used: statistics.capacity.used.cpuCores,
                                                  max: statistics.capacity.max.cpuCores,
                                                  pct: statistics.capacity.percentages.cpu,
                                              },
                                              {
                                                  key: 'Disk',
                                                  used: statistics.capacity.used.diskGb,
                                                  max: statistics.capacity.max.diskGb,
                                                  pct: statistics.capacity.percentages.disk,
                                              },
                                          ].map(item => (
                                              <div key={item.key} className='mt-3'>
                                                  <div className='flex items-center justify-between text-xs text-white/70'>
                                                      <span>{item.key}</span>
                                                      <span>
                                                          {item.used}/{item.max} ({item.pct.toFixed(2)}%)
                                                      </span>
                                                  </div>
                                                  <div className='mt-1 h-2 rounded bg-white/10'>
                                                      <div
                                                          className='h-2 rounded bg-indigo-500'
                                                          style={{ width: `${Math.min(item.pct, 100)}%` }}
                                                      />
                                                  </div>
                                              </div>
                                          ))}
                                      </div>
                                  </div>

                                  <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                                      <h3 className='text-sm font-semibold uppercase tracking-wide text-white/80'>
                                          Service Status Distribution
                                      </h3>
                                      <div className='mt-3 grid gap-3 md:grid-cols-2 xl:grid-cols-3'>
                                          {(statistics.charts.statusBreakdown || []).map(
                                              item => (
                                                  <div
                                                      key={item.status}
                                                      className='rounded-lg border border-white/10 bg-[#111a31] p-3'
                                                  >
                                                      <div className='flex items-center justify-between'>
                                                          <p className='text-sm font-semibold text-white capitalize'>
                                                              {item.status}
                                                          </p>
                                                          <p className='text-xs text-white/70'>
                                                              {item.total}
                                                          </p>
                                                      </div>
                                                      <div className='mt-2 h-2 rounded bg-white/10'>
                                                          <div
                                                              className='h-2 rounded bg-indigo-500'
                                                              style={{
                                                                  width: `${Math.min(
                                                                      item.percentage || 0,
                                                                      100
                                                                  )}%`,
                                                              }}
                                                          />
                                                      </div>
                                                      <p className='mt-1 text-xs text-white/60'>
                                                          {item.percentage.toFixed(2)}%
                                                      </p>
                                                  </div>
                                              )
                                          )}
                                      </div>
                                  </div>
                              </div>
                          )
                      })()
                    : null}

                        {loading ? <Spinner /> : null}
                    </div>
                </div>
        </PageContentBlock>
    )
}

export default ResellerAdminPanelContainer
