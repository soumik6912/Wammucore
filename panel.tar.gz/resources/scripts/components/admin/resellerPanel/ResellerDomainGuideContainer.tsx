import { getResellerOnboarding } from '@/api/admin/resellerPanel/manageOnboarding'
import { httpErrorToHuman } from '@/api/http'
import Button from '@/components/elements/Button'
import {
    NavigationBarContext,
} from '@/components/elements/navigation/NavigationBar'
import PageContentBlock from '@/components/elements/PageContentBlock'
import Spinner from '@/components/elements/Spinner'
import { getResellerPrimaryRoutes } from '@/routers/resellerPrimaryRoutes'
import { useContext, useEffect, useState } from 'react'
import { Navigate, useNavigate } from 'react-router-dom'

const ResellerDomainGuideContainer = () => {
    const navigate = useNavigate()
    const { setRoutes, setBreadcrumb } = useContext(NavigationBarContext)
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState<string | null>(null)
    const [snapshot, setSnapshot] = useState<Awaited<
        ReturnType<typeof getResellerOnboarding>
    > | null>(null)

    useEffect(() => {
        getResellerOnboarding()
            .then(setSnapshot)
            .catch(err => setError(httpErrorToHuman(err)))
            .finally(() => setLoading(false))
    }, [])

    useEffect(() => {
        setRoutes(getResellerPrimaryRoutes({ includeOnboarding: true }))
        setBreadcrumb('Reseller Panel')

        return () => {
            setRoutes([])
            setBreadcrumb(null)
        }
    }, [setBreadcrumb, setRoutes])

    if (loading) {
        return <Spinner />
    }

    if (error) {
        return (
            <PageContentBlock title='Domain Setup Guide'>
                <div className='rounded-xl border border-rose-400/30 bg-rose-500/10 p-4 text-sm text-rose-100'>
                    {error}
                </div>
            </PageContentBlock>
        )
    }

    if (!snapshot) {
        return <Navigate to='/admin/reseller-panel' replace />
    }

    if (snapshot.completed) {
        return <Navigate to='/admin/reseller-panel' replace />
    }

    return (
        <PageContentBlock title='Domain Setup Guide'>
            <div className='space-y-4'>
                <div className='rounded-2xl border border-indigo-400/20 bg-[#111827] p-5'>
                    <p className='text-xs uppercase tracking-[0.18em] text-white/45'>
                        After Registration
                    </p>
                    <h1 className='mt-2 text-2xl font-semibold text-white'>
                        Domain Setup Guide
                    </h1>
                    <p className='mt-2 text-sm text-white/70'>
                        Keep these edge-routing details ready. You will publish the
                        final DNS records later in onboarding after branding and KYC
                        are approved.
                    </p>
                </div>

                <div className='rounded-2xl border border-white/10 bg-[#08111f] p-5 text-sm text-white/80'>
                    <p>
                        Hostname:{' '}
                        <span className='font-medium text-white'>
                            {snapshot.domains.primaryHostname || '-'}
                        </span>
                    </p>
                    <p className='mt-2'>
                        CNAME target:{' '}
                        <span className='font-medium text-white'>
                            {snapshot.domains.edgeGatewayHost}
                        </span>
                    </p>
                    <p className='mt-2'>
                        TXT ownership prefix:{' '}
                        <span className='font-medium text-white'>
                            {snapshot.domains.verificationPrefix}
                        </span>
                    </p>
                    <p className='mt-3 text-xs text-white/55'>
                        You will publish the final CNAME and TXT records later during
                        onboarding after branding and KYC are approved.
                    </p>
                    <p className='mt-2 text-xs text-amber-100/80'>
                        Do not use URL forwarding or redirect rules to the edge host.
                        Use a DNS CNAME/proxied CNAME that keeps the browser on your
                        custom domain and preserves the original Host header.
                    </p>
                </div>

                <div className='flex justify-end'>
                    <Button
                        onClick={() =>
                            navigate(snapshot.currentPath || '/admin/reseller-panel')
                        }
                    >
                        Continue
                    </Button>
                </div>
            </div>
        </PageContentBlock>
    )
}

export default ResellerDomainGuideContainer
