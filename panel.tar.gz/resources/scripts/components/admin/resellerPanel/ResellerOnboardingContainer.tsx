﻿import {
    getResellerOnboarding,
    requestResellerOnboardingSsl,
    resendResellerOnboardingVerification,
    ResellerOnboardingSnapshot,
    saveResellerOnboardingBranding,
    saveResellerOnboardingDomains,
    submitResellerOnboardingKyc,
    submitResellerOnboardingPersonalDetails,
    verifyResellerOnboardingDns,
} from '@/api/admin/resellerPanel/manageOnboarding'
import { httpErrorToHuman } from '@/api/http'
import Button from '@/components/elements/Button'
import PageContentBlock from '@/components/elements/PageContentBlock'
import Spinner from '@/components/elements/Spinner'
import {
    NavigationBarContext,
} from '@/components/elements/navigation/NavigationBar'
import { getResellerPrimaryRoutes } from '@/routers/resellerPrimaryRoutes'
import { FormEvent, useContext, useEffect, useMemo, useState } from 'react'
import { Navigate, useLocation, useNavigate } from 'react-router-dom'

const statusTone = (status: string): string => {
    switch (status) {
        case 'completed':
        case 'skipped':
            return 'border-emerald-400/30 bg-emerald-500/10 text-emerald-100'
        case 'rejected':
        case 'suspended':
            return 'border-rose-400/30 bg-rose-500/10 text-rose-100'
        case 'in_progress':
            return 'border-amber-400/30 bg-amber-500/10 text-amber-100'
        default:
            return 'border-white/10 bg-[#111827] text-white/75'
    }
}

const verificationStageCopy = (status: string): string => {
    switch (status) {
        case 'approved':
            return 'KYC approved'
        case 'under_review':
            return 'KYC under review'
        case 'rejected':
            return 'KYC reviewed'
        case 'suspended':
            return 'KYC suspended'
        default:
            return 'KYC submitted'
    }
}

const kycInputClassName = (hasError: boolean): string =>
    `h-11 w-full min-w-0 rounded-lg border bg-[#0f172a] px-3 text-sm text-white outline-none transition-all ${
        hasError
            ? 'border-rose-400/70 focus:border-rose-300 focus:ring-2 focus:ring-rose-400/20'
            : 'border-white/10 focus:border-cyan-300/60 focus:ring-2 focus:ring-cyan-400/15'
    }`

const kycFileCardClassName = (hasError: boolean, hasFile: boolean): string =>
    `block rounded-xl border p-4 text-sm transition-all ${
        hasError
            ? 'border-rose-400/45 bg-rose-500/10 text-rose-100'
            : hasFile
              ? 'border-emerald-400/35 bg-emerald-500/10 text-emerald-50 shadow-[0_0_22px_rgba(74,222,128,0.12)]'
              : 'border-white/10 bg-[#0f172a] text-white/75'
    }`

const kycFileInputClassName =
    'mt-3 block w-full min-w-0 cursor-pointer rounded-lg border border-white/10 bg-black/20 p-2 text-xs text-white/75 file:mr-3 file:rounded-md file:border-0 file:bg-white/10 file:px-3 file:py-1.5 file:text-xs file:font-medium file:text-white hover:file:bg-white/15'

const completedStepStatuses = ['completed', 'skipped']

const stepStatusLabel = (status: string, isCurrent: boolean): string => {
    if (completedStepStatuses.includes(status)) {
        return 'Done'
    }

    if (isCurrent) {
        return 'Current'
    }

    if (status === 'rejected') {
        return 'Needs review'
    }

    if (status === 'suspended') {
        return 'Suspended'
    }

    return 'Pending'
}

const stepTreeTone = (status: string, isCurrent: boolean): string => {
    if (completedStepStatuses.includes(status)) {
        return 'border-emerald-300/40 bg-emerald-400/15 text-emerald-100 shadow-[0_0_18px_rgba(74,222,128,0.12)]'
    }

    if (status === 'rejected' || status === 'suspended') {
        return 'border-rose-300/40 bg-rose-500/15 text-rose-100'
    }

    if (isCurrent) {
        return 'border-cyan-300/45 bg-cyan-400/15 text-cyan-100 shadow-[0_0_20px_rgba(34,211,238,0.12)]'
    }

    return 'border-white/10 bg-white/[0.04] text-white/55'
}

interface PersonalDetailsDraft {
    firstName: string
    lastName: string
    contactEmail: string
    phoneNumber: string
    addressLine1: string
    addressLine2: string
    city: string
    stateName: string
    postalCode: string
    countryName: string
}

interface BrandingDraft {
    displayName: string
    supportUrl: string
    tosUrl: string
    privacyUrl: string
    primaryColor: string
    secondaryColor: string
    accentColor: string
    customCss: string
}

interface OnboardingDraft {
    personalDetails?: PersonalDetailsDraft
    branding?: BrandingDraft
    hostname?: string
    kyc?: {
        identityProofType: KycIdentityProofType
        businessName: string
        businessRegistrationNumber: string
    }
}

type OnboardingDraftSection = keyof OnboardingDraft
type KycIdentityProofType = 'aadhaar' | 'pan'

const ONBOARDING_DRAFT_PREFIX = 'wammucore.reseller-onboarding.draft.v1'

const hasAnyDraftValue = (value: unknown): boolean => {
    if (typeof value === 'string') {
        return value.trim() !== ''
    }

    if (Array.isArray(value)) {
        return value.some(hasAnyDraftValue)
    }

    if (value && typeof value === 'object') {
        return Object.values(value as Record<string, unknown>).some(hasAnyDraftValue)
    }

    return false
}

const onboardingDraftKey = (ownerEmail?: string | null): string | null => {
    if (typeof window === 'undefined') {
        return null
    }

    const email = String(ownerEmail || 'unknown').trim().toLowerCase() || 'unknown'
    const host = window.location.host.toLowerCase()

    return `${ONBOARDING_DRAFT_PREFIX}:${host}:${email}`
}

const readOnboardingDraft = (ownerEmail?: string | null): OnboardingDraft => {
    const key = onboardingDraftKey(ownerEmail)
    if (!key || typeof window === 'undefined') {
        return {}
    }

    try {
        const parsed = JSON.parse(window.localStorage.getItem(key) || '{}') as OnboardingDraft

        if (!parsed || typeof parsed !== 'object') {
            return {}
        }

        return {
            personalDetails: parsed.personalDetails,
            branding: parsed.branding,
            hostname: parsed.hostname,
            kyc: parsed.kyc,
        }
    } catch {
        return {}
    }
}

const writeOnboardingDraft = (ownerEmail: string | null | undefined, draft: OnboardingDraft) => {
    const key = onboardingDraftKey(ownerEmail)
    if (!key || typeof window === 'undefined') {
        return
    }

    try {
        const filtered = Object.entries(draft).reduce((carry, [key, value]) => {
            if (hasAnyDraftValue(value)) {
                ;(carry as Record<string, unknown>)[key] = value
            }

            return carry
        }, {} as OnboardingDraft)

        if (Object.keys(filtered).length === 0) {
            window.localStorage.removeItem(key)
            return
        }

        window.localStorage.setItem(
            key,
            JSON.stringify({
                ...filtered,
                savedAt: new Date().toISOString(),
            })
        )
    } catch {
        // Browser storage can fail in private mode; onboarding still works.
    }
}

const clearOnboardingDraftSection = (
    ownerEmail: string | null | undefined,
    section: OnboardingDraftSection
) => {
    const current = readOnboardingDraft(ownerEmail)
    delete current[section]
    writeOnboardingDraft(ownerEmail, current)
}

const ResellerOnboardingContainer = () => {
    const navigate = useNavigate()
    const location = useLocation()
    const { setRoutes, setBreadcrumb } = useContext(NavigationBarContext)
    const [loading, setLoading] = useState(true)
    const [submitting, setSubmitting] = useState(false)
    const [error, setError] = useState<string | null>(null)
    const [message, setMessage] = useState<string | null>(null)
    const [snapshot, setSnapshot] = useState<ResellerOnboardingSnapshot | null>(null)
    const [identityProofType, setIdentityProofType] =
        useState<KycIdentityProofType>('aadhaar')
    const [aadhaarNumber, setAadhaarNumber] = useState('')
    const [panNumber, setPanNumber] = useState('')
    const [businessName, setBusinessName] = useState('')
    const [businessRegistrationNumber, setBusinessRegistrationNumber] = useState('')
    const [aadhaarFront, setAadhaarFront] = useState<File | null>(null)
    const [aadhaarBack, setAadhaarBack] = useState<File | null>(null)
    const [panDocument, setPanDocument] = useState<File | null>(null)
    const [supportingDocuments, setSupportingDocuments] = useState<File[]>([])
    const [branding, setBranding] = useState({
        displayName: '',
        supportUrl: '',
        tosUrl: '',
        privacyUrl: '',
        primaryColor: '',
        secondaryColor: '',
        accentColor: '',
        customCss: '',
    })
    const [personalDetails, setPersonalDetails] = useState({
        firstName: '',
        lastName: '',
        contactEmail: '',
        phoneNumber: '',
        addressLine1: '',
        addressLine2: '',
        city: '',
        stateName: '',
        postalCode: '',
        countryName: '',
    })
    const [hostname, setHostname] = useState('')
    const personalDetailsLocked = Boolean(snapshot?.personalDetails?.locked)
    const kycLocked = Boolean(snapshot?.identity?.documentsUploaded)

    const scrollToOnboardingStatus = () => {
        if (typeof window === 'undefined') {
            return
        }

        window.requestAnimationFrame(() => {
            window.document
                .getElementById('reseller-onboarding-status')
                ?.scrollIntoView({ behavior: 'smooth', block: 'center' })
        })
    }

    const showInlineError = (text: string) => {
        setMessage(null)
        setError(text)
        scrollToOnboardingStatus()
    }

    const load = async () => {
        setLoading(true)
        setError(null)

        try {
            const data = await getResellerOnboarding()
            const draft = readOnboardingDraft(data.owner.email)
            const nextBranding = {
                displayName: data.branding.displayName || '',
                supportUrl: data.branding.supportUrl || '',
                tosUrl: data.branding.tosUrl || '',
                privacyUrl: data.branding.privacyUrl || '',
                primaryColor: data.branding.primaryColor || '',
                secondaryColor: data.branding.secondaryColor || '',
                accentColor: data.branding.accentColor || '',
                customCss: data.branding.customCss || '',
            }
            const nextPersonalDetails = {
                firstName: data.personalDetails.firstName || '',
                lastName: data.personalDetails.lastName || '',
                contactEmail: data.personalDetails.contactEmail || data.owner.email || '',
                phoneNumber: data.personalDetails.phoneNumber || '',
                addressLine1: data.personalDetails.addressLine1 || '',
                addressLine2: data.personalDetails.addressLine2 || '',
                city: data.personalDetails.city || '',
                stateName: data.personalDetails.stateName || '',
                postalCode: data.personalDetails.postalCode || '',
                countryName: data.personalDetails.countryName || '',
            }

            setSnapshot(data)
            setBranding({ ...nextBranding, ...(draft.branding || {}) })
            setHostname(draft.hostname ?? data.domains.primaryHostname ?? '')
            setPersonalDetails(
                data.personalDetails.locked
                    ? nextPersonalDetails
                    : { ...nextPersonalDetails, ...(draft.personalDetails || {}) }
            )
            const allowedProofTypes =
                data.kycPolicy.allowedProofTypes.length > 0
                    ? data.kycPolicy.allowedProofTypes
                    : (['aadhaar', 'pan'] as KycIdentityProofType[])
            const preferredProofType =
                draft.kyc?.identityProofType ||
                (data.identity.panMasked && !data.identity.aadhaarMasked ? 'pan' : 'aadhaar')
            setIdentityProofType(
                allowedProofTypes.includes(preferredProofType)
                    ? preferredProofType
                    : allowedProofTypes[0] || 'aadhaar'
            )
            setBusinessName(draft.kyc?.businessName ?? data.identity.businessName ?? '')
            setBusinessRegistrationNumber(draft.kyc?.businessRegistrationNumber ?? '')
        } catch (err) {
            setError(httpErrorToHuman(err))
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        void load()
    }, [])

    useEffect(() => {
        if (!snapshot || loading) {
            return
        }

        writeOnboardingDraft(snapshot.owner.email, {
            personalDetails: personalDetailsLocked ? undefined : personalDetails,
            branding,
            hostname,
            kyc: kycLocked
                ? undefined
                : {
                    identityProofType,
                    businessName,
                    businessRegistrationNumber,
                },
        })
    }, [
        snapshot,
        loading,
        personalDetailsLocked,
        personalDetails,
        branding,
        hostname,
        kycLocked,
        identityProofType,
        businessName,
        businessRegistrationNumber,
    ])

    useEffect(() => {
        setRoutes(
            getResellerPrimaryRoutes({
                includeOnboarding: true,
                operationalLocked: true,
            })
        )
        setBreadcrumb('Reseller Panel')

        return () => {
            setRoutes([])
            setBreadcrumb(null)
        }
    }, [setBreadcrumb, setRoutes])

    const activeStep = useMemo(() => {
        if (!snapshot) {
            return null
        }

        return (
            snapshot.steps.find(step => step.key === snapshot.currentStep) ||
            snapshot.steps.find(step => step.path === snapshot.currentPath) ||
            null
        )
    }, [snapshot])

    useEffect(() => {
        if (
            snapshot &&
            !snapshot.completed &&
            snapshot.currentPath &&
            snapshot.currentPath !== location.pathname
        ) {
            navigate(snapshot.currentPath, { replace: true })
        }
    }, [snapshot, location.pathname, navigate])

    const nextStepPath = useMemo(() => {
        if (!snapshot || !activeStep) {
            return null
        }

        const index = snapshot.steps.findIndex(step => step.key === activeStep.key)
        return index >= 0 && index < snapshot.steps.length - 1
            ? snapshot.steps[index + 1].path
            : '/admin/reseller-panel'
    }, [snapshot, activeStep])

    const completedStepCount = useMemo(
        () =>
            snapshot?.steps.filter(step =>
                completedStepStatuses.includes(step.status)
            ).length ?? 0,
        [snapshot]
    )

    const renderStepTree = () => (
        <aside className='rounded-3xl border border-white/10 bg-[linear-gradient(145deg,rgba(15,23,42,0.96),rgba(8,13,28,0.94))] p-5 shadow-[0_18px_48px_rgba(0,0,0,0.22)]'>
            <div className='flex flex-wrap items-start justify-between gap-3'>
                <div>
                    <p className='text-xs font-semibold uppercase tracking-[0.22em] text-cyan-100/65'>
                        Onboarding checklist
                    </p>
                    <h2 className='mt-2 text-xl font-semibold text-white'>
                        {completedStepCount}/{snapshot?.steps.length ?? 0} steps done
                    </h2>
                </div>
                <span className='rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.16em] text-white/65'>
                    {snapshot?.status.replace(/_/g, ' ')}
                </span>
            </div>

            <div className='mt-5 space-y-0'>
                {(snapshot?.steps ?? []).map((step, index, steps) => {
                    const isCurrent = step.key === snapshot?.currentStep
                    const isDone = completedStepStatuses.includes(step.status)
                    const label = stepStatusLabel(step.status, isCurrent)

                    return (
                        <div key={step.key} className='grid grid-cols-[2rem_1fr] gap-3'>
                            <div className='flex flex-col items-center'>
                                <div
                                    className={`flex h-8 w-8 items-center justify-center rounded-full border text-xs font-bold ${stepTreeTone(
                                        step.status,
                                        isCurrent
                                    )}`}
                                >
                                    {isDone ? '✓' : index + 1}
                                </div>
                                {index < steps.length - 1 ? (
                                    <div
                                        className={`h-full min-h-8 w-px ${
                                            isDone
                                                ? 'bg-emerald-300/35'
                                                : 'bg-white/10'
                                        }`}
                                    />
                                ) : null}
                            </div>
                            <div
                                className={`mb-3 rounded-2xl border p-3 ${stepTreeTone(
                                    step.status,
                                    isCurrent
                                )}`}
                            >
                                <div className='flex flex-wrap items-center justify-between gap-2'>
                                    <p className='text-sm font-semibold text-white'>
                                        {step.title}
                                    </p>
                                    <span className='rounded-full border border-white/10 bg-black/20 px-2 py-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-current'>
                                        {label}
                                    </span>
                                </div>
                                <p className='mt-2 text-xs leading-5 text-white/62'>
                                    {step.description}
                                </p>
                                {step.note ? (
                                    <p className='mt-2 rounded-xl border border-white/10 bg-black/20 px-3 py-2 text-xs text-white/72'>
                                        {step.note}
                                    </p>
                                ) : null}
                            </div>
                        </div>
                    )
                })}
            </div>
        </aside>
    )

    const run = async (handler: () => Promise<void>) => {
        setSubmitting(true)
        setError(null)
        setMessage(null)
        try {
            await handler()
            await load()
        } catch (err) {
            showInlineError(httpErrorToHuman(err))
        } finally {
            setSubmitting(false)
        }
    }

    const submitBranding = (event: FormEvent) => {
        event.preventDefault()

        void run(async () => {
            const updated = await saveResellerOnboardingBranding({
                display_name: branding.displayName,
                support_url: branding.supportUrl || null,
                tos_url: branding.tosUrl || null,
                privacy_url: branding.privacyUrl || null,
                primary_color: branding.primaryColor || null,
                secondary_color: branding.secondaryColor || null,
                accent_color: branding.accentColor || null,
                custom_css: branding.customCss || null,
            })
            setSnapshot(updated)
            clearOnboardingDraftSection(snapshot?.owner.email, 'branding')
            setMessage('Branding step saved.')
        })
    }

    const submitDomains = (event: FormEvent) => {
        event.preventDefault()

        void run(async () => {
            const updated = await saveResellerOnboardingDomains({
                hostname,
            })
            setSnapshot(updated)
            clearOnboardingDraftSection(snapshot?.owner.email, 'hostname')
            setMessage('Custom hostname saved.')
        })
    }

    const personalDetailsValidation = useMemo(() => {
        const checks = [
            {
                label: 'First name',
                done: personalDetails.firstName.trim().length >= 2,
            },
            {
                label: 'Last name',
                done: personalDetails.lastName.trim().length >= 2,
            },
            {
                label: 'Contact email',
                done: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
                    personalDetails.contactEmail.trim()
                ),
            },
            {
                label: 'Phone number',
                done: personalDetails.phoneNumber.trim().length >= 8,
            },
            {
                label: 'Address',
                done: personalDetails.addressLine1.trim().length >= 5,
            },
            {
                label: 'City',
                done: personalDetails.city.trim().length >= 2,
            },
            {
                label: 'State',
                done: personalDetails.stateName.trim().length >= 2,
            },
            {
                label: 'Postal code',
                done: personalDetails.postalCode.trim().length >= 3,
            },
            {
                label: 'Country',
                done: personalDetails.countryName.trim().length >= 2,
            },
        ]

        return {
            checks,
            ready: checks.every(check => check.done),
            remaining: checks.filter(check => !check.done).length,
        }
    }, [personalDetails])
    const normalizedAadhaarNumber = aadhaarNumber.replace(/\D/g, '').slice(0, 12)
    const normalizedPanNumber = panNumber.replace(/[^a-zA-Z0-9]/g, '').toUpperCase().slice(0, 10)
    const trimmedBusinessName = businessName.trim()
    const normalizedBusinessRegistrationNumber = businessRegistrationNumber.trim().toUpperCase()
    const allowedKycProofTypes: KycIdentityProofType[] =
        snapshot?.kycPolicy.allowedProofTypes.length
            ? snapshot.kycPolicy.allowedProofTypes
            : ['aadhaar', 'pan']
    const selectedKycProofAllowed = allowedKycProofTypes.includes(identityProofType)
    const usingAadhaarProof = identityProofType === 'aadhaar'
    const usingPanProof = identityProofType === 'pan'

    const kycValidation = useMemo(() => {
        const errors = {
            identityProofType: '',
            aadhaarNumber: '',
            panNumber: '',
            businessName: '',
            businessRegistrationNumber: '',
            aadhaarFront: '',
            aadhaarBack: '',
            panDocument: '',
        }

        if (!personalDetailsLocked) {
            errors.identityProofType = 'Complete personal details before KYC can be submitted.'
        }

        if (!selectedKycProofAllowed) {
            errors.identityProofType = 'Choose an enabled KYC document type.'
        }

        if (usingAadhaarProof && !normalizedAadhaarNumber) {
            errors.aadhaarNumber = 'Aadhaar number is required.'
        } else if (usingAadhaarProof && normalizedAadhaarNumber.length !== 12) {
            errors.aadhaarNumber = 'Enter a valid 12-digit Aadhaar number.'
        }

        if (usingPanProof && !normalizedPanNumber) {
            errors.panNumber = 'PAN number is required.'
        } else if (usingPanProof && !/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(normalizedPanNumber)) {
            errors.panNumber = 'Use PAN format like ABCDE1234F.'
        }

        if (trimmedBusinessName && trimmedBusinessName.length < 2) {
            errors.businessName = 'Business name looks too short.'
        }

        if (
            normalizedBusinessRegistrationNumber &&
            normalizedBusinessRegistrationNumber.length < 4
        ) {
            errors.businessRegistrationNumber =
                'Business registration number looks too short.'
        }

        if (usingAadhaarProof && !aadhaarFront) {
            errors.aadhaarFront = 'Upload the Aadhaar front file.'
        }

        if (usingAadhaarProof && !aadhaarBack) {
            errors.aadhaarBack = 'Upload the Aadhaar back file.'
        }

        if (usingPanProof && !panDocument) {
            errors.panDocument = 'Upload the PAN document.'
        }

        const checks = [
            {
                label: 'Personal details complete',
                done: personalDetailsLocked,
            },
            {
                label: usingAadhaarProof ? 'Aadhaar selected' : 'PAN selected',
                done: !errors.identityProofType,
            },
            ...(usingAadhaarProof
                ? [
                    {
                        label: 'Aadhaar is valid',
                        done: !errors.aadhaarNumber,
                    },
                    {
                        label: 'Aadhaar front uploaded',
                        done: !errors.aadhaarFront,
                    },
                    {
                        label: 'Aadhaar back uploaded',
                        done: !errors.aadhaarBack,
                    },
                ]
                : [
                    {
                        label: 'PAN is valid',
                        done: !errors.panNumber,
                    },
                    {
                        label: 'PAN document uploaded',
                        done: !errors.panDocument,
                    },
                ]),
        ]

        return {
            errors,
            checks,
            remaining: checks.filter(check => !check.done).length,
            ready:
                !kycLocked &&
                checks.every(check => check.done) &&
                !errors.businessName &&
                !errors.businessRegistrationNumber,
        }
    }, [
        personalDetailsLocked,
        selectedKycProofAllowed,
        usingAadhaarProof,
        usingPanProof,
        normalizedAadhaarNumber,
        normalizedPanNumber,
        trimmedBusinessName,
        normalizedBusinessRegistrationNumber,
        aadhaarFront,
        aadhaarBack,
        panDocument,
        kycLocked,
    ])

    if (loading) {
        return <Spinner />
    }

    if (!snapshot) {
        return (
            <PageContentBlock title='Reseller Onboarding'>
                <section className='mx-auto max-w-2xl rounded-3xl border border-rose-400/25 bg-rose-500/10 p-6 text-rose-50 shadow-[0_0_34px_rgba(244,63,94,0.10)]'>
                    <p className='text-xs font-semibold uppercase tracking-[0.22em] text-rose-100/70'>
                        Onboarding unavailable
                    </p>
                    <h1 className='mt-3 text-2xl font-semibold text-white'>
                        We could not load your reseller onboarding step.
                    </h1>
                    <p className='mt-3 text-sm text-rose-50/80'>
                        {error || 'Please retry. If it still fails, root admin needs to check the reseller onboarding record.'}
                    </p>
                    <Button className='mt-5' onClick={() => void load()}>
                        Retry
                    </Button>
                </section>
            </PageContentBlock>
        )
    }

    if (snapshot.completed) {
        return <Navigate to='/admin/reseller-panel' replace />
    }

    const primaryDomainItem =
        snapshot.domains.items.find(item => item.isPrimary) ||
        snapshot.domains.items[0] ||
        null

    const renderStep = () => {
        switch (activeStep?.key) {
            case 'registration':
                return (
                    <div className='space-y-4'>
                        <div className='grid gap-3 md:grid-cols-2'>
                            <div className='rounded-xl border border-white/10 bg-[#0f172a] p-4'>
                                <p className='text-xs uppercase tracking-[0.2em] text-white/45'>Owner Email</p>
                                <p className='mt-2 text-sm text-white'>{snapshot.owner.email || '-'}</p>
                            </div>
                            <div className='rounded-xl border border-white/10 bg-[#0f172a] p-4'>
                                <p className='text-xs uppercase tracking-[0.2em] text-white/45'>Current Status</p>
                                <p className='mt-2 text-sm text-white'>{snapshot.status}</p>
                            </div>
                        </div>
                    </div>
                )
            case 'email_verification':
                return (
                    <div className='space-y-4'>
                        <div className='rounded-xl border border-white/10 bg-[#0f172a] p-4'>
                            <p className='text-sm text-white'>Email: {snapshot.owner.email || '-'}</p>
                            <p className='mt-2 text-sm text-white/70'>
                                Status: {snapshot.owner.emailVerified ? 'Verified' : 'Pending'}
                            </p>
                        </div>
                        {!snapshot.owner.emailVerified ? (
                            <Button
                                onClick={() =>
                                    void run(async () => {
                                        setMessage(await resendResellerOnboardingVerification())
                                    })
                                }
                                disabled={submitting}
                            >
                                Resend verification email
                            </Button>
                        ) : null}
                    </div>
                )
            case 'personal_details':
                return (
                    <form
                        onSubmit={event => {
                            event.preventDefault()
                            if (personalDetailsLocked) {
                                return
                            }
                            if (!personalDetailsValidation.ready) {
                                const firstMissing = personalDetailsValidation.checks.find(
                                    check => !check.done
                                )
                                showInlineError(
                                    firstMissing
                                        ? `${firstMissing.label} needs attention before continuing.`
                                        : 'Complete the required personal details before continuing.'
                                )
                                return
                            }

                            void run(async () => {
                                const result =
                                    await submitResellerOnboardingPersonalDetails(
                                        personalDetails
                                    )
                                clearOnboardingDraftSection(
                                    snapshot.owner.email,
                                    'personalDetails'
                                )
                                setMessage(result.message)
                            })
                        }}
                        className='space-y-5'
                    >
                        {personalDetailsLocked ? (
                            <div className='rounded-2xl border border-emerald-400/30 bg-[radial-gradient(circle_at_top,rgba(74,222,128,0.18),transparent_55%),rgba(16,32,24,0.92)] p-5 shadow-[0_0_36px_rgba(74,222,128,0.16)]'>
                                <div className='flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between'>
                                    <div className='min-w-0'>
                                        <p className='text-xs font-semibold uppercase tracking-[0.2em] text-emerald-100/75'>
                                            Personal Details
                                        </p>
                                        <h3 className='mt-2 flex items-center gap-2 text-xl font-semibold text-emerald-50'>
                                            <span className='inline-flex h-8 w-8 items-center justify-center rounded-full border border-emerald-300/40 bg-emerald-400/15 text-lg text-emerald-200 shadow-[0_0_18px_rgba(74,222,128,0.22)]'>
                                                ✓
                                            </span>
                                            Owner profile submitted
                                        </h3>
                                    </div>
                                    <div className='rounded-xl border border-emerald-300/20 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-100/90'>
                                        Submitted:{' '}
                                        {snapshot.personalDetails.lockedAt
                                            ? new Date(
                                                  snapshot.personalDetails.lockedAt
                                              ).toLocaleString()
                                            : 'Just now'}
                                    </div>
                                </div>
                            </div>
                        ) : null}
                        <div className='grid gap-3 md:grid-cols-2'>
                            <input
                                type='text'
                                value={personalDetails.firstName}
                                onChange={event => {
                                    const value = event.currentTarget?.value ?? ''
                                    setPersonalDetails(current => ({
                                        ...current,
                                        firstName: value,
                                    }))
                                }}
                                placeholder='First name'
                                disabled={personalDetailsLocked}
                                className='h-11 rounded-lg border border-white/10 bg-[#0f172a] px-3 text-sm text-white disabled:opacity-70'
                            />
                            <input
                                type='text'
                                value={personalDetails.lastName}
                                onChange={event => {
                                    const value = event.currentTarget?.value ?? ''
                                    setPersonalDetails(current => ({
                                        ...current,
                                        lastName: value,
                                    }))
                                }}
                                placeholder='Last name'
                                disabled={personalDetailsLocked}
                                className='h-11 rounded-lg border border-white/10 bg-[#0f172a] px-3 text-sm text-white disabled:opacity-70'
                            />
                            <input
                                type='email'
                                value={personalDetails.contactEmail}
                                onChange={event => {
                                    const value = event.currentTarget?.value ?? ''
                                    setPersonalDetails(current => ({
                                        ...current,
                                        contactEmail: value,
                                    }))
                                }}
                                placeholder='Contact email'
                                disabled={personalDetailsLocked}
                                className='h-11 rounded-lg border border-white/10 bg-[#0f172a] px-3 text-sm text-white disabled:opacity-70'
                            />
                            <input
                                type='text'
                                value={personalDetails.phoneNumber}
                                onChange={event => {
                                    const value = event.currentTarget?.value ?? ''
                                    setPersonalDetails(current => ({
                                        ...current,
                                        phoneNumber: value,
                                    }))
                                }}
                                placeholder='Phone number'
                                disabled={personalDetailsLocked}
                                className='h-11 rounded-lg border border-white/10 bg-[#0f172a] px-3 text-sm text-white disabled:opacity-70'
                            />
                        </div>
                        <div className='grid gap-3'>
                            <input
                                type='text'
                                value={personalDetails.addressLine1}
                                onChange={event => {
                                    const value = event.currentTarget?.value ?? ''
                                    setPersonalDetails(current => ({
                                        ...current,
                                        addressLine1: value,
                                    }))
                                }}
                                placeholder='Address line 1'
                                disabled={personalDetailsLocked}
                                className='h-11 rounded-lg border border-white/10 bg-[#0f172a] px-3 text-sm text-white disabled:opacity-70'
                            />
                            <input
                                type='text'
                                value={personalDetails.addressLine2}
                                onChange={event => {
                                    const value = event.currentTarget?.value ?? ''
                                    setPersonalDetails(current => ({
                                        ...current,
                                        addressLine2: value,
                                    }))
                                }}
                                placeholder='Address line 2 (optional)'
                                disabled={personalDetailsLocked}
                                className='h-11 rounded-lg border border-white/10 bg-[#0f172a] px-3 text-sm text-white disabled:opacity-70'
                            />
                        </div>
                        <div className='grid gap-3 md:grid-cols-2 xl:grid-cols-4'>
                            <input
                                type='text'
                                value={personalDetails.city}
                                onChange={event => {
                                    const value = event.currentTarget?.value ?? ''
                                    setPersonalDetails(current => ({
                                        ...current,
                                        city: value,
                                    }))
                                }}
                                placeholder='City'
                                disabled={personalDetailsLocked}
                                className='h-11 rounded-lg border border-white/10 bg-[#0f172a] px-3 text-sm text-white disabled:opacity-70'
                            />
                            <input
                                type='text'
                                value={personalDetails.stateName}
                                onChange={event => {
                                    const value = event.currentTarget?.value ?? ''
                                    setPersonalDetails(current => ({
                                        ...current,
                                        stateName: value,
                                    }))
                                }}
                                placeholder='State / region'
                                disabled={personalDetailsLocked}
                                className='h-11 rounded-lg border border-white/10 bg-[#0f172a] px-3 text-sm text-white disabled:opacity-70'
                            />
                            <input
                                type='text'
                                value={personalDetails.postalCode}
                                onChange={event => {
                                    const value = event.currentTarget?.value ?? ''
                                    setPersonalDetails(current => ({
                                        ...current,
                                        postalCode: value,
                                    }))
                                }}
                                placeholder='Postal code'
                                disabled={personalDetailsLocked}
                                className='h-11 rounded-lg border border-white/10 bg-[#0f172a] px-3 text-sm text-white disabled:opacity-70'
                            />
                            <input
                                type='text'
                                value={personalDetails.countryName}
                                onChange={event => {
                                    const value = event.currentTarget?.value ?? ''
                                    setPersonalDetails(current => ({
                                        ...current,
                                        countryName: value,
                                    }))
                                }}
                                placeholder='Country'
                                disabled={personalDetailsLocked}
                                className='h-11 rounded-lg border border-white/10 bg-[#0f172a] px-3 text-sm text-white disabled:opacity-70'
                            />
                        </div>
                        {!personalDetailsLocked ? (
                            <div className='space-y-3'>
                                <div
                                    className={`rounded-2xl border p-4 text-sm ${
                                        personalDetailsValidation.ready
                                            ? 'border-emerald-400/30 bg-emerald-500/10 text-emerald-100'
                                            : 'border-amber-400/25 bg-amber-500/10 text-amber-100'
                                    }`}
                                >
                                    {personalDetailsValidation.ready
                                        ? 'All required owner details are ready.'
                                        : `${personalDetailsValidation.remaining} required item${personalDetailsValidation.remaining === 1 ? '' : 's'} still need attention.`}
                                </div>
                                <Button
                                    type='submit'
                                    disabled={submitting || personalDetailsLocked}
                                    loading={submitting}
                                    className='w-full sm:w-auto'
                                >
                                    Next
                                </Button>
                            </div>
                        ) : (
                            <div className='grid gap-3 md:grid-cols-2'>
                                <div className='rounded-xl border border-indigo-400/20 bg-indigo-500/10 p-4 text-sm text-indigo-100'>
                                    Submitted: {snapshot.personalDetails.submittedAt
                                        ? new Date(
                                              snapshot.personalDetails.submittedAt
                                          ).toLocaleString()
                                        : '-'}
                                </div>
                                <div className='rounded-xl border border-indigo-400/20 bg-indigo-500/10 p-4 text-sm text-indigo-100'>
                                    This step is complete. Continue to the next checklist item.
                                </div>
                            </div>
                        )}
                    </form>
                )
            case 'kyc_verification':
                return (
                    <form onSubmit={event => {
                        event.preventDefault()
                        if (kycLocked) {
                            return
                        }
                        const firstKycError = Object.values(kycValidation.errors).find(Boolean)
                        if (firstKycError) {
                            showInlineError(firstKycError)
                            return
                        }
                        if (usingAadhaarProof && (!aadhaarFront || !aadhaarBack)) {
                            showInlineError('Upload both Aadhaar front and Aadhaar back files.')
                            return
                        }
                        if (usingPanProof && !panDocument) {
                            showInlineError('Upload the PAN document.')
                            return
                        }
                        void run(async () => {
                            const result = await submitResellerOnboardingKyc({
                                identityProofType,
                                aadhaarNumber: usingAadhaarProof ? normalizedAadhaarNumber : '',
                                panNumber: usingPanProof ? normalizedPanNumber : '',
                                businessName: trimmedBusinessName,
                                businessRegistrationNumber: normalizedBusinessRegistrationNumber,
                                aadhaarFront: usingAadhaarProof ? aadhaarFront : null,
                                aadhaarBack: usingAadhaarProof ? aadhaarBack : null,
                                panDocument: usingPanProof ? panDocument : null,
                                supportingDocuments,
                            })
                            setMessage(result.message)
                            setAadhaarNumber('')
                            setPanNumber('')
                            setBusinessName('')
                            setBusinessRegistrationNumber('')
                            setAadhaarFront(null)
                            setAadhaarBack(null)
                            setPanDocument(null)
                            setSupportingDocuments([])
                            clearOnboardingDraftSection(snapshot.owner.email, 'kyc')
                        })
                    }} className='space-y-4'>
                        {kycLocked ? (
                            <div className='rounded-2xl border border-emerald-400/30 bg-[radial-gradient(circle_at_top,rgba(74,222,128,0.18),transparent_55%),rgba(16,32,24,0.92)] p-5 shadow-[0_0_36px_rgba(74,222,128,0.16)]'>
                                <div className='flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between'>
                                    <div className='min-w-0'>
                                        <p className='text-xs font-semibold uppercase tracking-[0.2em] text-emerald-100/75'>
                                            Verification Submitted
                                        </p>
                                        <h3 className='mt-2 flex items-center gap-2 text-xl font-semibold text-emerald-50'>
                                            <span className='inline-flex h-8 w-8 items-center justify-center rounded-full border border-emerald-300/40 bg-emerald-400/15 text-lg text-emerald-200 shadow-[0_0_18px_rgba(74,222,128,0.22)]'>
                                                ✓
                                            </span>
                                            {verificationStageCopy(snapshot.identity.status)}
                                        </h3>
                                    </div>
                                    <div className='rounded-xl border border-emerald-300/20 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-100/90'>
                                        Files secured: {snapshot.identity.documents.length}
                                    </div>
                                </div>
                                {snapshot.identity.reviewNote ? (
                                    <div className='mt-4 rounded-xl border border-white/10 bg-black/20 px-4 py-3 text-sm text-emerald-50/85'>
                                        {snapshot.identity.reviewNote}
                                    </div>
                                ) : null}
                            </div>
                        ) : null}
                        {(snapshot.identity.aadhaarMasked ||
                            snapshot.identity.panMasked ||
                            snapshot.identity.businessRegistrationMasked) ? (
                            <div className='grid gap-3 md:grid-cols-3'>
                                {snapshot.identity.aadhaarMasked ? (
                                    <div className='rounded-xl border border-indigo-400/20 bg-indigo-500/10 p-4 text-sm text-indigo-100'>
                                        Stored Aadhaar: {snapshot.identity.aadhaarMasked}
                                    </div>
                                ) : null}
                                {snapshot.identity.panMasked ? (
                                    <div className='rounded-xl border border-indigo-400/20 bg-indigo-500/10 p-4 text-sm text-indigo-100'>
                                        Stored PAN: {snapshot.identity.panMasked}
                                    </div>
                                ) : null}
                                {snapshot.identity.businessRegistrationMasked ? (
                                    <div className='rounded-xl border border-indigo-400/20 bg-indigo-500/10 p-4 text-sm text-indigo-100'>
                                        Stored Business ID: {snapshot.identity.businessRegistrationMasked}
                                    </div>
                                ) : null}
                            </div>
                        ) : null}
                        {snapshot.identity.fraudFlags.length > 0 ? (
                            <div className='rounded-xl border border-amber-400/30 bg-amber-500/10 p-4 text-sm text-amber-100'>
                                Fraud checks flagged: {snapshot.identity.fraudFlags.join(', ')}
                            </div>
                        ) : null}
                        {!kycLocked ? (
                            <div
                                className={`rounded-2xl border p-4 transition-all ${
                                    kycValidation.ready
                                        ? 'border-emerald-400/35 bg-[radial-gradient(circle_at_top,rgba(74,222,128,0.18),transparent_60%),rgba(16,32,24,0.92)] shadow-[0_0_28px_rgba(74,222,128,0.14)]'
                                        : 'border-white/10 bg-[#0f172a]'
                                }`}
                            >
                                <div className='flex flex-col gap-3 md:flex-row md:items-center md:justify-between'>
                                    <div>
                                        <p className='text-xs font-semibold uppercase tracking-[0.2em] text-white/50'>
                                            KYC Readiness
                                        </p>
                                        <h3
                                            className={`mt-2 text-lg font-semibold ${
                                                kycValidation.ready
                                                    ? 'text-emerald-50'
                                                    : 'text-white'
                                            }`}
                                        >
                                            {kycValidation.ready
                                                ? 'Everything required is ready to submit.'
                                                : `${kycValidation.remaining} required item${kycValidation.remaining === 1 ? '' : 's'} still need attention.`}
                                        </h3>
                                    </div>
                                    <div className='rounded-xl border border-white/10 bg-black/20 px-4 py-3 text-sm text-white/75'>
                                        {kycValidation.checks.filter(check => check.done).length}/
                                        {kycValidation.checks.length} complete
                                    </div>
                                </div>
                                <div className='mt-4 grid gap-2 md:grid-cols-2 xl:grid-cols-5'>
                                    {kycValidation.checks.map(check => (
                                        <div
                                            key={check.label}
                                            className={`rounded-xl border px-3 py-2 text-xs font-medium ${
                                                check.done
                                                    ? 'border-emerald-400/30 bg-emerald-500/10 text-emerald-100'
                                                    : 'border-amber-400/25 bg-amber-500/10 text-amber-100'
                                            }`}
                                        >
                                            {check.done ? 'Ready' : 'Waiting'} - {check.label}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ) : null}
                        {!kycLocked ? (
                            <div className='grid gap-3 md:grid-cols-2'>
                                {([
                                    {
                                        type: 'aadhaar' as const,
                                        title: 'Aadhaar Card',
                                        description: 'Choose Aadhaar, then upload front and back. DigiLocker verification is recommended when available.',
                                    },
                                    {
                                        type: 'pan' as const,
                                        title: 'PAN Card',
                                        description: 'Use PAN number with one PAN document upload.',
                                    },
                                ].filter(option => allowedKycProofTypes.includes(option.type))).map(option => {
                                    const selected = identityProofType === option.type

                                    return (
                                        <button
                                            key={option.type}
                                            type='button'
                                            onClick={() => setIdentityProofType(option.type)}
                                            className={`rounded-2xl border p-4 text-left transition-all ${
                                                selected
                                                    ? 'border-cyan-300/55 bg-cyan-400/15 text-cyan-50 shadow-[0_0_26px_rgba(34,211,238,0.14)]'
                                                    : 'border-white/10 bg-[#0f172a] text-white/72 hover:border-white/20 hover:bg-white/[0.05]'
                                            }`}
                                        >
                                            <span className='flex items-center justify-between gap-3'>
                                                <span className='text-sm font-semibold text-white'>
                                                    {option.title}
                                                </span>
                                                <span
                                                    className={`rounded-full px-2 py-1 text-[10px] font-semibold uppercase tracking-[0.16em] ${
                                                        selected
                                                            ? 'bg-cyan-300/18 text-cyan-100'
                                                            : 'bg-white/8 text-white/45'
                                                    }`}
                                                >
                                                    {selected ? 'Selected' : 'Choose'}
                                                </span>
                                            </span>
                                            <span className='mt-2 block text-xs leading-5 text-white/55'>
                                                {option.description}
                                            </span>
                                        </button>
                                    )
                                })}
                            </div>
                        ) : null}
                        {!kycLocked && usingAadhaarProof && snapshot.kycPolicy.digilockerEnabled ? (
                            <div className='rounded-2xl border border-sky-300/20 bg-[radial-gradient(circle_at_top_left,rgba(56,189,248,0.14),transparent_45%),rgba(8,23,42,0.92)] p-4 text-sm text-sky-50'>
                                <div className='flex flex-col gap-3 md:flex-row md:items-center md:justify-between'>
                                    <div>
                                        <p className='text-xs font-semibold uppercase tracking-[0.2em] text-sky-100/70'>
                                            DigiLocker Aadhaar
                                        </p>
                                        <p className='mt-2 max-w-2xl leading-6 text-sky-50/75'>
                                            DigiLocker fetch is the most secure Aadhaar path. If your provider login opens, complete it there; otherwise upload both Aadhaar sides below.
                                        </p>
                                    </div>
                                    {snapshot.kycPolicy.digilockerUrl ? (
                                        <a
                                            href={snapshot.kycPolicy.digilockerUrl}
                                            target='_blank'
                                            rel='noreferrer'
                                            className='inline-flex items-center justify-center rounded-xl border border-sky-200/25 bg-sky-400/15 px-4 py-2.5 text-sm font-semibold text-sky-50 transition hover:bg-sky-400/25'
                                        >
                                            Fetch from DigiLocker
                                        </a>
                                    ) : (
                                        <span className='rounded-xl border border-white/10 bg-black/20 px-4 py-2.5 text-xs font-semibold uppercase tracking-[0.14em] text-sky-100/65'>
                                            Provider setup required
                                        </span>
                                    )}
                                </div>
                            </div>
                        ) : null}
                        {!kycLocked ? (
                        <div className='grid gap-3 md:grid-cols-2'>
                            {usingAadhaarProof ? (
                            <div className='space-y-2'>
                                <input
                                    type='text'
                                    inputMode='numeric'
                                    maxLength={12}
                                    value={aadhaarNumber}
                                    onChange={event =>
                                        setAadhaarNumber(
                                            (event.currentTarget?.value ?? '').replace(/\D/g, '').slice(0, 12)
                                        )
                                    }
                                    placeholder='12-digit Aadhaar number'
                                    className={kycInputClassName(Boolean(kycValidation.errors.aadhaarNumber))}
                                />
                                <p
                                    className={`text-xs ${
                                        kycValidation.errors.aadhaarNumber
                                            ? 'text-rose-200'
                                            : 'text-white/45'
                                    }`}
                                >
                                    {kycValidation.errors.aadhaarNumber ||
                                        'Enter the 12 digits exactly as shown on the Aadhaar record.'}
                                </p>
                            </div>
                            ) : null}
                            {usingPanProof ? (
                            <div className='space-y-2'>
                                <input
                                    type='text'
                                    maxLength={10}
                                    value={panNumber}
                                    onChange={event =>
                                        setPanNumber(
                                            (event.currentTarget?.value ?? '')
                                                .replace(/[^a-zA-Z0-9]/g, '')
                                                .toUpperCase()
                                                .slice(0, 10)
                                        )
                                    }
                                    placeholder='PAN number'
                                    className={kycInputClassName(Boolean(kycValidation.errors.panNumber))}
                                />
                                <p
                                    className={`text-xs ${
                                        kycValidation.errors.panNumber
                                            ? 'text-rose-200'
                                            : 'text-white/45'
                                    }`}
                                >
                                    {kycValidation.errors.panNumber ||
                                        'Use PAN format like ABCDE1234F.'}
                                </p>
                            </div>
                            ) : null}
                            <div className='space-y-2'>
                                <input
                                    type='text'
                                    value={businessName}
                                    onChange={event => setBusinessName(event.currentTarget?.value ?? '')}
                                    placeholder='Business name (optional)'
                                    className={kycInputClassName(Boolean(kycValidation.errors.businessName))}
                                />
                                <p
                                    className={`text-xs ${
                                        kycValidation.errors.businessName
                                            ? 'text-rose-200'
                                            : 'text-white/45'
                                    }`}
                                >
                                    {kycValidation.errors.businessName ||
                                        'Optional'}
                                </p>
                            </div>
                            <div className='space-y-2'>
                                <input
                                    type='text'
                                    value={businessRegistrationNumber}
                                    onChange={event =>
                                        setBusinessRegistrationNumber(
                                            (event.currentTarget?.value ?? '').toUpperCase()
                                        )
                                    }
                                    placeholder='Business registration number (optional)'
                                    className={kycInputClassName(
                                        Boolean(kycValidation.errors.businessRegistrationNumber)
                                    )}
                                />
                                <p
                                    className={`text-xs ${
                                        kycValidation.errors.businessRegistrationNumber
                                            ? 'text-rose-200'
                                            : 'text-white/45'
                                    }`}
                                >
                                    {kycValidation.errors.businessRegistrationNumber ||
                                        'Optional'}
                                </p>
                            </div>
                        </div>
                        ) : null}
                        {!kycLocked ? (
                        <div className='grid gap-3 md:grid-cols-2 xl:grid-cols-3'>
                            {usingAadhaarProof ? (
                            <>
                            <label className={kycFileCardClassName(Boolean(kycValidation.errors.aadhaarFront), Boolean(aadhaarFront))}>
                                <span className='block text-sm font-medium text-white'>
                                    Aadhaar Front
                                </span>
                                <input
                                    type='file'
                                    accept='.jpg,.jpeg,.png,.webp,.pdf'
                                    onChange={event => setAadhaarFront(event.currentTarget.files?.[0] || null)}
                                    className={kycFileInputClassName}
                                />
                                <span
                                    className={`mt-3 block text-xs ${
                                        kycValidation.errors.aadhaarFront
                                            ? 'text-rose-200'
                                            : aadhaarFront
                                              ? 'text-emerald-100'
                                              : 'text-white/50'
                                    }`}
                                >
                                    {kycValidation.errors.aadhaarFront ||
                                        aadhaarFront?.name ||
                                        'PNG, JPG, WEBP, or PDF'}
                                </span>
                            </label>
                            <label className={kycFileCardClassName(Boolean(kycValidation.errors.aadhaarBack), Boolean(aadhaarBack))}>
                                <span className='block text-sm font-medium text-white'>
                                    Aadhaar Back
                                </span>
                                <input
                                    type='file'
                                    accept='.jpg,.jpeg,.png,.webp,.pdf'
                                    onChange={event => setAadhaarBack(event.currentTarget.files?.[0] || null)}
                                    className={kycFileInputClassName}
                                />
                                <span
                                    className={`mt-3 block text-xs ${
                                        kycValidation.errors.aadhaarBack
                                            ? 'text-rose-200'
                                            : aadhaarBack
                                              ? 'text-emerald-100'
                                              : 'text-white/50'
                                    }`}
                                >
                                    {kycValidation.errors.aadhaarBack ||
                                        aadhaarBack?.name ||
                                        'PNG, JPG, WEBP, or PDF'}
                                </span>
                            </label>
                            </>
                            ) : null}
                            {usingPanProof ? (
                            <label className={kycFileCardClassName(Boolean(kycValidation.errors.panDocument), Boolean(panDocument))}>
                                <span className='block text-sm font-medium text-white'>
                                    PAN Document
                                </span>
                                <input
                                    type='file'
                                    accept='.jpg,.jpeg,.png,.webp,.pdf'
                                    onChange={event => setPanDocument(event.currentTarget.files?.[0] || null)}
                                    className={kycFileInputClassName}
                                />
                                <span
                                    className={`mt-3 block text-xs ${
                                        kycValidation.errors.panDocument
                                            ? 'text-rose-200'
                                            : panDocument
                                              ? 'text-emerald-100'
                                              : 'text-white/50'
                                    }`}
                                >
                                    {kycValidation.errors.panDocument ||
                                        panDocument?.name ||
                                        'PAN image or PDF'}
                                </span>
                            </label>
                            ) : null}
                            <label className={kycFileCardClassName(false, supportingDocuments.length > 0)}>
                                <span className='block text-sm font-medium text-white'>
                                    Supporting Documents
                                </span>
                                <input
                                    type='file'
                                    accept='.jpg,.jpeg,.png,.webp,.pdf'
                                    multiple
                                    onChange={event =>
                                        setSupportingDocuments(
                                            Array.from(event.currentTarget.files || []).slice(0, 3)
                                        )
                                    }
                                    className={kycFileInputClassName}
                                />
                                <span className='mt-2 block text-xs text-white/50'>
                                    {supportingDocuments.length > 0
                                        ? `${supportingDocuments.length} file${supportingDocuments.length === 1 ? '' : 's'} selected`
                                        : 'Optional, up to 3 files.'}
                                </span>
                            </label>
                        </div>
                        ) : null}
                        {!kycLocked ? (
                        <div className='space-y-3'>
                            <Button
                                type='submit'
                                variant='filled'
                                color='success'
                                disabled={submitting || kycLocked}
                                loading={submitting}
                                className='w-full sm:w-auto'
                            >
                                Submit KYC
                            </Button>
                        </div>
                        ) : null}
                    </form>
                )
            case 'admin_review':
                return (
                    <div className='space-y-4'>
                        <div className={`rounded-xl border p-4 text-sm ${statusTone(snapshot.identity.status)}`}>
                            <p className='font-medium uppercase tracking-[0.18em]'>
                                {snapshot.identity.status}
                            </p>
                            <p className='mt-2 text-sm text-white/75'>
                                Uploaded files: {snapshot.identity.documents.length} | Malware scan: {snapshot.identity.malwareScanStatus || 'pending'}
                            </p>
                            {snapshot.identity.reviewNote ? (
                                <p className='mt-2 text-sm'>{snapshot.identity.reviewNote}</p>
                            ) : null}
                        </div>
                    </div>
                )
            case 'workspace_creation':
                return (
                    <div className='space-y-4'>
                        <div className={`rounded-xl border p-4 text-sm ${statusTone(activeStep.status)}`}>
                            Workspace status: {activeStep.status}
                        </div>
                    </div>
                )
            case 'branding_setup':
                return (
                    <form onSubmit={submitBranding} className='space-y-4'>
                        <div className='grid gap-3 md:grid-cols-2'>
                            {[
                                ['displayName', 'Display Name'],
                                ['supportUrl', 'Support URL'],
                                ['tosUrl', 'Terms URL'],
                                ['privacyUrl', 'Privacy URL'],
                                ['primaryColor', 'Primary Color'],
                                ['secondaryColor', 'Secondary Color'],
                                ['accentColor', 'Accent Color'],
                            ].map(([key, label]) => (
                                <input
                                    key={key}
                                    type='text'
                                    value={(branding as any)[key]}
                                    onChange={event => {
                                        const value = event.currentTarget?.value ?? ''
                                        setBranding(current => ({
                                            ...current,
                                            [key]: value,
                                        }))
                                    }}
                                    placeholder={label}
                                    className='h-11 rounded-lg border border-white/10 bg-[#0f172a] px-3 text-sm text-white'
                                />
                            ))}
                        </div>
                        <textarea
                            value={branding.customCss}
                            onChange={event => {
                                const value = event.currentTarget?.value ?? ''
                                setBranding(current => ({
                                    ...current,
                                    customCss: value,
                                }))
                            }}
                            placeholder='Custom CSS (optional)'
                            className='h-40 w-full rounded-lg border border-white/10 bg-[#0f172a] px-3 py-3 text-sm text-white'
                        />
                        <Button type='submit' disabled={submitting}>
                            Save branding
                        </Button>
                    </form>
                )
            case 'domain_setup':
                return (
                    <form onSubmit={submitDomains} className='space-y-4'>
                        <div className='rounded-xl border border-amber-400/20 bg-amber-500/10 p-4 text-sm text-amber-100'>
                            If you change this hostname later, DNS ownership, CNAME verification, and SSL activation will all return to pending until the new records pass verification again.
                        </div>
                        <input
                            type='text'
                            value={hostname}
                            onChange={event => setHostname(event.currentTarget?.value ?? '')}
                            placeholder='vps.clienthost.com or *.clienthost.com'
                            className='h-11 w-full rounded-lg border border-white/10 bg-[#0f172a] px-3 text-sm text-white'
                        />
                        {primaryDomainItem ? (
                            <div className='rounded-xl border border-white/10 bg-[#0f172a] p-4 text-sm text-white/75'>
                                <p>
                                    CNAME: <span className='text-white'>{primaryDomainItem.hostname}</span> {'->'}{' '}
                                    <span className='text-white'>{primaryDomainItem.cnameTarget}</span>
                                </p>
                                <p className='mt-2'>
                                    TXT: <span className='text-white'>{primaryDomainItem.verificationHost}</span>
                                </p>
                                <p className='mt-1 break-all text-white/85'>
                                    {primaryDomainItem.verificationValue || 'Token will be generated when saved.'}
                                </p>
                            </div>
                        ) : null}
                        <Button type='submit' disabled={submitting}>
                            Save hostname
                        </Button>
                    </form>
                )
            case 'dns_verification':
                return (
                    <div className='space-y-4'>
                        <div className='rounded-xl border border-white/10 bg-[#0f172a] p-4 text-sm text-white/75'>
                            <p>Hostname: {primaryDomainItem?.hostname || '-'}</p>
                            <p className='mt-1'>
                                CNAME target: {snapshot.domains.edgeGatewayHost}
                            </p>
                            <p className='mt-1'>
                                TXT host: {primaryDomainItem?.verificationHost || '-'}
                            </p>
                            <p className='mt-1 break-all'>
                                TXT value: {primaryDomainItem?.verificationValue || '-'}
                            </p>
                            {primaryDomainItem?.isWildcard ? (
                                <p className='mt-2 text-xs text-white/55'>
                                    Wildcard probe host: {primaryDomainItem.probeHostname}
                                </p>
                            ) : null}
                            <p className='mt-2 text-xs text-white/55'>
                                Cloudflare proxy is supported as long as the ownership TXT record still matches.
                            </p>
                            {primaryDomainItem?.lastError ? (
                                <p className='mt-2 text-sm text-rose-200'>
                                    {primaryDomainItem.lastError}
                                </p>
                            ) : null}
                        </div>
                        <Button
                            variant='filled'
                            color='success'
                            className='shadow-[0_0_28px_rgba(74,222,128,0.22)]'
                            onClick={() =>
                                void run(async () => {
                                    const result = await verifyResellerOnboardingDns()
                                    setSnapshot(result.snapshot)
                                    setMessage(
                                        result.verification?.passed
                                            ? 'Custom hostname verified successfully.'
                                            : 'Verification completed.'
                                    )
                                })
                            }
                            disabled={submitting}
                        >
                            Verify hostname now
                        </Button>
                    </div>
                )
            case 'ssl_provisioning':
                return (
                    <div className='space-y-4'>
                        <p className='text-sm text-white/75'>
                            Edge SSL is provisioned after successful verification. You can trigger it again if the hostname was just changed.
                        </p>
                        <div className='rounded-xl border border-white/10 bg-[#0f172a] p-4 text-sm text-white/75'>
                            <p>
                                SSL status: {primaryDomainItem?.sslStatus || snapshot.domains.sslStatus}
                            </p>
                            <p className='mt-1'>
                                Routing status: {primaryDomainItem?.routingStatus || snapshot.domains.routingStatus}
                            </p>
                        </div>
                        <Button
                            onClick={() =>
                                void run(async () => {
                                    const updated = await requestResellerOnboardingSsl()
                                    setSnapshot(updated)
                                    setMessage('SSL and routing were activated for the custom hostname.')
                                })
                            }
                            disabled={submitting}
                        >
                            Activate SSL routing
                        </Button>
                    </div>
                )
            default:
                return (
                    <div className='space-y-4'>
                        <div className={`rounded-xl border p-4 text-sm ${statusTone(activeStep?.status ?? 'pending')}`}>
                            Finishing the reseller workspace setup.
                        </div>
                    </div>
                )
        }
    }

    return (
        <PageContentBlock title='Reseller Onboarding'>
            <div className='grid min-w-0 gap-5 xl:grid-cols-[24rem_1fr]'>
                {renderStepTree()}

                <section className='min-w-0 rounded-3xl border border-white/10 bg-[linear-gradient(145deg,rgba(8,17,31,0.98),rgba(7,10,24,0.96))] p-5 shadow-[0_18px_48px_rgba(0,0,0,0.22)] md:p-6'>
                    <div className='mb-6 flex flex-wrap items-start justify-between gap-3'>
                        <div className='min-w-0'>
                            <p className='text-xs font-semibold uppercase tracking-[0.22em] text-white/45'>Current step</p>
                            <h1 className='mt-2 text-3xl font-semibold text-white'>
                                {activeStep?.title || 'Reseller onboarding'}
                            </h1>
                            {activeStep?.description ? (
                                <p className='mt-2 max-w-3xl text-sm leading-6 text-white/65'>
                                    {activeStep.description}
                                </p>
                            ) : null}
                            {snapshot.blockedReason ? (
                                <p className='mt-3 max-w-3xl text-sm leading-6 text-white/60'>{snapshot.blockedReason}</p>
                            ) : null}
                        </div>
                        {activeStep ? (
                            <span className={`rounded-full px-3 py-1 text-[11px] uppercase tracking-[0.16em] ${statusTone(activeStep.status)}`}>
                                {stepStatusLabel(activeStep.status, true)}
                            </span>
                        ) : null}
                    </div>

                    <div id='reseller-onboarding-status' className='scroll-mt-24' aria-live='polite'>
                    {message ? (
                        <div className='mb-4 rounded-xl border border-emerald-400/30 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-100'>
                            {message}
                        </div>
                    ) : null}
                    {error ? (
                        <div className='mb-4 rounded-xl border border-rose-400/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-100'>
                            {error}
                        </div>
                    ) : null}
                    </div>

                    {renderStep()}

                    {nextStepPath && activeStep?.status === 'completed' ? (
                        <div className='mt-8 flex justify-end'>
                            <Button
                                variant='filled'
                                color='accent'
                                className='shadow-[0_0_26px_rgba(255,255,255,0.14)]'
                                onClick={() => navigate(nextStepPath)}
                            >
                                Next
                            </Button>
                        </div>
                    ) : null}
                </section>
            </div>
        </PageContentBlock>
    )
}

export default ResellerOnboardingContainer

