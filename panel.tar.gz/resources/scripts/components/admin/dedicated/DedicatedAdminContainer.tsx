﻿import { httpErrorToHuman } from '@/api/http'
import PageContentBlock from '@/components/elements/PageContentBlock'
import Spinner from '@/components/elements/Spinner'
import { NavigationBarContext } from '@/components/elements/navigation/NavigationBar'
import http from '@/api/http'
import { useContext, useEffect, useMemo, useState } from 'react'

type Paginated<T> = {
    data: T[]
    current_page?: number
    last_page?: number
    total?: number
}

type DedicatedService = {
    id: number
    uuid: string
    name: string
    status: string
    provisioning_status?: string
    payment_status?: string
    dedicated_ip?: string | null
    location_name?: string | null
    user?: { name?: string; email?: string } | null
    plan?: { name?: string; slug?: string } | null
    inventory?: { server_name?: string; status?: string } | null
}

type ProvisioningRequest = {
    id: number
    status: string
    selected_os?: string
    requested_at?: string | null
    user?: { name?: string; email?: string } | null
    plan?: { name?: string } | null
    dedicated_service?: DedicatedService | null
}

type IpRequest = {
    id: number
    status: string
    quantity: number
    requested_at?: string | null
    user?: { name?: string; email?: string } | null
    address_pool?: { name?: string } | null
    dedicated_service?: DedicatedService | null
}

type Inventory = {
    id: number
    server_name: string
    status: string
    proxmox_ip?: string | null
    location_name?: string | null
    location?: { short_code?: string; description?: string } | null
    address_pool?: { name?: string } | null
}

type Plan = {
    id: number
    name: string
    slug: string
    price_monthly?: string | number
    currency?: string
    cpu_cores?: number
    ram_gb?: number
    storage_gb?: number
    is_active?: boolean
}

type DataState = {
    services: Paginated<DedicatedService> | null
    provisioning: Paginated<ProvisioningRequest> | null
    ipRequests: Paginated<IpRequest> | null
    inventory: Inventory[]
    plans: Plan[]
}

const tabs = [
    { key: 'services', label: 'Purchased Dedicated' },
    { key: 'requests', label: 'Dedicated Requests' },
    { key: 'ips', label: 'Purchased IPs' },
    { key: 'inventory', label: 'Dedicated Inventory' },
    { key: 'plans', label: 'Dedicated Plans' },
] as const

type TabKey = (typeof tabs)[number]['key']

const statusClass = (status?: string) => {
    const value = (status || '').toLowerCase()
    if (['active', 'completed', 'available', 'paid'].includes(value)) {
        return 'border-emerald-300/30 bg-emerald-400/10 text-emerald-100'
    }
    if (['failed', 'suspended', 'offline', 'retired'].includes(value)) {
        return 'border-red-300/30 bg-red-500/10 text-red-100'
    }
    return 'border-amber-300/30 bg-amber-400/10 text-amber-100'
}

const Badge = ({ children }: { children: string }) => (
    <span className={`inline-flex rounded-full border px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide ${statusClass(children)}`}>
        {children || '-'}
    </span>
)

const Empty = ({ label }: { label: string }) => (
    <div className='rounded-2xl border border-white/10 bg-white/[0.03] p-6 text-sm text-white/60'>
        No {label} found.
    </div>
)

const DedicatedAdminContainer = () => {
    const { setBreadcrumb } = useContext(NavigationBarContext)
    const [activeTab, setActiveTab] = useState<TabKey>('services')
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState<string | null>(null)
    const [data, setData] = useState<DataState>({
        services: null,
        provisioning: null,
        ipRequests: null,
        inventory: [],
        plans: [],
    })

    const load = async () => {
        setLoading(true)
        setError(null)
        try {
            const [services, provisioning, ipRequests, inventory, plans] = await Promise.all([
                http.get('/api/admin/dedicated/services', { params: { per_page: 50 } }),
                http.get('/api/admin/dedicated/provisioning-requests', { params: { per_page: 50 } }),
                http.get('/api/admin/dedicated/ip-requests', { params: { per_page: 50 } }),
                http.get('/api/admin/dedicated/inventory'),
                http.get('/api/admin/dedicated/plans'),
            ])

            setData({
                services: services.data.data,
                provisioning: provisioning.data.data,
                ipRequests: ipRequests.data.data,
                inventory: inventory.data.data || [],
                plans: plans.data.data || [],
            })
        } catch (requestError) {
            setError(httpErrorToHuman(requestError))
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        setBreadcrumb('Dedicated Services')
        void load()
        return () => setBreadcrumb(null)
    }, [setBreadcrumb])

    const summary = useMemo(
        () => [
            { label: 'Dedicated Services', value: data.services?.total ?? data.services?.data?.length ?? 0 },
            { label: 'Open Requests', value: data.provisioning?.data?.filter(item => item.status !== 'completed').length ?? 0 },
            { label: 'Purchased IP Requests', value: data.ipRequests?.total ?? data.ipRequests?.data?.length ?? 0 },
            { label: 'Inventory Servers', value: data.inventory.length },
        ],
        [data]
    )

    const renderServices = () => {
        const rows = data.services?.data || []
        if (!rows.length) return <Empty label='dedicated services' />
        return (
            <div className='overflow-x-auto rounded-2xl border border-white/10'>
                <table className='min-w-full divide-y divide-white/10 text-sm'>
                    <thead className='bg-white/[0.04] text-left text-xs uppercase tracking-wide text-white/50'>
                        <tr>
                            <th className='px-4 py-3'>Service</th>
                            <th className='px-4 py-3'>User</th>
                            <th className='px-4 py-3'>Plan</th>
                            <th className='px-4 py-3'>IP</th>
                            <th className='px-4 py-3'>Status</th>
                        </tr>
                    </thead>
                    <tbody className='divide-y divide-white/10 text-white/80'>
                        {rows.map(row => (
                            <tr key={row.id}>
                                <td className='px-4 py-3 font-semibold text-white'>#{row.id} {row.name}</td>
                                <td className='px-4 py-3'>{row.user?.email || '-'}</td>
                                <td className='px-4 py-3'>{row.plan?.name || '-'}</td>
                                <td className='px-4 py-3'>{row.dedicated_ip || '-'}</td>
                                <td className='px-4 py-3'><Badge>{row.status}</Badge></td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        )
    }

    const renderRequests = () => {
        const rows = data.provisioning?.data || []
        if (!rows.length) return <Empty label='dedicated requests' />
        return (
            <div className='grid gap-3'>
                {rows.map(row => (
                    <div key={row.id} className='rounded-2xl border border-white/10 bg-[#0f1730]/90 p-4 text-white'>
                        <div className='flex flex-col gap-3 md:flex-row md:items-center md:justify-between'>
                            <div>
                                <p className='text-sm font-semibold'>Request #{row.id} · {row.plan?.name || 'Dedicated Server'}</p>
                                <p className='mt-1 text-xs text-white/55'>{row.user?.email || '-'} · OS: {row.selected_os || 'Proxmox VE'}</p>
                            </div>
                            <Badge>{row.status}</Badge>
                        </div>
                    </div>
                ))}
            </div>
        )
    }

    const renderIpRequests = () => {
        const rows = data.ipRequests?.data || []
        if (!rows.length) return <Empty label='purchased IP requests' />
        return (
            <div className='grid gap-3'>
                {rows.map(row => (
                    <div key={row.id} className='rounded-2xl border border-white/10 bg-[#0f1730]/90 p-4 text-white'>
                        <div className='flex flex-col gap-3 md:flex-row md:items-center md:justify-between'>
                            <div>
                                <p className='text-sm font-semibold'>IP Request #{row.id} · {row.quantity} IPs</p>
                                <p className='mt-1 text-xs text-white/55'>{row.user?.email || '-'} · Pool: {row.address_pool?.name || '-'}</p>
                            </div>
                            <Badge>{row.status}</Badge>
                        </div>
                    </div>
                ))}
            </div>
        )
    }

    const renderInventory = () => {
        if (!data.inventory.length) return <Empty label='dedicated inventory servers' />
        return (
            <div className='grid gap-3 md:grid-cols-2 xl:grid-cols-3'>
                {data.inventory.map(item => (
                    <div key={item.id} className='rounded-2xl border border-white/10 bg-[#0f1730]/90 p-4 text-white'>
                        <div className='flex items-start justify-between gap-3'>
                            <div>
                                <p className='font-semibold'>#{item.id} {item.server_name}</p>
                                <p className='mt-1 text-xs text-white/55'>{item.proxmox_ip || '-'} · {item.location?.short_code || item.location_name || '-'}</p>
                                <p className='mt-1 text-xs text-white/55'>Pool: {item.address_pool?.name || '-'}</p>
                            </div>
                            <Badge>{item.status}</Badge>
                        </div>
                    </div>
                ))}
            </div>
        )
    }

    const renderPlans = () => {
        if (!data.plans.length) return <Empty label='dedicated plans' />
        return (
            <div className='grid gap-3 md:grid-cols-2 xl:grid-cols-3'>
                {data.plans.map(plan => (
                    <div key={plan.id} className='rounded-2xl border border-white/10 bg-[#0f1730]/90 p-4 text-white'>
                        <div className='flex items-start justify-between gap-3'>
                            <div>
                                <p className='font-semibold'>#{plan.id} {plan.name}</p>
                                <p className='mt-1 text-xs text-white/55'>{plan.cpu_cores || 0} CPU · {plan.ram_gb || 0} GB RAM · {plan.storage_gb || 0} GB Disk</p>
                                <p className='mt-2 text-sm font-bold'>{plan.currency || 'INR'} {plan.price_monthly ?? '-'}</p>
                            </div>
                            <Badge>{plan.is_active ? 'active' : 'hidden'}</Badge>
                        </div>
                    </div>
                ))}
            </div>
        )
    }

    return (
        <PageContentBlock title='Dedicated Services'>
            <div className='space-y-5'>
                <section className='rounded-3xl border border-cyan-300/20 bg-[linear-gradient(135deg,rgba(9,18,36,0.98),rgba(25,18,66,0.94))] p-5 text-white'>
                    <div className='flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between'>
                        <div>
                            <p className='text-xs font-bold uppercase tracking-[0.28em] text-cyan-100/70'>Root Admin</p>
                            <h1 className='mt-2 text-2xl font-bold'>Dedicated services workspace</h1>
                            <p className='mt-2 max-w-3xl text-sm text-white/60'>Purchased dedicated services, dedicated provisioning requests, inventory, plans, and purchased IP allocation requests.</p>
                        </div>
                        <button type='button' onClick={load} className='rounded-xl border border-white/15 px-4 py-2 text-sm font-semibold text-white hover:bg-white/10'>Refresh</button>
                    </div>
                </section>

                {error ? <div className='rounded-2xl border border-red-300/20 bg-red-500/10 p-4 text-sm text-red-100'>{error}</div> : null}

                <section className='grid gap-3 sm:grid-cols-2 xl:grid-cols-4'>
                    {summary.map(item => (
                        <div key={item.label} className='rounded-2xl border border-white/10 bg-[#0f1730]/90 p-4 text-white'>
                            <p className='text-xs uppercase tracking-wide text-white/45'>{item.label}</p>
                            <p className='mt-2 text-2xl font-bold'>{item.value}</p>
                        </div>
                    ))}
                </section>

                <div className='flex flex-wrap gap-2'>
                    {tabs.map(tab => (
                        <button
                            key={tab.key}
                            type='button'
                            onClick={() => setActiveTab(tab.key)}
                            className={`rounded-xl border px-4 py-2 text-sm font-semibold transition ${activeTab === tab.key ? 'border-cyan-300/40 bg-cyan-300/15 text-cyan-50' : 'border-white/10 bg-white/[0.03] text-white/65 hover:bg-white/10'}`}
                        >
                            {tab.label}
                        </button>
                    ))}
                </div>

                {loading ? (
                    <div className='py-12'><Spinner /></div>
                ) : activeTab === 'services' ? renderServices()
                    : activeTab === 'requests' ? renderRequests()
                    : activeTab === 'ips' ? renderIpRequests()
                    : activeTab === 'inventory' ? renderInventory()
                    : renderPlans()}
            </div>
        </PageContentBlock>
    )
}

export default DedicatedAdminContainer
