import { useFlashKey } from '@/util/useFlash'
import { zodResolver } from '@hookform/resolvers/zod'
import { FormProvider, useForm } from 'react-hook-form'
import { useTranslation } from 'react-i18next'
import { KeyedMutator } from 'swr'
import { z } from 'zod'

import { Location, LocationResponse } from '@/api/admin/locations/getLocations'
import updateLocation from '@/api/admin/locations/updateLocation'

import FlashMessageRender from '@/components/elements/FlashMessageRenderer'
import CheckboxForm from '@/components/elements/forms/CheckboxForm'
import Modal from '@/components/elements/Modal'
import TextInputForm from '@/components/elements/forms/TextInputForm'
import TextareaForm from '@/components/elements/forms/TextareaForm'

interface Props {
    location: Location
    open: boolean
    onClose: () => void
    mutate: KeyedMutator<LocationResponse>
}

const EditLocationModal = ({ location, open, onClose, mutate }: Props) => {
    const { clearFlashes, clearAndAddHttpError } = useFlashKey(
        `admin.locations.${location.id}.edit`
    )
    const { t: tStrings } = useTranslation('strings')
    const { t } = useTranslation('admin.locations')

    const schema = z.object({
        shortCode: z.string().nonempty().max(60),
        description: z.string().max(191).nullable(),
        showToUsers: z.boolean(),
        showToResellers: z.boolean(),
    })

    const form = useForm({
        resolver: zodResolver(schema),
        defaultValues: {
            shortCode: location.shortCode,
            description: location.description,
            showToUsers: location.showToUsers,
            showToResellers: location.showToResellers,
        },
    })

    const submit = async (data: z.infer<typeof schema>) => {
        clearFlashes()

        try {
            const updatedLocation = await updateLocation(
                location.id,
                data.shortCode,
                data.description,
                data.showToUsers,
                data.showToResellers
            )

            mutate(data => {
                if (!data) return data

                return {
                    ...data,
                    items: data.items.map(l =>
                        l.id === location.id ? updatedLocation : l
                    ),
                }
            }, false)

            form.reset({
                shortCode: updatedLocation.shortCode,
                description: updatedLocation.description,
                showToUsers: updatedLocation.showToUsers,
                showToResellers: updatedLocation.showToResellers,
            })

            onClose()
        } catch (e) {
            clearAndAddHttpError(e as Error)
        }
    }

    const handleClose = () => {
        clearFlashes()
        form.reset()
        onClose()
    }

    return (
        <Modal open={open} onClose={handleClose}>
            <Modal.Header>
                <div className='flex items-center gap-3'>
                    <div className='w-10 h-10 bg-blue-500/10 rounded-lg flex items-center justify-center'>
                        <svg className='w-5 h-5 text-blue-400' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                            <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z' />
                        </svg>
                    </div>
                    <div>
                        <Modal.Title>{tStrings('edit')} Location</Modal.Title>
                        <p className='text-sm text-slate-400 mt-0.5'>{location.shortCode}</p>
                    </div>
                </div>
            </Modal.Header>

            <FormProvider {...form}>
                <form onSubmit={form.handleSubmit(submit)}>
                    <Modal.Body>
                        <FlashMessageRender
                            className='mb-5'
                            byKey={`admin.locations.${location.id}.edit`}
                        />
                        
                        <div className='space-y-4'>
                            <TextInputForm
                                name='shortCode'
                                label={t('short_code')}
                            />
                            <TextareaForm
                                name='description'
                                label={tStrings('description')}
                            />
                            <div className='rounded-lg border border-white/10 bg-white/[0.03] p-4'>
                                <p className='mb-3 text-sm font-semibold text-white'>
                                    Location visibility
                                </p>
                                <div className='space-y-3'>
                                    <CheckboxForm
                                        name='showToUsers'
                                        label='Show to main platform users'
                                    />
                                    <CheckboxForm
                                        name='showToResellers'
                                        label='Show to reseller stores'
                                    />
                                </div>
                            </div>
                        </div>

                        {(location.nodesCount > 0 || location.serversCount > 0) && (
                            <div className='mt-5 p-3 bg-slate-800 border border-slate-700 rounded-lg'>
                                <div className='flex items-start gap-2.5'>
                                    <svg className='w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                        <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z' />
                                    </svg>
                                    <div className='text-sm text-slate-300'>
                                        <p className='font-medium mb-1'>Location in use</p>
                                        <p className='text-slate-400'>
                                            This location has {location.nodesCount} {location.nodesCount === 1 ? 'node' : 'nodes'} 
                                            {location.serversCount > 0 && ` and ${location.serversCount} ${location.serversCount === 1 ? 'server' : 'servers'}`}.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        )}
                    </Modal.Body>

                    <Modal.Actions>
                        <Modal.Action type='button' onClick={handleClose}>
                            {tStrings('cancel')}
                        </Modal.Action>
                        <Modal.Action
                            type='submit'
                            loading={form.formState.isSubmitting}
                        >
                            {tStrings('save')}
                        </Modal.Action>
                    </Modal.Actions>
                </form>
            </FormProvider>
        </Modal>
    )
}

export default EditLocationModal
