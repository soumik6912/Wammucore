import { useFlashKey } from '@/util/useFlash'
import usePagination from '@/util/usePagination'
import { useDebouncedValue } from '@mantine/hooks'
import { useState } from 'react'
import { useTranslation } from 'react-i18next'

import deleteLocation from '@/api/admin/locations/deleteLocation'
import { Location, LocationResponse } from '@/api/admin/locations/getLocations'
import useLocationsSWR from '@/api/admin/locations/useLocationsSWR'

import Menu from '@/components/elements/Menu'
import PageContentBlock from '@/components/elements/PageContentBlock'
import Pagination from '@/components/elements/Pagination'
import Spinner from '@/components/elements/Spinner'
import Table, {
    Actions,
    ColumnArray,
    RowActionsProps,
} from '@/components/elements/displays/Table'

import SearchBar from '@/components/admin/SearchBar'
import CreateLocationModal from '@/components/admin/locations/CreateLocationModal'
import EditLocationModal from '@/components/admin/locations/EditLocationModal'

const LocationsContainer = () => {
    const { t } = useTranslation('admin.locations')
    const { t: tStrings } = useTranslation('strings')
    const [page, setPage] = usePagination()
    const [isCreating, setIsCreating] = useState(false)
    const { clearFlashes, clearAndAddHttpError } = useFlashKey('admin.locations')

    const [query, setQuery] = useState('')
    const [debouncedQuery] = useDebouncedValue(query, 200)
    const { data, mutate } = useLocationsSWR({ page, query: debouncedQuery })

    const columns: ColumnArray<Location> = [
        {
            header: t('short_code'),
            accessor: 'shortCode',
            cell: ({ value, row }) => (
                <div className='space-y-0.5'>
                    <span className='block font-semibold text-white'>
                        #{row.id} - {value}
                    </span>
                    <span className='block text-[11px] font-mono text-white/45'>
                        Location ID #{row.id}
                    </span>
                </div>
            ),
        },
        {
            header: tStrings('description'),
            accessor: 'description',
            overflow: true,
        },
        {
            header: 'Visible To',
            accessor: 'showToUsers',
            cell: ({ row }) => {
                const audiences = [
                    row.showToUsers ? 'Users' : null,
                    row.showToResellers ? 'Resellers' : null,
                ].filter(Boolean)

                return (
                    <div className='flex flex-wrap gap-2'>
                        {audiences.length > 0 ? (
                            audiences.map(audience => (
                                <span
                                    key={audience}
                                    className='inline-flex rounded-full border border-emerald-400/30 bg-emerald-500/10 px-2.5 py-1 text-xs font-semibold text-emerald-200'
                                >
                                    {audience}
                                </span>
                            ))
                        ) : (
                            <span className='inline-flex rounded-full border border-rose-400/30 bg-rose-500/10 px-2.5 py-1 text-xs font-semibold text-rose-200'>
                                Hidden
                            </span>
                        )}
                    </div>
                )
            },
        },
        {
            header: tStrings('node', { count: 2 }),
            accessor: 'nodesCount',
            align: 'center',
        },
        {
            header: tStrings('server', { count: 2 }),
            accessor: 'serversCount',
            align: 'center',
        },
    ]

    const rowActions = ({ row: loc }: RowActionsProps<Location>) => {
        const [isEditing, setIsEditing] = useState(false)
        const [isDeleting, setIsDeleting] = useState(false)
        
        const handleDelete = () => {
            if (loc.nodesCount > 0) return
            
            setIsDeleting(true)
            clearFlashes()

            deleteLocation(loc.id)
                .then(() => {
                    mutate(
                        mutateData =>
                            ({
                                ...mutateData,
                                items: mutateData!.items.filter(
                                    l => l.id !== loc.id
                                ),
                            }) as LocationResponse,
                        false
                    )
                })
                .catch(error => {
                    clearAndAddHttpError(error)
                    setIsDeleting(false)
                })
        }

        return (
            <>
                <EditLocationModal
                    mutate={mutate}
                    location={loc}
                    open={isEditing}
                    onClose={() => setIsEditing(false)}
                />
                <Actions>
                    <Menu.Item onClick={() => setIsEditing(true)}>
                        {tStrings('edit')}
                    </Menu.Item>
                    <Menu.Divider />
                    <Menu.Item
                        color='red'
                        disabled={loc.nodesCount > 0 || isDeleting}
                        onClick={handleDelete}
                    >
                        {isDeleting ? 'Deleting...' : tStrings('delete')}
                    </Menu.Item>
                </Actions>
            </>
        )
    }

    const totalLocations = data?.pagination?.total || 0
    const totalNodes = data?.items?.reduce((sum, loc) => sum + loc.nodesCount, 0) || 0
    const totalServers = data?.items?.reduce((sum, loc) => sum + loc.serversCount, 0) || 0

    return (
        <div className='min-h-screen bg-[#05020f]'>
            <PageContentBlock title={tStrings('location', { count: 2 }) ?? ''}>
                {/* Stats Overview */}
                <div className='mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3'>
                    <div className='rounded-lg border border-white/10 bg-[#1a1441] p-4'>
                        <div className='flex items-center justify-between'>
                            <div>
                                <p className='mb-1 text-xs uppercase tracking-wide text-white/65'>Locations</p>
                                <p className='text-2xl font-semibold text-white'>{totalLocations}</p>
                            </div>
                            <div className='flex h-11 w-11 items-center justify-center rounded-lg border border-white/10 bg-white/5'>
                                <svg className='h-5 w-5 text-indigo-300' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                    <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z' />
                                    <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M15 11a3 3 0 11-6 0 3 3 0 016 0z' />
                                </svg>
                            </div>
                        </div>
                    </div>

                    <div className='rounded-lg border border-white/10 bg-[#1a1441] p-4'>
                        <div className='flex items-center justify-between'>
                            <div>
                                <p className='mb-1 text-xs uppercase tracking-wide text-white/65'>Nodes</p>
                                <p className='text-2xl font-semibold text-white'>{totalNodes}</p>
                            </div>
                            <div className='flex h-11 w-11 items-center justify-center rounded-lg border border-white/10 bg-white/5'>
                                <svg className='h-5 w-5 text-indigo-300' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                    <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01' />
                                </svg>
                            </div>
                        </div>
                    </div>

                    <div className='rounded-lg border border-white/10 bg-[#1a1441] p-4 sm:col-span-2 lg:col-span-1'>
                        <div className='flex items-center justify-between'>
                            <div>
                                <p className='mb-1 text-xs uppercase tracking-wide text-white/65'>Servers</p>
                                <p className='text-2xl font-semibold text-white'>{totalServers}</p>
                            </div>
                            <div className='flex h-11 w-11 items-center justify-center rounded-lg border border-white/10 bg-white/5'>
                                <svg className='h-5 w-5 text-indigo-300' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                    <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z' />
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>

                <div className='mb-6 rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                    <SearchBar
                        value={query}
                        onChange={e => setQuery(e.target.value)}
                        buttonText={t('create_location')}
                        onClick={() => setIsCreating(true)}
                    />
                </div>

                {!data ? (
                    <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                        <div className='flex justify-center py-16'>
                            <Spinner />
                        </div>
                    </div>
                ) : data.items.length === 0 ? (
                    <div className='rounded-lg border border-white/10 bg-[#1a1441] p-12 text-center'>
                        <div className='mx-auto max-w-sm'>
                            <div className='mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full border border-white/10 bg-white/5'>
                                <svg className='h-8 w-8 text-indigo-300' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                    <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z' />
                                    <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M15 11a3 3 0 11-6 0 3 3 0 016 0z' />
                                </svg>
                            </div>
                            <h3 className='mb-2 text-lg font-medium text-white'>
                                {query ? 'No matches found' : 'No locations yet'}
                            </h3>
                            <p className='mb-6 text-sm text-white/60'>
                                {query
                                    ? 'Try adjusting your search to find what you\'re looking for'
                                    : 'Get started by creating your first datacenter location'}
                            </p>
                            {!query && (
                                <button
                                    onClick={() => setIsCreating(true)}
                                    className='inline-flex items-center gap-2 whitespace-nowrap rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-blue-700'
                                >
                                    <svg className='h-4 w-4' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                        <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M12 4v16m8-8H4' />
                                    </svg>
                                    Create Location
                                </button>
                            )}
                        </div>
                    </div>
                ) : (
                    <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                        <Pagination data={data} onPageSelect={setPage}>
                            {({ items }) => (
                                <Table
                                    columns={columns}
                                    data={items}
                                    rowActions={rowActions}
                                />
                            )}
                        </Pagination>
                    </div>
                )}

                <CreateLocationModal
                    open={isCreating}
                    onClose={() => setIsCreating(false)}
                    mutate={mutate}
                />
            </PageContentBlock>
        </div>
    )
}

export default LocationsContainer
