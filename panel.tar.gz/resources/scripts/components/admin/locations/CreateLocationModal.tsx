import { useFlashKey } from '@/util/useFlash'
import { zodResolver } from '@hookform/resolvers/zod'
import { FormProvider, useForm } from 'react-hook-form'
import { useTranslation } from 'react-i18next'
import { KeyedMutator } from 'swr'
import { z } from 'zod'

import createLocation from '@/api/admin/locations/createLocation'
import { LocationResponse } from '@/api/admin/locations/getLocations'

import FlashMessageRender from '@/components/elements/FlashMessageRenderer'
import CheckboxForm from '@/components/elements/forms/CheckboxForm'
import Modal from '@/components/elements/Modal'
import TextInputForm from '@/components/elements/forms/TextInputForm'
import TextareaForm from '@/components/elements/forms/TextareaForm'

interface Props {
    mutate: KeyedMutator<LocationResponse>
    open: boolean
    onClose: () => void
}

const CreateLocationModal = ({ mutate, open, onClose }: Props) => {
    const { clearFlashes, clearAndAddHttpError } = useFlashKey(
        'admin.locations.create'
    )
    const { t: tStrings } = useTranslation('strings')
    const { t } = useTranslation('admin.locations')

    const schema = z.object({
        shortCode: z.string().nonempty().max(60),
        description: z.string().max(191).nullable(),
        showToUsers: z.boolean(),
        showToResellers: z.boolean(),
    })

    const form = useForm({
        resolver: zodResolver(schema),
        defaultValues: {
            shortCode: '',
            description: '',
            showToUsers: true,
            showToResellers: true,
        },
    })

    const submit = async (data: z.infer<typeof schema>) => {
        clearFlashes()

        try {
            const location = await createLocation(
                data.shortCode,
                data.description,
                data.showToUsers,
                data.showToResellers
            )

            mutate(data => {
                if (!data || data.pagination.currentPage !== 1) return data

                return {
                    ...data,
                    items: [location, ...data.items],
                }
            }, false)

            form.reset()
            onClose()
        } catch (e) {
            clearAndAddHttpError(e as Error)
        }
    }

    const handleClose = () => {
        clearFlashes()
        form.reset()
        onClose()
    }

    return (
        <Modal open={open} onClose={handleClose}>
            <Modal.Header>
                <div className='flex items-center gap-3'>
                    <div className='w-10 h-10 bg-blue-500/10 rounded-lg flex items-center justify-center'>
                        <svg className='w-5 h-5 text-blue-400' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                            <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z' />
                            <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M15 11a3 3 0 11-6 0 3 3 0 016 0z' />
                        </svg>
                    </div>
                    <div>
                        <Modal.Title>{t('create_location')}</Modal.Title>
                        <p className='text-sm text-slate-400 mt-0.5'>Add a new datacenter location</p>
                    </div>
                </div>
            </Modal.Header>

            <FormProvider {...form}>
                <form onSubmit={form.handleSubmit(submit)}>
                    <Modal.Body>
                        <FlashMessageRender
                            className='mb-5'
                            byKey={'admin.locations.create'}
                        />
                        
                        <div className='space-y-4'>
                            <div>
                                <TextInputForm
                                    name='shortCode'
                                    label={t('short_code')}
                                />
                                <p className='text-xs text-slate-500 mt-1.5'>
                                    A short identifier for this location (e.g., US-EAST, EU-WEST)
                                </p>
                            </div>

                            <div>
                                <TextareaForm
                                    name='description'
                                    label={tStrings('description')}
                                />
                                <p className='text-xs text-slate-500 mt-1.5'>
                                    Optional description to help identify this location
                                </p>
                            </div>

                            <div className='rounded-lg border border-white/10 bg-white/[0.03] p-4'>
                                <p className='mb-3 text-sm font-semibold text-white'>
                                    Location visibility
                                </p>
                                <div className='space-y-3'>
                                    <CheckboxForm
                                        name='showToUsers'
                                        label='Show to main platform users'
                                    />
                                    <CheckboxForm
                                        name='showToResellers'
                                        label='Show to reseller stores'
                                    />
                                </div>
                            </div>
                        </div>

                        <div className='mt-5 p-3 bg-blue-500/5 border border-blue-500/20 rounded-lg'>
                            <div className='flex gap-2.5'>
                                <svg className='w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                                    <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z' />
                                </svg>
                                <p className='text-sm text-slate-300'>
                                    Locations help organize your nodes by geographic region or datacenter.
                                </p>
                            </div>
                        </div>
                    </Modal.Body>

                    <Modal.Actions>
                        <Modal.Action type='button' onClick={handleClose}>
                            {tStrings('cancel')}
                        </Modal.Action>
                        <Modal.Action
                            type='submit'
                            loading={form.formState.isSubmitting}
                        >
                            {tStrings('create')}
                        </Modal.Action>
                    </Modal.Actions>
                </form>
            </FormProvider>
        </Modal>
    )
}

export default CreateLocationModal
