import { MagnifyingGlassIcon } from '@heroicons/react/20/solid'
import { ChangeEventHandler, MouseEventHandler } from 'react'
import { useTranslation } from 'react-i18next'

import Button from '@/components/elements/Button'
import TextInput from '@/components/elements/inputs/TextInput'

interface Props {
    value?: string
    onChange?: ChangeEventHandler<HTMLInputElement>
    buttonText: string
    onClick: MouseEventHandler<HTMLButtonElement>
}

const SearchBar = ({ value, onChange, buttonText, onClick }: Props) => {
    const { t: tStrings } = useTranslation('strings')
    
    return (
        <div className='flex flex-col sm:flex-row gap-3 items-stretch sm:items-center'>
            <div className='flex-1 min-w-0'>
                <TextInput
                    icon={
                        <MagnifyingGlassIcon className='text-slate-400 w-4 h-4' />
                    }
                    className='w-full'
                    value={value}
                    onChange={onChange}
                    placeholder={`${tStrings('search')}...`}
                />
            </div>
            
            <Button
                className='inline-flex items-center justify-center whitespace-normal sm:whitespace-nowrap shrink-0 w-full sm:w-auto'
                onClick={onClick}
                variant='filled'
            >
                <span>{buttonText}</span>
            </Button>
        </div>
    )
}

export default SearchBar
