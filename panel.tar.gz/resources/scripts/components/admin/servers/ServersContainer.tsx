import { useDebouncedValue } from '@mantine/hooks'
import { useState } from 'react'
import { useTranslation } from 'react-i18next'

import PageContentBlock from '@/components/elements/PageContentBlock'

import SearchBar from '@/components/admin/SearchBar'
import CreateServerModal from '@/components/admin/servers/CreateServerModal'
import ServersTable from '@/components/admin/servers/ServersTable'


const ServersContainer = () => {
    const [query, setQuery] = useState('')
    const [debouncedQuery] = useDebouncedValue(query, 200)
    const [open, setOpen] = useState(false)
    const { t } = useTranslation('admin.servers.index')
    const { t: tStrings } = useTranslation('strings')

    return (
        <div className='min-h-screen bg-[#05020f]'>
            <CreateServerModal open={open} onClose={() => setOpen(false)} />
            <PageContentBlock title={tStrings('server_other') ?? 'Servers'}>
                <div className='mb-6 rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                    <SearchBar
                        value={query}
                        onChange={e => setQuery(e.target.value)}
                        buttonText={t('create_server')}
                        onClick={() => setOpen(true)}
                    />
                </div>
                <div className='space-y-6'>
                    <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                        <div className='mb-4'>
                            <h3 className='text-lg font-semibold text-white'>
                                Platform Servers
                            </h3>
                            <p className='mt-1 text-sm text-white/60'>
                                Main platform customer VPS only.
                            </p>
                        </div>
                        <ServersTable
                            query={debouncedQuery}
                            scope='platform'
                            pageKey='platform_page'
                        />
                    </div>

                    <div className='rounded-xl border border-white/10 bg-[#1a1441] p-4'>
                        <div className='mb-4'>
                            <h3 className='text-lg font-semibold text-white'>
                                Reseller Servers
                            </h3>
                            <p className='mt-1 text-sm text-white/60'>
                                Reseller-owned customer VPS with user and node details.
                            </p>
                        </div>
                        <ServersTable
                            query={debouncedQuery}
                            scope='reseller'
                            variant='reseller'
                            pageKey='reseller_page'
                        />
                    </div>
                </div>
            </PageContentBlock>
        </div>
    )
}

export default ServersContainer
