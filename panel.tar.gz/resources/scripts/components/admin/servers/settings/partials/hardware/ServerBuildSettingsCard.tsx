import { AdminServerContext } from '@/state/admin/server'
import { bytesToGib, bytesToTb, gibToBytes, tbToBytes } from '@/util/helpers'
import { useFlashKey } from '@/util/useFlash'
import { zodResolver } from '@hookform/resolvers/zod'
import { FormProvider, useForm } from 'react-hook-form'
import { useTranslation } from 'react-i18next'
import { z } from 'zod'

import updateBuild from '@/api/admin/servers/updateBuild'

import Button from '@/components/elements/Button'
import FlashMessageRender from '@/components/elements/FlashMessageRenderer'
import FormCard from '@/components/elements/FormCard'
import TextInputForm from '@/components/elements/forms/TextInputForm'

import AddressesMultiSelectForm from '@/components/admin/servers/AddressesMultiSelectForm'


const ServerBuildSettingsCard = () => {
    const server = AdminServerContext.useStoreState(state => state.server.data!)
    const setServer = AdminServerContext.useStoreActions(
        actions => actions.server.setServer
    )
    const { clearFlashes, clearAndAddHttpError } = useFlashKey(
        `admin.servers.${server.uuid}.settings.hardware.build`
    )
    const { t: tStrings } = useTranslation('strings')
    const { t } = useTranslation('admin.servers.settings')
    const { t: tIndex } = useTranslation('admin.servers.index')

    const pluckedAddressIds = [
        ...server.limits.addresses.ipv4.map(address => address.id.toString()),
        ...server.limits.addresses.ipv6.map(address => address.id.toString()),
    ]

    const schema = z.object({
        cpu: z.preprocess(Number, z.number().min(1)),
        cpuLimit: z.preprocess(Number, z.number().min(0).max(128)),
        cpuUnits: z.preprocess(Number, z.number().min(8)),
        cpuSockets: z.preprocess(Number, z.number().min(1).max(8)),
        memory: z.preprocess(Number, z.number().min(1)),
        swap: z.preprocess(Number, z.number().min(0)),
        disk: z.preprocess(Number, z.number().min(1)),
        addressIds: z.array(z.preprocess(Number, z.number())),
        snapshotLimit: z.union([
            z.literal(''),
            z.preprocess(Number, z.number().min(0)),
        ]),
        backupLimit: z.union([
            z.literal(''),
            z.preprocess(Number, z.number().min(0)),
        ]),
        bandwidthLimit: z.union([
            z.literal(''),
            z.preprocess(Number, z.number().min(0)),
        ]),
        networkRateLimit: z.union([
            z.literal(''),
            z.preprocess(Number, z.number().min(0)),
        ]),
        bandwidthUsage: z.preprocess(Number, z.number().min(0)),
    })

    const form = useForm({
        resolver: zodResolver(schema),
        defaultValues: {
            cpu: server.limits.cpu.toString(),
            cpuLimit: server.limits.cpuLimit.toString(),
            cpuUnits: server.limits.cpuUnits.toString(),
            cpuSockets: server.limits.cpuSockets.toString(),
            memory: bytesToGib(server.limits.memory).toString(),
            swap: bytesToGib(server.limits.swap).toString(),
            disk: bytesToGib(server.limits.disk).toString(),
            addressIds: pluckedAddressIds,
            snapshotLimit: server.limits.snapshots?.toString() ?? '',
            backupLimit: server.limits.backups?.toString() ?? '',
            bandwidthLimit: server.limits.bandwidth
                ? bytesToTb(server.limits.bandwidth).toString()
                : '',
            networkRateLimit:
                server.limits.networkRateLimit !== null
                    ? server.limits.networkRateLimit.toString()
                    : '',
            bandwidthUsage: bytesToTb(server.usages.bandwidth).toString(),
        },
    })

    const submit = async (_data: any) => {
        const {
            memory,
            swap,
            disk,
            cpuUnits,
            cpuLimit,
            cpuSockets,
            snapshotLimit,
            backupLimit,
            bandwidthLimit,
            networkRateLimit,
            bandwidthUsage,
            ...data
        } = _data as z.infer<typeof schema>
        clearFlashes()

        try {
            const newServer = await updateBuild(server.uuid, {
                memory: gibToBytes(memory),
                swap: gibToBytes(swap),
                disk: gibToBytes(disk),
                snapshotLimit: snapshotLimit !== '' ? snapshotLimit : null,
                backupLimit: backupLimit !== '' ? backupLimit : null,
                bandwidthLimit:
                    bandwidthLimit !== '' ? tbToBytes(bandwidthLimit) : null,
                networkRateLimit:
                    networkRateLimit !== '' ? Number(networkRateLimit) : null,
                bandwidthUsage: tbToBytes(bandwidthUsage),
                cpuLimit,
                cpuUnits,
                cpuSockets,
                ...data,
            })

            setServer(newServer)

            form.reset({
                cpu: data.cpu.toString(),
                cpuLimit: cpuLimit.toString(),
                cpuUnits: cpuUnits.toString(),
                cpuSockets: cpuSockets.toString(),
                memory: memory.toString(),
                swap: swap.toString(),
                disk: disk.toString(),
                addressIds: data.addressIds.map(id => id.toString()),
                snapshotLimit: snapshotLimit.toString() ?? '',
                backupLimit: backupLimit.toString() ?? '',
                bandwidthLimit:
                    bandwidthLimit !== '' ? bandwidthLimit.toString() : '',
                networkRateLimit:
                    networkRateLimit !== '' ? networkRateLimit.toString() : '',
                bandwidthUsage: bandwidthUsage.toString(),
            })
        } catch (error) {
            clearAndAddHttpError(error as any)
        }
    }

    return (
        <FormCard className='w-full'>
            <FormProvider {...form}>
                <form onSubmit={form.handleSubmit(submit)}>
                    <FormCard.Body>
                        <FormCard.Title>{t('build.title')}</FormCard.Title>
                        <div className='space-y-3 mt-3'>
                            <FlashMessageRender
                                byKey={`admin.servers.${server.uuid}.settings.hardware.build`}
                            />
                            <TextInputForm name='cpu' label={tStrings('cpu')} />
                            <TextInputForm
                                name='cpuLimit'
                                label='CPU Limit'
                            />
                            <TextInputForm
                                name='cpuSockets'
                                label='CPU Sockets'
                            />
                            <TextInputForm
                                name='cpuUnits'
                                label='CPU Units'
                            />
                            <TextInputForm
                                name='memory'
                                label={`${tStrings('memory')} (GiB)`}
                            />
                            <TextInputForm
                                name='swap'
                                label='Swap (GiB)'
                            />
                            <TextInputForm
                                name='disk'
                                label={`${tStrings('disk')} (GiB)`}
                            />
                            <AddressesMultiSelectForm nodeId={server.nodeId} />
                            <TextInputForm
                                name='snapshotLimit'
                                label={tIndex('snapshot_limit')}
                                placeholder={'Leave blank for no limit'}
                            />
                            <TextInputForm
                                name='backupLimit'
                                label={tIndex('backup_limit')}
                                placeholder={'Leave blank for no limit'}
                            />
                            <TextInputForm
                                name='bandwidthLimit'
                                label={`${tIndex('bandwidth_limit')} (TB)`}
                                placeholder={
                                    tIndex('limit_placeholder') ??
                                    'Leave blank for no limit'
                                }
                            />
                            <TextInputForm
                                name='networkRateLimit'
                                label='Network Rate Limit (Mbps)'
                                placeholder={'Leave blank for unlimited'}
                            />
                            <TextInputForm
                                name='bandwidthUsage'
                                label={`${tIndex('bandwidth_usage')} (TB)`}
                            />
                        </div>
                    </FormCard.Body>
                    <FormCard.Footer>
                        <Button
                            loading={form.formState.isSubmitting}
                            disabled={!form.formState.isDirty}
                            type='submit'
                            variant='filled'
                            color='success'
                            size='sm'
                        >
                            {tStrings('save')}
                        </Button>
                    </FormCard.Footer>
                </form>
            </FormProvider>
        </FormCard>
    )
}

export default ServerBuildSettingsCard
