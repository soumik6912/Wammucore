import { AdminServerContext } from '@/state/admin/server'
import { useFlashKey } from '@/util/useFlash'
import { hostname } from '@/util/validation'
import { zodResolver } from '@hookform/resolvers/zod'
import React from 'react'
import { FormProvider, useForm } from 'react-hook-form'
import { useTranslation } from 'react-i18next'
import { z } from 'zod'

import updateServer from '@/api/admin/servers/updateServer'
import { EloquentStatus } from '@/api/server/types'

import Button from '@/components/elements/Button'
import FlashMessageRender from '@/components/elements/FlashMessageRenderer'
import FormCard from '@/components/elements/FormCard'
import SelectForm from '@/components/elements/forms/SelectForm'
import TextInputForm from '@/components/elements/forms/TextInputForm'

import NodesSelectForm from '@/components/admin/servers/NodesSelectForm'
import UsersSelectForm from '@/components/admin/servers/UsersSelectForm'

const ServerInformationCard = () => {
    const server = AdminServerContext.useStoreState(state => state.server.data!)
    const setServer = AdminServerContext.useStoreActions(
        actions => actions.server.setServer
    )
    const { clearFlashes, clearAndAddHttpError } = useFlashKey(
        `admin.servers.${server.uuid}.settings.general.info`
    )
    const { t: tStrings } = useTranslation('strings')
    const { t } = useTranslation('admin.servers.settings')

    const schema = z.object({
        name: z.string().max(60).min(1),
        hostname: hostname().max(191).min(1),
        vmid: z.preprocess(Number, z.number().min(100).max(999999999)),
        userId: z.preprocess(Number, z.number()),
        billingServiceId: z.string().max(191).optional().nullable(),
        status: z.string(),
    })

    const form = useForm({
        resolver: zodResolver(schema),
        defaultValues: {
            name: server.name,
            hostname: server.hostname,
            vmid: server.vmid,
            userId: server.userId.toString(),
            billingServiceId: server.billing.serviceId || '',
            status: server.status ?? 'ready',
        },
    })

    const submit = async (_data: any) => {
        const { status, ...data } = _data as z.infer<typeof schema>

        clearFlashes()
        try {
            const updated = await updateServer(server.uuid, {
                status: status === 'ready' ? null : (status as EloquentStatus),
                ...data,
            })

            setServer(updated)

            form.reset({
                name: updated.name,
                hostname: updated.hostname,
                vmid: updated.vmid,
                userId: updated.userId.toString(),
                billingServiceId: updated.billing.serviceId || '',
                status: updated.status ?? 'ready',
            })
        } catch (error) {
            clearAndAddHttpError(error as any)
        }
    }

    const statusTypes = [
        { value: 'ready', label: t('server_info.statuses.ready') },
        { value: 'installing', label: t('server_info.statuses.installing') },
        {
            value: 'install_failed',
            label: t('server_info.statuses.install_failed'),
        },
        { value: 'suspended', label: t('server_info.statuses.suspended') },
        {
            value: 'restoring_backup',
            label: t('server_info.statuses.restoring_backup'),
        },
        {
            value: 'restoring_snapshot',
            label: t('server_info.statuses.restoring_snapshot'),
        },
    ]

    return (
        <FormCard className='w-full'>
            <FormProvider {...form}>
                <form onSubmit={form.handleSubmit(submit)}>
                    <FormCard.Body>
                        <FormCard.Title>
                            {t('server_info.title')}
                        </FormCard.Title>
                        <p className='mt-2 text-sm text-accent-500'>
                            Manage identity, ownership, and lifecycle state for this server.
                        </p>
                        <div className='space-y-4 mt-4'>
                            <FlashMessageRender
                                byKey={`admin.servers.${server.uuid}.settings.general.info`}
                            />
                            <div className='rounded-lg border border-accent-200 bg-accent-100 p-4 space-y-3'>
                                <h4 className='text-sm font-semibold text-foreground'>Server Identity</h4>
                                <TextInputForm
                                    name='name'
                                    label={tStrings('display_name')}
                                />
                                <TextInputForm
                                    name='hostname'
                                    label={tStrings('hostname')}
                                />
                                <TextInputForm
                                    name='vmid'
                                    label='VMID'
                                    placeholder='100'
                                />
                                <TextInputForm
                                    name='billingServiceId'
                                    label='Paymenter Service ID'
                                    placeholder='5378'
                                />
                                <p className='text-xs text-accent-500'>
                                    Used to open the exact Paymenter upgrade page for this VPS, like <span className='font-mono'>/services/5378/upgrade</span>.
                                </p>
                            </div>

                            <div className='rounded-lg border border-accent-200 bg-accent-100 p-4 space-y-3'>
                                <h4 className='text-sm font-semibold text-foreground'>Ownership and Status</h4>
                                <UsersSelectForm />
                                <SelectForm
                                    name={'status'}
                                    data={statusTypes}
                                    label={tStrings('status')}
                                />
                            </div>
                        </div>
                    </FormCard.Body>
                    <FormCard.Footer>
                        <Button
                            loading={form.formState.isSubmitting}
                            disabled={!form.formState.isDirty}
                            type='submit'
                            variant='filled'
                            color='success'
                            size='sm'
                        >
                            {tStrings('save')}
                        </Button>
                    </FormCard.Footer>
                </form>
            </FormProvider>
        </FormCard>
    )
}

export default ServerInformationCard
