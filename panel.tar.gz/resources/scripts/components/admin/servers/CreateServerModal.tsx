import { useFlashKey } from '@/util/useFlash'
import usePagination from '@/util/usePagination'
import { gibToBytes, tbToBytes } from '@/util/helpers'
import { hostname, password, usKeyboardCharacters } from '@/util/validation'
import { zodResolver } from '@hookform/resolvers/zod'
import { FormProvider, useForm } from 'react-hook-form'
import { useTranslation } from 'react-i18next'
import { z } from 'zod'

import createServer from '@/api/admin/servers/createServer'
import { ServerResponse } from '@/api/admin/servers/getServers'
import useServersSWR from '@/api/admin/servers/useServersSWR'

import FlashMessageRender from '@/components/elements/FlashMessageRenderer'
import Modal from '@/components/elements/Modal'
import CheckboxForm from '@/components/elements/forms/CheckboxForm'
import TextInputForm from '@/components/elements/forms/TextInputForm'

import AddressesMultiSelectForm from '@/components/admin/servers/AddressesMultiSelectForm'
import NodesSelectForm from '@/components/admin/servers/NodesSelectForm'
import TemplatesSelectForm from '@/components/admin/servers/TemplatesSelectForm'
import UsersSelectForm from '@/components/admin/servers/UsersSelectForm'


interface Props {
    nodeId?: number
    userId?: number
    open: boolean
    onClose: () => void
}

const CreateServerModal = ({ nodeId, userId, open, onClose }: Props) => {
    const [page] = usePagination()
    const { mutate } = useServersSWR({
        nodeId,
        userId,
        page,
        query: '',
        include: ['node', 'user'],
    })
    const { clearFlashes, clearAndAddHttpError } = useFlashKey(
        'admin.servers.create'
    )
    const { t } = useTranslation('admin.servers.index')
    const { t: tStrings } = useTranslation('strings')

    const schemaWithCreateVm = z.object({
        name: z.string().max(40).nonempty(),
        nodeId: z.preprocess(Number, z.number()),
        userId: z.preprocess(Number, z.number()),
        vmid: z.union([
            z.preprocess(Number, z.number().int().min(100).max(999999999)),
            z.literal(''),
        ]),
        hostname: hostname().max(191).nonempty(),
        addressIds: z.array(z.preprocess(Number, z.number())),
        cpu: z.preprocess(Number, z.number().min(1)),
        cpuLimit: z.union([z.literal(''), z.preprocess(Number, z.number().min(0).max(128))]),
        cpuUnits: z.union([z.literal(''), z.preprocess(Number, z.number().min(8))]),
        cpuSockets: z.union([z.literal(''), z.preprocess(Number, z.number().min(1).max(8))]),
        memory: z.preprocess(Number, z.number().min(1)),
        swap: z.preprocess(Number, z.number().min(0)),
        disk: z.preprocess(Number, z.number().min(1)),
        snapshotLimit: z.union([
            z.literal(''),
            z.preprocess(Number, z.number().min(0)),
        ]),
        backupLimit: z.union([
            z.literal(''),
            z.preprocess(Number, z.number().min(0)),
        ]),
        bandwidthLimit: z.union([
            z.literal(''),
            z.preprocess(Number, z.number().min(0)),
        ]),
        networkRateLimit: z.union([
            z.literal(''),
            z.preprocess(Number, z.number().min(0)),
        ]),
        accountPassword: password(usKeyboardCharacters()).nonempty(),
        shouldCreateServer: z.literal(true),
        startOnCompletion: z.boolean(),
        templateUuid: z.string().nonempty(),
    })

    const schemaWithoutCreatingVm = z.object({
        name: z.string().max(40).nonempty(),
        nodeId: z.preprocess(Number, z.number()),
        userId: z.preprocess(Number, z.number()),
        vmid: z.union([
            z.preprocess(Number, z.number().min(100).max(999999999)),
            z.literal(''),
        ]),
        hostname: hostname().max(191).nonempty(),
        addressIds: z.array(z.preprocess(Number, z.number())),
        cpu: z.preprocess(Number, z.number().min(1)),
        cpuLimit: z.union([z.literal(''), z.preprocess(Number, z.number().min(0).max(128))]),
        cpuUnits: z.union([z.literal(''), z.preprocess(Number, z.number().min(8))]),
        cpuSockets: z.union([z.literal(''), z.preprocess(Number, z.number().min(1).max(8))]),
        memory: z.preprocess(Number, z.number().min(1)),
        swap: z.preprocess(Number, z.number().min(0)),
        disk: z.preprocess(Number, z.number().min(1)),
        snapshotLimit: z.union([
            z.literal(''),
            z.preprocess(Number, z.number().min(0)),
        ]),
        backupLimit: z.union([
            z.literal(''),
            z.preprocess(Number, z.number().min(0)),
        ]),
        bandwidthLimit: z.union([
            z.literal(''),
            z.preprocess(Number, z.number().min(0)),
        ]),
        networkRateLimit: z.union([
            z.literal(''),
            z.preprocess(Number, z.number().min(0)),
        ]),
        accountPassword: password(usKeyboardCharacters()).optional(),
        shouldCreateServer: z.literal(false),
        startOnCompletion: z.boolean(),
        templateUuid: z.string(),
    })

    const schema = z.discriminatedUnion('shouldCreateServer', [
        schemaWithCreateVm,
        schemaWithoutCreatingVm,
    ])

    const form = useForm({
        resolver: zodResolver(schema),
        defaultValues: {
            name: '',
            nodeId: nodeId?.toString() ?? '',
            userId: userId?.toString() ?? '',
            vmid: '',
            hostname: '',
            addressIds: [],
            cpu: '',
            cpuLimit: '0',
            cpuUnits: '1024',
            cpuSockets: '1',
            memory: '',
            swap: '0',
            disk: '',
            snapshotLimit: '0',
            backupLimit: '',
            bandwidthLimit: '',
            networkRateLimit: '',
            accountPassword: '',
            shouldCreateServer: true,
            startOnCompletion: false,
            templateUuid: '',
        },
    })

    const watchShouldCreateServer = form.watch('shouldCreateServer')
    const watchNodeId = form.watch('nodeId')

    const submit = async (_data: any) => {
        const {
            vmid,
            cpu,
            cpuLimit,
            cpuUnits,
            cpuSockets,
            memory,
            swap,
            disk,
            snapshotLimit,
            backupLimit,
            bandwidthLimit,
            networkRateLimit,
            addressIds,
            accountPassword,
            ...data
        } = _data as z.infer<typeof schema>
        clearFlashes()
        try {
            const server = await createServer({
                ...data,
                vmid: vmid !== '' ? vmid : null,
                limits: {
                    cpu,
                    cpuLimit: cpuLimit !== '' ? cpuLimit : null,
                    cpuUnits: cpuUnits !== '' ? cpuUnits : null,
                    cpuSockets: cpuSockets !== '' ? cpuSockets : null,
                    memory: gibToBytes(memory),
                    swap: gibToBytes(swap),
                    disk: gibToBytes(disk),
                    snapshots: snapshotLimit !== '' ? snapshotLimit : null,
                    backups: backupLimit !== '' ? backupLimit : null,
                    bandwidth:
                        bandwidthLimit !== '' ? tbToBytes(bandwidthLimit) : null,
                    networkRateLimit:
                        networkRateLimit !== '' ? Number(networkRateLimit) : null,
                    addressIds,
                },
                accountPassword: accountPassword ? accountPassword : null,
            })

            mutate(data => {
                if (!data) return data

                return {
                    ...data,
                    items: [server, ...data.items],
                } as ServerResponse
            }, false)

            handleClose()
        } catch (e) {
            clearAndAddHttpError(e as Error)
        }
    }

    const handleClose = () => {
        clearFlashes()
        form.reset()
        onClose()
    }

    return (
        <Modal open={open} onClose={handleClose} size='2xl'>
            <Modal.Header>
                <div>
                    <Modal.Title>{t('create_modal.title')}</Modal.Title>
                    <p className='mt-2 text-sm text-accent-500 text-center'>
                        Deploy a VM with resource limits, network settings, and OS template options.
                    </p>
                </div>
            </Modal.Header>

            <FormProvider {...form}>
                <form onSubmit={form.handleSubmit(submit)}>
                    <Modal.Body className='space-y-4'>
                        <FlashMessageRender
                            className='mb-5'
                            byKey={'admin.servers.create'}
                        />
                        <div className='rounded-lg border border-accent-200 bg-accent-100 p-4 space-y-3'>
                            <h4 className='text-sm font-semibold text-foreground'>General</h4>
                            <TextInputForm
                                name={'name'}
                                label={tStrings('display_name')}
                            />
                            <div className='grid gap-3 md:grid-cols-2'>
                                {nodeId ? null : <NodesSelectForm />}
                                {userId ? null : <UsersSelectForm />}
                            </div>
                            <div className='grid gap-3 md:grid-cols-2'>
                                <TextInputForm
                                    name={'vmid'}
                                    label={'VMID'}
                                    placeholder={
                                        t('vmid_placeholder') ??
                                        'Leave blank for random VMID'
                                    }
                                />
                                <TextInputForm
                                    name={'hostname'}
                                    label={tStrings('hostname')}
                                />
                            </div>
                            <AddressesMultiSelectForm
                                disabled={watchNodeId === ''}
                            />
                        </div>

                        <div className='rounded-lg border border-accent-200 bg-accent-100 p-4 space-y-3'>
                            <h4 className='text-sm font-semibold text-foreground'>Compute Resources</h4>
                            <div className='grid gap-3 md:grid-cols-3'>
                                <TextInputForm
                                    name={'cpu'}
                                    label={tStrings('cpu')}
                                />
                                <TextInputForm
                                    name={'cpuLimit'}
                                    label={'CPU Limit'}
                                />
                                <TextInputForm
                                    name={'cpuSockets'}
                                    label={'CPU Sockets'}
                                />
                                <TextInputForm
                                    name={'cpuUnits'}
                                    label={'CPU Units'}
                                />
                            </div>
                            <div className='grid gap-3 md:grid-cols-2'>
                                <TextInputForm
                                    name={'memory'}
                                    label={`${tStrings('memory')} (GiB)`}
                                />
                                <TextInputForm
                                    name={'swap'}
                                    label={'Swap (GiB)'}
                                />
                            </div>
                            <div>
                                <TextInputForm
                                    name={'disk'}
                                    label={`${tStrings('disk')} (GiB)`}
                                />
                            </div>
                        </div>

                        <div className='rounded-lg border border-accent-200 bg-accent-100 p-4 space-y-3'>
                            <h4 className='text-sm font-semibold text-foreground'>Network and Limits</h4>
                            <div className='grid gap-3 md:grid-cols-3'>
                                <TextInputForm
                                    name={'networkRateLimit'}
                                    label={'Network Rate Limit (Mbps)'}
                                    placeholder={'Leave blank for unlimited'}
                                />
                                <TextInputForm
                                    name={'backupLimit'}
                                    label={t('backup_limit')}
                                    placeholder={
                                        t('limit_placeholder') ??
                                        'Leave blank for no limit'
                                    }
                                />
                                <TextInputForm
                                    name={'bandwidthLimit'}
                                    label={`${t('bandwidth_limit')} (TB)`}
                                    placeholder={
                                        t('limit_placeholder') ??
                                        'Leave blank for no limit'
                                    }
                                />
                            </div>
                        </div>

                        <div className='rounded-lg border border-accent-200 bg-accent-100 p-4 space-y-3'>
                            <h4 className='text-sm font-semibold text-foreground'>Provisioning</h4>
                            <TextInputForm
                                name={'accountPassword'}
                                label={tStrings('system_os_password')}
                                type={'password'}
                            />
                            <CheckboxForm
                                name={'shouldCreateServer'}
                                label={t('should_create_vm')}
                                className={'relative'}
                            />
                            <TemplatesSelectForm
                                disabled={
                                    !watchShouldCreateServer || watchNodeId === ''
                                }
                            />
                            <CheckboxForm
                                name={'startOnCompletion'}
                                label={t('start_server_after_installing')}
                                className={'relative'}
                            />
                        </div>
                    </Modal.Body>
                    <Modal.Actions>
                        <Modal.Action type='button' onClick={handleClose}>
                            {tStrings('cancel')}
                        </Modal.Action>
                        <Modal.Action
                            type='submit'
                            loading={form.formState.isSubmitting}
                        >
                            Create Server
                        </Modal.Action>
                    </Modal.Actions>
                </form>
            </FormProvider>
        </Modal>
    )
}

export default CreateServerModal
