import getAdminServerActivityLogs from '@/api/admin/servers/getActivityLogs'
import { format } from 'date-fns'
import { useState } from 'react'
import useSWR from 'swr'

import Button from '@/components/elements/Button'

interface Props {
    serverUuid: string
}

const AdminServerActivityLogPanel = ({ serverUuid }: Props) => {
    const [query, setQuery] = useState('')
    const [event, setEvent] = useState('')
    const [page, setPage] = useState(1)
    const [perPage, setPerPage] = useState(25)

    const { data, error, isLoading, isValidating, mutate } = useSWR(
        ['admin:server:activity', serverUuid, query, event, page, perPage],
        () =>
            getAdminServerActivityLogs(serverUuid, {
                query,
                event,
                page,
                perPage,
            }),
        { keepPreviousData: true }
    )

    const setSearch = (value: string) => {
        setPage(1)
        setQuery(value)
    }

    const setEventFilter = (value: string) => {
        setPage(1)
        setEvent(value)
    }

    const safeFormat = (value?: string | null) => {
        if (!value) return '-'

        const date = new Date(value)
        return Number.isNaN(date.getTime()) ? '-' : format(date, 'yyyy-MM-dd HH:mm:ss')
    }

    const eventLabel = (value: string) =>
        value
            .replace(/^server:/, '')
            .replace(/^security\.engine\./, 'security ')
            .replaceAll('_', ' ')

    return (
        <div className='rounded-lg border border-slate-700 bg-slate-950/80 p-4'>
            <div className='mb-4 flex flex-col gap-3 xl:flex-row xl:items-end xl:justify-between'>
                <div>
                    <p className='text-xs font-bold uppercase tracking-[0.24em] text-cyan-200/70'>Admin VPS audit trail</p>
                    <h3 className='mt-1 text-lg font-bold text-white'>VPS Event Logs</h3>
                    <p className='mt-1 text-xs text-slate-300'>
                        Full admin-only history for power actions, suspension, reinstall, recovery, and security automation.
                    </p>
                </div>
                <div className='flex flex-col gap-2 sm:flex-row'>
                    <input
                        value={query}
                        onChange={e => setSearch(e.target.value)}
                        placeholder='Search event, IP, reason...'
                        className='h-10 min-w-[220px] rounded-lg border border-white/15 bg-slate-950 px-3 text-sm text-white placeholder:text-white/35 outline-none focus:border-cyan-300/50'
                    />
                    <select
                        value={event}
                        onChange={e => setEventFilter(e.target.value)}
                        className='h-10 rounded-lg border border-white/15 bg-slate-950 px-3 text-sm text-white outline-none focus:border-cyan-300/50'
                    >
                        <option value=''>All events</option>
                        <option value='server:power_action'>Power actions</option>
                        <option value='server:admin_suspended'>Suspended</option>
                        <option value='server:admin_unsuspended'>Unsuspended</option>
                        <option value='server:reinstall'>Reinstall</option>
                        <option value='security.engine.warning'>Security warning</option>
                        <option value='security.engine.suspended'>Security suspended</option>
                    </select>
                    <Button className='!h-10 !text-white !bg-slate-800 !border-slate-500' onClick={() => mutate()}>
                        {isValidating ? 'Refreshing...' : 'Refresh'}
                    </Button>
                </div>
            </div>

            <div className='overflow-x-auto'>
                <table className='w-full min-w-[860px] text-left text-sm'>
                    <thead>
                        <tr className='border-b border-white/10 text-white/55'>
                            <th className='py-2 pr-4 font-medium'>Event</th>
                            <th className='py-2 pr-4 font-medium'>Reason / details</th>
                            <th className='py-2 pr-4 font-medium'>Actor</th>
                            <th className='py-2 pr-4 font-medium'>IP</th>
                            <th className='py-2 pr-4 font-medium'>Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        {isLoading && (
                            <tr>
                                <td colSpan={5} className='py-8 text-center text-white/55'>
                                    Loading VPS logs...
                                </td>
                            </tr>
                        )}

                        {!isLoading && error && (
                            <tr>
                                <td colSpan={5} className='py-8 text-center text-rose-300'>
                                    Failed to load VPS logs.
                                </td>
                            </tr>
                        )}

                        {!isLoading &&
                            !error &&
                            (data?.items || []).map(row => (
                                <tr key={`${row.id}-${row.timestamp}`} className='border-b border-white/5 text-white/85'>
                                    <td className='py-3 pr-4'>
                                        <span
                                            className={`inline-flex rounded-full px-2.5 py-1 text-xs font-bold capitalize ${
                                                row.event.includes('suspend') || row.event.includes('security')
                                                    ? 'border border-rose-300/25 bg-rose-400/10 text-rose-100'
                                                    : row.event.includes('power') || row.event.includes('reinstall')
                                                      ? 'border border-amber-300/25 bg-amber-400/10 text-amber-100'
                                                      : 'border border-cyan-300/20 bg-cyan-400/10 text-cyan-100'
                                            }`}
                                        >
                                            {eventLabel(row.event)}
                                        </span>
                                    </td>
                                    <td className='max-w-[520px] py-3 pr-4 text-white/80'>
                                        {row.description || 'No description recorded.'}
                                    </td>
                                    <td className='py-3 pr-4 text-white/70'>{row.actorLabel || 'System'}</td>
                                    <td className='py-3 pr-4 text-white/60'>{row.ip || '-'}</td>
                                    <td className='py-3 pr-4 text-white/70'>{safeFormat(row.timestamp)}</td>
                                </tr>
                            ))}

                        {!isLoading && !error && !(data?.items || []).length && (
                            <tr>
                                <td colSpan={5} className='py-8 text-center text-white/55'>
                                    No VPS events were recorded inside the current retention window.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>

            <div className='mt-4 flex flex-wrap items-center justify-between gap-3 text-sm text-white/60'>
                <span>
                    Showing {data?.pagination.count || 0} of {data?.pagination.total || 0} logs
                </span>
                <div className='flex items-center gap-2'>
                    <select
                        value={perPage}
                        onChange={e => {
                            setPage(1)
                            setPerPage(Number(e.target.value))
                        }}
                        className='h-9 rounded-lg border border-white/15 bg-slate-950 px-2 text-sm text-white'
                    >
                        <option value={10}>10</option>
                        <option value={25}>25</option>
                        <option value={50}>50</option>
                        <option value={100}>100</option>
                    </select>
                    <Button
                        className='!h-9 !text-white !bg-slate-800 !border-slate-500 disabled:!opacity-40'
                        disabled={page <= 1}
                        onClick={() => setPage(value => Math.max(1, value - 1))}
                    >
                        Prev
                    </Button>
                    <span>
                        Page {data?.pagination.currentPage || page} / {data?.pagination.totalPages || 1}
                    </span>
                    <Button
                        className='!h-9 !text-white !bg-slate-800 !border-slate-500 disabled:!opacity-40'
                        disabled={page >= (data?.pagination.totalPages || 1)}
                        onClick={() => setPage(value => value + 1)}
                    >
                        Next
                    </Button>
                </div>
            </div>
        </div>
    )
}

export default AdminServerActivityLogPanel
