import { AdminServerContext } from '@/state/admin/server'
import { bytesToString } from '@/util/helpers'
import { useEffect, useMemo, useRef, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Link, useNavigate } from 'react-router-dom'
import { useDebouncedValue } from '@mantine/hooks'
import { SimplePowerAction } from '@/api/server/management'
import { EloquentStatus } from '@/api/server/types'
import {
    AdminManagementStatus,
    getAdminManagementStatus,
    sendAdminManagementAction,
} from '@/api/admin/servers/management'
import { formatResourceGuardWarning } from '@/api/server/resourceGuard'
import createAdminConsoleSession from '@/api/admin/servers/createConsoleSession'
import transferServer from '@/api/admin/servers/transferServer'
import getOsOptions, { OsTemplateGroup } from '@/api/admin/servers/getOsOptions'
import reinstallServer from '@/api/admin/servers/reinstallServer'
import fixStuckServer from '@/api/admin/servers/fixStuckServer'
import deleteServer from '@/api/admin/servers/deleteServer'
import getNodes from '@/api/admin/nodes/getNodes'
import updateServer from '@/api/admin/servers/updateServer'
import useUsersSWR from '@/api/admin/users/useUsersSWR'
import { httpErrorToHuman } from '@/api/http'

import Button from '@/components/elements/Button'
import Select from '@/components/elements/inputs/Select'

import ServerContentBlock from '@/components/admin/servers/ServerContentBlock'
import AdminServerActivityLogPanel from '@/components/admin/servers/overview/AdminServerActivityLogPanel'

const ServerOverviewContainer = () => {
    const navigate = useNavigate()
    const server = AdminServerContext.useStoreState(state => state.server.data)
    const getServer = AdminServerContext.useStoreActions(actions => actions.server.getServer)
    const setServer = AdminServerContext.useStoreActions(actions => actions.server.setServer)
    const [management, setManagement] = useState<AdminManagementStatus | null>(null)
    const [osOptions, setOsOptions] = useState<OsTemplateGroup[]>([])
    const [selectedTemplate, setSelectedTemplate] = useState('')
    const [accountPassword, setAccountPassword] = useState('')
    const [startOnCompletion, setStartOnCompletion] = useState(false)
    const [isLoading, setIsLoading] = useState(true)
    const [actionLoading, setActionLoading] = useState<SimplePowerAction | null>(null)
    const [actionCooldown, setActionCooldown] = useState(false)
    const [isReinstalling, setIsReinstalling] = useState(false)
    const [availableNodes, setAvailableNodes] = useState<{ id: number; name: string }[]>([])
    const [targetNodeId, setTargetNodeId] = useState<number | null>(null)
    const [isTransferring, setIsTransferring] = useState(false)
    const [isOpeningConsole, setIsOpeningConsole] = useState(false)
    const [isFixingStuck, setIsFixingStuck] = useState(false)
    const [isDeleting, setIsDeleting] = useState(false)
    const [ownerQuery, setOwnerQuery] = useState('')
    const [selectedOwnerId, setSelectedOwnerId] = useState<string>('')
    const [isChangingOwner, setIsChangingOwner] = useState(false)
    const [error, setError] = useState<string | null>(null)
    const [notice, setNotice] = useState<string | null>(null)
    const actionCooldownTimerRef = useRef<number | null>(null)
    const [debouncedOwnerQuery] = useDebouncedValue(ownerQuery, 200)
    const { data: usersResponse, isLoading: isLoadingUsers, isValidating: isValidatingUsers } = useUsersSWR({
        query: debouncedOwnerQuery,
    })

    const { t } = useTranslation('admin.servers.overview')
    const { t: tStrings } = useTranslation('strings')

    if (!server) {
        return null
    }

    const ownerOptions = useMemo(
        () =>
            usersResponse?.items.map(user => ({
                value: user.id.toString(),
                label: `${user.name} (${user.email})`,
            })) ?? [],
        [usersResponse]
    )

    const refreshManagement = async () => {
        try {
            const data = await getAdminManagementStatus(server.uuid)
            setManagement(data)
            await getServer(server.uuid).catch(() => null)
            setError(null)
            setNotice(data.liveUnavailable ? data.liveUnavailableMessage ?? 'Live metrics are currently unavailable.' : null)
        } catch {
            setManagement(prev => prev ?? {
                serverId: server.uuid,
                status: server.status,
                state: 'loading',
                metrics: {
                    cpuUsed: 0,
                    memoryTotal: 0,
                    memoryUsed: 0,
                    uptime: 0,
                },
                availableActions: ['start', 'stop', 'shutdown', 'restart', 'kill', 'resume', 'suspend'],
            })
            setError(null)
            setNotice('Live metrics are temporarily unavailable from Proxmox. You can still use management actions.')
        } finally {
            setIsLoading(false)
        }
    }

    useEffect(() => {
        void refreshManagement()
        getNodes({ perPage: 200 })
            .then(({ items }) => {
                const options = items
                    .filter(node => node.id !== server.nodeId)
                    .map(node => ({ id: node.id, name: node.name }))
                setAvailableNodes(options)
                setTargetNodeId(options[0]?.id ?? null)
            })
            .catch(() => {
                setError('Failed to load nodes.')
            })

        getOsOptions(server.uuid)
            .then(groups => {
                setOsOptions(groups)
                const firstTemplate = groups.flatMap(g => g.templates)[0]
                if (firstTemplate) setSelectedTemplate(firstTemplate.uuid)
            })
            .catch(() => {
                setError('Failed to load OS options.')
            })
        const interval = window.setInterval(() => {
            if (document.visibilityState === 'hidden') return
            void refreshManagement()
        }, 10000)

        return () => window.clearInterval(interval)
    }, [server.uuid])

    useEffect(() => {
        const currentOwnerId = server.userId ? server.userId.toString() : ''
        setSelectedOwnerId(currentOwnerId)
        setOwnerQuery(currentOwnerId)
    }, [server.userId])

    const runAction = async (action: SimplePowerAction) => {
        if (actionLoading || actionCooldown) {
            return
        }

        setActionLoading(action)
        setError(null)
        setNotice(null)
        try {
            const response = await sendAdminManagementAction(server.uuid, action)
            const guardMessage = formatResourceGuardWarning(response.resourceGuardWarning)
            if (guardMessage) {
                setNotice(guardMessage)
            }
            await refreshManagement()
        } catch (error: any) {
            setError(
                error?.response?.data?.message ||
                    `Failed to send "${action}" action.`
            )
        } finally {
            setActionLoading(null)
            setActionCooldown(true)
            if (actionCooldownTimerRef.current) {
                window.clearTimeout(actionCooldownTimerRef.current)
            }
            actionCooldownTimerRef.current = window.setTimeout(() => {
                setActionCooldown(false)
                actionCooldownTimerRef.current = null
            }, 8000)
        }
    }

    useEffect(() => {
        return () => {
            if (actionCooldownTimerRef.current) {
                window.clearTimeout(actionCooldownTimerRef.current)
                actionCooldownTimerRef.current = null
            }
        }
    }, [])

    const handleOpenAdminConsole = async () => {
        setIsOpeningConsole(true)
        setError(null)
        setNotice(null)
        try {
            const creds = await createAdminConsoleSession(server.uuid, 'novnc')
            if (!('token' in creds)) {
                throw new Error('Secure terminal gateway is not configured for this node.')
            }

            const targetUrl = `${creds.isTlsEnabled ? 'https' : 'http'}://${creds.fqdn}:${creds.port}/?type=novnc&token=${encodeURIComponent(creds.token)}`
            window.open(
                targetUrl,
                `wammu-admin-console-${server.id}`,
                'popup=yes,width=1280,height=820,resizable=yes,scrollbars=yes'
            )
        } catch (error) {
            setError(httpErrorToHuman(error))
        } finally {
            setIsOpeningConsole(false)
        }
    }

    const handleTransfer = async () => {
        if (!targetNodeId) {
            setError('Select a target node first.')
            return
        }

        setIsTransferring(true)
        setError(null)
        setNotice(null)
        try {
            await transferServer(server.uuid, targetNodeId, true)
            setNotice('Transfer queued successfully.')
        } catch {
            setError('Failed to transfer server to target node.')
        } finally {
            setIsTransferring(false)
        }
    }

    const handleReinstall = async () => {
        if (!selectedTemplate || !accountPassword) {
            setError('Select OS template and password first.')
            return
        }

        setIsReinstalling(true)
        setError(null)
        setNotice(null)
        try {
            await reinstallServer(server.uuid, {
                templateUuid: selectedTemplate,
                accountPassword,
                startOnCompletion,
            })
            setNotice('Reinstall queued successfully.')
        } catch {
            setError('Failed to queue reinstall.')
        } finally {
            setIsReinstalling(false)
        }
    }

    const handleFixStuck = async () => {
        setIsFixingStuck(true)
        setError(null)
        setNotice(null)

        try {
            const result = await fixStuckServer(server.uuid)

            if (result.statusUpdated && result.newStatus !== null) {
                setServer({
                    ...server,
                    status: result.newStatus as EloquentStatus,
                })
            }

            const failedChecks = result.checks.filter(item => !item.ok)
            const summary = result.checks.length > 0
                ? `Checks: ${result.checks.length - failedChecks.length}/${result.checks.length} passed.`
                : ''
            const failedSummary = failedChecks.length > 0
                ? ` Failed: ${failedChecks.map(item => item.key).join(', ')}.`
                : ''

            setNotice(`${result.message}${summary ? ` ${summary}` : ''}${failedSummary}`)
            await refreshManagement()
        } catch {
            setError('Failed to run VPS recovery.')
        } finally {
            setIsFixingStuck(false)
        }
    }

    const handleDeleteServer = async () => {
        const confirmed = window.confirm(
            `Delete VM "${server.name}" (VMID ${server.vmid})? This action cannot be undone.`
        )

        if (!confirmed) return

        setIsDeleting(true)
        setError(null)
        setNotice(null)

        try {
            await deleteServer(server.uuid, false)
            navigate('/admin/servers')
        } catch {
            setError('Failed to delete server.')
        } finally {
            setIsDeleting(false)
        }
    }

    const handleChangeOwner = async () => {
        if (!selectedOwnerId) {
            setError('Select a new owner first.')
            return
        }

        const nextOwnerId = Number(selectedOwnerId)
        if (nextOwnerId === server.userId) {
            setNotice('This server already belongs to that user.')
            setError(null)
            return
        }

        setIsChangingOwner(true)
        setError(null)
        setNotice(null)

        try {
            const updated = await updateServer(server.uuid, {
                userId: nextOwnerId,
            })

            setServer(updated)
            setSelectedOwnerId(updated.userId.toString())
            setNotice('Server owner updated successfully.')
        } catch {
            setError('Failed to change server owner.')
        } finally {
            setIsChangingOwner(false)
        }
    }

    const memoryPercent = useMemo(() => {
        if (!management?.metrics.memoryTotal) return 0
        return Math.min(
            100,
            Math.round((management.metrics.memoryUsed / management.metrics.memoryTotal) * 100)
        )
    }, [management?.metrics.memoryTotal, management?.metrics.memoryUsed])

    const uptimeText = useMemo(() => {
        const totalSeconds = Math.max(0, Math.floor(management?.metrics.uptime ?? 0))

        const days = Math.floor(totalSeconds / 86400)
        const hours = Math.floor((totalSeconds % 86400) / 3600)
        const minutes = Math.floor((totalSeconds % 3600) / 60)

        if (days > 0) return `${days}d ${hours}h ${minutes}m`
        if (hours > 0) return `${hours}h ${minutes}m`
        if (minutes > 0) return `${minutes}m`

        return `${totalSeconds}s`
    }, [management?.metrics.uptime])

    const actionsBusy = !!actionLoading || actionCooldown

    return (
        <ServerContentBlock title={tStrings('overview')}>
            <div className='space-y-4'>
                <Link to={`/servers/${server.id}`}>
                    <Button className='inline-flex items-center' as={'span'}>
                        {t('enter_server_console')}
                    </Button>
                </Link>
                <Button
                    className='inline-flex items-center ml-2 !text-white !bg-slate-800 !border-slate-500 hover:!bg-slate-700'
                    disabled={isOpeningConsole}
                    onClick={handleOpenAdminConsole}
                >
                    {isOpeningConsole ? 'Opening noVNC...' : 'Open Admin noVNC'}
                </Button>

                <div className='rounded-lg border border-slate-700 bg-slate-900/50 p-4 space-y-4'>
                    <div className='rounded-md border border-slate-700 bg-slate-950/80 p-3'>
                        <div className='flex flex-wrap items-center justify-between gap-3'>
                            <div>
                                <p className='text-white text-sm font-semibold'>Admin VM Controls</p>
                                <p className='text-xs text-slate-300'>
                                    VMID #{server.vmid} | User #{server.userId} | Node #{server.nodeId} | Status: {server.status}
                                </p>
                            </div>
                            <div className='flex flex-wrap gap-2'>
                                <Link to={`/admin/servers/${server.uuid}/settings/general`}>
                                    <Button className='!text-white !bg-indigo-700 !border-indigo-500 hover:!bg-indigo-600' as={'span'}>
                                        Edit General
                                    </Button>
                                </Link>
                                <Link to={`/admin/servers/${server.uuid}/settings/hardware`}>
                                    <Button className='!text-white !bg-violet-700 !border-violet-500 hover:!bg-violet-600' as={'span'}>
                                        Edit Hardware
                                    </Button>
                                </Link>
                                <Button
                                    className='!text-white !bg-red-800 !border-red-500 hover:!bg-red-700'
                                    disabled={isDeleting}
                                    onClick={handleDeleteServer}
                                >
                                    {isDeleting ? 'Deleting...' : 'Delete VM'}
                                </Button>
                            </div>
                        </div>
                    </div>

                    <div className='rounded-md border border-slate-700 bg-slate-950/80 p-4 space-y-3'>
                        <div>
                            <p className='text-white text-sm font-semibold'>Change Owner</p>
                            <p className='text-xs text-slate-300'>
                                Move this server to another user account using the existing admin server update flow.
                            </p>
                        </div>
                        <Select
                            label='Owner'
                            placeholder='Search user by name or email'
                            data={ownerOptions}
                            value={selectedOwnerId}
                            onChange={value => setSelectedOwnerId(value ?? '')}
                            searchable
                            searchValue={ownerQuery}
                            onSearchChange={value => setOwnerQuery(value)}
                            nothingFound='No users found'
                            loading={isLoadingUsers || isValidatingUsers}
                        />
                        <div className='flex justify-end'>
                            <Button
                                className='!text-white !bg-indigo-700 !border-indigo-500 hover:!bg-indigo-600'
                                disabled={isChangingOwner || !selectedOwnerId}
                                onClick={handleChangeOwner}
                            >
                                {isChangingOwner ? 'Changing Owner...' : 'Change Owner'}
                            </Button>
                        </div>
                    </div>

                    <div className='flex items-center justify-between gap-4'>
                        <h3 className='text-white font-bold tracking-wide'>Live VPS Management</h3>
                        <span className='text-xs text-white bg-slate-800 border border-slate-600 rounded px-2 py-1'>
                            {isLoading || !management || management.state === 'loading'
                                ? 'Loading...'
                                : `State: ${management.state}`}
                        </span>
                    </div>

                    {error && (
                        <p className='rounded-md border border-red-500/40 bg-red-950/40 px-3 py-2 text-sm font-medium text-red-300'>{error}</p>
                    )}

                    {notice && (
                        <p className='rounded-md border border-amber-400/30 bg-amber-900/20 px-3 py-2 text-sm font-medium text-amber-200'>{notice}</p>
                    )}

                    <div className='grid grid-cols-1 sm:grid-cols-3 gap-3 text-sm'>
                        <div className='rounded-md border border-slate-600 bg-slate-950/80 p-3'>
                            <p className='text-white/85 font-semibold'>CPU</p>
                            <p className='text-white font-bold'>{Math.round(management?.metrics.cpuUsed ?? 0)}%</p>
                        </div>
                        <div className='rounded-md border border-slate-600 bg-slate-950/80 p-3'>
                            <p className='text-white/85 font-semibold'>Memory</p>
                            <p className='text-white font-bold'>
                                {bytesToString(management?.metrics.memoryUsed ?? 0)} / {bytesToString(management?.metrics.memoryTotal ?? 0)} ({memoryPercent}%)
                            </p>
                        </div>
                        <div className='rounded-md border border-slate-600 bg-slate-950/80 p-3'>
                            <p className='text-white/85 font-semibold'>Uptime</p>
                            <p className='text-white font-bold'>{uptimeText}</p>
                        </div>
                    </div>

                    <div className='flex flex-wrap gap-2'>
                                <Button
                                    className='!text-white !bg-emerald-700 !border-emerald-500 hover:!bg-emerald-600'
                                    variant='filled'
                                    disabled={!management?.availableActions.includes('start') || actionsBusy}
                                    onClick={() => runAction('start')}
                                >
                                    {actionLoading === 'start' ? 'Starting...' : 'Start'}
                                </Button>
                        <Button
                            className='!text-white !bg-red-700 !border-red-500 hover:!bg-red-600'
                            color='danger'
                            variant='filled'
                                    disabled={
                                        !(management?.availableActions.includes('stop') || management?.availableActions.includes('shutdown')) ||
                                        actionsBusy
                                    }
                                    onClick={() => runAction('stop')}
                                >
                            {actionLoading === 'stop' ? 'Stopping...' : 'Stop'}
                        </Button>
                        <Button
                                    className='!text-white !bg-indigo-700 !border-indigo-500 hover:!bg-indigo-600'
                                    variant='filled'
                                    disabled={!management?.availableActions.includes('restart') || actionsBusy}
                                    onClick={() => runAction('restart')}
                                >
                                    {actionLoading === 'restart' ? 'Restarting...' : 'Restart'}
                                </Button>
                                <Button className='!text-white !bg-slate-800 !border-slate-500 hover:!bg-slate-700' disabled={actionsBusy} onClick={() => void refreshManagement()}>
                                    Refresh
                                </Button>
                                <Button
                                    className='!text-white !bg-amber-700 !border-amber-500 hover:!bg-amber-600'
                                    disabled={isFixingStuck || actionsBusy}
                                    onClick={handleFixStuck}
                                >
                                    {isFixingStuck ? 'Fixing...' : 'Fix Stuck VPS'}
                        </Button>
                    </div>

                    <div className='border-t border-slate-700 pt-4 space-y-3'>
                        <h4 className='text-white font-bold tracking-wide'>Reinstall / Change OS</h4>
                        <select
                            className='w-full bg-slate-950 border border-slate-500 rounded-md px-3 py-2 text-sm text-white font-medium'
                            value={selectedTemplate}
                            onChange={e => setSelectedTemplate(e.target.value)}
                            style={{ backgroundColor: '#020617', color: '#ffffff' }}
                        >
                            {osOptions.length === 0 && (
                                <option value=''>No OS templates available</option>
                            )}
                            {osOptions.map(group => (
                                <optgroup key={group.uuid} label={group.name} style={{ color: '#ffffff', backgroundColor: '#020617' }}>
                                    {group.templates.map(template => (
                                        <option key={template.uuid} value={template.uuid} style={{ color: '#ffffff', backgroundColor: '#020617' }}>
                                            {template.name} {template.isWindows ? '(Windows)' : '(Linux)'}
                                        </option>
                                    ))}
                                </optgroup>
                            ))}
                        </select>
                        <label className='block text-sm font-semibold text-white'>New OS account password</label>
                        <input
                            type='password'
                            value={accountPassword}
                            onChange={e => setAccountPassword(e.target.value)}
                            placeholder='New OS account password'
                            autoComplete='new-password'
                            className='w-full !bg-slate-950 !border-slate-500 rounded-md px-3 py-2 text-sm !text-white placeholder:!text-slate-300 focus:!border-indigo-400 focus:!ring-1 focus:!ring-indigo-500/40'
                            style={{ backgroundColor: '#020617', color: '#ffffff' }}
                        />
                        <label className='inline-flex items-center gap-2 text-sm text-white font-medium'>
                            <input
                                type='checkbox'
                                checked={startOnCompletion}
                                onChange={e => setStartOnCompletion(e.target.checked)}
                            />
                            Start after reinstall
                        </label>
                        <div>
                            <Button
                                color='danger'
                                className='!text-white !bg-red-700 !border-red-500 hover:!bg-red-600'
                                variant='filled'
                                disabled={isReinstalling || actionsBusy || !selectedTemplate || !accountPassword}
                                onClick={handleReinstall}
                            >
                                {isReinstalling ? 'Reinstalling...' : 'Reinstall & Change OS'}
                            </Button>
                        </div>
                    </div>

                    <div className='border-t border-slate-700 pt-4 space-y-3'>
                        <h4 className='text-white font-bold tracking-wide'>Transfer to Another Node</h4>
                        <select
                            className='w-full bg-slate-950 border border-slate-500 rounded-md px-3 py-2 text-sm text-white font-medium'
                            value={targetNodeId ?? ''}
                            onChange={e => setTargetNodeId(e.target.value ? Number(e.target.value) : null)}
                            style={{ backgroundColor: '#020617', color: '#ffffff' }}
                        >
                            {availableNodes.length === 0 && (
                                <option value='' style={{ color: '#ffffff', backgroundColor: '#020617' }}>No eligible nodes found</option>
                            )}
                            {availableNodes.map(node => (
                                <option key={node.id} value={node.id} style={{ color: '#ffffff', backgroundColor: '#020617' }}>
                                    #{node.id} - {node.name}
                                </option>
                            ))}
                        </select>
                        <div>
                            <Button
                                className='!text-white !bg-indigo-700 !border-indigo-500 hover:!bg-indigo-600'
                                variant='filled'
                                disabled={isTransferring || actionsBusy || !targetNodeId}
                                onClick={handleTransfer}
                            >
                                {isTransferring ? 'Transferring...' : 'Transfer Server'}
                            </Button>
                        </div>
                    </div>
                </div>
                <AdminServerActivityLogPanel serverUuid={server.uuid} />
            </div>
        </ServerContentBlock>
    )
}

export default ServerOverviewContainer
