import usePagination from '@/util/usePagination'
import { useTranslation } from 'react-i18next'
import { Link } from 'react-router-dom'

import useServersSWR from '@/api/admin/servers/useServersSWR'
import { ServerBuild } from '@/api/server/getServer'

import Menu from '@/components/elements/Menu'
import Pagination from '@/components/elements/Pagination'
import Spinner from '@/components/elements/Spinner'
import Table, {
    Actions,
    ColumnArray,
    RowActionsProps,
} from '@/components/elements/displays/Table'


interface Props {
    query?: string
    className?: string
    nodeId?: number
    userId?: number
    scope?: 'all' | 'platform' | 'reseller'
    variant?: 'default' | 'reseller'
    pageKey?: string
}

const ServersTable = ({
    query,
    className,
    nodeId,
    userId,
    scope = 'all',
    variant = 'default',
    pageKey = 'page',
}: Props) => {
    const { t: tStrings } = useTranslation('strings')
    const [page, setPage] = usePagination(pageKey)
    const { data } = useServersSWR({
        page,
        query,
        nodeId,
        userId,
        scope,
        include: ['node', 'user'],
    })

    const columns: ColumnArray<ServerBuild> =
        variant === 'reseller'
            ? [
                  {
                      accessor: 'id',
                      header: 'Server ID',
                      cell: ({ value, row }) => (
                          <Link
                              to={`/admin/servers/${row.id}`}
                              className='link text-foreground'
                          >
                              {value}
                          </Link>
                      ),
                  },
                  {
                      accessor: 'name',
                      header: 'Server Name',
                      cell: ({ value, row }) => (
                          <Link
                              to={`/admin/servers/${row.id}`}
                              className='link text-foreground'
                          >
                              {value}
                          </Link>
                      ),
                  },
                  {
                      accessor: 'user',
                      header: 'Username',
                      cell: ({ value }) =>
                          value ? (
                              <Link
                                  to={`/admin/users/${value.id}/settings`}
                                  className='link text-foreground'
                              >
                                  {value.name}
                              </Link>
                          ) : (
                              '-'
                          ),
                  },
                  {
                      accessor: 'user',
                      header: 'Email',
                      cell: ({ value }) =>
                          value ? (
                              <Link
                                  to={`/admin/users/${value.id}/settings`}
                                  className='link text-foreground'
                              >
                                  {value.email}
                              </Link>
                          ) : (
                              '-'
                          ),
                  },
                  {
                      accessor: 'node',
                      header: 'Node',
                      cell: ({ value }) => value?.name ?? '-',
                  },
              ]
            : [
                  {
                      accessor: 'name',
                      header: tStrings('name'),
                      cell: ({ value, row }) => (
                          <Link
                              to={`/admin/servers/${row.id}`}
                              className='link text-foreground'
                          >
                              {value}
                          </Link>
                      ),
                  },
                  {
                      accessor: 'hostname',
                      header: tStrings('hostname'),
                  },
                  {
                      accessor: 'user',
                      header: tStrings('owner'),
                      cell: ({ value }) =>
                          value ? (
                              <Link
                                  to={`/admin/users/${value.id}/settings`}
                                  className='link text-foreground'
                              >
                                  {value.email}
                              </Link>
                          ) : (
                              '-'
                          ),
                  },
                  {
                      accessor: 'node',
                      header: tStrings('node'),
                      cell: ({ value }) => value?.name ?? '-',
                  },
              ]

    const rowActions = ({ row: server }: RowActionsProps<ServerBuild>) => {
        return (
            <Actions>
                <Menu.Item
                    onClick={() => window.location.assign(`/servers/${server.id}`)}
                >
                    <div className='flex items-center gap-2.5'>
                        <svg className='h-4 w-4' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                            <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M15 12a3 3 0 11-6 0 3 3 0 016 0z' />
                            <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z' />
                        </svg>
                        <span className='font-medium'>View in Client Panel</span>
                    </div>
                </Menu.Item>
                <Menu.Divider />
                <Menu.Item
                    onClick={() => navigator.clipboard.writeText(server.uuid)}
                >
                    <div className='flex items-center gap-2.5'>
                        <svg className='h-4 w-4' fill='none' stroke='currentColor' viewBox='0 0 24 24'>
                            <path strokeLinecap='round' strokeLinejoin='round' strokeWidth={2} d='M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z' />
                        </svg>
                        <span className='font-medium'>Copy Server ID</span>
                    </div>
                </Menu.Item>
            </Actions>
        )
    }

    const emptyTitle = query
        ? 'No servers found'
        : scope === 'reseller'
        ? 'No reseller servers yet'
        : scope === 'platform'
        ? 'No platform servers yet'
        : 'No servers yet'
    const emptyDescription = query
        ? 'Try a different search query.'
        : scope === 'reseller'
        ? 'Reseller customer VPS will appear here.'
        : 'Create a server to get started.'

    return (
        <div className={className}>
            {!data ? (
                <div className='flex flex-col items-center justify-center py-20'>
                    <Spinner />
                    <p className='mt-4 text-sm text-white/60'>Loading servers...</p>
                </div>
            ) : data.items.length === 0 ? (
                <div className='rounded-xl border border-white/10 bg-[#111a31] p-10 text-center'>
                    <h3 className='text-lg font-semibold text-white'>
                        {emptyTitle}
                    </h3>
                    <p className='mt-2 text-sm text-white/60'>
                        {emptyDescription}
                    </p>
                </div>
            ) : (
                <Pagination data={data} onPageSelect={setPage} pageKey={pageKey}>
                    {({ items }) => (
                        <Table
                            columns={columns}
                            data={items}
                            rowActions={rowActions}
                        />
                    )}
                </Pagination>
            )}
        </div>
    )
}

export default ServersTable
