﻿import {
    RootControlRole,
    RootControlStaffMember,
    acknowledgeRootControlAlert,
    createRootControlRole,
    deleteRootControlRole,
    getRootControlActivity,
    getRootControlAlerts,
    getRootControlAuditLogs,
    getRootControlIpLogs,
    getRootControlOverview,
    getRootControlPaymenterOverview,
    getRootControlPermissions,
    getRootControlRoles,
    getRootControlStaff,
    syncRootControlStaffRoles,
    updateRootControlPaymenterOverride,
    updateRootControlRole,
} from '@/api/admin/rootControl/manageRootControl'
import PageContentBlock from '@/components/elements/PageContentBlock'
import { NavigationBarContext } from '@/components/elements/navigation/NavigationBar'
import { httpErrorToHuman } from '@/api/http'
import { formatDistanceToNow } from 'date-fns'
import { useContext, useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'

const metricCard = (
    label: string,
    value: string | number,
    accent: string = 'text-white'
) => (
    <div className='rounded-2xl border border-white/10 bg-[#16113a] p-4 shadow-[0_10px_35px_rgba(4,3,12,0.3)]'>
        <p className='break-words text-[11px] uppercase tracking-[0.16em] text-white/45'>{label}</p>
        <p className={`mt-3 break-words text-2xl font-semibold ${accent}`}>{value}</p>
    </div>
)

interface RootControlPermission {
    key: string
    label: string
    group?: string | null
    description?: string | null
}

const RootAdminControlContainer = () => {
    const { setRoutes } = useContext(NavigationBarContext)
    const [loading, setLoading] = useState(true)
    const [savingRoleId, setSavingRoleId] = useState<number | 'new' | null>(null)
    const [refreshing, setRefreshing] = useState(false)
    const [status, setStatus] = useState<string | null>(null)
    const [error, setError] = useState<string | null>(null)
    const [overview, setOverview] = useState<any>(null)
    const [auditLogs, setAuditLogs] = useState<any[]>([])
    const [activity, setActivity] = useState<any[]>([])
    const [ipLogs, setIpLogs] = useState<any[]>([])
    const [alerts, setAlerts] = useState<any[]>([])
    const [paymenter, setPaymenter] = useState<any | null>(null)
    const [permissions, setPermissions] = useState<RootControlPermission[]>([])
    const [roles, setRoles] = useState<RootControlRole[]>([])
    const [staff, setStaff] = useState<RootControlStaffMember[]>([])
    const [editingRoleId, setEditingRoleId] = useState<number | 'new' | null>(null)
    const [roleForm, setRoleForm] = useState({
        name: '',
        slug: '',
        description: '',
        permissions: [] as string[],
    })

    const load = async () => {
        setRefreshing(true)
        setError(null)

        try {
            const [
                overviewData,
                auditData,
                activityData,
                ipData,
                alertData,
                paymenterData,
                permissionData,
                roleData,
                staffData,
            ] = await Promise.all([
                getRootControlOverview(),
                getRootControlAuditLogs(),
                getRootControlActivity(),
                getRootControlIpLogs(),
                getRootControlAlerts(),
                getRootControlPaymenterOverview(),
                getRootControlPermissions(),
                getRootControlRoles(),
                getRootControlStaff(),
            ])

            setOverview(overviewData)
            setAuditLogs(auditData)
            setActivity(activityData)
            setIpLogs(ipData)
            setAlerts(alertData)
            setPaymenter(paymenterData)
            setPermissions(permissionData)
            setRoles(roleData)
            setStaff(staffData)
        } catch (loadError) {
            setError(httpErrorToHuman(loadError))
        } finally {
            setRefreshing(false)
            setLoading(false)
        }
    }

    useEffect(() => {
        setRoutes([
            {
                name: 'Dashboard',
                path: '/admin',
                end: true,
                group: 'Command Center',
            },
            {
                name: 'Owner Console',
                path: '/admin/control',
                group: 'Command Center',
            },
        ])

        void load()

        return () => setRoutes([])
    }, [setRoutes])

    const groupedPermissions = useMemo(() => {
        return permissions.reduce<Record<string, RootControlPermission[]>>((acc, item) => {
            const group = item.group || 'Other'
            acc[group] = acc[group] || []
            acc[group].push(item)

            return acc
        }, {})
    }, [permissions])

    const visibleTenants = overview?.recentTenants || []

    const beginCreateRole = () => {
        setEditingRoleId('new')
        setRoleForm({
            name: '',
            slug: '',
            description: '',
            permissions: [],
        })
        setStatus(null)
        setError(null)
    }

    const beginEditRole = (role: RootControlRole) => {
        setEditingRoleId(role.id)
        setRoleForm({
            name: role.name,
            slug: role.slug,
            description: role.description || '',
            permissions: role.permissions,
        })
        setStatus(null)
        setError(null)
    }

    const saveRole = async () => {
        if (!editingRoleId) {
            return
        }

        setSavingRoleId(editingRoleId)
        setStatus(null)
        setError(null)

        try {
            if (editingRoleId === 'new') {
                await createRootControlRole({
                    name: roleForm.name,
                    slug: roleForm.slug,
                    description: roleForm.description || null,
                    permissions: roleForm.permissions,
                })
                setStatus('Platform role created.')
            } else {
                await updateRootControlRole(editingRoleId, {
                    name: roleForm.name,
                    slug: roleForm.slug,
                    description: roleForm.description || null,
                    permissions: roleForm.permissions,
                })
                setStatus('Platform role updated.')
            }

            setEditingRoleId(null)
            await load()
        } catch (saveError) {
            setError(httpErrorToHuman(saveError))
        } finally {
            setSavingRoleId(null)
        }
    }

    const removeRole = async (role: RootControlRole) => {
        if (role.isSystem || !window.confirm(`Delete role "${role.name}"?`)) {
            return
        }

        try {
            await deleteRootControlRole(role.id)
            setStatus('Platform role deleted.')
            await load()
        } catch (deleteError) {
            setError(httpErrorToHuman(deleteError))
        }
    }

    const acknowledgeAlert = async (alertId: number) => {
        try {
            await acknowledgeRootControlAlert(alertId)
            setStatus('Alert acknowledged.')
            await load()
        } catch (ackError) {
            setError(httpErrorToHuman(ackError))
        }
    }

    const syncStaffRoles = async (member: RootControlStaffMember, roleIds: number[]) => {
        try {
            await syncRootControlStaffRoles(member.id, roleIds)
            setStatus(`Updated platform roles for ${member.email}.`)
            await load()
        } catch (syncError) {
            setError(httpErrorToHuman(syncError))
        }
    }

    const togglePaymenterDisable = async (integration: any) => {
        const disabled = Boolean(integration.rootOverride?.billingDisabled)
        const note = window.prompt(
            disabled
                ? `Clear the billing disable override for ${integration.reseller.displayName}? Optional note:`
                : `Disable billing for ${integration.reseller.displayName}. Enter a note:`,
            integration.rootOverride?.note || ''
        )

        if (note === null) {
            return
        }

        try {
            await updateRootControlPaymenterOverride(integration.id, {
                rootOverrideEnabled: true,
                rootOverrideBillingDisabled: !disabled,
                rootOverrideNote: note.trim() || null,
            })
            setStatus(
                disabled
                    ? `Billing re-enabled for ${integration.reseller.displayName}.`
                    : `Billing disabled for ${integration.reseller.displayName}.`
            )
            await load()
        } catch (updateError) {
            setError(httpErrorToHuman(updateError))
        }
    }

    const overridePaymenterUrl = async (integration: any) => {
        const url = window.prompt(
            `Root override Paymenter URL for ${integration.reseller.displayName} (leave blank to clear)`,
            integration.rootOverride?.paymenterUrl ||
                integration.paymenterUrl ||
                ''
        )

        if (url === null) {
            return
        }

        const note = window.prompt(
            'Root override note',
            integration.rootOverride?.note || 'Root admin override'
        )

        if (note === null) {
            return
        }

        try {
            await updateRootControlPaymenterOverride(integration.id, {
                rootOverrideEnabled: true,
                rootOverridePaymenterUrl: url.trim() || null,
                rootOverrideNote: note.trim() || null,
            })
            setStatus(
                `Updated Paymenter override for ${integration.reseller.displayName}.`
            )
            await load()
        } catch (updateError) {
            setError(httpErrorToHuman(updateError))
        }
    }

    if (loading) {
        return (
            <PageContentBlock title='Owner Console'>
                <div className='rounded-2xl border border-white/10 bg-[#16113a] p-6 text-white/70'>
                    Loading root control center...
                </div>
            </PageContentBlock>
        )
    }

    return (
        <PageContentBlock title='Owner Console'>
            <div className='space-y-6'>
                <div className='rounded-[1.8rem] border border-white/10 bg-[radial-gradient(circle_at_top,_rgba(56,189,248,0.16),_transparent_32%),linear-gradient(180deg,rgba(16,15,49,0.98),rgba(10,8,28,0.98))] p-6 shadow-[0_18px_60px_rgba(5,5,20,0.35)]'>
                    <div className='flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between'>
                        <div className='max-w-3xl'>
                            <p className='inline-flex rounded-full border border-sky-300/20 bg-sky-400/10 px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.2em] text-sky-100/85'>
                                Platform Command Layer
                            </p>
                            <h1 className='mt-4 text-3xl font-semibold text-white'>
                                Root admin control center
                            </h1>
                            <p className='mt-3 break-words text-sm leading-7 text-white/65'>
                                This is the platform-wide command surface for tenants, infrastructure, abuse response, audit trails, and staff access control.
                            </p>
                        </div>
                        <div className='flex w-full flex-col gap-3 sm:w-auto sm:flex-row sm:flex-wrap'>
                            <button
                                onClick={() => void load()}
                                className='rounded-2xl border border-white/15 bg-white/8 px-4 py-3 text-sm font-semibold text-white transition hover:bg-white/12 sm:whitespace-nowrap'
                            >
                                {refreshing ? 'Refreshing...' : 'Refresh data'}
                            </button>
                            <Link
                                to='/admin/resellers'
                                className='rounded-2xl border border-emerald-300/20 bg-emerald-500/12 px-4 py-3 text-center text-sm font-semibold text-emerald-100 transition hover:bg-emerald-500/18 sm:whitespace-nowrap'
                            >
                                Open tenant list
                            </Link>
                        </div>
                    </div>
                    <div className='mt-5 grid gap-3 lg:grid-cols-3'>
                        <div className='rounded-2xl border border-white/10 bg-white/[0.04] p-4'>
                            <p className='text-xs font-semibold uppercase tracking-[0.18em] text-sky-100/70'>
                                What This Is For
                            </p>
                            <p className='mt-2 break-words text-sm leading-6 text-white/65'>
                                Use this page to watch platform-wide security, staff access, billing integrations, and reseller health from one place.
                            </p>
                        </div>
                        <div className='rounded-2xl border border-white/10 bg-white/[0.04] p-4'>
                            <p className='text-xs font-semibold uppercase tracking-[0.18em] text-emerald-100/70'>
                                Best For
                            </p>
                            <p className='mt-2 break-words text-sm leading-6 text-white/65'>
                                Fast operational checks, assigning staff roles, reviewing alerts, and jumping into root-only areas without digging through multiple menus.
                            </p>
                        </div>
                        <div className='rounded-2xl border border-white/10 bg-white/[0.04] p-4'>
                            <p className='text-xs font-semibold uppercase tracking-[0.18em] text-amber-100/70'>
                                Not For
                            </p>
                            <p className='mt-2 break-words text-sm leading-6 text-white/65'>
                                Customer VPS management or your normal day-to-day panel work. Those still belong in the main admin, user, or reseller sections.
                            </p>
                        </div>
                    </div>
                </div>

                {status ? (
                    <div className='rounded-xl border border-emerald-300/20 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-100'>
                        {status}
                    </div>
                ) : null}
                {error ? (
                    <div className='rounded-xl border border-rose-300/20 bg-rose-500/10 px-4 py-3 text-sm text-rose-100'>
                        {error}
                    </div>
                ) : null}

                <div className='grid gap-4 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4'>
                    {metricCard('Tenants', overview.metrics.tenants, 'text-sky-200')}
                    {metricCard('Platform Admins', overview.metrics.platformAdmins, 'text-fuchsia-200')}
                    {metricCard('Users', overview.metrics.users, 'text-emerald-200')}
                    {metricCard('Servers', overview.metrics.servers, 'text-white')}
                    {metricCard('Nodes', overview.metrics.nodes, 'text-amber-200')}
                    {metricCard('Open Admin Alerts', overview.metrics.openAdminAlerts, 'text-rose-200')}
                    {metricCard('Critical Security Alerts', overview.metrics.criticalSecurityAlerts, 'text-red-200')}
                    {metricCard('Suspicious Admin Logins / 24h', overview.metrics.suspiciousAdminLogins24h, 'text-orange-200')}
                </div>

                {paymenter ? (
                    <div className='grid items-start gap-5 2xl:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)]'>
                        <div className='min-w-0 overflow-hidden rounded-2xl border border-white/10 bg-[#16113a] p-5'>
                            <div className='flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between'>
                                <div className='min-w-0'>
                                    <h2 className='text-lg font-semibold text-white'>
                                        Paymenter Billing Layer
                                    </h2>
                                    <p className='mt-1 break-words text-sm text-white/55'>
                                        Reseller-owned Paymenter connections, module wiring, and root-admin overrides.
                                    </p>
                                </div>
                                <div className='grid w-full grid-cols-2 gap-2 text-left text-xs text-white/65 sm:grid-cols-4 sm:text-right xl:w-auto'>
                                    <div>
                                        <p className='font-semibold text-emerald-200'>
                                            {paymenter.summary.connectedTotal}
                                        </p>
                                        <p>Connected</p>
                                    </div>
                                    <div>
                                        <p className='font-semibold text-rose-200'>
                                            {paymenter.summary.disabledTotal}
                                        </p>
                                        <p>Disabled</p>
                                    </div>
                                    <div>
                                        <p className='font-semibold text-sky-200'>
                                            {paymenter.summary.webhooksToday}
                                        </p>
                                        <p>Webhooks Today</p>
                                    </div>
                                    <div>
                                        <p className='font-semibold text-amber-200'>
                                            {paymenter.summary.webhookFailuresToday}
                                        </p>
                                        <p>Failures Today</p>
                                    </div>
                                </div>
                            </div>

                            <div className='mt-4 space-y-3'>
                                {paymenter.items.length === 0 ? (
                                    <div className='rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white/60'>
                                        No reseller Paymenter integrations are configured yet.
                                    </div>
                                ) : (
                                    paymenter.items.map((integration: any) => (
                                        <div
                                            key={integration.id}
                                            className='rounded-xl border border-white/10 bg-white/[0.04] p-4'
                                        >
                                            <div className='flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between'>
                                                <div>
                                                    <div className='flex flex-wrap items-center gap-2'>
                                                        <p className='break-words text-sm font-semibold text-white'>
                                                            {integration.reseller.displayName}
                                                        </p>
                                                        <span className='rounded-full border border-white/10 bg-white/8 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-white/65'>
                                                            {integration.status}
                                                        </span>
                                                        {!integration.effectiveBillingEnabled ? (
                                                            <span className='rounded-full border border-rose-300/20 bg-rose-500/10 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-rose-100'>
                                                                Billing Disabled
                                                            </span>
                                                        ) : null}
                                                    </div>
                                                    <p className='mt-2 break-all text-xs text-white/45'>
                                                        Paymenter URL: {integration.effectivePaymenterUrl || 'Not set'}
                                                    </p>
                                                    <p className='mt-1 text-xs text-white/45'>
                                                        Last webhook:{' '}
                                                        {integration.lastWebhookReceivedAt
                                                            ? formatDistanceToNow(
                                                                  integration.lastWebhookReceivedAt,
                                                                  { addSuffix: true }
                                                              )
                                                            : 'never'}
                                                    </p>
                                                    <p className='mt-1 text-xs text-white/45'>
                                                        Last error: {integration.lastError || 'None'}
                                                    </p>
                                                </div>
                                                <div className='flex flex-wrap gap-2'>
                                                    <button
                                                        onClick={() =>
                                                            void overridePaymenterUrl(
                                                                integration
                                                            )
                                                        }
                                                        className='rounded-xl border border-sky-300/20 bg-sky-500/10 px-3 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-sky-100 hover:bg-sky-500/18'
                                                    >
                                                        Override URL
                                                    </button>
                                                    <button
                                                        onClick={() =>
                                                            void togglePaymenterDisable(
                                                                integration
                                                            )
                                                        }
                                                        className='rounded-xl border border-rose-300/20 bg-rose-500/10 px-3 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-rose-100 hover:bg-rose-500/18'
                                                    >
                                                        {integration.rootOverride
                                                            ?.billingDisabled
                                                            ? 'Re-enable Billing'
                                                            : 'Disable Billing'}
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    ))
                                )}
                            </div>
                        </div>

                        <div className='min-w-0 overflow-hidden rounded-2xl border border-white/10 bg-[#16113a] p-5'>
                            <div className='flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between'>
                                <h2 className='text-lg font-semibold text-white'>
                                    Recent Paymenter Webhooks
                                </h2>
                                <span className='text-xs uppercase tracking-[0.22em] text-white/45'>
                                    Last 20 deliveries
                                </span>
                            </div>
                            <div className='mt-4 space-y-3'>
                                {paymenter.logs.length === 0 ? (
                                    <div className='rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white/60'>
                                        No Paymenter webhook traffic has been recorded yet.
                                    </div>
                                ) : (
                                    paymenter.logs.map((log: any) => (
                                        <div
                                            key={log.id}
                                            className='rounded-xl border border-white/10 bg-white/[0.04] p-4'
                                        >
                                            <div className='flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between'>
                                                <div className='min-w-0'>
                                                    <p className='break-words text-sm font-semibold text-white'>
                                                        {log.event}
                                                    </p>
                                                    <p className='mt-1 text-xs text-white/45'>
                                                        {log.reseller?.displayName || 'Unknown reseller'}
                                                    </p>
                                                </div>
                                                <span className='rounded-full border border-white/10 bg-white/8 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-white/65'>
                                                    {log.status}
                                                </span>
                                            </div>
                                            <p className='mt-2 break-all text-xs text-white/50'>
                                                {log.externalServiceId || log.externalOrderId || log.externalInvoiceId || 'No external ids'}
                                            </p>
                                            <p className='mt-1 text-xs text-white/45'>
                                                {log.createdAt
                                                    ? formatDistanceToNow(log.createdAt, {
                                                          addSuffix: true,
                                                      })
                                                    : '-'}
                                            </p>
                                            {log.errorMessage ? (
                                                <p className='mt-2 text-xs text-rose-200'>
                                                    {log.errorMessage}
                                                </p>
                                            ) : null}
                                        </div>
                                    ))
                                )}
                            </div>
                        </div>
                    </div>
                ) : null}

                <div className='grid items-start gap-5 2xl:grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)]'>
                    <div className='min-w-0 rounded-2xl border border-white/10 bg-[#16113a] p-5'>
                        <div className='flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between'>
                            <h2 className='text-lg font-semibold text-white'>Admin Alerts</h2>
                            <Link to='/admin/security' className='self-start text-xs font-semibold uppercase tracking-[0.18em] text-sky-200/80 hover:text-sky-100 sm:self-auto'>
                                Open security workspace
                            </Link>
                        </div>
                        <div className='mt-4 space-y-3'>
                            {alerts.length === 0 ? (
                                <div className='rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white/60'>
                                    No active admin alerts right now.
                                </div>
                            ) : (
                                alerts.map(alert => (
                                    <div key={alert.id} className='rounded-xl border border-white/10 bg-white/[0.04] p-4'>
                                        <div className='flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between'>
                                            <div>
                                                <div className='flex flex-wrap items-center gap-2'>
                                                    <span className='rounded-full border border-white/10 bg-white/8 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-white/65'>
                                                        {alert.type}
                                                    </span>
                                                    <span className='rounded-full border border-rose-300/20 bg-rose-500/10 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-rose-100'>
                                                        {alert.severity}
                                                    </span>
                                                </div>
                                                <p className='mt-3 text-sm font-semibold text-white'>{alert.title}</p>
                                                <p className='mt-1 text-sm text-white/60'>{alert.message || 'No extra context provided.'}</p>
                                                <p className='mt-2 text-xs text-white/45'>
                                                    {alert.user?.email || alert.reseller?.displayName || alert.server?.uuid || 'Platform signal'}
                                                </p>
                                            </div>
                                            {alert.status === 'open' ? (
                                                <button
                                                    onClick={() => void acknowledgeAlert(alert.id)}
                                                    className='rounded-xl border border-emerald-300/20 bg-emerald-500/10 px-3 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-emerald-100 hover:bg-emerald-500/18'
                                                >
                                                    Acknowledge
                                                </button>
                                            ) : null}
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>

                    <div className='min-w-0 rounded-2xl border border-white/10 bg-[#16113a] p-5'>
                        <div className='flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between'>
                            <h2 className='text-lg font-semibold text-white'>Abuse Hotspots</h2>
                            <Link to='/admin/security' className='self-start text-xs font-semibold uppercase tracking-[0.18em] text-sky-200/80 hover:text-sky-100 sm:self-auto'>
                                Investigate
                            </Link>
                        </div>
                        <div className='mt-4 space-y-3'>
                            {overview.abuseHotspots.length === 0 ? (
                                <div className='rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white/60'>
                                    No abuse hotspots are above threshold right now.
                                </div>
                            ) : (
                                overview.abuseHotspots.map((hotspot: any) => (
                                    <div key={`${hotspot.serverUuid}-${hotspot.score}`} className='rounded-xl border border-white/10 bg-white/[0.04] p-4'>
                                        <div className='flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between'>
                                            <div className='min-w-0'>
                                                <p className='break-words text-sm font-semibold text-white'>{hotspot.serverName || hotspot.serverUuid}</p>
                                                <p className='mt-1 break-all text-xs text-white/45'>
                                                    {hotspot.ownerEmail || 'Unknown owner'} - {hotspot.resellerName || 'No reseller'}
                                                </p>
                                            </div>
                                            <div className='shrink-0 text-left sm:text-right'>
                                                <p className='text-lg font-semibold text-rose-200'>{hotspot.score}</p>
                                                <p className='text-[11px] uppercase tracking-[0.18em] text-white/45'>Score</p>
                                            </div>
                                        </div>
                                        <div className='mt-3 grid gap-2 text-xs text-white/65 sm:grid-cols-2'>
                                            <div>Outbound: {hotspot.lastOutboundMbps} Mbps</div>
                                            <div>Suspension threshold: {hotspot.suspendThreshold}</div>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>

                <div className='grid items-start gap-5 2xl:grid-cols-[minmax(0,1.1fr)_minmax(0,0.9fr)]'>
                    <div className='min-w-0 overflow-hidden rounded-2xl border border-white/10 bg-[#16113a] p-5'>
                        <div className='flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between'>
                            <h2 className='text-lg font-semibold text-white'>Recent Audit Trail</h2>
                            <Link to='/admin/users' className='self-start text-xs font-semibold uppercase tracking-[0.18em] text-sky-200/80 hover:text-sky-100 sm:self-auto'>
                                Open users
                            </Link>
                        </div>
                        <div className='mt-4 overflow-x-auto rounded-xl border border-white/10'>
                            <table className='w-full min-w-[680px] table-fixed text-left text-sm text-white/85'>
                                <thead>
                                    <tr className='border-b border-white/10 text-white/45'>
                                        <th className='w-[28%] px-3 py-2'>Action</th>
                                        <th className='w-[18%] px-3 py-2'>Actor</th>
                                        <th className='w-[28%] px-3 py-2'>Path</th>
                                        <th className='w-[14%] px-3 py-2'>IP</th>
                                        <th className='w-[12%] px-3 py-2'>Time</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {auditLogs.map(log => (
                                        <tr key={log.id} className='border-b border-white/5 align-top'>
                                            <td className='px-3 py-3'>
                                                <div className='break-all font-medium text-white'>{log.action}</div>
                                                <div className='text-xs text-white/45'>{log.statusCode || '-'} - {log.requestMethod || '-'}</div>
                                            </td>
                                            <td className='break-all px-3 py-3'>{log.actorType}#{log.actorId || '-'}</td>
                                            <td className='break-all px-3 py-3 text-white/60'>{log.path || '-'}</td>
                                            <td className='break-all px-3 py-3'>{log.ipAddress || '-'}</td>
                                            <td className='px-3 py-3 text-white/60'>
                                                {log.createdAt
                                                    ? formatDistanceToNow(log.createdAt, {
                                                          addSuffix: true,
                                                      })
                                                    : '-'}
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div className='min-w-0 rounded-2xl border border-white/10 bg-[#16113a] p-5'>
                        <div className='flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between'>
                            <h2 className='text-lg font-semibold text-white'>Tenant Snapshot</h2>
                            <Link to='/admin/resellers' className='self-start text-xs font-semibold uppercase tracking-[0.18em] text-sky-200/80 hover:text-sky-100 sm:self-auto'>
                                Manage tenants
                            </Link>
                        </div>
                        <div className='mt-4 space-y-3'>
                            {visibleTenants.length === 0 ? (
                                <div className='rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white/60'>
                                    No reseller workspaces have been created yet. This area will start filling after you approve and activate real reseller tenants.
                                </div>
                            ) : (
                                visibleTenants.map((tenant: any) => (
                                    <div key={tenant.id} className='rounded-xl border border-white/10 bg-white/[0.04] p-4'>
                                        <div className='flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between'>
                                            <div className='min-w-0'>
                                                <p className='break-words text-sm font-semibold text-white'>{tenant.displayName}</p>
                                                <p className='mt-1 break-words text-xs text-white/45'>
                                                    {tenant.status} - {tenant.verificationStatus}
                                                </p>
                                            </div>
                                            <div className='shrink-0 text-left text-xs text-white/60 sm:text-right'>
                                                <div>{tenant.usersCount} users</div>
                                                <div>{tenant.serversCount} servers</div>
                                            </div>
                                        </div>
                                        <div className='mt-3 h-2 rounded-full bg-white/10'>
                                            <div
                                                className='h-2 rounded-full bg-gradient-to-r from-sky-400 via-indigo-400 to-fuchsia-400'
                                                style={{
                                                    width: `${Math.min(
                                                        100,
                                                        tenant.maxVms > 0
                                                            ? (tenant.usedVms / tenant.maxVms) * 100
                                                            : 0
                                                    )}%`,
                                                }}
                                            />
                                        </div>
                                        <p className='mt-2 text-xs text-white/45'>
                                            {tenant.usedVms} / {tenant.maxVms} VMs used
                                        </p>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>

                <div className='grid items-start gap-5 2xl:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]'>
                    <div className='min-w-0 rounded-2xl border border-white/10 bg-[#16113a] p-5'>
                        <div className='flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between'>
                            <h2 className='text-lg font-semibold text-white'>Platform Roles</h2>
                            <button
                                onClick={beginCreateRole}
                                className='self-start rounded-xl border border-sky-300/20 bg-sky-500/10 px-3 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-sky-100 hover:bg-sky-500/18 sm:self-auto'
                            >
                                New role
                            </button>
                        </div>

                        <div className='mt-4 space-y-3'>
                            {roles.map(role => (
                                <div key={role.id} className='rounded-xl border border-white/10 bg-white/[0.04] p-4'>
                                    <div className='flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between'>
                                        <div className='min-w-0'>
                                            <div className='flex flex-wrap items-center gap-2'>
                                                <p className='break-words text-sm font-semibold text-white'>{role.name}</p>
                                                {role.isSystem ? (
                                                    <span className='rounded-full border border-white/10 bg-white/8 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-white/65'>
                                                        System
                                                    </span>
                                                ) : null}
                                            </div>
                                            <p className='mt-1 break-all text-xs text-white/45'>{role.slug}</p>
                                            <p className='mt-2 break-words text-sm text-white/60'>{role.description || 'No description provided.'}</p>
                                            <p className='mt-2 text-xs text-white/45'>
                                                {role.permissions.length} permissions - {role.usersCount} assigned users
                                            </p>
                                        </div>
                                        <div className='flex shrink-0 flex-wrap gap-2'>
                                            <button
                                                onClick={() => beginEditRole(role)}
                                                className='rounded-xl border border-white/10 bg-white/8 px-3 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-white/75 hover:bg-white/12'
                                            >
                                                Edit
                                            </button>
                                            {!role.isSystem ? (
                                                <button
                                                    onClick={() => void removeRole(role)}
                                                    className='rounded-xl border border-rose-300/20 bg-rose-500/10 px-3 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-rose-100 hover:bg-rose-500/18'
                                                >
                                                    Delete
                                                </button>
                                            ) : null}
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className='min-w-0 rounded-2xl border border-white/10 bg-[#16113a] p-5'>
                        <h2 className='text-lg font-semibold text-white'>
                            {editingRoleId === 'new'
                                ? 'Create platform role'
                                : editingRoleId
                                ? 'Edit platform role'
                                : 'Role editor'}
                        </h2>
                        <div className='mt-4 space-y-4'>
                            <div>
                                <label className='mb-2 block text-xs font-semibold uppercase tracking-[0.18em] text-white/45'>
                                    Role name
                                </label>
                                <input
                                    value={roleForm.name}
                                    onChange={event => {
                                        const value = event.currentTarget.value

                                        setRoleForm(current => ({
                                            ...current,
                                            name: value,
                                        }))
                                    }}
                                    className='w-full rounded-xl border border-white/10 bg-[#0e0b29] px-4 py-3 text-sm text-white outline-none focus:border-sky-300/40'
                                    placeholder='Platform Operator'
                                />
                            </div>
                            <div>
                                <label className='mb-2 block text-xs font-semibold uppercase tracking-[0.18em] text-white/45'>
                                    Slug
                                </label>
                                <input
                                    value={roleForm.slug}
                                    onChange={event => {
                                        const value = event.currentTarget.value

                                        setRoleForm(current => ({
                                            ...current,
                                            slug: value,
                                        }))
                                    }}
                                    className='w-full rounded-xl border border-white/10 bg-[#0e0b29] px-4 py-3 text-sm text-white outline-none focus:border-sky-300/40'
                                    placeholder='platform-operator'
                                />
                            </div>
                            <div>
                                <label className='mb-2 block text-xs font-semibold uppercase tracking-[0.18em] text-white/45'>
                                    Description
                                </label>
                                <textarea
                                    value={roleForm.description}
                                    onChange={event => {
                                        const value = event.currentTarget.value

                                        setRoleForm(current => ({
                                            ...current,
                                            description: value,
                                        }))
                                    }}
                                    rows={3}
                                    className='w-full rounded-xl border border-white/10 bg-[#0e0b29] px-4 py-3 text-sm text-white outline-none focus:border-sky-300/40'
                                    placeholder='What this staff role should be allowed to do.'
                                />
                            </div>
                            <div className='max-h-[360px] overflow-y-auto rounded-2xl border border-white/10 bg-[#0e0b29] p-4'>
                                {Object.entries(groupedPermissions).map(([group, items]) => (
                                    <div key={group} className='mb-5 last:mb-0'>
                                        <p className='mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-white/45'>
                                            {group}
                                        </p>
                                        <div className='space-y-2'>
                                            {items.map(permission => (
                                                <label key={permission.key} className='flex items-start gap-3 rounded-xl border border-white/8 bg-white/[0.03] px-3 py-3 text-sm text-white/80'>
                                                    <input
                                                        type='checkbox'
                                                        checked={roleForm.permissions.includes(permission.key)}
                                                        onChange={event => {
                                                            const checked = event.currentTarget.checked

                                                            setRoleForm(current => ({
                                                                ...current,
                                                                permissions: checked
                                                                    ? [...current.permissions, permission.key]
                                                                    : current.permissions.filter(
                                                                          item => item !== permission.key
                                                                      ),
                                                            }))
                                                        }}
                                                        className='mt-1 h-4 w-4 rounded border-white/20 bg-transparent text-sky-400'
                                                    />
                                                    <span className='min-w-0'>
                                                        <span className='block break-words font-medium text-white'>{permission.label}</span>
                                                        <span className='mt-1 block text-xs text-white/45'>
                                                            {permission.description}
                                                        </span>
                                                    </span>
                                                </label>
                                            ))}
                                        </div>
                                    </div>
                                ))}
                            </div>
                            <div className='flex flex-wrap gap-3'>
                                <button
                                    disabled={!editingRoleId || savingRoleId !== null}
                                    onClick={() => void saveRole()}
                                    className='rounded-xl border border-sky-300/20 bg-sky-500/12 px-4 py-3 text-sm font-semibold text-sky-100 hover:bg-sky-500/18 disabled:opacity-50'
                                >
                                    {savingRoleId ? 'Saving...' : 'Save role'}
                                </button>
                                {editingRoleId ? (
                                    <button
                                        onClick={() => setEditingRoleId(null)}
                                        className='rounded-xl border border-white/10 bg-white/8 px-4 py-3 text-sm font-semibold text-white/70 hover:bg-white/12'
                                    >
                                        Cancel
                                    </button>
                                ) : null}
                            </div>
                        </div>
                    </div>
                </div>

                <div className='rounded-2xl border border-white/10 bg-[#16113a] p-5'>
                    <div className='flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between'>
                        <h2 className='text-lg font-semibold text-white'>Platform Staff Access</h2>
                        <Link to='/admin/users' className='self-start text-xs font-semibold uppercase tracking-[0.18em] text-sky-200/80 hover:text-sky-100 sm:self-auto'>
                            Open user admin
                        </Link>
                    </div>
                    <div className='mt-4 grid gap-4 2xl:grid-cols-2'>
                        {staff.map(member => (
                            <div key={member.id} className='rounded-xl border border-white/10 bg-white/[0.04] p-4'>
                                <div className='flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between'>
                                    <div className='min-w-0'>
                                        <p className='break-words text-sm font-semibold text-white'>{member.name}</p>
                                        <p className='mt-1 break-all text-xs text-white/45'>{member.email}</p>
                                        <p className='mt-2 break-words text-xs text-white/45'>
                                            {member.rootAdmin ? 'Root admin' : member.roleName}
                                            {member.lastLoginIp ? ` - ${member.lastLoginIp}` : ''}
                                        </p>
                                    </div>
                                    <span className='self-start rounded-full border border-white/10 bg-white/8 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-white/65 sm:self-auto'>
                                        {member.rootAdmin ? 'Full access' : member.isPlatformAdmin ? 'RBAC admin' : 'User'}
                                    </span>
                                </div>

                                {!member.rootAdmin ? (
                                    <div className='mt-4 space-y-3'>
                                        <div className='grid gap-2'>
                                            {roles.map(role => (
                                                <label key={`${member.id}-${role.id}`} className='flex items-center gap-3 rounded-xl border border-white/8 bg-white/[0.03] px-3 py-2 text-sm text-white/75'>
                                                    <input
                                                        type='checkbox'
                                                        checked={member.adminRoles.some(item => item.id === role.id)}
                                                        onChange={event => {
                                                            const next = event.target.checked
                                                                ? [...member.adminRoles.map(item => item.id), role.id]
                                                                : member.adminRoles
                                                                      .map(item => item.id)
                                                                      .filter(id => id !== role.id)

                                                            void syncStaffRoles(member, next)
                                                        }}
                                                        className='h-4 w-4 rounded border-white/20 bg-transparent text-sky-400'
                                                    />
                                                    <span>{role.name}</span>
                                                </label>
                                            ))}
                                        </div>
                                    </div>
                                ) : null}
                            </div>
                        ))}
                    </div>
                </div>

                <div className='grid items-start gap-5 2xl:grid-cols-2'>
                    <div className='min-w-0 rounded-2xl border border-white/10 bg-[#16113a] p-5'>
                        <h2 className='text-lg font-semibold text-white'>Activity Feed</h2>
                        <div className='mt-4 space-y-3'>
                            {activity.map(item => (
                                <div key={item.id} className='rounded-xl border border-white/10 bg-white/[0.04] p-4'>
                                    <div className='flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between'>
                                        <div>
                                            <p className='text-sm font-semibold text-white'>{item.event}</p>
                                            <p className='mt-1 text-xs text-white/45'>{item.actor?.label || item.ip}</p>
                                        </div>
                                        <p className='text-xs text-white/45'>
                                            {item.timestamp
                                                ? formatDistanceToNow(item.timestamp, {
                                                      addSuffix: true,
                                                  })
                                                : '-'}
                                        </p>
                                    </div>
                                    <p className='mt-2 text-sm text-white/60'>
                                        {item.description || 'No description provided.'}
                                    </p>
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className='min-w-0 rounded-2xl border border-white/10 bg-[#16113a] p-5'>
                        <h2 className='text-lg font-semibold text-white'>Platform Admin IP Logs</h2>
                        <div className='mt-4 space-y-3'>
                            {ipLogs.map(log => (
                                <div key={log.id} className='rounded-xl border border-white/10 bg-white/[0.04] p-4'>
                                    <div className='flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between'>
                                        <div>
                                            <p className='text-sm font-semibold text-white'>{log.email || 'Unknown account'}</p>
                                            <p className='mt-1 text-xs text-white/45'>
                                                {log.ipAddress || 'Unknown IP'}
                                                {log.countryCode ? ` - ${log.countryCode}` : ''}
                                                {log.city ? ` - ${log.city}` : ''}
                                            </p>
                                        </div>
                                        <span
                                            className={`rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] ${
                                                log.isSuspicious
                                                    ? 'border border-rose-300/20 bg-rose-500/10 text-rose-100'
                                                    : 'border border-emerald-300/20 bg-emerald-500/10 text-emerald-100'
                                            }`}
                                        >
                                            {log.isSuspicious ? 'Suspicious' : 'Normal'}
                                        </span>
                                    </div>
                                    <p className='mt-2 text-xs text-white/45'>
                                        {log.createdAt
                                            ? formatDistanceToNow(log.createdAt, {
                                                  addSuffix: true,
                                              })
                                            : '-'}
                                    </p>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </PageContentBlock>
    )
}

export default RootAdminControlContainer

