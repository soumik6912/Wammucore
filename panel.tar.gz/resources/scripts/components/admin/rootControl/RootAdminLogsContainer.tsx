import {
    getRootControlLogs,
    RootControlLogCategory,
    RootControlLogItem,
    RootControlLogSeverity,
    RootControlLogSource,
} from '@/api/admin/rootControl/getRootControlLogs'
import { httpErrorToHuman } from '@/api/http'
import PageContentBlock from '@/components/elements/PageContentBlock'
import { NavigationBarContext } from '@/components/elements/navigation/NavigationBar'
import { useDebouncedValue } from '@mantine/hooks'
import { formatDistanceToNow } from 'date-fns'
import { useContext, useEffect, useMemo, useState } from 'react'
import useSWR from 'swr'

const selectClass =
    'rounded-xl border border-white/10 bg-[#0e0b29] px-3 py-2.5 text-sm text-white outline-none focus:border-sky-300/40'

const sourceOptions: Array<{ value: RootControlLogSource; label: string }> = [
    { value: 'all', label: 'All sources' },
    { value: 'application', label: 'Application logs' },
    { value: 'audit', label: 'Audit' },
    { value: 'activity', label: 'Activity' },
    { value: 'auth', label: 'Auth/IP' },
    { value: 'admin_alert', label: 'Admin alerts' },
    { value: 'security_event', label: 'Security events' },
    { value: 'security_alert', label: 'Security alerts' },
    { value: 'paymenter', label: 'Paymenter' },
    { value: 'provisioning', label: 'Provisioning' },
    { value: 'resource_guard', label: 'Resource guard' },
]

const categoryOptions: Array<{ value: RootControlLogCategory; label: string }> = [
    { value: 'all', label: 'All categories' },
    { value: 'suspension', label: 'Suspensions' },
    { value: 'server', label: 'Servers' },
    { value: 'provisioning', label: 'Provisioning' },
    { value: 'paymenter', label: 'Paymenter' },
    { value: 'resource_guard', label: 'Over-allocation guard' },
    { value: 'security', label: 'Security' },
    { value: 'error', label: 'Errors' },
    { value: 'application', label: 'Application' },
    { value: 'auth', label: 'Auth/IP' },
    { value: 'admin', label: 'Admin' },
    { value: 'alert', label: 'Alerts' },
    { value: 'audit', label: 'Audit' },
]

const severityOptions: Array<{ value: RootControlLogSeverity; label: string }> = [
    { value: 'all', label: 'All severity' },
    { value: 'critical', label: 'Critical' },
    { value: 'error', label: 'Error' },
    { value: 'warning', label: 'Warning' },
    { value: 'info', label: 'Info' },
    { value: 'debug', label: 'Debug' },
]

const severityClass = (severity: string): string => {
    switch (severity) {
        case 'critical':
            return 'border-red-300/25 bg-red-500/15 text-red-100'
        case 'error':
            return 'border-rose-300/25 bg-rose-500/15 text-rose-100'
        case 'warning':
            return 'border-amber-300/25 bg-amber-500/15 text-amber-100'
        case 'debug':
            return 'border-violet-300/25 bg-violet-500/15 text-violet-100'
        default:
            return 'border-emerald-300/25 bg-emerald-500/15 text-emerald-100'
    }
}

const humanKey = (value: string): string =>
    value
        .replace(/_/g, ' ')
        .replace(/\b\w/g, letter => letter.toUpperCase())

const formatWhen = (date: Date | null): string => {
    if (!date) {
        return '-'
    }

    return `${date.toLocaleString()} - ${formatDistanceToNow(date, {
        addSuffix: true,
    })}`
}

const subjectLabel = (item: RootControlLogItem): string => {
    if (item.server) {
        return `${item.server.name || 'Server'}${item.server.uuid ? ` (${item.server.uuid})` : ''}`
    }

    if (item.userEmail) {
        return item.userEmail
    }

    if (item.subject.type) {
        return `${item.subject.type}#${item.subject.id || '-'}`
    }

    return 'Platform'
}

const RootAdminLogsContainer = () => {
    const { setBreadcrumb } = useContext(NavigationBarContext)
    const [page, setPage] = useState(1)
    const [perPage, setPerPage] = useState<50 | 100>(50)
    const [source, setSource] = useState<RootControlLogSource>('all')
    const [category, setCategory] = useState<RootControlLogCategory>('all')
    const [severity, setSeverity] = useState<RootControlLogSeverity>('all')
    const [queryInput, setQueryInput] = useState('')
    const [debouncedQuery] = useDebouncedValue(queryInput, 350)

    useEffect(() => {
        setBreadcrumb('Audit Logs')

        return () => setBreadcrumb(null)
    }, [setBreadcrumb])

    useEffect(() => {
        setPage(1)
    }, [source, category, severity, perPage, debouncedQuery])

    const request = useMemo(
        () => ({
            page,
            perPage,
            source,
            category,
            severity,
            query: debouncedQuery,
        }),
        [page, perPage, source, category, severity, debouncedQuery]
    )

    const { data, error, isValidating, mutate } = useSWR(
        ['root-control-logs', request],
        () => getRootControlLogs(request),
        {
            keepPreviousData: true,
        }
    )

    const logs = data?.items || []
    const meta = data?.meta
    const errorMessage = error ? httpErrorToHuman(error) : null

    return (
        <PageContentBlock title='Audit Logs' containerSize='wide'>
            <div className='space-y-5'>
                <div className='rounded-[1.5rem] border border-white/10 bg-[linear-gradient(180deg,rgba(16,15,49,0.98),rgba(10,8,28,0.98))] p-5 shadow-[0_18px_60px_rgba(5,5,20,0.35)]'>
                    <div className='flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between'>
                        <div>
                            <p className='text-xs font-semibold uppercase tracking-[0.2em] text-sky-100/70'>
                                Root Admin Only
                            </p>
                            <h1 className='mt-2 text-2xl font-semibold text-white'>
                                Logs
                            </h1>
                            <p className='mt-2 max-w-3xl text-sm leading-6 text-white/60'>
                                Last {meta?.windowDays || 90} days across admin actions, errors, server lifecycle events, suspensions, resource guard stops, security events, login/IP signals, and Paymenter webhooks.
                            </p>
                        </div>
                        <button
                            type='button'
                            onClick={() => void mutate()}
                            className='rounded-xl border border-sky-300/20 bg-sky-500/12 px-4 py-2.5 text-sm font-semibold text-sky-100 transition hover:bg-sky-500/18'
                        >
                            {isValidating ? 'Refreshing...' : 'Refresh'}
                        </button>
                    </div>
                </div>

                <div className='rounded-2xl border border-white/10 bg-[#16113a] p-4'>
                    <div className='grid gap-3 lg:grid-cols-[minmax(180px,1fr)_minmax(160px,0.8fr)_minmax(150px,0.7fr)_minmax(120px,0.5fr)]'>
                        <input
                            value={queryInput}
                            onChange={event => setQueryInput(event.currentTarget.value)}
                            placeholder='Search server UUID, email, action, reason, IP, path...'
                            className='rounded-xl border border-white/10 bg-[#0e0b29] px-3 py-2.5 text-sm text-white outline-none placeholder:text-white/35 focus:border-sky-300/40'
                        />
                        <select
                            value={source}
                            onChange={event =>
                                setSource(event.currentTarget.value as RootControlLogSource)
                            }
                            className={selectClass}
                        >
                            {sourceOptions.map(option => (
                                <option key={option.value} value={option.value}>
                                    {option.label}
                                </option>
                            ))}
                        </select>
                        <select
                            value={category}
                            onChange={event =>
                                setCategory(
                                    event.currentTarget.value as RootControlLogCategory
                                )
                            }
                            className={selectClass}
                        >
                            {categoryOptions.map(option => (
                                <option key={option.value} value={option.value}>
                                    {option.label}
                                </option>
                            ))}
                        </select>
                        <select
                            value={severity}
                            onChange={event =>
                                setSeverity(
                                    event.currentTarget.value as RootControlLogSeverity
                                )
                            }
                            className={selectClass}
                        >
                            {severityOptions.map(option => (
                                <option key={option.value} value={option.value}>
                                    {option.label}
                                </option>
                            ))}
                        </select>
                    </div>
                    <div className='mt-3 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between'>
                        <div className='text-xs text-white/45'>
                            {meta
                                ? `${meta.total} entries found. Showing ${meta.count} on page ${meta.currentPage} of ${meta.totalPages}.`
                                : 'Loading logs...'}
                            {meta?.cutoff ? ` Window starts ${meta.cutoff.toLocaleString()}.` : ''}
                        </div>
                        <select
                            value={perPage}
                            onChange={event =>
                                setPerPage(Number(event.currentTarget.value) as 50 | 100)
                            }
                            className={selectClass}
                        >
                            <option value={50}>50 per page</option>
                            <option value={100}>100 per page</option>
                        </select>
                    </div>
                </div>

                {errorMessage ? (
                    <div className='rounded-xl border border-rose-300/20 bg-rose-500/10 px-4 py-3 text-sm text-rose-100'>
                        {errorMessage}
                    </div>
                ) : null}

                <div className='overflow-hidden rounded-2xl border border-white/10 bg-[#16113a]'>
                    <div className='grid grid-cols-[170px_minmax(0,1fr)_minmax(180px,0.45fr)] border-b border-white/10 bg-white/[0.04] px-4 py-3 text-xs font-semibold uppercase tracking-[0.16em] text-white/45 max-xl:hidden'>
                        <span>When</span>
                        <span>Event</span>
                        <span>Target</span>
                    </div>

                    {logs.length === 0 && !isValidating ? (
                        <div className='px-5 py-10 text-center text-sm text-white/55'>
                            No log entries match these filters.
                        </div>
                    ) : null}

                    <div className='divide-y divide-white/8'>
                        {logs.map(item => {
                            const hasContext = Object.keys(item.context).length > 0

                            return (
                                <div
                                    key={item.id}
                                    className='grid gap-4 px-4 py-4 xl:grid-cols-[170px_minmax(0,1fr)_minmax(180px,0.45fr)]'
                                >
                                    <div className='text-xs text-white/45'>
                                        {formatWhen(item.occurredAt)}
                                    </div>
                                    <div className='min-w-0'>
                                        <div className='flex flex-wrap items-center gap-2'>
                                            <span
                                                className={`rounded-full border px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.16em] ${severityClass(
                                                    item.severity
                                                )}`}
                                            >
                                                {item.severity}
                                            </span>
                                            <span className='rounded-full border border-white/10 bg-white/8 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-white/65'>
                                                {humanKey(item.source)}
                                            </span>
                                            <span className='rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-white/50'>
                                                {humanKey(item.category)}
                                            </span>
                                        </div>
                                        <p className='mt-3 break-words text-sm font-semibold text-white'>
                                            {item.title}
                                        </p>
                                        {item.message ? (
                                            <p className='mt-2 break-words text-sm leading-6 text-white/65'>
                                                {item.message}
                                            </p>
                                        ) : null}
                                        {item.reason ? (
                                            <div className='mt-3 rounded-xl border border-amber-300/15 bg-amber-500/8 px-3 py-2 text-sm leading-6 text-amber-100/85'>
                                                <span className='font-semibold'>Reason: </span>
                                                {item.reason}
                                            </div>
                                        ) : null}
                                        <div className='mt-3 flex flex-wrap gap-2 text-xs text-white/45'>
                                            {item.actor.type ? (
                                                <span>
                                                    Actor: {humanKey(item.actor.type)}
                                                    {item.actor.id ? `#${item.actor.id}` : ''}
                                                </span>
                                            ) : null}
                                            {item.requestMethod || item.path ? (
                                                <span>
                                                    {item.requestMethod || 'GET'} {item.path || '-'}
                                                </span>
                                            ) : null}
                                            {item.ipAddress ? <span>IP: {item.ipAddress}</span> : null}
                                            {item.resellerId ? (
                                                <span>Reseller #{item.resellerId}</span>
                                            ) : null}
                                        </div>
                                        {hasContext ? (
                                            <details className='mt-3 rounded-xl border border-white/10 bg-[#0e0b29] px-3 py-2'>
                                                <summary className='cursor-pointer text-xs font-semibold uppercase tracking-[0.16em] text-sky-100/75'>
                                                    Context
                                                </summary>
                                                <pre className='mt-3 max-h-80 overflow-auto whitespace-pre-wrap break-words text-xs leading-5 text-white/65'>
                                                    {JSON.stringify(item.context, null, 2)}
                                                </pre>
                                            </details>
                                        ) : null}
                                    </div>
                                    <div className='min-w-0 rounded-xl border border-white/10 bg-white/[0.03] px-3 py-3 text-sm text-white/70 xl:bg-transparent'>
                                        <p className='break-words font-semibold text-white'>
                                            {subjectLabel(item)}
                                        </p>
                                        {item.userEmail ? (
                                            <p className='mt-1 break-all text-xs text-white/45'>
                                                {item.userEmail}
                                            </p>
                                        ) : null}
                                        {item.server?.uuid ? (
                                            <p className='mt-1 break-all text-xs text-white/45'>
                                                {item.server.uuid}
                                            </p>
                                        ) : null}
                                    </div>
                                </div>
                            )
                        })}
                    </div>
                </div>

                <div className='flex flex-col gap-3 rounded-2xl border border-white/10 bg-[#16113a] px-4 py-3 sm:flex-row sm:items-center sm:justify-between'>
                    <button
                        type='button'
                        disabled={!meta || meta.currentPage <= 1}
                        onClick={() => setPage(current => Math.max(1, current - 1))}
                        className='rounded-xl border border-white/10 bg-white/8 px-4 py-2 text-sm font-semibold text-white/75 transition hover:bg-white/12 disabled:cursor-not-allowed disabled:opacity-40'
                    >
                        Previous
                    </button>
                    <p className='text-center text-sm text-white/55'>
                        Page {meta?.currentPage || page} / {meta?.totalPages || 1}
                    </p>
                    <button
                        type='button'
                        disabled={!meta || meta.currentPage >= meta.totalPages}
                        onClick={() => setPage(current => current + 1)}
                        className='rounded-xl border border-white/10 bg-white/8 px-4 py-2 text-sm font-semibold text-white/75 transition hover:bg-white/12 disabled:cursor-not-allowed disabled:opacity-40'
                    >
                        Next
                    </button>
                </div>
            </div>
        </PageContentBlock>
    )
}

export default RootAdminLogsContainer
