import { ArrowPathIcon, ExclamationTriangleIcon, QueueListIcon, ServerStackIcon, WrenchScrewdriverIcon } from '@heroicons/react/24/outline'
import { useMemo, useState } from 'react'

import useDiagnosticsSWR from '@/api/admin/diagnostics/useDiagnosticsSWR'
import { DiagnosticsServiceLine } from '@/api/admin/diagnostics/types'
import PageContentBlock from '@/components/elements/PageContentBlock'
import Spinner from '@/components/elements/Spinner'
import { MetricCard, cardClassName } from '@/components/admin/security/SecurityUi'

const categoryClassNames: Record<string, string> = {
    provisioning: 'border-amber-400/30 bg-amber-500/10 text-amber-100',
    paymenter: 'border-sky-400/30 bg-sky-500/10 text-sky-100',
    proxmox: 'border-orange-400/30 bg-orange-500/10 text-orange-100',
    metrics: 'border-fuchsia-400/30 bg-fuchsia-500/10 text-fuchsia-100',
    application: 'border-white/15 bg-white/10 text-white/75',
}

const severityClassNames: Record<DiagnosticsServiceLine['severity'], string> = {
    error: 'text-rose-100',
    info: 'text-white/65',
}

const CategoryBadge = ({ category }: { category: string }) => (
    <span
        className={`inline-flex items-center rounded-full border px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] ${
            categoryClassNames[category] ?? categoryClassNames.application
        }`}
    >
        {category}
    </span>
)

const ServiceLogPanel = ({
    title,
    lines,
}: {
    title: string
    lines: DiagnosticsServiceLine[]
}) => (
    <section className={`${cardClassName} overflow-hidden p-5`}>
        <div className='flex items-center justify-between gap-3'>
            <div>
                <h2 className='text-lg font-semibold text-white'>{title}</h2>
                <p className='mt-1 text-sm text-white/55'>
                    Recent service output for fast admin troubleshooting.
                </p>
            </div>
            <span className='rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-white/45'>
                {lines.length} lines
            </span>
        </div>
            <div className='theme-panel-inner mt-4 rounded-2xl p-4'>
            <div className='max-h-[24rem] space-y-2 overflow-auto font-mono text-xs leading-6'>
                {lines.length ? (
                    lines.map((item, index) => (
                        <div key={`${title}-${index}`} className={severityClassNames[item.severity]}>
                            {item.line}
                        </div>
                    ))
                ) : (
                    <div className='text-white/35'>No matching log lines.</div>
                )}
            </div>
        </div>
    </section>
)

const DiagnosticsContainer = () => {
    const [input, setInput] = useState('')
    const [query, setQuery] = useState('')
    const { data, mutate } = useDiagnosticsSWR(query)

    const failedJobs = data?.failedJobs ?? []
    const applicationErrors = data?.applicationErrors ?? []
    const serviceLogs = data?.serviceLogs

    const helperText = useMemo(() => {
        if (query.trim() === '') {
            return 'Search by VMID, server id, hostname, UUID, Paymenter, clone, reinstall, suspend, or any log fragment.'
        }

        return `Filtered by "${query}".`
    }, [query])

    return (
        <div className='theme-page min-h-screen'>
            <PageContentBlock title='Diagnostics - Admin' containerSize='wide'>
                <div className='space-y-6'>
                    <section className={`${cardClassName} overflow-hidden p-6`}>
                        <div className='flex flex-col gap-5 xl:flex-row xl:items-end xl:justify-between'>
                            <div className='max-w-3xl'>
                                <p className='theme-eyebrow text-xs font-semibold uppercase tracking-[0.32em]'>
                                    Admin Diagnostics
                                </p>
                                <h1 className='mt-3 text-3xl font-semibold tracking-tight text-white'>
                                    Logs and provisioning health
                                </h1>
                                <p className='mt-3 max-w-2xl text-sm leading-7 text-white/60'>
                                    Check failed jobs, provisioning blockers, recent application exceptions, and worker service logs in one place. This is meant to answer why VPS create, reinstall, suspend, or Paymenter-triggered actions are failing without opening the shell.
                                </p>
                            </div>
                            <div className='flex w-full max-w-2xl flex-col gap-3 xl:items-end'>
                                <form
                                    className='flex w-full gap-3'
                                    onSubmit={event => {
                                        event.preventDefault()
                                        setQuery(input.trim())
                                    }}
                                >
                                    <input
                                        value={input}
                                        onChange={event => setInput(event.currentTarget.value)}
                                        className='theme-input w-full rounded-2xl px-4 py-3 text-sm transition'
                                        placeholder='Search by VMID, UUID, hostname, Paymenter, clone, reinstall...'
                                    />
                                    <button
                                        type='submit'
                                        className='theme-button-primary rounded-2xl px-4 py-3 text-sm font-semibold transition'
                                    >
                                        Search
                                    </button>
                                    <button
                                        type='button'
                                        onClick={() => mutate()}
                                        className='theme-button-soft inline-flex items-center gap-2 rounded-2xl px-4 py-3 text-sm font-semibold transition'
                                    >
                                        <ArrowPathIcon className='h-4 w-4' />
                                        Refresh
                                    </button>
                                </form>
                                <p className='text-sm text-white/45'>{helperText}</p>
                            </div>
                        </div>
                    </section>

                    {!data ? (
                        <div className={`${cardClassName} py-16`}>
                            <Spinner />
                        </div>
                    ) : (
                        <>
                            <section className='grid gap-4 md:grid-cols-2 xl:grid-cols-5'>
                                <MetricCard
                                    label='Failed Jobs'
                                    value={data.summary.failedJobs}
                                    helper='Queued jobs currently marked failed.'
                                    accent={<QueueListIcon className='h-10 w-10 text-violet-300/70' />}
                                />
                                <MetricCard
                                    label='Provisioning Failures'
                                    value={data.summary.provisioningFailures}
                                    helper='Create, reinstall, or sync jobs that broke.'
                                    accent={<ServerStackIcon className='h-10 w-10 text-amber-300/70' />}
                                />
                                <MetricCard
                                    label='Paymenter API Errors'
                                    value={data.summary.paymenterRelatedErrors}
                                    helper='Recent panel-side errors related to Paymenter traffic.'
                                    accent={<WrenchScrewdriverIcon className='h-10 w-10 text-sky-300/70' />}
                                />
                                <MetricCard
                                    label='Application Errors'
                                    value={data.summary.recentApplicationErrors}
                                    helper='Recent Laravel exceptions from the panel.'
                                    accent={<ExclamationTriangleIcon className='h-10 w-10 text-rose-300/70' />}
                                />
                                <MetricCard
                                    label='Worker Alerts'
                                    value={data.summary.workerFailures}
                                    helper='Recent Core or supervisor log lines marked as errors.'
                                    accent={<ArrowPathIcon className='h-10 w-10 text-fuchsia-300/70' />}
                                />
                            </section>

                            <section className='grid gap-6 xl:grid-cols-[1.05fr,0.95fr]'>
                                <div className={`${cardClassName} overflow-hidden p-5`}>
                                    <div className='flex items-center justify-between gap-3'>
                                        <div>
                                            <h2 className='text-lg font-semibold text-white'>
                                                Failed jobs
                                            </h2>
                                            <p className='mt-1 text-sm text-white/55'>
                                                Exact queue failures with server, node, and template clues.
                                            </p>
                                        </div>
                                        <span className='rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-white/45'>
                                            {failedJobs.length} items
                                        </span>
                                    </div>
                                    <div className='mt-4 space-y-3'>
                                        {failedJobs.length ? (
                                            failedJobs.map(item => (
                                                <article
                                                    key={item.uuid}
                                                    className='rounded-2xl border border-white/8 bg-white/[0.03] p-4'
                                                >
                                                    <div className='flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between'>
                                                        <div className='min-w-0 flex-1'>
                                                            <div className='flex flex-wrap items-center gap-2'>
                                                                <CategoryBadge category={item.category} />
                                                                <span className='text-xs uppercase tracking-[0.18em] text-white/35'>
                                                                    {item.failedAt}
                                                                </span>
                                                            </div>
                                                            <h3 className='mt-3 text-base font-semibold text-white'>
                                                                {item.job}
                                                            </h3>
                                                            <p className='mt-2 text-sm text-rose-100/90'>
                                                                {item.headline}
                                                            </p>
                                                            <div className='mt-3 flex flex-wrap gap-2 text-xs text-white/45'>
                                                                {item.serverId ? <span>Server #{item.serverId}</span> : null}
                                                                {item.nodeId ? <span>Node #{item.nodeId}</span> : null}
                                                                {item.templateId ? <span>Template #{item.templateId}</span> : null}
                                                                <span className='break-all'>Job {item.uuid}</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <pre className='theme-panel-inner mt-4 max-h-48 overflow-auto rounded-2xl p-4 text-xs leading-6 text-white/70 whitespace-pre-wrap'>
                                                        {item.snippet}
                                                    </pre>
                                                </article>
                                            ))
                                        ) : (
                                            <div className='rounded-2xl border border-dashed border-white/10 px-4 py-10 text-sm text-white/45'>
                                                No failed jobs match the current filter.
                                            </div>
                                        )}
                                    </div>
                                </div>

                                <div className={`${cardClassName} overflow-hidden p-5`}>
                                    <div className='flex items-center justify-between gap-3'>
                                        <div>
                                            <h2 className='text-lg font-semibold text-white'>
                                                Recent application errors
                                            </h2>
                                            <p className='mt-1 text-sm text-white/55'>
                                                Recent Laravel exceptions parsed from the panel log.
                                            </p>
                                        </div>
                                        <span className='rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-white/45'>
                                            {applicationErrors.length} entries
                                        </span>
                                    </div>
                                    <div className='mt-4 space-y-3'>
                                        {applicationErrors.length ? (
                                            applicationErrors.map((item, index) => (
                                                <article
                                                    key={`${item.timestamp}-${index}`}
                                                    className='rounded-2xl border border-white/8 bg-white/[0.03] p-4'
                                                >
                                                    <div className='flex flex-wrap items-center gap-2'>
                                                        <CategoryBadge category={item.category} />
                                                        <span className='text-xs uppercase tracking-[0.18em] text-white/35'>
                                                            {item.level}
                                                        </span>
                                                        <span className='text-xs text-white/35'>
                                                            {item.timestamp}
                                                        </span>
                                                        <span className='text-xs text-white/35'>
                                                            {item.source}
                                                        </span>
                                                    </div>
                                                    <h3 className='mt-3 text-base font-semibold text-white'>
                                                        {item.headline}
                                                    </h3>
                                                    <pre className='mt-4 max-h-52 overflow-auto rounded-2xl border border-white/8 bg-[#06040f] p-4 text-xs leading-6 text-white/70 whitespace-pre-wrap'>
                                                        {item.snippet}
                                                    </pre>
                                                </article>
                                            ))
                                        ) : (
                                            <div className='rounded-2xl border border-dashed border-white/10 px-4 py-10 text-sm text-white/45'>
                                                No application errors match the current filter.
                                            </div>
                                        )}
                                    </div>
                                </div>
                            </section>

                            <section className='grid gap-6 xl:grid-cols-4'>
                                <ServiceLogPanel title='Core Queue' lines={serviceLogs?.horizon ?? []} />
                                <ServiceLogPanel title='Scheduler' lines={serviceLogs?.scheduler ?? []} />
                                <ServiceLogPanel title='Supervisor' lines={serviceLogs?.supervisord ?? []} />
                                <ServiceLogPanel title='Diagnostics' lines={serviceLogs?.diagnostics ?? []} />
                            </section>
                        </>
                    )}
                </div>
            </PageContentBlock>
        </div>
    )
}

export default DiagnosticsContainer
