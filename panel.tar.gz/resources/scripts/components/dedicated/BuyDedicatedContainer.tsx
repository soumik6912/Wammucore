﻿import Button from '@/components/elements/Button'
import PageContentBlock from '@/components/elements/PageContentBlock'
import { useStoreState } from '@/state'
import { ServerStackIcon } from '@heroicons/react/24/outline'
import { useEffect, useMemo } from 'react'

const DEDICATED_PLANS_URL = 'https://wammuhost.com/servers/dedicated'

const BuyDedicatedContainer = () => {
    const user = useStoreState(state => state.user.data)
    const panelName = useStoreState(state => state.settings.data?.panelName || 'WammuCore')
    const tenantId = useStoreState(state => state.settings.data?.tenantId ?? null)
    const isReseller = Boolean(user?.resellerAdmin || user?.resellerId)

    useEffect(() => {
        document.title = `Buy Dedicated | ${panelName}`
    }, [panelName])

    const helperText = useMemo(
        () =>
            isReseller
                ? 'Dedicated plans are available for verified reseller accounts.'
                : 'Dedicated server plans are available from the WammuHost dedicated store.',
        [isReseller]
    )

    if (tenantId !== null && !isReseller) {
        return (
            <PageContentBlock title='Dedicated Services'>
                <div className='mx-auto max-w-3xl rounded-3xl border border-white/10 bg-[#0f1730]/95 p-6 text-white'>
                    <p className='text-xs font-bold uppercase tracking-[0.26em] text-cyan-100/70'>
                        Reseller Customer Panel
                    </p>
                    <h1 className='mt-3 text-2xl font-bold'>Dedicated services are not available here</h1>
                    <p className='mt-3 text-sm leading-6 text-white/65'>
                        This customer panel only shows VPS plans and services from your reseller.
                    </p>
                </div>
            </PageContentBlock>
        )
    }

    return (
        <PageContentBlock title='Buy Dedicated'>
            <div className='mx-auto max-w-5xl'>
                <section className='overflow-hidden rounded-3xl border border-cyan-300/20 bg-[radial-gradient(circle_at_top_left,rgba(34,211,238,0.18),transparent_36%),linear-gradient(135deg,rgba(11,18,36,0.98),rgba(31,20,74,0.94))] p-6 text-white shadow-[0_0_45px_rgba(34,211,238,0.12)]'>
                    <div className='flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between'>
                        <div className='max-w-3xl'>
                            <p className='text-xs font-bold uppercase tracking-[0.26em] text-cyan-100/70'>
                                Dedicated Services
                            </p>
                            <h1 className='mt-3 text-3xl font-bold tracking-tight'>
                                Buy dedicated Proxmox hardware
                            </h1>
                            <p className='mt-3 text-sm leading-6 text-white/70'>
                                {helperText}
                            </p>
                            <div className='mt-6'>
                                <Button
                                    type='button'
                                    variant='filled'
                                    onClick={() => window.location.assign(DEDICATED_PLANS_URL)}
                                >
                                    Check Dedicated Plans
                                </Button>
                            </div>
                        </div>
                        <div className='grid h-20 w-20 shrink-0 place-items-center rounded-3xl border border-cyan-200/20 bg-cyan-300/10'>
                            <ServerStackIcon className='h-10 w-10 text-cyan-100' />
                        </div>
                    </div>
                </section>
            </div>
        </PageContentBlock>
    )
}

export default BuyDedicatedContainer
