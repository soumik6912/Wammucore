type RouteDefinition = {
    name: string
    path: string
    end?: boolean
    group?: string
}

type Options = {
    includeOnboarding?: boolean
    operationalLocked?: boolean
}

export const getResellerPrimaryRoutes = (
    options: Options = {}
): RouteDefinition[] => {
    const routes: RouteDefinition[] = []

    if (options.includeOnboarding) {
        routes.push({
            name: 'Onboarding',
            path: '/admin/reseller-panel/onboarding',
            group: 'Workspace',
        })
    }

    if (options.operationalLocked) {
        return routes.length > 0
            ? routes
            : [
                  {
                      name: 'Verification',
                      path: '/admin/reseller-panel',
                      end: true,
                      group: 'Workspace',
                  },
              ]
    }

    routes.push(
        {
            name: 'Dashboard',
            path: '/admin/reseller-panel',
            end: true,
            group: 'Workspace',
        },
        {
            name: 'Branding & Domains',
            path: '/admin/reseller-panel?section=settings',
            end: true,
            group: 'Workspace',
        },
        {
            name: 'Customers',
            path: '/admin/reseller-panel?section=users',
            end: true,
            group: 'Customers',
        },
        {
            name: 'VPS',
            path: '/admin/reseller-panel?section=services',
            end: true,
            group: 'Customers',
        },
        {
            name: 'Support',
            path: '/admin/reseller-panel?section=tickets',
            end: true,
            group: 'Customers',
        },
        {
            name: 'Catalog & Pricing',
            path: '/admin/reseller-panel?section=plans',
            end: true,
            group: 'Commerce',
        },
        {
            name: 'Billing',
            path: '/admin/reseller-panel?section=orders',
            end: true,
            group: 'Commerce',
        },
        {
            name: 'API Keys',
            path: '/admin/reseller-panel?section=api_keys',
            end: true,
            group: 'Operations',
        },
        {
            name: 'Security & Logs',
            path: '/admin/reseller-panel?section=logs',
            end: true,
            group: 'Operations',
        },
        {
            name: 'Analytics',
            path: '/admin/reseller-panel?section=statistics',
            end: true,
            group: 'Operations',
        }
    )

    return routes
}

export default getResellerPrimaryRoutes
