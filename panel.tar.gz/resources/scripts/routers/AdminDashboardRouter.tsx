import { routes as adminCotermRoutes } from '@/routers/AdminCotermRouter'
import { routes as adminIpamRoutes } from '@/routers/AdminIpamRouter'
import { routes as adminNodeRoutes } from '@/routers/AdminNodeRouter'
import { routes as adminResellerRoutes } from '@/routers/AdminResellerRouter'
import { routes as adminSecurityRoutes } from '@/routers/AdminSecurityRouter'
import { routes as adminServerRoutes } from '@/routers/AdminServerRouter'
import { routes as adminUserRoutes } from '@/routers/AdminUserRouter'
import { lazyLoad } from '@/routers/helpers'
import AuthenticatedRoutes from '@/routers/middleware/AuthenticatedRoutes'
import MasterAdminViewRoutes from '@/routers/middleware/MasterAdminViewRoutes'
import RootAdminOnlyRoutes from '@/routers/middleware/RootAdminOnlyRoutes'
import { Route } from '@/routers/router'
import { HomeIcon } from '@heroicons/react/20/solid'
import { EyeIcon, EyeSlashIcon } from '@heroicons/react/24/outline'
import { FormEvent, lazy, useContext, useEffect, useMemo, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Link, Navigate, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { useStoreState } from '@/state'

import getRootAdminSecurityGateStatus from '@/api/admin/rootAdminSecurity/getRootAdminSecurityGateStatus'
import {
    confirmRootAdminTwoFactor,
    setupRootAdminTwoFactor,
} from '@/api/admin/rootAdminSecurity/manageRootAdminTwoFactor'
import verifyRootAdminSecurityGate from '@/api/admin/rootAdminSecurity/verifyRootAdminSecurityGate'
import setTenantContext from '@/api/admin/tenancy/setTenantContext'
import useTenantContextSWR from '@/api/admin/tenancy/useTenantContextSWR'
import { httpErrorToHuman } from '@/api/http'

import ContentContainer from '@/components/elements/ContentContainer'
import Spinner from '@/components/elements/Spinner'
import { NavigationBarContext } from '@/components/elements/navigation/NavigationBar'
import { getAdminPrimaryRoutes } from '@/routers/adminPrimaryRoutes'

const wrapMasterOnlyRoutes = (routes: Route[]): Route[] =>
    routes.map(route => ({
        ...route,
        element: (
            <MasterAdminViewRoutes>
                {route.element ? (route.element as JSX.Element) : <Outlet />}
            </MasterAdminViewRoutes>
        ),
    }))

const masterOnlyNodeRoutes = wrapMasterOnlyRoutes(adminNodeRoutes)
const masterOnlyIpamRoutes = wrapMasterOnlyRoutes(adminIpamRoutes)
const masterOnlyCotermRoutes = wrapMasterOnlyRoutes(adminCotermRoutes)
const masterOnlyServerRoutes = wrapMasterOnlyRoutes(adminServerRoutes)
const masterOnlyUserRoutes = wrapMasterOnlyRoutes(adminUserRoutes)
const masterOnlySecurityRoutes = wrapMasterOnlyRoutes(adminSecurityRoutes)
const masterOnlyResellerRoutes = wrapMasterOnlyRoutes(adminResellerRoutes)

export const routes: Route[] = [
    {
        path: '/admin',
        element: (
            <AuthenticatedRoutes requireAdmin>
                {lazyLoad(lazy(() => import('@/routers/AdminDashboardRouter')))}
            </AuthenticatedRoutes>
        ),
        handle: {
            crumb: () => ({
                to: '/admin',
                element: (
                    <HomeIcon
                        className={
                            'w-4 h-4 text-accent-500 hover:text-accent-800 transition'
                        }
                    />
                ),
            }),
        },
        children: [
            {
                index: true,
                element: lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/admin/AdminHomeContainer'
                            )
                    )
                ),
            },
            {
                path: 'control',
                element: (
                    <MasterAdminViewRoutes>
                        {lazyLoad(
                            lazy(
                                () =>
                                    import(
                                        '@/components/admin/rootControl/RootAdminControlContainer'
                                    )
                            )
                        )}
                    </MasterAdminViewRoutes>
                ),
            },
            {
                path: 'logs',
                element: (
                    <RootAdminOnlyRoutes>
                        {lazyLoad(
                            lazy(
                                () =>
                                    import(
                                        '@/components/admin/rootControl/RootAdminLogsContainer'
                                    )
                            )
                        )}
                    </RootAdminOnlyRoutes>
                ),
            },
            {
                path: 'locations',
                element: (
                    <MasterAdminViewRoutes>
                        {lazyLoad(
                            lazy(
                                () =>
                                    import(
                                        '@/components/admin/locations/LocationsContainer'
                                    )
                            )
                        )}
                    </MasterAdminViewRoutes>
                ),
            },
            {
                path: 'diagnostics',
                element: (
                    <MasterAdminViewRoutes>
                        {lazyLoad(
                            lazy(
                                () =>
                                    import(
                                        '@/components/admin/diagnostics/DiagnosticsContainer'
                                    )
                            )
                        )}
                    </MasterAdminViewRoutes>
                ),
            },
            {
                path: 'core',
                element: (
                    <RootAdminOnlyRoutes>
                        {lazyLoad(
                            lazy(
                                () =>
                                    import(
                                        '@/components/admin/horizon/HorizonContainer'
                                    )
                            )
                        )}
                    </RootAdminOnlyRoutes>
                ),
            },
            {
                path: 'horizon',
                element: (
                    <RootAdminOnlyRoutes>
                        <Navigate to='/admin/core' replace />
                    </RootAdminOnlyRoutes>
                ),
            },
            {
                path: 'services',
                element: (
                    <MasterAdminViewRoutes>
                        {lazyLoad(
                            lazy(
                                () =>
                                    import(
                                        '@/components/admin/services/AdminServicesHubContainer'
                                    )
                            )
                        )}
                    </MasterAdminViewRoutes>
                ),
            },
            {
                path: 'vps-plans',
                element: (
                    <MasterAdminViewRoutes>
                        <Navigate to='/admin/plans' replace />
                    </MasterAdminViewRoutes>
                ),
            },
            {
                path: 'ip-plans',
                element: (
                    <MasterAdminViewRoutes>
                        <Navigate to='/admin/ipam' replace />
                    </MasterAdminViewRoutes>
                ),
            },
            {
                path: 'dedicated-plans',
                element: (
                    <MasterAdminViewRoutes>
                        <Navigate to='/admin/dedicated' replace />
                    </MasterAdminViewRoutes>
                ),
            },
            ...masterOnlyNodeRoutes,
            ...masterOnlyServerRoutes,
            {
                path: 'plans',
                element: (
                    <MasterAdminViewRoutes>
                        {lazyLoad(
                            lazy(
                                () =>
                                    import(
                                        '@/components/admin/plans/PlanCatalogContainer'
                                    )
                            )
                        )}
                    </MasterAdminViewRoutes>
                ),
            },
            {
                path: 'dedicated',
                element: (
                    <MasterAdminViewRoutes>
                        {lazyLoad(
                            lazy(
                                () =>
                                    import(
                                        '@/components/admin/dedicated/DedicatedAdminContainer'
                                    )
                            )
                        )}
                    </MasterAdminViewRoutes>
                ),
            },
            ...masterOnlySecurityRoutes,
            ...masterOnlyIpamRoutes,
            ...masterOnlyUserRoutes,
            ...masterOnlyResellerRoutes,
            {
                path: 'reseller-settings',
                element: (
                    <MasterAdminViewRoutes>
                        {lazyLoad(
                            lazy(
                                () =>
                                    import(
                                        '@/components/admin/resellerSettings/ResellerSettingsContainer'
                                    )
                            )
                        )}
                    </MasterAdminViewRoutes>
                ),
            },
            {
                path: 'reseller/create',
                element: (
                    <MasterAdminViewRoutes>
                        {lazyLoad(
                            lazy(
                                () =>
                                    import(
                                        '@/components/admin/resellers/ResellerCreateInterfaceContainer'
                                    )
                            )
                        )}
                    </MasterAdminViewRoutes>
                ),
            },
            ...masterOnlyCotermRoutes,
            {
                path: 'tokens',
                element: (
                    <MasterAdminViewRoutes>
                        {lazyLoad(
                            lazy(
                                () =>
                                    import('@/components/admin/tokens/TokensContainer')
                            )
                        )}
                    </MasterAdminViewRoutes>
                ),
            },
            {
                path: 'email',
                element: (
                    <MasterAdminViewRoutes>
                        {lazyLoad(
                            lazy(
                                () =>
                                    import(
                                        '@/components/admin/email/EmailSettingsContainer'
                                    )
                            )
                        )}
                    </MasterAdminViewRoutes>
                ),
            },
            {
                path: 'reseller-panel/onboarding',
                element: lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/admin/resellerPanel/ResellerOnboardingContainer'
                            )
                    )
                ),
            },
            {
                path: 'reseller-panel/domain-guide',
                element: lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/admin/resellerPanel/ResellerDomainGuideContainer'
                            )
                    )
                ),
            },
            {
                path: 'reseller-panel/onboarding/:slug',
                element: lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/admin/resellerPanel/ResellerOnboardingContainer'
                        )
                    )
                ),
            },
            {
                path: 'reseller-panel/r',
                element: <Navigate to='/admin/reseller-panel' replace />,
            },
            {
                path: 'reseller-panel/r/:resellerRef',
                element: lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/admin/resellerPanel/ResellerAdminPanelContainer'
                            )
                    )
                ),
            },
            {
                path: 'reseller-panel/:resellerRef',
                element: lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/admin/resellerPanel/ResellerAdminPanelContainer'
                            )
                    )
                ),
            },
            {
                path: 'reseller-panel',
                element: lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/admin/resellerPanel/ResellerAdminPanelContainer'
                            )
                    )
                ),
            },
        ],
    },
]

export const AdminBanner = () => (
    <div className='theme-panel-soft border-b'>
        <ContentContainer>
            <div className='flex items-center py-2'>
                <div className='flex items-center gap-2'>
                    <div className='theme-pill-active flex h-4 w-4 items-center justify-center rounded'>
                        <svg className='h-2.5 w-2.5' fill='currentColor' viewBox='0 0 20 20'>
                            <path fillRule='evenodd' d='M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z' clipRule='evenodd' />
                        </svg>
                    </div>
                    <p className='theme-eyebrow text-xs font-medium'>
                        Administrator Mode
                    </p>
                </div>
            </div>
        </ContentContainer>
    </div>
)

const resellerReferenceFromAdminPath = (path: string): string | null => {
    const match =
        path.match(/^\/admin\/reseller-panel\/r\/([^/?#]+)/) ||
        path.match(/^\/admin\/reseller-panel\/([^/?#]+)/)
    const raw = match?.[1]
    if (!raw) {
        return null
    }

    const reference = decodeURIComponent(raw).trim().toLowerCase()
    if (['r', 'onboarding', 'domain-guide'].includes(reference)) {
        return null
    }

    return /^[a-z0-9][a-z0-9._-]{0,119}$/.test(reference)
        ? reference
        : null
}

const rootGateCacheKey = 'wammucore:root-admin-gate-status'
const rootGateCacheTtlMs = 60_000

const AdminDashboardRouter = () => {
    const user = useStoreState(state => state.user.data)
    const isRootAdmin = Boolean(user?.rootAdmin)
    const isResellerOnlyAdmin = Boolean(user?.resellerAdmin && !user?.rootAdmin)
    const { setRoutes } = useContext(NavigationBarContext)
    const { t: tStrings } = useTranslation('strings')
    const { data: tenantContext, mutate: mutateTenantContext } =
        useTenantContextSWR()
    const navRoutes = useMemo(
        () =>
            getAdminPrimaryRoutes(
                tStrings,
                tenantContext?.mode !== 'reseller',
                isRootAdmin
            ),
        [tStrings, tenantContext?.mode, isRootAdmin]
    )
    const location = useLocation()
    const navigate = useNavigate()
    const [isGateLoading, setIsGateLoading] = useState(true)
    const [isGateRequired, setIsGateRequired] = useState(false)
    const [isGateSubmitting, setIsGateSubmitting] = useState(false)
    const [gatePassword, setGatePassword] = useState('')
    const [gateRemember, setGateRemember] = useState(true)
    const [gateSessionTtlMinutes, setGateSessionTtlMinutes] = useState(30)
    const [gateRememberTtlMinutes, setGateRememberTtlMinutes] = useState(10080)
    const [isGateTwoFactorRequired, setIsGateTwoFactorRequired] = useState(false)
    const [isGateTwoFactorSetupRequired, setIsGateTwoFactorSetupRequired] =
        useState(false)
    const [gateTwoFactorCode, setGateTwoFactorCode] = useState('')
    const [gateRecoveryCode, setGateRecoveryCode] = useState('')
    const [gateUseRecoveryCode, setGateUseRecoveryCode] = useState(false)
    const [gateError, setGateError] = useState<string | null>(null)
    const [showGatePassword, setShowGatePassword] = useState(false)
    const [setupSecret, setSetupSecret] = useState<string | null>(null)
    const [setupQrCodeUrl, setSetupQrCodeUrl] = useState<string | null>(null)
    const [setupRecoveryCodes, setSetupRecoveryCodes] = useState<string[]>([])
    const [setupConfirmCode, setSetupConfirmCode] = useState('')
    const [setupError, setSetupError] = useState<string | null>(null)
    const [isSetupSubmitting, setIsSetupSubmitting] = useState(false)
    const [isSetupConfirmSubmitting, setIsSetupConfirmSubmitting] = useState(false)
    const [isContextSwitching, setIsContextSwitching] = useState(false)
    const [isReturningToRootAdmin, setIsReturningToRootAdmin] = useState(false)
    const [contextSwitchError, setContextSwitchError] = useState<string | null>(
        null
    )

    const isEntityScopedAdminRoute = useMemo(() => {
        const segments = location.pathname.split('/').filter(Boolean)
        if (segments[0] !== 'admin' || segments.length < 3) {
            return false
        }

        return ['servers', 'nodes', 'users', 'ipam'].includes(segments[1])
    }, [location.pathname])

    const isResellerPanelRoute = useMemo(
        () =>
            location.pathname === '/admin/reseller-panel' ||
            location.pathname.startsWith('/admin/reseller-panel/'),
        [location.pathname]
    )
    const showRootWorkspaceBanner = useMemo(
        () =>
            location.pathname === '/admin' ||
            location.pathname.startsWith('/admin/resellers'),
        [location.pathname]
    )
    const resellerRouteReference = useMemo(
        () => resellerReferenceFromAdminPath(location.pathname),
        [location.pathname]
    )

    useEffect(() => {
        if (!isRootAdmin) {
            setIsGateRequired(false)
            setIsGateTwoFactorRequired(false)
            setIsGateTwoFactorSetupRequired(false)
            setIsGateLoading(false)

            return
        }

        let isMounted = true
        const cachedGateStatus = (() => {
            try {
                const cached = JSON.parse(
                    window.sessionStorage.getItem(rootGateCacheKey) || 'null'
                )

                if (
                    cached &&
                    typeof cached.cachedAt === 'number' &&
                    Date.now() - cached.cachedAt < rootGateCacheTtlMs
                ) {
                    return cached.status
                }
            } catch {
                // Ignore bad session cache and fetch a fresh status.
            }

            return null
        })()

        if (cachedGateStatus) {
            setIsGateRequired(Boolean(cachedGateStatus.required))
            setGateSessionTtlMinutes(Number(cachedGateStatus.sessionTtlMinutes || 30))
            setGateRememberTtlMinutes(Number(cachedGateStatus.rememberTtlMinutes || 10080))
            setIsGateTwoFactorRequired(Boolean(cachedGateStatus.twoFactor?.required))
            setIsGateTwoFactorSetupRequired(Boolean(cachedGateStatus.twoFactor?.setupRequired))
            setIsGateLoading(false)
        }

        getRootAdminSecurityGateStatus()
            .then(status => {
                if (!isMounted) {
                    return
                }

                try {
                    window.sessionStorage.setItem(
                        rootGateCacheKey,
                        JSON.stringify({ cachedAt: Date.now(), status })
                    )
                } catch {
                    // Session cache is a performance hint only.
                }

                setIsGateRequired(status.required)
                setGateSessionTtlMinutes(status.sessionTtlMinutes)
                setGateRememberTtlMinutes(status.rememberTtlMinutes)
                setIsGateTwoFactorRequired(status.twoFactor.required)
                setIsGateTwoFactorSetupRequired(status.twoFactor.setupRequired)
            })
            .catch(() => {
                if (!isMounted) {
                    return
                }

                // Fail open in UI; backend middleware still enforces the gate.
                setIsGateRequired(false)
            })
            .finally(() => {
                if (isMounted) {
                    setIsGateLoading(false)
                }
            })

        return () => {
            isMounted = false
        }
    }, [isRootAdmin])

    const beginTwoFactorSetup = async () => {
        setSetupError(null)
        setIsSetupSubmitting(true)

        try {
            const response = await setupRootAdminTwoFactor(false)
            setSetupSecret(response.secret)
            setSetupQrCodeUrl(response.qrCodeUrl)
            setSetupRecoveryCodes(response.recoveryCodes)
        } catch (error) {
            setSetupError(httpErrorToHuman(error))
        } finally {
            setIsSetupSubmitting(false)
        }
    }

    const confirmTwoFactorSetup = async () => {
        if (!setupConfirmCode.trim()) {
            setSetupError('Enter the 6-digit code from your authenticator app.')
            return
        }

        setSetupError(null)
        setIsSetupConfirmSubmitting(true)

        try {
            await confirmRootAdminTwoFactor(setupConfirmCode.trim())
            setSetupConfirmCode('')
            setIsGateTwoFactorSetupRequired(false)
            setIsGateTwoFactorRequired(true)
        } catch (error) {
            setSetupError(httpErrorToHuman(error))
        } finally {
            setIsSetupConfirmSubmitting(false)
        }
    }

    const submitGate = async (event: FormEvent<HTMLFormElement>) => {
        event.preventDefault()

        if (!gatePassword.trim()) {
            setGateError('Root admin password is required.')
            return
        }

        setGateError(null)
        setIsGateSubmitting(true)

        try {
            await verifyRootAdminSecurityGate({
                password: gatePassword,
                remember: gateRemember,
                twoFactorCode: gateUseRecoveryCode
                    ? undefined
                    : gateTwoFactorCode.trim() || undefined,
                recoveryCode: gateUseRecoveryCode
                    ? gateRecoveryCode.trim() || undefined
                    : undefined,
            })

            setGatePassword('')
            setGateTwoFactorCode('')
            setGateRecoveryCode('')
            setIsGateRequired(false)
        } catch (error) {
            const payload = (error as any)?.response?.data
            if (payload?.code === 'root_admin_two_factor_setup_required') {
                setIsGateTwoFactorSetupRequired(true)
            }

            setGateError(httpErrorToHuman(error))
        } finally {
            setIsGateSubmitting(false)
        }
    }

    const switchToRootAdmin = async () => {
        if (!isRootAdmin) {
            return
        }

        setContextSwitchError(null)
        setIsContextSwitching(true)
        setIsReturningToRootAdmin(true)
        try {
            const nextContext = await setTenantContext({ mode: 'all' })
            await mutateTenantContext(nextContext, false)
            navigate('/admin', { replace: true })
        } catch (error) {
            setContextSwitchError(httpErrorToHuman(error))
        } finally {
            setIsReturningToRootAdmin(false)
            setIsContextSwitching(false)
        }
    }

    const forceReturnToRootAdmin = () => {
        if (!isRootAdmin) {
            return
        }

        void switchToRootAdmin()
    }

    const switchToPlatformAdmin = async () => {
        if (!isRootAdmin) {
            return
        }

        setContextSwitchError(null)
        setIsContextSwitching(true)
        try {
            const nextContext = await setTenantContext({ mode: 'platform' })
            await mutateTenantContext(nextContext, false)
            navigate('/admin', { replace: true })
        } catch (error) {
            setContextSwitchError(httpErrorToHuman(error))
        } finally {
            setIsContextSwitching(false)
        }
    }

    useEffect(() => {
        const resetStaleContextSwitch = () => {
            setIsContextSwitching(false)
            setIsReturningToRootAdmin(false)
            setContextSwitchError(null)
        }

        window.addEventListener('pagehide', resetStaleContextSwitch)
        window.addEventListener('pageshow', resetStaleContextSwitch)
        window.addEventListener('popstate', resetStaleContextSwitch)

        return () => {
            window.removeEventListener('pagehide', resetStaleContextSwitch)
            window.removeEventListener('pageshow', resetStaleContextSwitch)
            window.removeEventListener('popstate', resetStaleContextSwitch)
        }
    }, [])

    useEffect(() => {
        setIsContextSwitching(false)
        setIsReturningToRootAdmin(false)
        setContextSwitchError(null)
    }, [location.key])

    useEffect(() => {
        if (!isEntityScopedAdminRoute && !isResellerPanelRoute) {
            setRoutes(navRoutes)
        }

        return () => {
            if (!isEntityScopedAdminRoute && !isResellerPanelRoute) {
                setRoutes([])
            }
        }
    }, [setRoutes, navRoutes, isEntityScopedAdminRoute, isResellerPanelRoute])

    useEffect(() => {
        if (!resellerRouteReference || !tenantContext) {
            return
        }

        const activeReferences = [
            tenantContext.activeReseller?.uuid,
            tenantContext.activeReseller?.slug,
            tenantContext.activeReseller?.id,
            tenantContext.resellerId,
        ]
            .filter(value => value !== null && value !== undefined)
            .map(value => String(value).toLowerCase())

        if (
            tenantContext.mode === 'reseller' &&
            activeReferences.includes(resellerRouteReference)
        ) {
            setIsContextSwitching(false)
            setContextSwitchError(null)
            return
        }

        let cancelled = false
        setContextSwitchError(null)
        setIsContextSwitching(true)

        setTenantContext({
            mode: 'reseller',
            resellerRef: resellerRouteReference,
        })
            .then(nextContext => {
                if (!cancelled) {
                    void mutateTenantContext(nextContext, false)
                }
            })
            .catch(error => {
                if (!cancelled) {
                    setContextSwitchError(httpErrorToHuman(error))
                }
            })
            .finally(() => {
                if (!cancelled) {
                    setIsContextSwitching(false)
                }
            })

        return () => {
            cancelled = true
        }
    }, [resellerRouteReference, tenantContext, mutateTenantContext])

    if (isGateLoading) {
        return <Spinner />
    }

    if (isGateRequired) {
        return (
            <div className='theme-page min-h-screen px-4 py-10'>
                <div className='theme-panel mx-auto w-full max-w-lg rounded-2xl p-6 shadow-xl'>
                    <h1 className='text-xl font-semibold text-white'>
                        Root Admin Security Check
                    </h1>
                    <p className='mt-2 text-sm text-white/70'>
                        Enter your root admin security password to continue.
                    </p>

                    {isGateTwoFactorSetupRequired ? (
                        <div className='mt-5 space-y-4 rounded-xl border border-amber-400/25 bg-amber-900/15 p-4'>
                            <p className='text-sm text-amber-100'>
                                Two-factor authentication is required before you can access root admin controls.
                            </p>

                            {!setupSecret ? (
                                <button
                                    type='button'
                                    onClick={beginTwoFactorSetup}
                                    disabled={isSetupSubmitting}
                                    className='w-full rounded-lg border border-amber-300/40 bg-amber-500/10 px-4 py-2.5 text-sm font-semibold text-amber-100 transition hover:bg-amber-500/20 disabled:cursor-not-allowed disabled:opacity-60'
                                >
                                    {isSetupSubmitting
                                        ? 'Preparing 2FA Setup...'
                                        : 'Start 2FA Setup'}
                                </button>
                            ) : (
                                <div className='space-y-3'>
                                    <div className='theme-panel-inner rounded-lg p-3 text-xs text-white/75'>
                                        <p className='font-semibold text-white'>Authenticator Secret</p>
                                        <p className='mt-1 break-all font-mono text-[11px]'>
                                            {setupSecret}
                                        </p>
                                        {setupQrCodeUrl ? (
                                            <a
                                                href={setupQrCodeUrl}
                                                target='_blank'
                                                rel='noreferrer'
                                                className='theme-accent-text mt-2 inline-block hover:text-white'
                                            >
                                                Open QR setup link
                                            </a>
                                        ) : null}
                                    </div>

                                    {setupRecoveryCodes.length > 0 ? (
                                        <div className='theme-panel-inner rounded-lg p-3'>
                                            <p className='text-xs font-semibold uppercase tracking-wide text-white/70'>
                                                Recovery Codes (save these)
                                            </p>
                                            <div className='mt-2 grid grid-cols-1 gap-1 text-[11px] font-mono text-white/85 sm:grid-cols-2'>
                                                {setupRecoveryCodes.map(code => (
                                                    <span key={code}>{code}</span>
                                                ))}
                                            </div>
                                        </div>
                                    ) : null}

                                    <div>
                                        <label className='mb-2 block text-sm font-medium text-white/85'>
                                            Confirm 2FA Code
                                        </label>
                                        <input
                                            type='text'
                                            value={setupConfirmCode}
                                            onChange={event =>
                                                setSetupConfirmCode(event.target.value)
                                            }
                                            placeholder='123456'
                                            className='theme-input w-full rounded-lg px-4 py-2.5'
                                        />
                                    </div>

                                    <button
                                        type='button'
                                        onClick={confirmTwoFactorSetup}
                                        disabled={isSetupConfirmSubmitting}
                                        className='theme-button-primary w-full rounded-lg px-4 py-2.5 text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-60'
                                    >
                                        {isSetupConfirmSubmitting
                                            ? 'Confirming...'
                                            : 'Confirm 2FA Setup'}
                                    </button>
                                </div>
                            )}

                            {setupError ? (
                                <p className='rounded-lg border border-red-500/40 bg-red-900/30 px-3 py-2 text-sm text-red-200'>
                                    {setupError}
                                </p>
                            ) : null}
                        </div>
                    ) : null}

                    <form className='mt-5 space-y-4' onSubmit={submitGate}>
                        <div>
                            <label className='mb-2 block text-sm font-medium text-white/85'>
                                Security Password
                            </label>
                            <div className='relative'>
                                <input
                                    type={showGatePassword ? 'text' : 'password'}
                                    value={gatePassword}
                                    onChange={event =>
                                        setGatePassword(event.target.value)
                                    }
                                    autoComplete='current-password'
                                    className='theme-input w-full rounded-lg px-4 py-2.5 pr-11'
                                    placeholder='Enter root admin security password'
                                />
                                <button
                                    type='button'
                                    onClick={() =>
                                        setShowGatePassword(current => !current)
                                    }
                                    className='absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1 text-white/70 hover:bg-white/10 hover:text-white'
                                    aria-label={
                                        showGatePassword
                                            ? 'Hide security password'
                                            : 'Show security password'
                                    }
                                >
                                    {showGatePassword ? (
                                        <EyeSlashIcon className='h-4 w-4' />
                                    ) : (
                                        <EyeIcon className='h-4 w-4' />
                                    )}
                                </button>
                            </div>
                        </div>

                        {isGateTwoFactorRequired ? (
                            <div className='space-y-3 rounded-lg border border-white/10 bg-white/5 p-3'>
                                <label className='inline-flex items-center gap-2 text-sm text-white/80'>
                                    <input
                                        type='checkbox'
                                        checked={gateUseRecoveryCode}
                                        onChange={event =>
                                            setGateUseRecoveryCode(event.target.checked)
                                        }
                                        className='h-4 w-4 rounded border border-purple-500/35 bg-transparent'
                                    />
                                    <span>Use recovery code instead of authenticator code</span>
                                </label>

                                {gateUseRecoveryCode ? (
                                    <div>
                                        <label className='mb-2 block text-sm font-medium text-white/85'>
                                            Recovery Code
                                        </label>
                                        <input
                                            type='text'
                                            value={gateRecoveryCode}
                                            onChange={event =>
                                                setGateRecoveryCode(event.target.value)
                                            }
                                            placeholder='Enter one recovery code'
                                            className='theme-input w-full rounded-lg px-4 py-2.5'
                                        />
                                    </div>
                                ) : (
                                    <div>
                                        <label className='mb-2 block text-sm font-medium text-white/85'>
                                            Authenticator Code
                                        </label>
                                        <input
                                            type='text'
                                            value={gateTwoFactorCode}
                                            onChange={event =>
                                                setGateTwoFactorCode(event.target.value)
                                            }
                                            placeholder='123456'
                                            className='theme-input w-full rounded-lg px-4 py-2.5'
                                        />
                                    </div>
                                )}
                            </div>
                        ) : null}

                        <label className='inline-flex items-start gap-2 text-sm text-white/80'>
                            <input
                                type='checkbox'
                                checked={gateRemember}
                                onChange={event => setGateRemember(event.target.checked)}
                                className='mt-0.5 h-4 w-4 rounded border border-purple-500/35 bg-transparent'
                            />
                            <span>
                                Remember this device (
                                {gateRemember
                                    ? `${gateRememberTtlMinutes} minutes`
                                    : `${gateSessionTtlMinutes} minutes`}
                                )
                            </span>
                        </label>

                        {gateError ? (
                            <p className='rounded-lg border border-red-500/40 bg-red-900/30 px-3 py-2 text-sm text-red-200'>
                                {gateError}
                            </p>
                        ) : null}

                        <button
                            type='submit'
                            disabled={isGateSubmitting}
                            className='theme-button-primary w-full rounded-lg px-4 py-2.5 text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-60'
                        >
                            {isGateSubmitting ? 'Verifying...' : 'Verify & Continue'}
                        </button>
                    </form>
                </div>
            </div>
        )
    }

    if (isResellerOnlyAdmin && !isResellerPanelRoute) {
        return <Navigate to='/admin/reseller-panel' replace />
    }

    return (
        <>
            {tenantContext?.mode !== 'reseller' && isRootAdmin && showRootWorkspaceBanner ? (
                <div className='theme-panel-soft relative z-40 border-b px-4 py-2'>
                    <div className='mx-auto flex w-full max-w-[1360px] flex-col gap-3 py-1 sm:flex-row sm:items-center sm:justify-between'>
                        <div className='min-w-0'>
                            <p className='break-words text-sm font-semibold text-white'>
                                {tenantContext?.mode === 'platform'
                                    ? 'Main Platform Admin Panel'
                                    : 'Root Admin Global View'}
                            </p>
                            <p className='theme-muted mt-0.5 max-w-3xl break-words text-xs leading-5'>
                                Use reseller workspace only when you need to inspect or support a specific reseller. Root admin access stays separate.
                            </p>
                        </div>
                        <Link
                            to='/reseller/panel'
                            className='theme-button-primary inline-flex shrink-0 items-center justify-center rounded-xl px-3 py-2 text-center text-xs font-semibold transition sm:whitespace-nowrap'
                        >
                            Choose Reseller Workspace
                        </Link>
                    </div>
                </div>
            ) : null}
            {tenantContext?.mode === 'reseller' ? (
                <div className='theme-panel-soft relative z-[4100] border-b px-4 py-2'>
                    <div className='mx-auto flex w-full max-w-[1360px] flex-col gap-2 md:flex-row md:items-center md:justify-between'>
                        <p className='text-sm text-white'>
                            Viewing as reseller:{' '}
                            <span className='font-semibold'>
                                {tenantContext.activeReseller?.displayName ||
                                    'Unknown reseller'}
                            </span>
                        </p>
                        {isRootAdmin ? (
                            <div className='flex flex-wrap items-center gap-2'>
                                <button
                                    type='button'
                                    aria-busy={isReturningToRootAdmin || isContextSwitching}
                                    onMouseDown={event => event.stopPropagation()}
                                    onClick={forceReturnToRootAdmin}
                                    className='theme-button-primary relative z-[4110] pointer-events-auto rounded-md px-3 py-1.5 text-xs font-semibold transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-emerald-200'
                                >
                                    {isReturningToRootAdmin
                                        ? 'Returning...'
                                        : 'Return to Root Admin'}
                                </button>
                            </div>
                        ) : null}
                    </div>
                    {contextSwitchError ? (
                        <p className='mx-auto mt-2 w-full max-w-[1360px] text-xs text-red-200'>
                            {contextSwitchError}
                        </p>
                    ) : null}
                </div>
            ) : null}
            <Outlet />
        </>
    )
}

export default AdminDashboardRouter
