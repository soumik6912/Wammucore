import { routes as serverRoutes } from '@/routers/ServerRouter'
import TransitionRouter from '@/routers/TransitionRouter'
import { lazyLoad } from '@/routers/helpers'
import { Route } from '@/routers/router'
import { lazy, useContext, useEffect } from 'react'
import { useTranslation } from 'react-i18next'
import { useStoreState } from '@/state'

import { NavigationBarContext } from '@/components/elements/navigation/NavigationBar'

const DashboardContainer = lazy(
    () => import('@/components/dashboard/DashboardContainer')
)
const AccountContainer = lazy(
    () => import('@/components/account/AccountContainer')
)

const DashboardRouter = () => {
    const { setRoutes } = useContext(NavigationBarContext)
    const { t: tStrings } = useTranslation('strings')
    const tenantId = useStoreState(state => state.settings.data?.tenantId ?? null)

    const routes = [
        {
            name: tStrings('overview'),
            path: '/',
        },
        {
            name: 'VPS Plans',
            path: '/store',
        },
        ...(tenantId === null
            ? [
                {
                    name: 'Buy Dedicated',
                    path: '/dedicated',
                },
            ]
            : []),
        {
            name: 'Account',
            path: '/account',
        },
    ]

    useEffect(() => {
        setRoutes(routes)

        return () => setRoutes([])
    }, [setRoutes, tenantId, tStrings])

    return (
        <>
            <TransitionRouter>
                {lazyLoad(DashboardContainer)}
            </TransitionRouter>
        </>
    )
}

export const routes: Route[] = [
    {
        path: '/',
        element: <DashboardRouter />,
    },
    {
        path: '/store',
        element: (
            <TransitionRouter>
                {lazyLoad(lazy(() => import('@/components/store/StoreContainer')))}
            </TransitionRouter>
        ),
    },
    {
        path: '/dedicated',
        element: (
            <TransitionRouter>
                {lazyLoad(lazy(() => import('@/components/dedicated/BuyDedicatedContainer')))}
            </TransitionRouter>
        ),
    },
    {
        path: '/account',
        element: (
            <TransitionRouter>
                {lazyLoad(AccountContainer)}
            </TransitionRouter>
        ),
    },
    ...serverRoutes,
]

export default DashboardRouter
