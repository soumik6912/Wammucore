import { lazyLoad } from '@/routers/helpers'
import { Route } from '@/routers/router'
import { ServerContext } from '@/state/server'
import {
    ArrowPathIcon,
    ExclamationCircleIcon,
    NoSymbolIcon,
} from '@heroicons/react/24/outline'
import { lazy, useContext, useEffect, useMemo, useState } from 'react'
import { Navigate, Outlet, useMatches } from 'react-router-dom'

import { httpErrorToHuman } from '@/api/http'
import getInstallProgress from '@/api/server/getInstallProgress'
import { acknowledgeServerSecurityLock } from '@/api/server/securityLock'
import { EloquentStatus } from '@/api/server/types'

import ScreenBlock, { ErrorMessage } from '@/components/elements/ScreenBlock'
import Spinner from '@/components/elements/Spinner'
import StatusProgressBlock from '@/components/elements/StatusProgressBlock'
import StatusStateBlock from '@/components/elements/StatusStateBlock'
import { NavigationBarContext } from '@/components/elements/navigation/NavigationBar'

const LegacyServerRouteRedirect = ({ to }: { to: 'usage' | 'actions' }) => {
    const matches = useMatches()
    const id = matches[0].params.id

    return <Navigate to={`/servers/${id}/${to}`} replace />
}

export const routes: Route[] = [
    {
        element: (
            <ServerContext.Provider>
                {lazyLoad(lazy(() => import('./ServerRouter')))}
            </ServerContext.Provider>
        ),
        path: '/servers/:id',
        children: [
            {
                index: true,
                element: lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/servers/overview/ServerOverviewContainer'
                            )
                    )
                ),
            },
            {
                path: 'backups',
                element: lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/servers/backups/BackupsContainer'
                            )
                    )
                ),
            },
            {
                path: 'usage',
                element: lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/servers/backups/ServerUsageContainer'
                            )
                    )
                ),
            },
            {
                path: 'actions',
                element: lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/servers/backups/LatestActionsContainer'
                            )
                    )
                ),
            },
            {
                path: 'backups/usage',
                element: <LegacyServerRouteRedirect to='usage' />,
            },
            {
                path: 'backups/actions',
                element: <LegacyServerRouteRedirect to='actions' />,
            },
            {
                path: 'settings',
                element: lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/servers/settings/ServerSettingsContainer'
                            )
                    )
                ),
                children: [
                    {
                        path: 'general',
                        element: lazyLoad(
                            lazy(
                                () =>
                                    import(
                                        '@/components/servers/settings/GeneralContainer'
                                    )
                            )
                        ),
                    },


                    {
                        path: 'network',
                        element: lazyLoad(
                            lazy(
                                () =>
                                    import(
                                        '@/components/servers/settings/NetworkContainer'
                                    )
                            )
                        ),
                    },
                    {
                        path: 'security',
                        element: lazyLoad(
                            lazy(
                                () =>
                                    import(
                                        '@/components/servers/settings/SecurityContainer'
                                    )
                            )
                        ),
                    },
                ],
            },
            {
                path: 'terminal',
                element: lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/servers/terminal/ServerTerminalContainer'
                            )
                    )
                ),
            },
            {
                path: 'docker',
                element: lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/servers/docker/ServerDockerManagerContainer'
                            )
                    )
                ),
            },
            {
                path: 'os-panel',
                element: lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/servers/os/ServerOsPanelContainer'
                            )
                    )
                ),
            },
            {
                path: 'tutorials',
                element: lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/servers/tutorials/TutorialsContainer'
                            )
                    )
                ),
            },
            {
                path: 'security/firewall',
                element: lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/servers/security/FirewallContainer'
                            )
                    )
                ),
            },
        ],
    },
]

const ServerRouter = () => {
    const matches = useMatches()
    const id = matches[0].params.id
    const [error, setError] = useState<string>()
    const [completionHoldUntil, setCompletionHoldUntil] = useState<number | null>(
        null
    )
    const [isProvisioningByTask, setIsProvisioningByTask] = useState(false)
    const [isAcknowledgingSecurityLock, setIsAcknowledgingSecurityLock] =
        useState(false)
    const [securityLockError, setSecurityLockError] = useState<string>()
    const server = ServerContext.useStoreState(state => state.server.data)
    const getServer = ServerContext.useStoreActions(
        actions => actions.server.getServer
    )
    const clearServerState = ServerContext.useStoreActions(
        actions => actions.clearServerState
    )

    const visibleRoutes = useMemo(
        () => [
            {
                name: 'Home',
                path: '/',
                end: true,
            },
            {
                name: 'Overview',
                path: `/servers/${id}`,
                end: true,
            },
            {
                name: 'Docker Manager',
                path: `/servers/${id}/docker`,
            },
            {
                name: 'Settings',
                path: `/servers/${id}/settings`,
            },
            {
                name: 'OS & Panel',
                path: `/servers/${id}/os-panel`,
            },
            {
                name: 'Backups',
                path: `/servers/${id}/backups`,
                end: true,
            },
            {
                name: 'Server Usage',
                path: `/servers/${id}/usage`,
            },
            {
                name: 'Latest Actions',
                path: `/servers/${id}/actions`,
            },
            {
                name: 'Firewall',
                path: `/servers/${id}/security/firewall`,
            },
            {
                name: 'Tutorials',
                path: `/servers/${id}/tutorials`,
            },
        ],
        [id]
    )

    const restrictedRoutes = useMemo(
        () => [
            {
                name: 'Home',
                path: '/',
                end: true,
            },
        ],
        []
    )

    const recoveryRoutes = useMemo(
        () => [
            {
                name: 'Home',
                path: '/',
                end: true,
            },
            {
                name: 'Overview',
                path: `/servers/${id}`,
                end: true,
            },
            {
                name: 'OS & Panel',
                path: `/servers/${id}/os-panel`,
            },
            {
                name: 'Latest Actions',
                path: `/servers/${id}/actions`,
            },
        ],
        [id]
    )

    useEffect(() => {
        setError(undefined)

        getServer(id as string).catch((error: any) => {
            setError(httpErrorToHuman(error))
        })

        const interval = window.setInterval(() => {
            if (document.visibilityState === 'hidden') return
            getServer({ uuid: id as string, silent: true }).catch(() => null)
        }, 10000)

        const onFocus = () => {
            getServer({ uuid: id as string, silent: true }).catch(() => null)
        }
        window.addEventListener('focus', onFocus)

        return () => {
            window.clearInterval(interval)
            window.removeEventListener('focus', onFocus)
            clearServerState()
        }
    }, [id])

    useEffect(() => {
        if (server?.securityLock?.active) {
            setIsProvisioningByTask(false)
            return
        }

        let mounted = true
        let timer: number | null = null

        const loadInstallState = async () => {
            try {
                const data = await getInstallProgress(id as string)
                if (!mounted) return

                const taskState = String(data.taskState || '').toLowerCase()
                const activeTaskState = !['completed', 'stopped', 'failed', 'canceled', 'cancelled'].includes(taskState)
                const hasActiveProvisioning =
                    Boolean(data.isProvisioning) ||
                    (Number(data.progressPercent || 0) > 0 &&
                        data.phase !== 'completed' &&
                        activeTaskState)

                setIsProvisioningByTask(hasActiveProvisioning)
            } catch {
                if (!mounted) return
                setIsProvisioningByTask(false)
            } finally {
                if (!mounted) return
                timer = window.setTimeout(loadInstallState, 10000)
            }
        }

        loadInstallState()

        return () => {
            mounted = false
            if (timer) {
                window.clearTimeout(timer)
            }
        }
    }, [id, server?.securityLock?.active])

    useEffect(() => {
        const transitionKey = `wammucore:install-transition:${id}`
        const provisioningStatuses = [
            'installing',
            'restoring_backup',
            'restoring_snapshot',
        ]

        if (typeof server?.status === 'string' && provisioningStatuses.includes(server.status)) {
            try {
                window.sessionStorage.setItem(
                    transitionKey,
                    JSON.stringify({ active: true, timestamp: Date.now() })
                )
            } catch {
                //
            }
            setCompletionHoldUntil(null)
            return
        }

        if (server?.status === null) {
            try {
                const raw = window.sessionStorage.getItem(transitionKey)
                const persisted = raw ? JSON.parse(raw) : null
                const isRecent =
                    persisted?.active &&
                    typeof persisted.timestamp === 'number' &&
                    Date.now() - persisted.timestamp < 10 * 60 * 1000

                if (isRecent) {
                    const holdUntil = Date.now() + 1800
                    setCompletionHoldUntil(holdUntil)
                    window.setTimeout(() => {
                        try {
                            window.sessionStorage.removeItem(transitionKey)
                        } catch {
                            //
                        }
                        setCompletionHoldUntil(current =>
                            current === holdUntil ? null : current
                        )
                    }, 1850)
                }
            } catch {
                //
            }
        }
    }, [server?.status, id])

    const getScreenBlock = (status: EloquentStatus) => {
        switch (status) {
            case 'suspended':
                {
                    const bandwidthLimitReached =
                        typeof server?.limits?.bandwidth === 'number' &&
                        server.limits.bandwidth > 0 &&
                        typeof server?.usages?.bandwidth === 'number' &&
                        server.usages.bandwidth >= server.limits.bandwidth

                    const message = bandwidthLimitReached
                        ? 'VPS is suspended due to bandwidth limit. Contact your provider.'
                        : 'This server is suspended. Contact your provider or system administrator for help.'

                return (
                    <StatusStateBlock
                        description={message}
                        Icon={NoSymbolIcon}
                        title='Server Suspended'
                        tone='warning'
                    />
                )
                }
            case 'installing':
                return (
                    <StatusProgressBlock
                        description='Your server is being installed and configured. Most installs complete in 1 to 15 minutes.'
                        serverUuid={(server?.uuid ?? id ?? '') as string}
                        title='Installing Server'
                    />
                )
            case 'restoring_backup':
                return (
                    <StatusProgressBlock
                        description='Your backup is being restored and verified. This usually takes 1 to 15 minutes.'
                        serverUuid={(server?.uuid ?? id ?? '') as string}
                        title='Restoring Backup'
                    />
                )
            case 'restoring_snapshot':
                return (
                    <StatusProgressBlock
                        description='Your snapshot is being restored and applied. This usually takes 1 to 15 minutes.'
                        serverUuid={(server?.uuid ?? id ?? '') as string}
                        title='Restoring Snapshot'
                    />
                )
            case 'install_failed':
                return (
                    <StatusStateBlock
                        description='Installation did not complete successfully. Please contact your administrator to retry or recover this VPS.'
                        Icon={ExclamationCircleIcon}
                        title='Install Failed'
                        tone='danger'
                    />
                )
            case null:
                return null
            default:
                return (
                    <StatusStateBlock
                        description='This server is in an unusable state. Please contact your administrator for recovery.'
                        Icon={ExclamationCircleIcon}
                        title='Unusable State'
                        tone='danger'
                    />
                )
        }
    }

    const isTransitionHolding =
        completionHoldUntil !== null && completionHoldUntil > Date.now()
    const isRecoverableInstallFailure = server?.status === 'install_failed'
    const hasSecurityLock = Boolean(server?.securityLock?.active)
    const hasBlockedServerState =
        typeof server?.status === 'string' && !isRecoverableInstallFailure
    const shouldRestrictNavigation =
        hasBlockedServerState ||
        isTransitionHolding ||
        isProvisioningByTask ||
        hasSecurityLock

    const { setRoutes, setBreadcrumb } = useContext(NavigationBarContext)

    useEffect(() => {
        setRoutes(
            hasSecurityLock
                ? recoveryRoutes
                : isRecoverableInstallFailure
                ? recoveryRoutes
                : shouldRestrictNavigation
                  ? restrictedRoutes
                  : visibleRoutes
        )

        return () => {
            setRoutes([])
            setBreadcrumb(null)
        }
    }, [
        setRoutes,
        setBreadcrumb,
        isRecoverableInstallFailure,
        hasSecurityLock,
        recoveryRoutes,
        shouldRestrictNavigation,
        restrictedRoutes,
        visibleRoutes,
    ])

    useEffect(() => {
        setBreadcrumb(shouldRestrictNavigation ? null : server?.name ?? null)
    }, [server, setBreadcrumb, shouldRestrictNavigation])

    const acknowledgeSecurityLock = async () => {
        if (!server) return

        setIsAcknowledgingSecurityLock(true)
        setSecurityLockError(undefined)

        try {
            await acknowledgeServerSecurityLock(server.uuid || (id as string))
            await getServer({ uuid: id as string, silent: true })
        } catch (error: any) {
            setSecurityLockError(httpErrorToHuman(error))
        } finally {
            setIsAcknowledgingSecurityLock(false)
        }
    }

    const renderSecurityLock = () => {
        const lock = server?.securityLock
        if (!lock) return null

        const details: Array<[string, string]> = [
            ['IP address', lock.ipAddress || '-'],
            ['Direction', lock.direction || 'outgoing'],
            ['Attack type', lock.attackType || 'unknown'],
            [
                'PPS',
                typeof lock.pps === 'number' ? lock.pps.toLocaleString() : '-',
            ],
            [
                'Bandwidth',
                typeof lock.bandwidthMbps === 'number'
                    ? `${lock.bandwidthMbps.toLocaleString()} Mbps`
                    : '-',
            ],
            ['Provider action', lock.providerAction || '-'],
        ]

        return (
            <div className='flex min-h-[calc(100vh-220px)] items-center justify-center px-4 py-8'>
                <div className='w-full max-w-4xl overflow-hidden rounded-[28px] border border-[var(--border-soft)] bg-[var(--surface-card)] shadow-2xl shadow-black/20'>
                    <div className='border-b border-[var(--border-soft)] bg-[var(--surface-soft)] px-6 py-5 sm:px-8'>
                        <div className='flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between'>
                            <div>
                                <p className='text-xs font-black uppercase tracking-[0.35em] text-red-400'>
                                    Security Hold
                                </p>
                                <h1 className='mt-2 text-2xl font-black text-[var(--text-primary)] sm:text-3xl'>
                                    {lock.title}
                                </h1>
                                <p className='mt-3 max-w-3xl text-sm leading-6 text-[var(--text-muted)]'>
                                    {lock.message}
                                </p>
                            </div>
                            <div className='rounded-2xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm font-bold text-red-200'>
                                VPS force-stopped
                            </div>
                        </div>
                    </div>

                    <div className='space-y-6 px-6 py-6 sm:px-8'>
                        <div className='grid gap-3 sm:grid-cols-2 lg:grid-cols-3'>
                            {details.map(([label, value]) => (
                                <div
                                    key={label}
                                    className='rounded-2xl border border-[var(--border-soft)] bg-[var(--surface-soft)] p-4'
                                >
                                    <p className='text-[11px] font-black uppercase tracking-[0.22em] text-[var(--text-muted)]'>
                                        {label}
                                    </p>
                                    <p className='mt-2 break-words text-sm font-bold text-[var(--text-primary)]'>
                                        {value}
                                    </p>
                                </div>
                            ))}
                        </div>

                        {(lock.summary || lock.docker.summary) && (
                            <div className='rounded-2xl border border-[var(--border-soft)] bg-[var(--surface-soft)] p-5'>
                                <p className='text-[11px] font-black uppercase tracking-[0.22em] text-[var(--text-muted)]'>
                                    What we found
                                </p>
                                {lock.summary && (
                                    <p className='mt-3 text-sm leading-6 text-[var(--text-primary)]'>
                                        {lock.summary}
                                    </p>
                                )}
                                {lock.docker.summary && (
                                    <p className='mt-3 text-sm leading-6 text-[var(--text-muted)]'>
                                        {lock.docker.summary}
                                    </p>
                                )}
                                {lock.docker.sample.length > 0 && (
                                    <div className='mt-4 space-y-2'>
                                        {lock.docker.sample.map(item => (
                                            <div
                                                key={item}
                                                className='rounded-xl border border-[var(--border-soft)] bg-[var(--surface-card)] px-3 py-2 font-mono text-xs leading-5 text-[var(--text-primary)]'
                                            >
                                                {item}
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                        )}

                        {securityLockError && (
                            <div className='rounded-2xl border border-red-500/40 bg-red-500/10 px-4 py-3 text-sm font-semibold text-red-200'>
                                {securityLockError}
                            </div>
                        )}

                        <div className='flex flex-col gap-3 rounded-2xl border border-[var(--border-soft)] bg-[var(--surface-soft)] p-5 sm:flex-row sm:items-center sm:justify-between'>
                            <p className='text-sm leading-6 text-[var(--text-muted)]'>
                                Check your applications, exposed ports, and
                                Docker containers before starting the VPS again.
                                Acknowledging unlocks the VPS panel; it does not
                                hide this event from admin logs.
                            </p>
                            <button
                                type='button'
                                className='inline-flex shrink-0 items-center justify-center rounded-xl border border-purple-400/40 bg-purple-600 px-5 py-3 text-sm font-black text-white shadow-lg shadow-purple-950/30 transition hover:bg-purple-500 disabled:cursor-not-allowed disabled:opacity-60'
                                disabled={isAcknowledgingSecurityLock}
                                onClick={acknowledgeSecurityLock}
                            >
                                {isAcknowledgingSecurityLock
                                    ? 'Unlocking...'
                                    : 'I understand'}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    return (
        <>
            {!server ? (
                error ? (
                    <ErrorMessage message={error} />
                ) : (
                    <Spinner />
                )
            ) : (
                <>
                    {hasSecurityLock ? (
                        renderSecurityLock()
                    ) : typeof server.status === 'string' && !isRecoverableInstallFailure ? (
                        <div className='flex min-h-[calc(100vh-220px)] items-center justify-center px-4 py-6'>
                            {getScreenBlock(server.status)}
                        </div>
                    ) : isProvisioningByTask ? (
                        <div className='flex min-h-[calc(100vh-220px)] items-center justify-center px-4 py-6'>
                            <StatusProgressBlock
                                description='Your server is being installed and configured. Most installs complete in 1 to 15 minutes.'
                                serverUuid={(server?.uuid ?? id ?? '') as string}
                                title='Installing Server'
                            />
                        </div>
                    ) : completionHoldUntil && completionHoldUntil > Date.now() ? (
                        <div className='flex min-h-[calc(100vh-220px)] items-center justify-center px-4 py-6'>
                            <StatusProgressBlock
                                description='Your server is being installed and configured. Most installs complete in 1 to 15 minutes.'
                                serverUuid={(server?.uuid ?? id ?? '') as string}
                                title='Installing Server'
                                forceCompleted
                            />
                        </div>
                    ) : (
                        <Outlet />
                    )}
                </>
            )}
        </>
    )
}

export default ServerRouter
