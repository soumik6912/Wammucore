import { lazyLoad, query } from '@/routers/helpers'
import { Route } from '@/routers/router'
import { lazy, useContext, useEffect, useMemo } from 'react'
import { useTranslation } from 'react-i18next'
import { Outlet } from 'react-router-dom'

import getUser from '@/api/admin/users/getUser'
import useUserSWR, { getKey } from '@/api/admin/users/useUserSWR'

import { NavigationBarContext } from '@/components/elements/navigation/NavigationBar'
import { getAdminPrimaryRoutes } from '@/routers/adminPrimaryRoutes'
import { useStoreState } from '@/state'


export const routes: Route[] = [
    {
        path: 'users',
        children: [
            {
                index: true,
                element: lazyLoad(
                    lazy(
                        () => import('@/components/admin/users/UsersContainer')
                    )
                ),
            },
            {
                path: ':id',
                element: lazyLoad(lazy(() => import('./AdminUserRouter'))),
                loader: async ({ params }) => {
                    try {
                        const id = parseInt(params.id!);
                        const user = await query(getKey(id), () => getUser(id));
                        return user;
                    } catch (error) {
                        return null;
                    }
                },
                children: [
                    {
                        path: 'settings',
                        element: lazyLoad(
                            lazy(
                                () =>
                                    import(
                                        '@/components/admin/users/settings/UserSettingsContainer'
                                    )
                            )
                        ),
                        children: [
                            {
                                path: 'general',
                                element: lazyLoad(
                                    lazy(
                                        () =>
                                            import(
                                                '@/components/admin/users/settings/GeneralContainer'
                                            )
                                    )
                                ),
                            },
                        ],
                    },
                    {
                        path: 'servers',
                        element: lazyLoad(
                            lazy(
                                () =>
                                    import(
                                        '@/components/admin/users/servers/UserServersContainer'
                                    )
                            )
                        ),
                    },
                ],
            },
        ],
    },
]

const AdminUserRouter = () => {
    const { setRoutes, setBreadcrumb } = useContext(NavigationBarContext)
    const { data: user } = useUserSWR()
    const { t: tStrings } = useTranslation('strings')
    const isRootAdmin = useStoreState(state => Boolean(state.user.data?.rootAdmin))
    const adminRoutes = useMemo(
        () => getAdminPrimaryRoutes(tStrings, true, isRootAdmin),
        [tStrings, isRootAdmin]
    )
    const visibleRoutes = useMemo(() => [
        {
            name: tStrings('setting_other'),
            path: '/admin/users/:id/settings',
        },
        {
            name: tStrings('server_other'),
            path: '/admin/users/:id/servers',
        },
    ], [tStrings])

    useEffect(() => {
        setRoutes(visibleRoutes)

        return () => {
            setRoutes(adminRoutes)
            setBreadcrumb(null)
        }
    }, [setRoutes, setBreadcrumb, visibleRoutes, adminRoutes])

    useEffect(() => {
        setBreadcrumb(user.name)
    }, [user.name])

    return <Outlet />
}

export default AdminUserRouter
