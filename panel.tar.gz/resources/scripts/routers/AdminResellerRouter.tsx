import { lazyLoad } from '@/routers/helpers'
import { Route } from '@/routers/router'
import { lazy } from 'react'

export const routes: Route[] = [
    {
        path: 'resellers',
        children: [
            {
                index: true,
                element: lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/admin/resellers/ResellersContainer'
                            )
                    )
                ),
            },
        ],
    },
]
