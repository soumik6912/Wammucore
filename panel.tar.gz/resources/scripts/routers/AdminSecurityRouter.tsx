import { lazyLoad } from '@/routers/helpers'
import { Route } from '@/routers/router'
import { lazy, useContext, useEffect, useMemo } from 'react'
import { useTranslation } from 'react-i18next'
import { Outlet } from 'react-router-dom'

import { NavigationBarContext } from '@/components/elements/navigation/NavigationBar'
import { getAdminPrimaryRoutes } from '@/routers/adminPrimaryRoutes'
import { useStoreState } from '@/state'

export const routes: Route[] = [
    {
        path: 'security',
        element: lazyLoad(lazy(() => import('@/routers/AdminSecurityRouter'))),
        children: [
            {
                index: true,
                element: lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/admin/security/SecurityOverviewContainer'
                            )
                    )
                ),
            },
            {
                path: 'traffic',
                element: lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/admin/security/TrafficMonitorContainer'
                            )
                    )
                ),
            },
            {
                path: 'alerts',
                element: lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/admin/security/AlertsContainer'
                            )
                    )
                ),
            },
            {
                path: 'scores',
                element: lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/admin/security/AbuseScoresContainer'
                            )
                    )
                ),
            },
        ],
    },
]

const AdminSecurityRouter = () => {
    const { t: tStrings } = useTranslation('strings')
    const isRootAdmin = useStoreState(state => Boolean(state.user.data?.rootAdmin))
    const adminRoutes = useMemo(
        () => getAdminPrimaryRoutes(tStrings, true, isRootAdmin),
        [tStrings, isRootAdmin]
    )
    const visibleRoutes = useMemo(
        () => [
            {
                name: 'Overview',
                path: '/admin/security',
                end: true,
            },
            {
                name: 'Traffic Monitor',
                path: '/admin/security/traffic',
            },
            {
                name: 'Alerts',
                path: '/admin/security/alerts',
            },
            {
                name: 'Abuse Score',
                path: '/admin/security/scores',
            },
        ],
        []
    )

    const { setRoutes, setBreadcrumb } = useContext(NavigationBarContext)

    useEffect(() => {
        setRoutes(visibleRoutes)

        return () => {
            setRoutes(adminRoutes)
            setBreadcrumb(null)
        }
    }, [setRoutes, setBreadcrumb, visibleRoutes, adminRoutes])

    useEffect(() => {
        setBreadcrumb('Security')
    }, [setBreadcrumb])

    return <Outlet />
}

export default AdminSecurityRouter
