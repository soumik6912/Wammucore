import { lazyLoad, query } from '@/routers/helpers'
import { Route } from '@/routers/router'
import { lazy, useContext, useEffect, useMemo } from 'react'
import { Translation, useTranslation } from 'react-i18next'
import { Navigate, Outlet } from 'react-router-dom'

import getAddresses from '@/api/admin/addressPools/addresses/getAddresses'
import getAddressPool from '@/api/admin/addressPools/getAddressPool'
import { getKey as getPoolKey } from '@/api/admin/addressPools/useAddressPoolSWR'
import { getKey as getAddressesKey } from '@/api/admin/addressPools/useAddressesSWR'

import { NavigationBarContext } from '@/components/elements/navigation/NavigationBar'
import { getAdminPrimaryRoutes } from '@/routers/adminPrimaryRoutes'
import { useStoreState } from '@/state'

export const routes: Route[] = [
    {
        path: 'ipam',
        handle: {
            crumb: () => ({
                to: '/admin/ipam',
                element: (
                    <Translation ns={'strings'}>{t => t('ipam')}</Translation>
                ),
            }),
        },
        children: [
            {
                index: true,
                element: lazyLoad(
                    lazy(() => import('@/components/admin/ipam/IpamContainer'))
                ),
            },
            {
                path: ':poolId',
                loader: async ({ params }) => {
                    try {
                        const poolId = parseInt(params.poolId!);
                        const pool = await query(getPoolKey(poolId), () => getAddressPool(poolId));
                        return pool;
                    } catch (error) {
                        return null;
                    }
                },
                element: lazyLoad(lazy(() => import('./AdminIpamRouter'))),
                handle: {
                    crumb: data => ({
                        to: `/admin/ipam/${data.poolId}`,
                        element: data.name,
                    }),
                },
                children: [
                    {
                        index: true,
                        element: <Navigate to={'./addresses'} replace />,
                    },
                    {
                        path: 'addresses',
                        loader: async ({ params }) => {
                            try {
                                const id = parseInt(params.poolId!)
                                const page = params.page ? parseInt(params.page) : 1
                                const addresses = await query(getAddressesKey(id, page, ''), () =>
                                    getAddresses(id, {
                                        page,
                                        query: '',
                                        include: ['server'],
                                    })
                                )
                                return addresses
                            } catch (error) {
                                return null
                            }
                        },
                        element: lazyLoad(
                            lazy(
                                () =>
                                    import(
                                        '@/components/admin/ipam/addresses/AddressesContainer'
                                    )
                            )
                        ),
                    },
                ],
            },
        ],
    },
]

const AdminIpamRouter = () => {
    const { setRoutes, setBreadcrumb } = useContext(NavigationBarContext)
    const { t: tStrings } = useTranslation('strings')
    const isRootAdmin = useStoreState(state => Boolean(state.user.data?.rootAdmin))
    const navRoutes = useMemo(
        () => getAdminPrimaryRoutes(tStrings, true, isRootAdmin),
        [tStrings, isRootAdmin]
    )

    useEffect(() => {
        setRoutes(navRoutes)

        return () => {
            setRoutes(navRoutes)
            setBreadcrumb(null)
        }
    }, [setRoutes, setBreadcrumb, navRoutes])

    return <Outlet />
}

export default AdminIpamRouter
