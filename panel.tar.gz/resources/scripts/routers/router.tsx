import { lazyLoad } from '@/routers/helpers'
import { routes as adminRoutes } from '@/routers/AdminDashboardRouter'
import { routes as clientRoutes } from '@/routers/DashboardRouter'
import AuthenticatedRoutes from '@/routers/middleware/AuthenticatedRoutes'
import GuestRoutes from '@/routers/middleware/GuestRoutes'
import { ReactNode, lazy } from 'react'
import { Navigate, Outlet, RouteObject, createBrowserRouter } from 'react-router-dom'

import { NotFound } from '@/components/elements/ScreenBlock'
import RouteErrorFallback from '@/components/elements/RouteErrorFallback'
import NavigationBar from '@/components/elements/navigation/NavigationBar'
import TrustpilotReviewPrompt from '@/components/customer/TrustpilotReviewPrompt'

import NavigationBarProvider from '@/components/NavigationBarProvider'

const LoginContainer = lazy(() => import('@/components/auth/LoginContainer'))

export type Route = {
    handle?: Handle
    children?: Route[]
} & Omit<RouteObject, 'handle' | 'children'>

export interface Handle {
    crumb: (data: any) => {
        to: string
        element: ReactNode
    }
}

const tenantScopedRoutes = (routes: Route[]): Route[] =>
    routes.map(route => ({
        ...route,
        path:
            typeof route.path === 'string'
                ? route.path === '/'
                    ? ''
                    : route.path.replace(/^\//, '')
                : route.path,
        children: route.children ? tenantScopedRoutes(route.children) : undefined,
    }))

const router = createBrowserRouter([
    {
        path: '/auth',
        errorElement: <RouteErrorFallback />,
        element: (
            <GuestRoutes>
                <Outlet />
            </GuestRoutes>
        ),
        children: [
            {
                path: 'login',
                element: lazyLoad(LoginContainer),
            },
            {
                path: 'register',
                element: lazyLoad(lazy(() => import('@/components/auth/RegisterContainer'))),
            },
            {
                path: 'reseller/register',
                element: <Navigate to='/reseller/register' replace />,
            },
            {
                path: 'forgot-password',
                element: lazyLoad(lazy(() => import('@/components/auth/ForgotPasswordContainer'))),
            },
            {
                path: 'verify-email',
                element: lazyLoad(lazy(() => import('@/components/auth/VerifyEmailContainer'))),
            },
        ],
    },
    {
        path: '/login',
        element: <Navigate to='/auth/login' replace />,
    },
    {
        path: '/register',
        element: <Navigate to='/auth/register' replace />,
    },
    {
        path: '/forgot-password',
        element: <Navigate to='/auth/forgot-password' replace />,
    },
    {
        path: '/r/:resellerRef/auth',
        errorElement: <RouteErrorFallback />,
        element: (
            <GuestRoutes>
                <Outlet />
            </GuestRoutes>
        ),
        children: [
            {
                path: 'login',
                element: lazyLoad(LoginContainer),
            },
            {
                path: 'register',
                element: lazyLoad(lazy(() => import('@/components/auth/RegisterContainer'))),
            },
            {
                path: 'forgot-password',
                element: lazyLoad(lazy(() => import('@/components/auth/ForgotPasswordContainer'))),
            },
        ],
    },
    {
        path: '/r/:resellerRef/login',
        element: <Navigate to='../auth/login' replace />,
    },
    {
        path: '/r/:resellerRef/register',
        element: <Navigate to='../auth/register' replace />,
    },
    {
        path: '/r/:resellerRef/forgot-password',
        element: <Navigate to='../auth/forgot-password' replace />,
    },
    {
        path: '/verify-email',
        element: lazyLoad(lazy(() => import('@/components/auth/VerifyEmailContainer'))),
    },
    {
        path: '/reseller/register',
        errorElement: <RouteErrorFallback />,
        element: (
            <GuestRoutes>
                {lazyLoad(
                    lazy(() => import('@/components/auth/ResellerRegisterContainer'))
                )}
            </GuestRoutes>
        ),
    },
    {
        path: '/reseller/login',
        errorElement: <RouteErrorFallback />,
        element: (
            <GuestRoutes>
                {lazyLoad(LoginContainer)}
            </GuestRoutes>
        ),
    },
    {
        path: '/:resellerRef/auth',
        errorElement: <RouteErrorFallback />,
        element: (
            <GuestRoutes>
                <Outlet />
            </GuestRoutes>
        ),
        children: [
            {
                path: 'login',
                element: lazyLoad(LoginContainer),
            },
            {
                path: 'register',
                element: lazyLoad(lazy(() => import('@/components/auth/RegisterContainer'))),
            },
            {
                path: 'forgot-password',
                element: lazyLoad(lazy(() => import('@/components/auth/ForgotPasswordContainer'))),
            },
        ],
    },
    {
        path: '/:resellerRef/login',
        element: <Navigate to='../auth/login' replace />,
    },
    {
        path: '/:resellerRef/register',
        element: <Navigate to='../auth/register' replace />,
    },
    {
        path: '/:resellerRef/forgot-password',
        element: <Navigate to='../auth/forgot-password' replace />,
    },
    {
        path: '/:resellerRef',
        errorElement: <RouteErrorFallback />,
        element: (
            <AuthenticatedRoutes>
                <NavigationBarProvider>
                    <NavigationBar />
                    <TrustpilotReviewPrompt />
                    <Outlet />
                </NavigationBarProvider>
            </AuthenticatedRoutes>
        ),
        children: [
            ...tenantScopedRoutes(clientRoutes),
            {
                path: '*',
                element: <NotFound full />,
            },
        ] as RouteObject[],
    },
    {
        path: '/r/:resellerRef',
        errorElement: <RouteErrorFallback />,
        element: (
            <AuthenticatedRoutes>
                <NavigationBarProvider>
                    <NavigationBar />
                    <TrustpilotReviewPrompt />
                    <Outlet />
                </NavigationBarProvider>
            </AuthenticatedRoutes>
        ),
        children: [
            ...tenantScopedRoutes(clientRoutes),
            {
                path: '*',
                element: <NotFound full />,
            },
        ] as RouteObject[],
    },
    {
        path: '/',
        errorElement: <RouteErrorFallback />,
        element: (
            <AuthenticatedRoutes>
                <NavigationBarProvider>
                    <NavigationBar />
                    <TrustpilotReviewPrompt />
                    <Outlet />
                </NavigationBarProvider>
            </AuthenticatedRoutes>
        ),
        children: [
            ...clientRoutes,
            ...adminRoutes,
            {
                path: '*',
                element: <NotFound full />,
            },
        ] as RouteObject[],
    },
    {
        path: '/console',
        errorElement: <RouteErrorFallback />,
        element: (
            <AuthenticatedRoutes>
                {lazyLoad(
                    lazy(() => import('@/components/servers/terminal/ConsolePopupContainer'))
                )}
            </AuthenticatedRoutes>
        ),
    },
    {
        path: '/reseller/create',
        errorElement: <RouteErrorFallback />,
        element: (
            <AuthenticatedRoutes requireRootAdmin>
                <Navigate to='/admin/reseller/create' replace />
            </AuthenticatedRoutes>
        ),
    },
    {
        path: '/reseller/panel',
        errorElement: <RouteErrorFallback />,
        element: (
            <AuthenticatedRoutes requireRootAdmin>
                {lazyLoad(
                    lazy(
                        () =>
                            import(
                                '@/components/admin/resellers/ResellerPanelEntryContainer'
                            )
                    )
                )}
            </AuthenticatedRoutes>
        ),
    },
    {
        path: '*',
        element: <NotFound full />,
    },
])

export default router
