import useTenantContextSWR from '@/api/admin/tenancy/useTenantContextSWR'
import Spinner from '@/components/elements/Spinner'
import { Navigate } from 'react-router-dom'

interface Props {
    children: JSX.Element
}

const MasterAdminViewRoutes = ({ children }: Props) => {
    const { data: tenantContext } = useTenantContextSWR()

    if (!tenantContext) {
        return <Spinner />
    }

    if (tenantContext.mode === 'reseller') {
        return <Navigate to='/admin/reseller-panel' replace />
    }

    return children
}

export default MasterAdminViewRoutes
