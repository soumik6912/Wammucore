import useTenantContextSWR from '@/api/admin/tenancy/useTenantContextSWR'
import Spinner from '@/components/elements/Spinner'
import { useStoreState } from '@/state'
import { Navigate } from 'react-router-dom'

interface Props {
    children: JSX.Element
}

const RootAdminOnlyRoutes = ({ children }: Props) => {
    const { data: tenantContext } = useTenantContextSWR()
    const isRootAdmin = useStoreState(state => Boolean(state.user.data?.rootAdmin))

    if (!tenantContext) {
        return <Spinner />
    }

    if (!isRootAdmin) {
        return <Navigate to='/admin' replace />
    }

    if (tenantContext.mode === 'reseller') {
        return <Navigate to='/admin/reseller-panel' replace />
    }

    return children
}

export default RootAdminOnlyRoutes
