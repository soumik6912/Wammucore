import { useStoreState } from '@/state'
import refreshAuthSession from '@/api/auth/refreshAuthSession'
import { useStoreActions } from '@/state'
import { Navigate, useLocation } from 'react-router-dom'
import { useEffect, useState } from 'react'

interface Props {
    children: JSX.Element
}

const reservedTenantSegments = new Set([
    'admin',
    'api',
    'auth',
    'authorize',
    'assets',
    'build',
    'favicon.ico',
    'locales',
    'login',
    'register',
    'reseller',
    'servers',
    'store',
    'account',
    'forgot-password',
    'verify-email',
])

const tenantRoutePrefixFromPath = (pathname: string): string => {
    const legacyMatch = pathname.match(/^\/r\/[^/]+/)
    if (legacyMatch?.[0]) {
        return legacyMatch[0]
    }

    const directMatch = pathname.match(/^\/([^/?#]+)/)
    const segment = directMatch?.[1] ? decodeURIComponent(directMatch[1]).trim() : ''
    if (!segment || reservedTenantSegments.has(segment.toLowerCase())) {
        return ''
    }

    return `/${encodeURIComponent(segment)}`
}

const GuestRoutes: React.FC<Props> = ({ children }) => {
    const user = useStoreState(state => state.user.data)
    const tenantResellerId = useStoreState(state => state.settings.data?.resellerId ?? null)
    const setUserData = useStoreActions(actions => actions.user.setUserData)
    const location = useLocation()
    const [checkingRefresh, setCheckingRefresh] = useState(!user?.email)
    const tenantRoutePrefix = tenantRoutePrefixFromPath(location.pathname)

    useEffect(() => {
        let mounted = true

        if (user?.email) {
            setCheckingRefresh(false)
            return () => {
                mounted = false
            }
        }

        void refreshAuthSession()
            .then(session => {
                if (!mounted) {
                    return
                }

                setUserData(session.user)
            })
            .catch(() => {
                // No valid remember token is normal on fresh login pages.
            })
            .finally(() => {
                if (mounted) {
                    setCheckingRefresh(false)
                }
            })

        return () => {
            mounted = false
        }
    }, [setUserData, user?.email])

    if (!user?.email && checkingRefresh) {
        return null
    }

    if (user?.email) {
        if (tenantRoutePrefix && tenantResellerId) {
            const userMatchesTenant =
                !user.rootAdmin &&
                !user.platformAdmin &&
                !user.resellerAdmin &&
                user.resellerId === tenantResellerId

            return userMatchesTenant ? (
                <Navigate to={tenantRoutePrefix} state={{ from: location }} replace />
            ) : (
                children
            )
        }

        const from = (location.state as any)?.from
        const fromPath = typeof from?.pathname === 'string' ? from.pathname : ''
        const fromSearch = typeof from?.search === 'string' ? from.search : ''
        const resellerAdminTarget = fromPath.startsWith('/admin/reseller-panel')
            ? `${fromPath}${fromSearch}`
            : '/admin/reseller-panel'
        const resellerOnboardingTarget =
            user.resellerOnboardingPath || '/admin/reseller-panel/onboarding'
        const resellerOnboardingLocked =
            user.resellerCustomerPanelLocked ||
            !user.resellerOnboardingCompleted ||
            user.resellerOnboardingStatus !== 'completed'

        if (user.resellerAdmin && !user.rootAdmin && !user.platformAdmin) {
            return (
                <Navigate
                    to={
                        !resellerOnboardingLocked
                            ? resellerAdminTarget
                            : resellerOnboardingTarget
                    }
                    state={{ from: location }}
                    replace
                />
            )
        }

        if (tenantResellerId && user.resellerAdmin && user.resellerId === tenantResellerId) {
            return <Navigate to='/admin' state={{ from: location }} replace />
        }

        return <Navigate to='/' state={{ from: location }} replace />
    }

    return children
}

export default GuestRoutes
