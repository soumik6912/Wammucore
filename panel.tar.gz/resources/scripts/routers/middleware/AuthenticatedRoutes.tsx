import { useStoreState } from '@/state'
import getAuthSession from '@/api/auth/getAuthSession'
import { useStoreActions } from '@/state'
import { useEffect } from 'react'
import { Navigate, useLocation } from 'react-router-dom'

interface Props {
    children: JSX.Element
    requireRootAdmin?: boolean
    requireAdmin?: boolean
}

const reservedTenantSegments = new Set([
    'admin',
    'api',
    'auth',
    'authorize',
    'assets',
    'build',
    'favicon.ico',
    'locales',
    'login',
    'register',
    'reseller',
    'servers',
    'store',
    'account',
    'forgot-password',
    'verify-email',
])

const tenantRoutePrefixFromPath = (pathname: string): string => {
    const legacyMatch = pathname.match(/^\/r\/[^/]+/)
    if (legacyMatch?.[0]) {
        return legacyMatch[0]
    }

    const directMatch = pathname.match(/^\/([^/?#]+)/)
    const segment = directMatch?.[1] ? decodeURIComponent(directMatch[1]).trim() : ''
    if (!segment || reservedTenantSegments.has(segment.toLowerCase())) {
        return ''
    }

    return `/${encodeURIComponent(segment)}`
}

const AuthenticatedRoutes: React.FC<Props> = ({
    children,
    requireRootAdmin,
    requireAdmin,
}) => {
    const user = useStoreState(state => state.user.data)
    const setUserData = useStoreActions(actions => actions.user.setUserData)
    const clearUserData = useStoreActions(actions => actions.user.clearUserData)
    const tenantResellerId = useStoreState(state => state.settings.data?.resellerId ?? null)
    const location = useLocation()
    const isAdminArea =
        location.pathname === '/admin' || location.pathname.startsWith('/admin/')
    const isResellerPanelArea =
        location.pathname === '/admin/reseller-panel' ||
        location.pathname.startsWith('/admin/reseller-panel/')
    const isResellerOnboardingArea =
        location.pathname === '/admin/reseller-panel/onboarding' ||
        location.pathname.startsWith('/admin/reseller-panel/onboarding/')
    const tenantRoutePrefix = tenantRoutePrefixFromPath(location.pathname)
    const loginPath = isResellerPanelArea || (isAdminArea && tenantResellerId)
        ? '/reseller/login'
        : tenantRoutePrefix
        ? `${tenantRoutePrefix}/auth/login`
        : '/auth/login'

    useEffect(() => {
        if (!user) {
            return
        }

        let alive = true

        const check = () => {
            getAuthSession()
                .then(nextUser => {
                    if (alive) {
                        setUserData(nextUser)
                    }
                })
                .catch(() => {
                    if (alive) {
                        clearUserData()
                        window.dispatchEvent(new CustomEvent('wammucore:auth-invalid'))
                    }
                })
        }

        const interval = window.setInterval(check, isAdminArea ? 10000 : 20000)
        const onFocus = () => check()
        window.addEventListener('focus', onFocus)

        return () => {
            alive = false
            window.clearInterval(interval)
            window.removeEventListener('focus', onFocus)
        }
    }, [clearUserData, isAdminArea, setUserData, user?.email])

    if (!user) {
        return <Navigate to={loginPath} state={{ from: location }} replace />
    }

    const resellerOnboardingLocked = Boolean(
        user.resellerAdmin &&
            !user.rootAdmin &&
            !user.platformAdmin &&
            (
                user.resellerCustomerPanelLocked ||
                !user.resellerOnboardingCompleted ||
                user.resellerOnboardingStatus !== 'completed'
            )
    )

    if (resellerOnboardingLocked && !isResellerOnboardingArea) {
        return (
            <Navigate
                to={user.resellerOnboardingPath || '/admin/reseller-panel/onboarding'}
                state={{ from: location }}
                replace
            />
        )
    }

    if (
        isAdminArea &&
        (tenantResellerId || isResellerPanelArea) &&
        !user.rootAdmin &&
        !user.platformAdmin
    ) {
        if (!user.resellerAdmin || (tenantResellerId && user.resellerId !== tenantResellerId)) {
            return <Navigate to='/' replace />
        }
    }

    if (
        requireAdmin &&
        !user?.rootAdmin &&
        !user?.platformAdmin &&
        !user?.resellerAdmin
    ) {
        return <Navigate to='/' replace />
    }

    if (requireRootAdmin && !user?.rootAdmin) {
        return <Navigate to='/' replace />
    }

    return children
}

export default AuthenticatedRoutes
