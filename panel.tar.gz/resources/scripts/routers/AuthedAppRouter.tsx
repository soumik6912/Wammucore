import { routes as adminRoutes } from '@/routers/AdminDashboardRouter'
import { routes as clientRoutes } from '@/routers/DashboardRouter'
import { RouteObject, useRoutes } from 'react-router-dom'

import { NotFound } from '@/components/elements/ScreenBlock'

const AuthedAppRouter = () =>
    useRoutes([
        ...clientRoutes,
        ...adminRoutes,
        {
            path: '*',
            element: <NotFound full />,
        },
    ] as RouteObject[])

export default AuthedAppRouter
