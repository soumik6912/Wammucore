type TFn = (key: string) => string
type RouteDefinition = {
    name: string
    path: string
    end?: boolean
    group?: string
}

const groups = {
    command: 'Command Center',
    operations: 'Operations',
    infrastructure: 'Infrastructure',
    security: 'Security & Audit',
    system: 'System & API',
    workspace: 'Workspace',
} as const

export const getAdminPrimaryRoutes = (
    t: TFn,
    isMasterView: boolean = true,
    isRootAdmin: boolean = false
): RouteDefinition[] => {
    if (!isMasterView) {
        return [
            {
                name: 'Reseller Workspace',
                path: '/admin/reseller-panel',
                end: true,
                group: groups.workspace,
            },
        ]
    }

    const alwaysRoutes: RouteDefinition[] = [
        {
            name: 'Dashboard',
            path: '/admin',
            end: true,
            group: groups.command,
        },
        {
            name: 'Owner Console',
            path: '/admin/control',
            group: groups.command,
        },
        {
            name: 'Services',
            path: '/admin/services',
            group: groups.operations,
        },
        {
            name: 'VPS Services',
            path: '/admin/servers',
            group: groups.operations,
        },
        {
            name: 'VPS Plans',
            path: '/admin/plans',
            group: groups.operations,
        },
        {
            name: 'IP Plans',
            path: '/admin/ipam',
            group: groups.operations,
        },
        {
            name: 'Dedicated Services',
            path: '/admin/dedicated',
            group: groups.operations,
        },
        {
            name: t('user_other'),
            path: '/admin/users',
            group: groups.operations,
        },
        {
            name: 'Resellers',
            path: '/admin/resellers',
            group: groups.operations,
        },
        {
            name: 'Reseller Settings',
            path: '/admin/reseller-settings',
            group: groups.operations,
        },
        {
            name: 'Security Center',
            path: '/admin/security',
            group: groups.security,
        },
    ]

    return [
        ...alwaysRoutes,
        {
            name: t('location_other'),
            path: '/admin/locations',
            group: groups.infrastructure,
        },
        {
            name: t('node_other'),
            path: '/admin/nodes',
            group: groups.infrastructure,
        },
        {
            name: 'Health Checks',
            path: '/admin/diagnostics',
            group: groups.security,
        },
        {
            name: 'Coterm Gateways',
            path: '/admin/coterms',
            group: groups.infrastructure,
        },
        {
            name: 'API Tokens',
            path: '/admin/tokens',
            group: groups.system,
        },
        {
            name: 'Email & Templates',
            path: '/admin/email',
            group: groups.system,
        },
        ...(isRootAdmin
            ? [
                {
                    name: 'Audit Logs',
                    path: '/admin/logs',
                    group: groups.security,
                },
                {
                    name: 'Core Services',
                    path: '/admin/core',
                    group: groups.system,
                },
            ]
            : []),
    ]
}
