import { Action, action } from 'easy-peasy'

export interface UserData {
    name: string
    email: string
    avatarUrl?: string | null
    rootAdmin: boolean
    platformAdmin: boolean
    resellerAdmin: boolean
    resellerId: number | null
    resellerOnboardingStatus: string | null
    resellerOnboardingCurrentStep: string | null
    resellerOnboardingPath: string
    resellerOnboardingCompleted: boolean
    resellerCustomerPanelLocked: boolean
    adminRoles: Array<{
        id: number
        name: string
        slug: string
    }>
    adminPermissions: string[]
    panelThemeKey: string | null
    createdAt: string
    updatedAt: string
}

export interface UserStore {
    data?: UserData
    setUserData: Action<UserStore, UserData>
    clearUserData: Action<UserStore>
    setPanelThemeKey: Action<UserStore, string | null>
}

const user: UserStore = {
    data: undefined,
    setUserData: action((state, payload) => {
        state.data = payload
    }),
    clearUserData: action(state => {
        state.data = undefined
    }),
    setPanelThemeKey: action((state, payload) => {
        if (state.data) {
            state.data.panelThemeKey = payload
        }
    }),
}

export default user
