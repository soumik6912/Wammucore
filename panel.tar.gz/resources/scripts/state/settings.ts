import { Action, action } from 'easy-peasy'

export interface SiteSettings {
    theme: 'dark' | 'light' | 'system'
    version: string
    licenseCatalog?: {
        id?: string
        name: string
        description?: string | null
        startsAt?: string | null
        priceDisplay?: string | null
        learnMoreUrl?: string | null
        purchaseUrl?: string | null
        iconUrl?: string | null
    }[]
    panelName?: string
    logoUrl?: string | null
    loginBackgroundImage?: string | null
    bannerImageUrl?: string | null
    faviconUrl?: string | null
    loadingLogoUrl?: string | null
    billingUrl?: string | null
    platformStoreRedirectUrl?: string | null
    effectiveStorefrontUrl?: string | null
    platformUpgradeEnabled?: boolean
    platformUpgradeUrlTemplate?: string | null
    upgradeButtonEnabled?: boolean
    upgradeUrlTemplate?: string | null
    apiDocsUrl?: string | null
    tutorialUrl?: string | null
    resellerRegistrationTermsUrl?: string | null
    resellerRegistrationPrivacyUrl?: string | null
    resellerRegistrationEnabled?: boolean
    resellerKyc?: {
        aadhaarEnabled: boolean
        panEnabled: boolean
        digilockerEnabled: boolean
        digilockerUrl: string | null
    }
    resellerEmailVerificationEnabled?: boolean
    resellerEmailVerificationAvailable?: boolean
    resellerEmailVerificationEffective?: boolean
    passwordResetEnabled?: boolean
    passwordResetAvailable?: boolean
    passwordResetEffective?: boolean
    resourceGuard?: {
        enabled: boolean
        thresholdPercent: number
    }
    trustpilotReview?: {
        enabled: boolean
        url: string | null
        viewThreshold: number
        delayDays: number
    }
    customDomains?: {
        edgeGatewayHost: string
        verificationPrefix: string
        autoSslEnabled: boolean
    }
    defaultPlanCurrency?: string
    platformMail?: {
        enabled: boolean
        configured: boolean
        source: 'panel' | 'env' | 'none'
        host: string | null
        port: number | null
        encryption: 'tls' | 'ssl' | 'none'
        username: string | null
        passwordSet: boolean
        fromEmail: string | null
        fromName: string | null
        replyToEmail: string | null
        ehloDomain: string | null
    }
    notificationEmailEnabled?: boolean
    notificationEmailAvailable?: boolean
    notificationEmailEffective?: boolean
    notificationTemplates?: {
        key: string
        label: string
        description: string
        enabled: boolean
        subject: string
        heading: string
        body: string
    }[]
    footerText?: string
    footerUrl?: string | null
    brandPrimaryColor?: string | null
    brandSecondaryColor?: string | null
    brandAccentColor?: string | null
    customCss?: string | null
    tenantThemeKey?: string | null
    tenantNameservers?: string[]
    tenantId?: number | null
    resellerId?: number | null
    tenantSlug?: string | null
    tenantUuid?: string | null
    tenantHostname?: string | null
    platformAdminUrl?: string | null
    clientAuth?: {
        allowSelfRegistration: boolean
        enableEmail2fa: boolean
        enableEmailVerification: boolean
        mailerConfigured: boolean
        passwordResetEnabled: boolean
    }
    resellerRegistrationMeta?: {
        enabled: boolean
        hostAllowed?: boolean
        hostMessage?: string | null
        edgeGatewayHost: string
        verificationPrefix: string
        termsUrl: string | null
        privacyUrl: string | null
        kycPolicy?: {
            allowedProofTypes: Array<'aadhaar' | 'pan'>
            aadhaarEnabled: boolean
            panEnabled: boolean
            digilockerEnabled: boolean
            digilockerUrl: string | null
        }
        emailVerificationEnabled: boolean
        emailVerificationAvailable: boolean
        emailVerificationRequired: boolean
        emailVerificationMessage: string | null
    }
}

export interface SettingsStore {
    data?: SiteSettings
    privacyMode: boolean
    setSettings: Action<SettingsStore, SiteSettings>
    setTheme: Action<SettingsStore, 'dark' | 'light' | 'system'>
    setPrivacyMode: Action<SettingsStore, boolean>
}

const settings: SettingsStore = {
    data: undefined,
    privacyMode: false,
    setSettings: action((state, payload) => {
        state.data = payload
    }),
    setTheme: action((state, payload) => {
        localStorage.setItem('theme', payload)
        // @ts-expect-error: version should be initialized by the time setTheme is called
        state.data = {
            ...state.data,
            ...{ theme: payload },
        }
    }),
    setPrivacyMode: action((state, payload) => {
        localStorage.setItem('privacy_mode', payload ? 'true' : 'false')
        state.privacyMode = payload
    }),
}

export default settings
