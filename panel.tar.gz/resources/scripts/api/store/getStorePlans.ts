import http from '@/api/http'

export interface StorePlan {
    id: number
    name: string
    slug: string
    description: string | null
    cpuCores: number
    ramMb: number
    diskGb: number
    bandwidthGb: number | null
    snapshotLimit: number
    backupLimit: number
    monthlyPrice: string | null
    currency: string
    ipQuantity: number
    addressPoolId: number | null
    addressPool: {
        id: number
        name: string
        resellerIpPriceEach: string
    } | null
    ipPriceEach: string
    paymenterCheckoutUrl: string | null
    checkoutEnabled: boolean
}

export interface StoreLocationOption {
    id: number
    shortCode: string
    description: string | null
    availableNodes: number
}

export interface StorePlansResponse {
    tenantId: number
    resellerId: number
    items: StorePlan[]
    locations: StoreLocationOption[]
}

const rawDataToStorePlan = (data: any): StorePlan => ({
    id: Number(data.id),
    name: data.name,
    slug: data.slug,
    description: data.description ?? null,
    cpuCores: Number(data.cpu_cores),
    ramMb: Number(data.ram_mb),
    diskGb: Number(data.disk_gb),
    bandwidthGb: data.bandwidth_gb === null ? null : Number(data.bandwidth_gb),
    snapshotLimit: Number(data.snapshot_limit ?? 0),
    backupLimit: Number(data.backup_limit ?? 0),
    monthlyPrice: data.monthly_price ?? null,
    currency: data.currency ?? 'USD',
    ipQuantity: Number(data.ip_quantity ?? 0),
    addressPoolId:
        data.address_pool_id === null || data.address_pool_id === undefined
            ? null
            : Number(data.address_pool_id),
    addressPool: data.address_pool
        ? {
              id: Number(data.address_pool.id),
              name: String(data.address_pool.name ?? ''),
              resellerIpPriceEach: String(
                  data.address_pool.reseller_ip_price_each ?? '0.00'
              ),
          }
        : null,
    ipPriceEach: data.ip_price_each ?? '0.00',
    paymenterCheckoutUrl: data.paymenter_checkout_url ?? null,
    checkoutEnabled: Boolean(data.checkout_enabled ?? false),
})

const rawDataToStoreLocation = (data: any): StoreLocationOption => ({
    id: Number(data.id),
    shortCode: String(data.short_code ?? ''),
    description: data.description ?? null,
    availableNodes: Number(data.available_nodes ?? 0),
})

const getStorePlans = async (): Promise<StorePlansResponse> => {
    const {
        data: { data },
    } = await http.get('/api/client/store/plans')

    return {
        tenantId: Number(data.tenant_id ?? data.reseller_id ?? 0),
        resellerId: Number(data.reseller_id ?? 0),
        items: Array.isArray(data.items) ? data.items.map(rawDataToStorePlan) : [],
        locations: Array.isArray(data.locations)
            ? data.locations.map(rawDataToStoreLocation)
            : [],
    }
}

export default getStorePlans
