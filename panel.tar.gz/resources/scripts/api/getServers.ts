import http, { PaginatedResult, getPaginationSet, WammuCoreRequestConfig } from '@/api/http'
import { ServerBuild, rawDataToServerBuild } from '@/api/server/getServer'

interface QueryParams {
    query?: string
    page?: number
    type?: string
    perPage?: number
}

export default ({
    query,
    perPage = 24,
    ...params
}: QueryParams, options?: WammuCoreRequestConfig): Promise<PaginatedResult<ServerBuild>> => {
    return new Promise((resolve, reject) => {
        http.get('/api/client/servers', {
            params: {
                'filter[name]': query,
                'per_page': perPage,
                ...params,
            },
            ...options,
        })
            .then(({ data }) =>
                resolve({
                    items: (data.data || []).map((datum: any) =>
                        rawDataToServerBuild(datum)
                    ),
                    pagination: getPaginationSet(
                        data?.meta?.pagination || {
                            total: 0,
                            count: 0,
                            per_page: perPage,
                            current_page: params.page ?? 1,
                            total_pages: 1,
                        }
                    ),
                })
            )
            .catch(reject)
    })
}
