import http from '@/api/http'
import { PublicShieldInput, toPublicShieldPayload } from '@/util/publicShield'

export interface LoginData {
    email: string
    password: string
    remember?: boolean
    loginContext?: 'platform' | 'tenant_customer' | 'reseller_admin'
    security?: PublicShieldInput
}

const login = async ({
    email,
    password,
    remember = false,
    loginContext = 'platform',
    security,
}: LoginData) => {
    const { data } = await http.post('/api/client/auth/login', {
        email: email.trim().toLowerCase(),
        password,
        remember,
        login_context: loginContext,
        ...(security ? toPublicShieldPayload(security) : {}),
    })

    return data.data
}

export default login
