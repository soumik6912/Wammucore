import http from '@/api/http'
import { PublicShieldInput, toPublicShieldPayload } from '@/util/publicShield'

interface ResetPasswordPayload {
    token: string
    email: string
    password: string
    passwordConfirmation: string
    security?: PublicShieldInput
}

const resetPassword = async (payload: ResetPasswordPayload) => {
    const { data } = await http.post('/api/client/auth/reset-password', {
        token: payload.token,
        email: payload.email.trim().toLowerCase(),
        password: payload.password,
        password_confirmation: payload.passwordConfirmation,
        ...(payload.security ? toPublicShieldPayload(payload.security) : {}),
    })

    return data.data
}

export default resetPassword
