import http from '@/api/http'
import { PublicShieldInput, toPublicShieldPayload } from '@/util/publicShield'

export interface RegisterResellerPayload {
    displayName: string
    domain: string
    adminName?: string | null
    adminEmail: string
    adminPassword: string
    adminPasswordConfirmation: string
    agreeTerms: boolean
    security?: PublicShieldInput
}

export interface RegisterResellerResponse {
    resellerId: number
    tenantUuid: string | null
    slug: string | null
    status: string
    verificationStatus: string
    panelDomain: string
    message: string
    autoLoggedIn: boolean
    redirectPath: string | null
}

const registerReseller = async (
    payload: RegisterResellerPayload
): Promise<RegisterResellerResponse> => {
    const {
        data: { data },
    } = await http.post('/auth/reseller/register', {
        display_name: payload.displayName.trim(),
        domain: payload.domain.trim(),
        admin_name: payload.adminName && payload.adminName.trim() ? payload.adminName.trim() : null,
        admin_email: payload.adminEmail.trim().toLowerCase(),
        admin_password: payload.adminPassword,
        admin_password_confirmation: payload.adminPasswordConfirmation,
        agree_terms: payload.agreeTerms,
        ...(payload.security ? toPublicShieldPayload(payload.security) : {}),
    })

    return {
        resellerId: Number(data.reseller_id),
        tenantUuid:
            typeof data.tenant_uuid === 'string' && data.tenant_uuid.trim() !== ''
                ? data.tenant_uuid
                : null,
        slug:
            typeof data.slug === 'string' && data.slug.trim() !== ''
                ? data.slug
                : null,
        status: String(data.status),
        verificationStatus: String(data.verification_status),
        panelDomain: String(data.panel_domain),
        message: String(data.message),
        autoLoggedIn: Boolean(data.auto_logged_in),
        redirectPath:
            typeof data.redirect_path === 'string' && data.redirect_path.trim() !== ''
                ? data.redirect_path
                : null,
    }
}

export default registerReseller
