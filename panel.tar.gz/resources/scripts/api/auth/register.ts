import http from '@/api/http'
import { PublicShieldInput, toPublicShieldPayload } from '@/util/publicShield'

export interface RegisterPayload {
    name: string
    email: string
    password: string
    passwordConfirmation: string
    security?: PublicShieldInput
}

const register = async (payload: RegisterPayload) => {
    const { data } = await http.post('/api/client/auth/register', {
        name: payload.name.trim(),
        email: payload.email.trim().toLowerCase(),
        password: payload.password,
        password_confirmation: payload.passwordConfirmation,
        ...(payload.security ? toPublicShieldPayload(payload.security) : {}),
    })

    return data.data
}

export default register
