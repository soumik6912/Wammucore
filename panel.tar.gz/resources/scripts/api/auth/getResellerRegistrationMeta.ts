import http from '@/api/http'

export interface ResellerRegistrationMeta {
    enabled: boolean
    hostAllowed: boolean
    hostMessage: string | null
    edgeGatewayHost: string
    verificationPrefix: string
    termsUrl: string | null
    privacyUrl: string | null
    kycPolicy: {
        allowedProofTypes: Array<'aadhaar' | 'pan'>
        aadhaarEnabled: boolean
        panEnabled: boolean
        digilockerEnabled: boolean
        digilockerUrl: string | null
    }
    emailVerificationEnabled: boolean
    emailVerificationAvailable: boolean
    emailVerificationRequired: boolean
    emailVerificationMessage: string | null
}

const getResellerRegistrationMeta = async (): Promise<ResellerRegistrationMeta> => {
    const {
        data: { data },
    } = await http.get('/auth/reseller/register/meta')

    return {
        enabled: Boolean(data.enabled),
        hostAllowed: Boolean(data.host_allowed ?? true),
        hostMessage:
            typeof data.host_message === 'string' && data.host_message.trim() !== ''
                ? data.host_message.trim()
                : null,
        edgeGatewayHost: String(
            data.edge_gateway_host || 'edge.wammuhost.com'
        ),
        verificationPrefix: String(
            data.verification_prefix || '_wammuhost-verify'
        ),
        termsUrl: data.terms_url ?? null,
        privacyUrl: data.privacy_url ?? null,
        kycPolicy: {
            allowedProofTypes: Array.isArray(data.kyc_policy?.allowed_proof_types)
                ? data.kyc_policy.allowed_proof_types
                      .map((type: any) => String(type))
                      .filter((type: string): type is 'aadhaar' | 'pan' =>
                          type === 'aadhaar' || type === 'pan'
                      )
                : ['aadhaar', 'pan'],
            aadhaarEnabled: Boolean(data.kyc_policy?.aadhaar_enabled ?? true),
            panEnabled: Boolean(data.kyc_policy?.pan_enabled ?? true),
            digilockerEnabled: Boolean(data.kyc_policy?.digilocker_enabled),
            digilockerUrl: data.kyc_policy?.digilocker_url ?? null,
        },
        emailVerificationEnabled: Boolean(data.email_verification_enabled),
        emailVerificationAvailable: Boolean(data.email_verification_available),
        emailVerificationRequired: Boolean(data.email_verification_required),
        emailVerificationMessage: data.email_verification_message ?? null,
    }
}

export default getResellerRegistrationMeta
