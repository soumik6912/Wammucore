import http from '@/api/http'

const logout = async () => {
    const { data } = await http.post('/api/client/auth/logout')

    return data.data
}

export default logout
