import http from '@/api/http'

interface VerifyEmailTwoFactorPayload {
    challengeId: string
    code: string
}

const verifyEmailTwoFactor = async (payload: VerifyEmailTwoFactorPayload) => {
    const { data } = await http.post('/api/client/auth/login/email-2fa', {
        challenge_id: payload.challengeId,
        code: payload.code,
    })

    return data.data
}

export default verifyEmailTwoFactor
