import http from '@/api/http'
import { PublicShieldInput, toPublicShieldPayload } from '@/util/publicShield'

const forgotPassword = async (email: string, security?: PublicShieldInput) => {
    const { data } = await http.post('/api/client/auth/forgot-password', {
        email: email.trim().toLowerCase(),
        ...(security ? toPublicShieldPayload(security) : {}),
    })

    return data.data
}

export default forgotPassword
