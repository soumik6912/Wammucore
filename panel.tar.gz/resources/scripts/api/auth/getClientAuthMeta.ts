import http from '@/api/http'

export interface ClientAuthMeta {
    tenantId: number | null
    resellerId: number | null
    resellerName: string | null
    tenantHostname: string | null
    allowSelfRegistration: boolean
    enableEmail2fa: boolean
    enableEmailVerification: boolean
    mailerConfigured: boolean
    passwordResetEnabled: boolean
}

const getClientAuthMeta = async (): Promise<ClientAuthMeta> => {
    const {
        data: { data },
    } = await http.get('/api/client/auth/meta')

    return {
        tenantId: data.tenant_id ?? data.reseller_id ?? null,
        resellerId: data.reseller_id ?? null,
        resellerName: data.reseller_name ?? null,
        tenantHostname: data.tenant_hostname ?? null,
        allowSelfRegistration: Boolean(data.allow_self_registration),
        enableEmail2fa: Boolean(data.enable_email_2fa),
        enableEmailVerification: Boolean(data.enable_email_verification),
        mailerConfigured: Boolean(data.mailer_configured),
        passwordResetEnabled: Boolean(data.password_reset_enabled),
    }
}

export default getClientAuthMeta
