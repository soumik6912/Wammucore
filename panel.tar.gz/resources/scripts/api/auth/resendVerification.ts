import http from '@/api/http'

const resendVerification = async (email: string) => {
    const { data } = await http.post('/api/client/auth/verify-email/resend', {
        email,
    })

    return data.data
}

export default resendVerification
