import http from '@/api/http'
import type { UserData } from '@/state/user'

export const mapAuthUser = (raw: any): UserData => ({
    name: String(raw?.name || ''),
    email: String(raw?.email || ''),
    avatarUrl: raw?.avatar_url ? String(raw.avatar_url) : null,
    rootAdmin: Boolean(raw?.root_admin),
    platformAdmin: Boolean(raw?.is_platform_admin),
    resellerAdmin: Boolean(raw?.reseller_admin),
    resellerId:
        raw?.reseller_id === undefined || raw?.reseller_id === null
            ? null
            : Number(raw.reseller_id),
    resellerOnboardingStatus:
        raw?.reseller_onboarding_status === undefined ||
        raw?.reseller_onboarding_status === null
            ? null
            : String(raw.reseller_onboarding_status),
    resellerOnboardingCurrentStep:
        raw?.reseller_onboarding_current_step === undefined ||
        raw?.reseller_onboarding_current_step === null
            ? null
            : String(raw.reseller_onboarding_current_step),
    resellerOnboardingPath:
        typeof raw?.reseller_onboarding_path === 'string' &&
        raw.reseller_onboarding_path.trim() !== ''
            ? raw.reseller_onboarding_path.trim()
            : '/admin/reseller-panel/onboarding',
    resellerOnboardingCompleted: Boolean(
        raw?.reseller_onboarding_completed ?? true
    ),
    resellerCustomerPanelLocked: Boolean(
        raw?.reseller_customer_panel_locked ?? false
    ),
    adminRoles: Array.isArray(raw?.admin_roles)
        ? raw.admin_roles.map((role: any) => ({
              id: Number(role?.id || 0),
              name: String(role?.name || ''),
              slug: String(role?.slug || ''),
          }))
        : [],
    adminPermissions: Array.isArray(raw?.admin_permissions)
        ? raw.admin_permissions.map((permission: any) => String(permission))
        : [],
    panelThemeKey:
        typeof raw?.panel_theme_key === 'string' && raw.panel_theme_key.trim() !== ''
            ? raw.panel_theme_key.trim()
            : null,
    createdAt: String(raw?.created_at || ''),
    updatedAt: String(raw?.updated_at || ''),
})

const getAuthSession = async (): Promise<UserData> => {
    const { data } = await http.get('/api/client/auth/session', {
        showProgress: false,
    } as any)
    const rawUser = data.data?.user

    if (!rawUser?.email) {
        throw new Error('Session response did not include a user.')
    }

    return mapAuthUser(rawUser)
}

export default getAuthSession
