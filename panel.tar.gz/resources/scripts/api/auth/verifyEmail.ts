import http from '@/api/http'

const verifyEmail = async (token: string) => {
    const { data } = await http.post('/api/client/auth/verify-email', {
        token,
    })

    return data.data
}

export default verifyEmail
