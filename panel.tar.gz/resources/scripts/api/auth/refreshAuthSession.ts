import http from '@/api/http'
import type { UserData } from '@/state/user'
import { mapAuthUser } from '@/api/auth/getAuthSession'

const refreshAuthSession = async (): Promise<{
    user: UserData
    redirectUrl: string | null
}> => {
    const { data } = await http.post(
        '/api/client/auth/refresh',
        {},
        { showProgress: false } as any
    )
    const rawUser = data.data?.user

    if (!rawUser?.email) {
        throw new Error('Refresh response did not include a user.')
    }

    return {
        user: mapAuthUser(rawUser),
        redirectUrl:
            typeof data.data?.redirect_url === 'string' && data.data.redirect_url.trim() !== ''
                ? data.data.redirect_url.trim()
                : null,
    }
}

export default refreshAuthSession
