/*
MIT License

Pterodactyl®
Copyright © Dane Everitt <dane@daneeveritt.com> and contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/
import {
    completeNavigationProgress,
    resetNavigationProgress,
    startNavigationProgress,
} from '@mantine/nprogress';
import axios, {AxiosInstance, AxiosRequestConfig} from 'axios';
import { showMutationSuccessNotification } from '@/util/actionNotifications'

declare module 'axios' {
    export interface AxiosRequestConfig {
        showProgress?: boolean
        showSuccessNotification?: boolean | string
    }
}

export interface WammuCoreRequestConfig<D = any> extends AxiosRequestConfig<D> {
    showProgress?: boolean
    showSuccessNotification?: boolean | string
    _csrfRetried?: boolean
}

const CSRF_REFRESH_URL = '/auth/csrf-token'
const UNSAFE_METHODS = ['post', 'put', 'patch', 'delete']
const AUTH_INVALID_EVENT = 'wammucore:auth-invalid'

const http: AxiosInstance = axios.create({
    withCredentials: true,
    headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
    },
})

const REGISTRATION_CONTEXT_KEY = 'wammucore.reseller-registration.context.v1'

const validResellerReference = (candidate: unknown): string | null => {
    const value = String(candidate ?? '').trim()

    return /^[a-z0-9][a-z0-9._-]{0,119}$/i.test(value) ? value : null
}

const csrfTokenFromMeta = (): string | null => {
    if (typeof document === 'undefined') {
        return null
    }

    const token = document
        .querySelector<HTMLMetaElement>('meta[name="csrf-token"]')
        ?.content?.trim()

    return token && token.length > 0 ? token : null
}

const updateCsrfMeta = (token: string | null) => {
    if (!token || typeof document === 'undefined') {
        return
    }

    let element = document.querySelector<HTMLMetaElement>('meta[name="csrf-token"]')
    if (!element) {
        element = document.createElement('meta')
        element.name = 'csrf-token'
        document.head.appendChild(element)
    }

    element.content = token
}

const hasReadableXsrfCookie = (): boolean => {
    if (typeof document === 'undefined') {
        return false
    }

    return document.cookie
        .split(';')
        .some(cookie => cookie.trim().startsWith('XSRF-TOKEN='))
}

const isUnsafeMethod = (method?: string): boolean =>
    UNSAFE_METHODS.includes(String(method || 'get').toLowerCase())

const isCsrfMismatchError = (error: any): boolean => {
    const status = Number(error?.response?.status || 0)
    const data = error?.response?.data
    const code = String(data?.code || data?.error || '').toLowerCase()
    const message = String(data?.message || '').toLowerCase()

    return (
        status === 419 ||
        code === 'csrf_token_mismatch' ||
        message.includes('csrf token mismatch')
    )
}

const refreshCsrfToken = async (): Promise<void> => {
    const response = await axios.get(CSRF_REFRESH_URL, {
        withCredentials: true,
        headers: {
            Accept: 'application/json',
        },
    })
    const token =
        response.data?.data?.csrf_token ??
        response.data?.csrf_token ??
        null

    updateCsrfMeta(typeof token === 'string' ? token : null)
}

const resellerReferenceFromAdminPath = (path: string): string | null => {
    const match =
        path.match(/^\/admin\/reseller-panel\/r\/([^/?#]+)/) ||
        path.match(/^\/admin\/reseller-panel\/([^/?#]+)/)
    const raw = match?.[1]
    if (!raw) {
        return null
    }

    const reference = decodeURIComponent(raw).trim()
    if (['r', 'onboarding', 'domain-guide'].includes(reference.toLowerCase())) {
        return null
    }

    return validResellerReference(reference)
}

const resellerReferenceFromTenantPath = (path: string): string | null => {
    const legacyMatch = path.match(/^\/r\/([^/?#]+)/)
    if (legacyMatch?.[1]) {
        return validResellerReference(decodeURIComponent(legacyMatch[1]).trim())
    }

    const directMatch = path.match(/^\/([^/?#]+)/)
    const raw = directMatch?.[1]
    if (!raw) {
        return null
    }

    const reference = decodeURIComponent(raw).trim()
    if (
        [
            'admin',
            'api',
            'auth',
            'authorize',
            'assets',
            'build',
            'favicon.ico',
            'locales',
            'login',
            'register',
            'reseller',
            'servers',
            'store',
            'account',
            'forgot-password',
            'verify-email',
        ].includes(reference.toLowerCase())
    ) {
        return null
    }

    return validResellerReference(reference)
}

const shouldAttachResellerReference = (url: string): boolean => {
    const path = url.split(/[?#]/)[0]

    return (
        path === '/api/admin/tenancy/context' ||
        path === '/api/admin/reseller-panel' ||
        path.startsWith('/api/admin/reseller-panel/') ||
        path.startsWith('/api/auth/') ||
        path.startsWith('/api/client/') ||
        path === CSRF_REFRESH_URL
    )
}

const resellerReferenceFromStoredContext = (): string | null => {
    if (typeof window === 'undefined') {
        return null
    }

    try {
        const parsed = JSON.parse(
            window.localStorage.getItem(REGISTRATION_CONTEXT_KEY) || '{}'
        ) as {
            slug?: unknown
            tenantUuid?: unknown
            resellerId?: unknown
        }

        const candidates = [parsed.slug, parsed.tenantUuid, parsed.resellerId]
        for (const candidate of candidates) {
            const value = validResellerReference(candidate)
            if (value) {
                return value
            }
        }
    } catch {
        return null
    }

    return null
}

const resellerReferenceFromBootstrappedUser = (): string | null => {
    if (typeof window === 'undefined') {
        return null
    }

    const boot = window as Window & {
        WammuCoreUser?: {
            root_admin?: boolean
            reseller_admin?: boolean
            reseller_id?: number | string | null
        }
        SiteConfiguration?: {
            reseller_id?: number | string | null
            tenant_id?: number | string | null
            tenant_slug?: string | null
            tenant_uuid?: string | null
        }
    }
    const tenantReference =
        validResellerReference(boot.SiteConfiguration?.tenant_slug) ||
        validResellerReference(boot.SiteConfiguration?.tenant_uuid) ||
        validResellerReference(boot.SiteConfiguration?.reseller_id) ||
        validResellerReference(boot.SiteConfiguration?.tenant_id)

    if (tenantReference) {
        return tenantReference
    }

    const user = boot.WammuCoreUser

    if (!user || Boolean(user.root_admin) || !Boolean(user.reseller_admin)) {
        return null
    }

    return validResellerReference(user.reseller_id)
}

const setHeaderValue = (
    headers: NonNullable<typeof http.defaults.headers>,
    key: string,
    value: string
) => {
    const maybeAxiosHeaders = headers as unknown as {
        set?: (name: string, value: string) => void
    }

    if (typeof maybeAxiosHeaders.set === 'function') {
        maybeAxiosHeaders.set(key, value)
        return
    }

    ;(headers as unknown as Record<string, string>)[key] = value
}

http.interceptors.request.use(req => {
    const shouldShowProgress =
        (req as typeof req & WammuCoreRequestConfig).showProgress !== false

    if (
        typeof window !== 'undefined' &&
        typeof req.url === 'string' &&
        shouldAttachResellerReference(req.url)
    ) {
        const reference =
            resellerReferenceFromTenantPath(window.location.pathname) ||
            resellerReferenceFromAdminPath(window.location.pathname) ||
            resellerReferenceFromBootstrappedUser() ||
            resellerReferenceFromStoredContext()

        if (reference) {
            req.headers = req.headers || {}
            setHeaderValue(
                req.headers as unknown as NonNullable<typeof http.defaults.headers>,
                'X-Wammu-Reseller-Ref',
                reference
            )
        }
    }

    if (
        typeof req.url === 'string' &&
        req.url !== CSRF_REFRESH_URL &&
        isUnsafeMethod(req.method) &&
        !hasReadableXsrfCookie()
    ) {
        const token = csrfTokenFromMeta()
        if (token) {
            req.headers = req.headers || {}
            setHeaderValue(
                req.headers as unknown as NonNullable<typeof http.defaults.headers>,
                'X-CSRF-TOKEN',
                token
            )
        }
    }

    if (shouldShowProgress && !req.url?.endsWith('/state')) {
        resetNavigationProgress()
        startNavigationProgress()
    }

    return req
})

http.interceptors.response.use(
    resp => {
        const shouldShowProgress =
            (resp.config as typeof resp.config & WammuCoreRequestConfig)
                .showProgress !== false
        const config = resp.config as typeof resp.config & WammuCoreRequestConfig
        const method = String(resp.config.method || 'get').toLowerCase()
        const url = String(resp.config.url || resp.request?.responseURL || '')
        const normalizedUrl = url.toLowerCase()
        const isPowerAction =
            normalizedUrl.includes('/power') ||
            normalizedUrl.includes('/state') ||
            normalizedUrl.includes('/management/actions/')
        const shouldShowSuccessNotification =
            config.showSuccessNotification !== false &&
            !isPowerAction &&
            ['post', 'put', 'patch', 'delete'].includes(method)

        if (shouldShowProgress && !resp.request?.url?.endsWith('/state')) {
            completeNavigationProgress()
        }

        if (shouldShowSuccessNotification) {
            showMutationSuccessNotification(
                method,
                url,
                resp.data,
                config.showSuccessNotification
            )
        }

        return resp
    },
    error => {
        const config = error?.config as WammuCoreRequestConfig | undefined
        const shouldShowProgress =
            config?.showProgress !== false

        if (shouldShowProgress) {
            completeNavigationProgress()
        }

        const status = Number(error?.response?.status || 0)
        const url = String(config?.url || '')
        if (
            typeof window !== 'undefined' &&
            !error?.response &&
            typeof navigator !== 'undefined' &&
            navigator.onLine === false
        ) {
            window.dispatchEvent(new CustomEvent('wammucore:offline-recovery-blocked'))
        }

        if (
            typeof window !== 'undefined' &&
            [401, 403].includes(status) &&
            !url.includes('/api/client/auth/login') &&
            !url.includes('/api/client/auth/meta')
        ) {
            window.dispatchEvent(
                new CustomEvent(AUTH_INVALID_EVENT, {
                    detail: {
                        status,
                        code: error?.response?.data?.code || null,
                        message: error?.response?.data?.message || null,
                    },
                })
            )
        }

        if (
            config &&
            !config._csrfRetried &&
            config.url !== CSRF_REFRESH_URL &&
            isUnsafeMethod(config.method) &&
            isCsrfMismatchError(error)
        ) {
            config._csrfRetried = true

            return refreshCsrfToken()
                .then(() => {
                    if (!hasReadableXsrfCookie()) {
                        const token = csrfTokenFromMeta()
                        if (token) {
                            config.headers = config.headers || {}
                            setHeaderValue(
                                config.headers as unknown as NonNullable<typeof http.defaults.headers>,
                                'X-CSRF-TOKEN',
                                token
                            )
                        }
                    }

                    return http(config)
                })
                .catch(() => {
                    throw error
                })
        }

        throw error
    }
)

export default http

/**
 * Converts an error into a human readable response. Mostly just a generic helper to
 * make sure we display the message from the server back to the user if we can.
 */
export function httpErrorToHuman(error: any): string {
    if (error.response && error.response.data) {
        let {data} = error.response

        // Some non-JSON requests can still return the error as a JSON block. In those cases, attempt
        // to parse it into JSON so we can display an actual error.
        if (typeof data === 'string') {
            try {
                data = JSON.parse(data)
            } catch (e) {
                // do nothing, bad json
            }
        }

        if (data.message) {
            return data.message
        }

        // Errors from wings directory, mostly just for file uploads.
        if (data.error && typeof data.error === 'string') {
            return data.error
        }
    }

    return error.message
}

export interface FractalResponseData {
    [k: string]: any
}

export interface FractalResponseList {
    data: FractalResponseData[]
}

export interface FractalPaginatedResponse extends FractalResponseList {
    meta: {
        pagination: {
            total: number
            count: number
            /* eslint-disable camelcase */
            per_page: number
            current_page: number
            total_pages: number
            /* eslint-enable camelcase */
        }
    }
}

export interface PaginatedResult<T> {
    items: T[]
    pagination: PaginationDataSet
}

export interface PaginationDataSet {
    total: number
    count: number
    perPage: number
    currentPage: number
    totalPages: number
}

export function getPaginationSet(data: any): PaginationDataSet {
    return {
        total: data.total,
        count: data.count,
        perPage: data.per_page,
        currentPage: data.current_page,
        totalPages: data.total_pages,
    }
}

type QueryBuilderFilterValue = string | number | boolean | null

export interface QueryBuilderParams<
    FilterKeys extends string = string,
    SortKeys extends string = string,
> {
    page?: number
    filters?: {
        [K in FilterKeys]?:
        | QueryBuilderFilterValue
        | Readonly<QueryBuilderFilterValue[]>
    }
    sorts?: {
        [K in SortKeys]?: -1 | 0 | 1 | 'asc' | 'desc' | null
    }
}

/**
 * Helper function that parses a data object provided and builds query parameters
 * for the Laravel Query Builder package automatically. This will apply sorts and
 * filters deterministically based on the provided values.
 */
export const withQueryBuilderParams = (
    data?: QueryBuilderParams
): Record<string, unknown> => {
    if (!data) return {}

    const filters = Object.keys(data.filters || {}).reduce(
        (obj, key) => {
            const value = data.filters?.[key]

            return !value || value === ''
                ? obj
                : {...obj, [`filter[${key}]`]: value}
        },
        {} as NonNullable<QueryBuilderParams['filters']>
    )

    const sorts = Object.keys(data.sorts || {}).reduce((arr, key) => {
        const value = data.sorts?.[key]
        if (!value || !['asc', 'desc', 1, -1].includes(value)) {
            return arr
        }

        return [...arr, (value === -1 || value === 'desc' ? '-' : '') + key]
    }, [] as string[])

    return {
        ...filters,
        sort: !sorts.length ? undefined : sorts.join(','),
        page: data.page,
    }
}
