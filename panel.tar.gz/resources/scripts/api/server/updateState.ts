import http from '@/api/http'
import { invalidateServerStateCache } from '@/api/server/getState'
import {
    mapPowerActionResponse,
    PowerActionResponse,
} from '@/api/server/resourceGuard'

export type PowerAction = 'start' | 'shutdown' | 'kill' | 'restart'

const updateState = async (
    uuid: string,
    state: PowerAction
): Promise<PowerActionResponse> => {
    invalidateServerStateCache(uuid)

    const { data } = await http.patch(`/api/client/servers/${uuid}/state`, {
        state,
    })

    return mapPowerActionResponse(data?.data || {})
}

export default updateState
