import { User } from '@/api/admin/users/getUsers'
import http, { WammuCoreRequestConfig } from '@/api/http'
import {
    mapResourceGuardWarning,
    ResourceGuardWarning,
} from '@/api/server/resourceGuard'
import {
    mapServerSecurityLock,
    ServerSecurityLock,
} from '@/api/server/securityLock'
import { EloquentStatus } from '@/api/server/types'

export type AddressType = 'ipv4' | 'ipv6'

export interface Address {
    id: number
    addressPoolId: number
    serverId: number | null
    type: AddressType
    address: string
    cidr: number
    gateway: string
    macAddress?: string
    resellerId: number | null
    resellerDisplayName: string | null
    reservedForUserId: number | null
    reservedForUserLabel: string | null
    claimStatus:
        | 'available'
        | 'claimed_by_reseller'
        | 'reserved_for_customer'
        | 'attached_to_vps'
    claimLabel: string
    server?: Server
}

export interface Server {
    id: number
    uuid: string
    uuidShort: string
    userId: number
    nodeId: number
    vmid: number
    hostname: string
    name: string
    description: string | null
    currentOs: string | null
    status: EloquentStatus
}

export interface ServerBuild {
    id: string
    internalId: number
    vmid: number
    uuid: string
    hostname: string
    name: string
    description: string | null
    currentOs: string | null
    status: EloquentStatus
    resourceGuard?: ResourceGuardWarning | null
    securityLock?: ServerSecurityLock | null
    nodeId: number
    credentials: {
        rootPassword: string | null
    }
    billing: {
        serviceId: string | null
        upgradeUrl: string | null
        upgradeVisible: boolean
        upgradeAvailable: boolean
        upgradeReason: string | null
        upgradeMessage: string | null
    }
    usages: {
        bandwidth: number // bytes
    }
    limits: {
        cpu: number
        cpuLimit: number
        cpuUnits: number
        cpuSockets: number
        memory: number // bytes
        swap: number // bytes
        disk: number // bytes
        snapshots: number | null
        backups: number | null
        bandwidth: number | null // bytes
        networkRateLimit: number | null
        addresses: {
            ipv4: Address[]
            ipv6: Address[]
        }
        macAddress: string | null
    }
    user?: User
    node?: ClientNode
}

export interface ClientNode {
    id: number
    locationId: number
    locationName: string | null
    name: string
    cluster: string
    cotermId: number | null
    terminalEnabled: boolean
    cardBackgroundImageUrl: string | null
    cardBackgroundImageBrightness: number
}

export const rawDataToAddress = (data: any): Address => ({
    id: data.id,
    addressPoolId: data.address_pool_id,
    serverId: data.server_id,
    type: data.type,
    address: data.address,
    cidr: data.cidr,
    gateway: data.gateway,
    macAddress: data.mac_address,
    resellerId: data.reseller_id ?? null,
    resellerDisplayName: data.reseller_display_name ?? null,
    reservedForUserId: data.reserved_for_user_id ?? null,
    reservedForUserLabel: data.reserved_for_user_label ?? null,
    claimStatus: data.claim_status ?? 'available',
    claimLabel: data.claim_label ?? 'Available',
    server: data.server ? rawDataToServer(data.server.data) : undefined,
})

export const rawDataToServer = (data: any): Server => ({
    id: data.id,
    uuid: data.uuid,
    uuidShort: data.uuid_short,
    nodeId: data.nodeId,
    userId: data.userId,
    vmid: data.vmid,
    hostname: data.hostname,
    name: data.name,
    description: data.description,
    currentOs: data.current_os ?? null,
    status: data.status,
})

export const rawDataToServerBuild = (data: any): ServerBuild => ({
    id: data.id,
    internalId: data.internal_id,
    vmid: data.vmid,
    uuid: data.uuid,
    hostname: data.hostname,
    name: data.name,
    status: data.status,
    currentOs: data.current_os ?? null,
    resourceGuard: mapResourceGuardWarning(data.resource_guard),
    securityLock: mapServerSecurityLock(data.security_lock),
    nodeId: data.node_id,
    description: data.description
        ? data.description.length > 0
            ? data.description
            : null
        : null,
    credentials: {
        rootPassword: data.credentials?.root_password ?? null,
    },
    billing: {
        serviceId: data.billing?.service_id ?? null,
        upgradeUrl: data.billing?.upgrade_url ?? null,
        upgradeVisible: Boolean(data.billing?.upgrade_visible ?? true),
        upgradeAvailable: Boolean(data.billing?.upgrade_available),
        upgradeReason: data.billing?.upgrade_reason ?? null,
        upgradeMessage: data.billing?.upgrade_message ?? null,
    },
    usages: {
        bandwidth: data?.usages?.bandwidth ?? 0,
    },
    limits: {
        cpu: data?.limits?.cpu ?? 0,
        cpuLimit: data?.limits?.cpu_limit ?? 0,
        cpuUnits: data?.limits?.cpu_units ?? 1024,
        cpuSockets: data?.limits?.cpu_sockets ?? 1,
        memory: data?.limits?.memory ?? 0,
        swap: data?.limits?.swap ?? 0,
        disk: data?.limits?.disk ?? 0,
        snapshots: data?.limits?.snapshots ?? null,
        backups: data?.limits?.backups ?? null,
        bandwidth: data?.limits?.bandwidth ?? null,
        networkRateLimit: data?.limits?.network_rate_limit ?? null,
        addresses: {
            ipv4: Array.isArray(data?.limits?.addresses?.ipv4)
                ? data.limits.addresses.ipv4.map((address: any) =>
                    rawDataToAddress(address)
                )
                : [],
            ipv6: Array.isArray(data?.limits?.addresses?.ipv6)
                ? data.limits.addresses.ipv6.map((address: any) =>
                    rawDataToAddress(address)
                )
                : [],
        },
        macAddress: data?.limits?.mac_address ?? null,
    },
    user: data?.user?.data,
    node: data?.node?.data
        ? {
              id: data.node.data.id,
              locationId: data.node.data.location_id,
              locationName: data.node.data.location_name ?? null,
              name: data.node.data.name,
              cluster: data.node.data.cluster,
              cotermId: data.node.data.coterm_id ?? null,
              terminalEnabled: Boolean(data.node.data.terminal_enabled),
              cardBackgroundImageUrl:
                  data.node.data.card_background_image_url ?? null,
              cardBackgroundImageBrightness:
                  data.node.data.card_background_image_brightness ?? 25,
          }
        : undefined,
})

export default (
    uuid: string,
    options?: WammuCoreRequestConfig
): Promise<ServerBuild> => {
    return new Promise((resolve, reject) => {
        http.get(`/api/client/servers/${uuid}`, options)
            .then(({ data }) => resolve(rawDataToServerBuild(data.data)))
            .catch(reject)
    })
}
