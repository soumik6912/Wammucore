import http, { WammuCoreRequestConfig } from '@/api/http'

export type ServerState = 'running' | 'stopped' | 'starting' | 'stopping' | 'shutting_down' | 'unknown'

export interface ServerStateData {
    state: ServerState
    cpuUsed: number
    memoryTotal: number
    memoryUsed: number
    uptime: number
}

export const rawDataToServerStateData = (data: any) => ({
    state: data.state,
    cpuUsed: data.cpu_used,
    memoryTotal: data.memory_total,
    memoryUsed: data.memory_used,
    uptime: data.uptime,
})

const STATUS_CACHE_TTL_MS = 8000

const statusCache = new Map<string, { expiresAt: number; data: ServerStateData }>()
const inFlightRequests = new Map<string, Promise<ServerStateData>>()

export const invalidateServerStateCache = (uuid?: string): void => {
    if (uuid) {
        statusCache.delete(uuid)
        inFlightRequests.delete(uuid)

        return
    }

    statusCache.clear()
    inFlightRequests.clear()
}

const fetchState = async (
    uuid: string,
    options?: WammuCoreRequestConfig
): Promise<ServerStateData> => {
    const { data: { data } } = await http.get(
        `/api/client/servers/${uuid}/state`,
        options
    )

    return rawDataToServerStateData(data)
}

const getState = (
    uuid: string,
    options?: WammuCoreRequestConfig
): Promise<ServerStateData> => {
    const now = Date.now()
    const cached = statusCache.get(uuid)
    if (cached && cached.expiresAt > now) {
        return Promise.resolve(cached.data)
    }

    const inFlight = inFlightRequests.get(uuid)
    if (inFlight) {
        return inFlight
    }

    const request = fetchState(uuid, options)
        .then(data => {
            statusCache.set(uuid, {
                data,
                expiresAt: Date.now() + STATUS_CACHE_TTL_MS,
            })

            return data
        })
        .catch(error => {
            if (cached) {
                return cached.data
            }

            throw error
        })
        .finally(() => {
            inFlightRequests.delete(uuid)
        })

    inFlightRequests.set(uuid, request)

    return request
}

export default getState
