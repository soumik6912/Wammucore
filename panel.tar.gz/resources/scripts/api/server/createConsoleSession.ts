import http from '@/api/http'

export type ConsoleType = 'novnc' | 'xtermjs'

interface ConsoleCredentialsWithoutCoterm {
    ticket: string
    node: string
    vmid: number
    fqdn: string
    port: number
    vncPort?: number
    pveAuthCookie?: string
    username?: string
    realmType?: string
}

interface ConsoleCredentialsWithCoterm {
    isTlsEnabled: boolean
    fqdn: string
    port: number
    token: string
}

export type ConsoleCredentials =
    | ConsoleCredentialsWithoutCoterm
    | ConsoleCredentialsWithCoterm

export const rawDataToConsoleCredentials = (data: any): ConsoleCredentials => {
    if (data.is_tls_enabled !== undefined) {
        return {
            isTlsEnabled: data.is_tls_enabled,
            fqdn: data.fqdn,
            port: data.port,
            token: data.token,
        }
    } else {
        const node = data.node || data.node_pve_name
        const fqdn = data.fqdn || data.node_fqdn
        const nodePort = data.node_port ?? data.port
        const vncPort = data.port ?? data.vnc_port

        return {
            ticket: data.ticket,
            node,
            vmid: data.vmid,
            fqdn,
            port: nodePort,
            vncPort,
            pveAuthCookie: data.pve_auth_cookie,
            username: data.username,
            realmType: data.realm_type,
        }
    }
}

export default (
    uuid: string,
    consoleType: ConsoleType
): Promise<ConsoleCredentials> => {
    return new Promise((resolve, reject) => {
        http.post(`/api/client/servers/${uuid}/create-console-session`, {
            type: consoleType,
        })
            .then(({ data: { data } }) => {
                const parsed = rawDataToConsoleCredentials(data)

                // User-side terminal must go through Coterm to avoid exposing Proxmox node endpoints.
                if ('ticket' in parsed) {
                    reject(
                        new Error(
                            'Secure terminal gateway is not configured for this node. Please contact your administrator.'
                        )
                    )
                    return
                }

                resolve(parsed)
            })
            .catch(reject)
    })
}
