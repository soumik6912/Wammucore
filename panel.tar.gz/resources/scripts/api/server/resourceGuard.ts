export interface ResourceGuardWarning {
    active: boolean
    title?: string
    message?: string
    advice?: string | null
    resources?: string[]
    metrics?: {
        cpuPercent?: number | null
        memoryPercent?: number | null
        diskPercent?: number | null
        bandwidthPercent?: number | null
        thresholdPercent?: number | null
    }
    stoppedAt?: string | null
}

export interface PowerActionResponse {
    serverId?: string
    requestedAction?: string
    sentAction?: string
    skipped?: boolean
    reason?: string | null
    queued?: boolean
    resourceGuardWarning?: ResourceGuardWarning | null
}

export const mapResourceGuardWarning = (raw: any): ResourceGuardWarning | null => {
    if (!raw || typeof raw !== 'object') return null

    return {
        active: !!raw.active,
        title: raw.title,
        message: raw.message,
        advice: raw.advice ?? null,
        resources: Array.isArray(raw.resources) ? raw.resources : [],
        metrics: {
            cpuPercent: numberOrNull(raw.metrics?.cpu_percent),
            memoryPercent: numberOrNull(raw.metrics?.memory_percent),
            diskPercent: numberOrNull(raw.metrics?.disk_percent),
            bandwidthPercent: numberOrNull(raw.metrics?.bandwidth_percent),
            thresholdPercent: numberOrNull(raw.metrics?.threshold_percent),
        },
        stoppedAt: raw.detected_at ?? raw.stopped_at ?? null,
    }
}

export const mapPowerActionResponse = (raw: any): PowerActionResponse => ({
    serverId: raw?.server_id,
    requestedAction: raw?.requested_action,
    sentAction: raw?.sent_action ?? raw?.action,
    skipped: !!raw?.skipped,
    reason: raw?.reason ?? null,
    queued: !!raw?.queued,
    resourceGuardWarning: mapResourceGuardWarning(raw?.resource_guard_warning),
})

export const formatResourceGuardWarning = (
    warning?: ResourceGuardWarning | null
): string | null => {
    if (!warning) return null

    return (
        warning.message ||
        warning.advice ||
        'Resource usage is high. Reduce load to keep your VPS stable.'
    ).trim()
}

const numberOrNull = (value: unknown): number | null => {
    const parsed = Number(value)
    return Number.isFinite(parsed) ? parsed : null
}
