import http from '@/api/http'

export interface Snapshot {
    name: string
    description: string
    isCurrent: boolean
    createdAt: string | null
    vmState: boolean
}

export const getSnapshots = async (uuid: string): Promise<Snapshot[]> => {
    const { data } = await http.get(`/api/client/servers/${uuid}/backups/snapshots`)
    return (data?.data || []).map((item: any) => ({
        name: item.name || '',
        description: item.description || '',
        isCurrent: !!item.is_current,
        createdAt: item.created_at || null,
        vmState: !!item.vm_state,
    }))
}

export const createSnapshot = async (uuid: string, name: string): Promise<void> => {
    await http.post(`/api/client/servers/${uuid}/backups/snapshots`, { name })
}

export const restoreSnapshot = async (
    uuid: string,
    snapshotName: string
): Promise<void> => {
    await http.post(
        `/api/client/servers/${uuid}/backups/snapshots/${encodeURIComponent(snapshotName)}/restore`
    )
}

export const deleteSnapshot = async (
    uuid: string,
    snapshotName: string
): Promise<void> => {
    await http.delete(
        `/api/client/servers/${uuid}/backups/snapshots/${encodeURIComponent(snapshotName)}`
    )
}
