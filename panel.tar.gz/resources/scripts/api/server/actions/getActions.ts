import http from '@/api/http'

export interface ServerActionRow {
    upid: string
    actionName: string
    status: string
    statusLabel: string
    triggeredOn: string | null
    completedOn: string | null
    node: string
    user: string
}

export interface ServerActionsResponse {
    items: ServerActionRow[]
    start: number
    limit: number
    count: number
}

const getActions = async (
    uuid: string,
    params?: { start?: number; limit?: number }
): Promise<ServerActionsResponse> => {
    const { data } = await http.get(`/api/client/servers/${uuid}/actions`, {
        params: {
            start: params?.start ?? 0,
            limit: params?.limit ?? 50,
        },
    })

    const payload = data?.data || {}

    return {
        items: (payload.items || []).map((item: any) => ({
            upid: item.upid || '',
            actionName: item.action_name || 'unknown',
            status: item.status || 'unknown',
            statusLabel: item.status_label || 'Unknown',
            triggeredOn: item.triggered_on || null,
            completedOn: item.completed_on || null,
            node: item.node || '',
            user: item.user || '',
        })),
        start: Number(payload.start || 0),
        limit: Number(payload.limit || 50),
        count: Number(payload.count || 0),
    }
}

export default getActions
