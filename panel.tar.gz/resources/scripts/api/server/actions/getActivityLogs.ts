import http from '@/api/http'

export interface ServerActivityLogRow {
    id: number
    event: string
    description: string | null
    ip: string | null
    timestamp: string | null
    actorName: string | null
    actorEmail: string | null
    resources: string[]
    blocked: boolean
}

export interface ServerActivityLogsResponse {
    items: ServerActivityLogRow[]
    pagination: {
        total: number
        count: number
        perPage: number
        currentPage: number
        totalPages: number
    }
}

const getActivityLogs = async (
    uuid: string,
    params?: {
        query?: string
        event?: string
        page?: number
        perPage?: number
    }
): Promise<ServerActivityLogsResponse> => {
    const { data } = await http.get(`/api/client/servers/${uuid}/activity`, {
        params: {
            q: params?.query || undefined,
            event: params?.event || undefined,
            page: params?.page ?? 1,
            per_page: params?.perPage ?? 25,
        },
    })

    const rows = Array.isArray(data?.data) ? data.data : []
    const pagination = data?.meta?.pagination || {}

    return {
        items: rows.map((item: any) => ({
            id: Number(item.id || 0),
            event: item.event || 'activity',
            description: item.description ?? null,
            ip: item.ip ?? null,
            timestamp: item.timestamp || item.created_at || null,
            actorName: item.actor?.data?.name ?? null,
            actorEmail: item.actor?.data?.email ?? null,
            resources: Array.isArray(item.properties?.resources)
                ? item.properties.resources
                : [],
            blocked: Boolean(item.properties?.blocked),
        })),
        pagination: {
            total: Number(pagination.total || 0),
            count: Number(pagination.count || rows.length),
            perPage: Number(pagination.per_page || params?.perPage || 25),
            currentPage: Number(pagination.current_page || params?.page || 1),
            totalPages: Number(pagination.total_pages || 1),
        },
    }
}

export default getActivityLogs
