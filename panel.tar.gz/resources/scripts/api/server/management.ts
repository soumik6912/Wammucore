import http from '@/api/http'
import { invalidateServerStateCache } from '@/api/server/getState'
import {
    mapResourceGuardWarning,
    mapPowerActionResponse,
    PowerActionResponse,
    ResourceGuardWarning,
} from '@/api/server/resourceGuard'

export type SimplePowerAction =
    | 'start'
    | 'stop'
    | 'shutdown'
    | 'restart'
    | 'kill'
    | 'resume'
    | 'suspend'

export interface ManagementStatus {
    serverId: string
    status: string | null
    state: string
    metrics: {
        cpuUsed: number
        memoryTotal: number
        memoryUsed: number
        uptime: number
    }
    availableActions: SimplePowerAction[]
    resourceGuardWarning?: ResourceGuardWarning | null
    accessLocked: boolean
    accessLockedMessage: string | null
}

export const getManagementStatus = async (
    serverUuid: string
): Promise<ManagementStatus> => {
    const { data } = await http.get(`/api/client/servers/${serverUuid}/management`)
    const payload = data?.data || {}

    return {
        serverId: payload.server_id,
        status: payload.status,
        state: payload.state,
        metrics: {
            cpuUsed: payload.metrics?.cpu_used ?? 0,
            memoryTotal: payload.metrics?.memory_total ?? 0,
            memoryUsed: payload.metrics?.memory_used ?? 0,
            uptime: payload.metrics?.uptime ?? 0,
        },
        availableActions: payload.available_actions ?? [],
        resourceGuardWarning: mapResourceGuardWarning(
            payload.resource_guard_warning
        ),
        accessLocked: Boolean(payload.access_locked),
        accessLockedMessage: payload.access_locked_message ?? null,
    }
}

export const sendManagementAction = async (
    serverUuid: string,
    action: SimplePowerAction
): Promise<PowerActionResponse> => {
    invalidateServerStateCache(serverUuid)
    const { data } = await http.post(
        `/api/client/servers/${serverUuid}/management/${action}`
    )

    return mapPowerActionResponse(data?.data || {})
}
