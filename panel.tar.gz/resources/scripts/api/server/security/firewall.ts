import http from '@/api/http'

export interface FirewallRule {
    cidr: string
    comment: string
    nomatch: boolean
    managed?: boolean
}

export interface FirewallIpset {
    name: string
    comment: string
    rules: FirewallRule[]
}

export interface FirewallStatus {
    available: boolean
    unavailableMessage: string | null
    enabled: boolean
    ipfilter: boolean
    policyIn: string
    policyOut: string
    rulesCount: number
    ipsets: FirewallIpset[]
}

export const getFirewallStatus = async (uuid: string): Promise<FirewallStatus> => {
    const { data } = await http.get(`/api/client/servers/${uuid}/settings/security/firewall`)
    const payload = data?.data || {}

    return {
        available: payload.available !== false,
        unavailableMessage: payload.unavailable_message || null,
        enabled: !!payload.enabled,
        ipfilter: !!payload.ipfilter,
        policyIn: payload.policy_in || 'ACCEPT',
        policyOut: payload.policy_out || 'ACCEPT',
        rulesCount: Number(payload.rules_count || 0),
        ipsets: (payload.ipsets || []).map((set: any) => ({
            name: set.name || '',
            comment: set.comment || '',
            rules: (set.rules || []).map((rule: any) => ({
                cidr: rule.cidr || '',
                comment: rule.comment || '',
                nomatch: !!rule.nomatch,
                managed: !!rule.managed,
            })),
        })),
    }
}

export const updateFirewallStatus = async (
    uuid: string,
    payload: { enabled: boolean; ipfilter?: boolean; policyIn?: string; policyOut?: string }
): Promise<void> => {
    await http.put(`/api/client/servers/${uuid}/settings/security/firewall`, {
        enabled: payload.enabled,
        ipfilter: payload.ipfilter ?? true,
        policy_in: payload.policyIn || 'ACCEPT',
        policy_out: payload.policyOut || 'ACCEPT',
    })
}

export const addFirewallRule = async (
    uuid: string,
    payload: { cidr: string; ipset?: string; comment?: string }
): Promise<void> => {
    await http.post(`/api/client/servers/${uuid}/settings/security/firewall/rules`, {
        cidr: payload.cidr,
        ipset: payload.ipset || 'ipfilter-net0',
        comment: payload.comment || '',
    })
}

export const deleteFirewallRule = async (
    uuid: string,
    payload: { cidr: string; ipset: string }
): Promise<void> => {
    await http.delete(`/api/client/servers/${uuid}/settings/security/firewall/rules`, {
        data: {
            cidr: payload.cidr,
            ipset: payload.ipset,
        },
    })
}
