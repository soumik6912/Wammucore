import http from '@/api/http'

export type ProvisioningPhase =
    | 'queued'
    | 'provisioning'
    | 'configuring_os'
    | 'finalizing'
    | 'completed'
    | 'unknown'

export interface InstallProgress {
    serverId: string
    serverStatus: string | null
    isProvisioning: boolean
    task: string | null
    taskState: string
    exitStatus: string | null
    phase: ProvisioningPhase
    progressPercent: number
    operation: 'create' | 'reinstall'
    pollIntervalSeconds: number
    startedAt: number | null
    elapsedSeconds: number | null
    hasRealTaskLog: boolean
    buildStage: string | null
    currentStepLabel: string | null
    waitingReason: string | null
    error: string | null
}

export default async function getInstallProgress(
    serverUuid: string
): Promise<InstallProgress> {
    const { data } = await http.get(
        `/api/client/servers/${serverUuid}/install-progress`
    )
    const payload = data?.data || {}

    return {
        serverId: payload.server_id,
        serverStatus: payload.server_status ?? null,
        isProvisioning: Boolean(payload.is_provisioning),
        task: payload.task ?? null,
        taskState: payload.task_state ?? 'unknown',
        exitStatus: payload.exit_status ?? null,
        phase: (payload.phase ?? 'unknown') as ProvisioningPhase,
        progressPercent: Number(payload.progress_percent ?? 0),
        operation: payload.operation === 'reinstall' ? 'reinstall' : 'create',
        pollIntervalSeconds: Number(payload.poll_interval_seconds ?? 60),
        startedAt:
            typeof payload.started_at === 'number' ? payload.started_at : null,
        elapsedSeconds:
            typeof payload.elapsed_seconds === 'number'
                ? payload.elapsed_seconds
                : null,
        hasRealTaskLog: Boolean(payload.has_real_task_log),
        buildStage: payload.build_stage ?? null,
        currentStepLabel: payload.current_step_label ?? null,
        waitingReason: payload.waiting_reason ?? null,
        error: payload.error ?? null,
    }
}
