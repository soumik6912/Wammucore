import http, { WammuCoreRequestConfig } from '@/api/http'
import {
    mapResourceGuardWarning,
    ResourceGuardWarning,
} from '@/api/server/resourceGuard'

export type UsageTimeframe = 'hour' | 'day' | 'week'

export interface UsagePoint {
    time: number
    at: string | null
    cpuPercent: number
    memoryUsed: number
    memoryTotal: number
    memoryPercent: number
    diskUsed: number
    diskTotal: number
    diskPercent: number
    netIn: number
    netOut: number
}

export interface UsageResponse {
    timeframe: UsageTimeframe
    generatedAt: string | null
    source: string | null
    cacheTtlSeconds: number
    pointCount: number
    rawPointCount: number
    sampleIntervalSeconds: number | null
    firstAt: string | null
    lastAt: string | null
    staleSeconds: number | null
    bandwidth: {
        used: number
        limit: number | null
        remaining: number | null
        percent: number | null
        limitReached: boolean
        suspendedForBandwidth: boolean
    }
    resourceGuardWarning?: ResourceGuardWarning | null
    points: UsagePoint[]
}

const getUsage = async (
    uuid: string,
    timeframe: UsageTimeframe,
    options?: WammuCoreRequestConfig
): Promise<UsageResponse> => {
    const { data } = await http.get(`/api/client/servers/${uuid}/usage`, {
        params: {
            timeframe,
        },
        ...options,
    })

    const payload = data?.data || {}

    return {
        timeframe: payload.timeframe || timeframe,
        generatedAt: payload.generated_at || null,
        source: payload.source || null,
        cacheTtlSeconds: Number(payload.cache_ttl_seconds || 0),
        pointCount: Number(payload.point_count || 0),
        rawPointCount: Number(payload.raw_point_count || payload.point_count || 0),
        sampleIntervalSeconds:
            payload.sample_interval_seconds === null || payload.sample_interval_seconds === undefined
                ? null
                : Number(payload.sample_interval_seconds),
        firstAt: payload.first_at || null,
        lastAt: payload.last_at || null,
        staleSeconds:
            payload.stale_seconds === null || payload.stale_seconds === undefined
                ? null
                : Number(payload.stale_seconds),
        bandwidth: {
            used: Number(payload.bandwidth?.used || 0),
            limit:
                payload.bandwidth?.limit === null || payload.bandwidth?.limit === undefined
                    ? null
                    : Number(payload.bandwidth.limit),
            remaining:
                payload.bandwidth?.remaining === null || payload.bandwidth?.remaining === undefined
                    ? null
                    : Number(payload.bandwidth.remaining),
            percent:
                payload.bandwidth?.percent === null || payload.bandwidth?.percent === undefined
                    ? null
                    : Number(payload.bandwidth.percent),
            limitReached: Boolean(payload.bandwidth?.limit_reached),
            suspendedForBandwidth: Boolean(payload.bandwidth?.suspended_for_bandwidth),
        },
        resourceGuardWarning: mapResourceGuardWarning(payload.resource_guard_warning),
        points: (payload.points || [])
            .map((point: any) => ({
                time: Number(point.time || 0),
                at: point.at || null,
                cpuPercent: Number(point.cpu_percent || 0),
                memoryUsed: Number(point.memory_used || 0),
                memoryTotal: Number(point.memory_total || 0),
                memoryPercent: Number(point.memory_percent || 0),
                diskUsed: Number(point.disk_used || 0),
                diskTotal: Number(point.disk_total || 0),
                diskPercent: Number(point.disk_percent || 0),
                netIn: Number(point.net_in || 0),
                netOut: Number(point.net_out || 0),
            }))
            .sort((a: UsagePoint, b: UsagePoint) => a.time - b.time),
    }
}

export default getUsage
