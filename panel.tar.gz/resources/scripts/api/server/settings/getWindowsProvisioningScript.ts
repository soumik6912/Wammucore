import http from '@/api/http'

export interface WindowsProvisioningScriptResponse {
    isWindowsCandidate: boolean
    administratorUsername: string
    computerName: string
    script: string
    warnings: string[]
    network: {
        ip: string | null
        prefixLength: number | null
        gateway: string | null
        pool: string | null
        macAddress: string | null
    }
}

const getWindowsProvisioningScript = async (
    serverUuid: string
): Promise<WindowsProvisioningScriptResponse> => {
    const { data } = await http.get(
        `/api/client/servers/${serverUuid}/settings/windows-provisioning-script`
    )
    const payload = data.data || {}
    const network = payload.network || {}

    return {
        isWindowsCandidate: Boolean(payload.is_windows_candidate),
        administratorUsername: payload.administrator_username || 'Administrator',
        computerName: payload.computer_name || 'WINDOWS-VPS',
        script: payload.script || '',
        warnings: payload.warnings || [],
        network: {
            ip: network.ip || null,
            prefixLength: network.prefix_length ?? null,
            gateway: network.gateway || null,
            pool: network.pool || null,
            macAddress: network.mac_address || null,
        },
    }
}

export default getWindowsProvisioningScript
