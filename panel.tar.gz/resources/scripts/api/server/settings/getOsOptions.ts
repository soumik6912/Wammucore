import http from '@/api/http'

export interface OsTemplateOption {
    uuid: string
    name: string
    isWindows: boolean
    osFamily: 'linux' | 'windows'
}

export interface OsTemplateGroup {
    uuid: string
    name: string
    templates: OsTemplateOption[]
}

const getOsOptions = async (serverUuid: string): Promise<OsTemplateGroup[]> => {
    const { data } = await http.get(`/api/client/servers/${serverUuid}/settings/os-options`)

    return (data.data || []).map((group: any) => ({
        uuid: group.uuid,
        name: group.name,
        templates: (group.templates || []).map((template: any) => ({
            uuid: template.uuid,
            name: template.name,
            isWindows: Boolean(template.is_windows),
            osFamily: template.os_family ?? 'linux',
        })),
    }))
}

export default getOsOptions
