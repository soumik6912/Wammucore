import http from '@/api/http'

export const resetFirewallConfiguration = async (uuid: string): Promise<void> => {
    await http.post(`/api/client/servers/${uuid}/settings/system/reset-firewall`)
}

export const resetSshConfiguration = async (uuid: string): Promise<void> => {
    await http.post(`/api/client/servers/${uuid}/settings/system/reset-ssh`)
}

export const cleanupLogs = async (uuid: string): Promise<void> => {
    await http.post(`/api/client/servers/${uuid}/settings/system/cleanup-logs`)
}

