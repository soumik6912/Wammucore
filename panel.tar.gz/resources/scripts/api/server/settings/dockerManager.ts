import http from '@/api/http'

export type DockerState = 'running' | 'stopped' | 'not_installed'
export type DockerAction = 'start' | 'stop' | 'restart'

export interface DockerContainerItem {
    id: string
    name: string
    image: string
    status: string
}

export interface DockerStatus {
    available: boolean
    unavailableMessage: string | null
    installed: boolean
    active: boolean
    enabled: boolean
    state: DockerState
    requiresRunning: boolean
    requiresRunningMessage: string | null
    version: string | null
    composeVersion: string | null
    containersTotal: number
    containersRunning: number
    containers: DockerContainerItem[]
}

const mapDockerStatus = (payload: any): DockerStatus => {
    return {
        available: payload.available !== false,
        unavailableMessage: payload.unavailable_message || null,
        installed: !!payload.installed,
        active: !!payload.active,
        enabled: !!payload.enabled,
        state: payload.state || 'not_installed',
        requiresRunning: !!payload.requires_running,
        requiresRunningMessage: payload.requires_running_message || null,
        version: payload.version || null,
        composeVersion: payload.compose_version || null,
        containersTotal: Number(payload.containers_total || 0),
        containersRunning: Number(payload.containers_running || 0),
        containers: Array.isArray(payload.containers)
            ? payload.containers.map((item: any) => ({
                  id: String(item.id || ''),
                  name: String(item.name || ''),
                  image: String(item.image || ''),
                  status: String(item.status || ''),
              }))
            : [],
    }
}

export const getDockerStatus = async (uuid: string): Promise<DockerStatus> => {
    const { data } = await http.get(`/api/client/servers/${uuid}/settings/docker`)
    return mapDockerStatus(data?.data || {})
}

export const dockerServiceAction = async (
    uuid: string,
    action: DockerAction
): Promise<DockerStatus> => {
    const { data } = await http.post(`/api/client/servers/${uuid}/settings/docker/service/${action}`)
    return mapDockerStatus(data?.data?.status || {})
}

export const dockerContainerAction = async (
    uuid: string,
    container: string,
    action: DockerAction
): Promise<DockerStatus> => {
    const encodedContainer = encodeURIComponent(container)
    const { data } = await http.post(
        `/api/client/servers/${uuid}/settings/docker/containers/${encodedContainer}/${action}`
    )

    return mapDockerStatus(data?.data?.status || {})
}
