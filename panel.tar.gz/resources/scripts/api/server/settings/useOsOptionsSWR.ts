import useSWR from 'swr'

import getOsOptions, { OsTemplateGroup } from '@/api/server/settings/getOsOptions'

const useOsOptionsSWR = (serverUuid: string) => {
    return useSWR<OsTemplateGroup[]>(
        ['server:settings:os-options', serverUuid],
        () => getOsOptions(serverUuid)
    )
}

export default useOsOptionsSWR
