import http from '@/api/http'

export interface ServerSecurityLock {
    active: boolean
    id: string
    type: 'outgoing_ddos'
    title: string
    message: string
    ipAddress: string | null
    direction: string | null
    attackType: string | null
    pps: number | null
    bandwidthMbps: number | null
    providerAction: string | null
    summary: string | null
    docker: {
        summary: string | null
        topContainer: string | null
        containers: Array<{
            id?: string
            name?: string
            image?: string
            ports?: string
            net_io?: string
            rx_bytes?: number
            tx_bytes?: number
        }>
        sample: string[]
        error: string | null
    }
    detectedAt: string | null
    stoppedAt: string | null
    acknowledgedAt: string | null
}

const numberOrNull = (value: unknown): number | null => {
    const parsed = Number(value)

    return Number.isFinite(parsed) ? parsed : null
}

export const mapServerSecurityLock = (
    data: any
): ServerSecurityLock | null => {
    if (!data || typeof data !== 'object') return null

    return {
        active: Boolean(data.active),
        id: String(data.id ?? ''),
        type: 'outgoing_ddos',
        title: data.title ?? 'Outgoing DDoS traffic detected',
        message:
            data.message ??
            'This VPS is locked for security review. Please acknowledge the notice to continue.',
        ipAddress: data.ip_address ?? null,
        direction: data.direction ?? null,
        attackType: data.attack_type ?? null,
        pps: numberOrNull(data.pps),
        bandwidthMbps: numberOrNull(data.bandwidth_mbps),
        providerAction: data.provider_action ?? null,
        summary: data.summary ?? null,
        docker: {
            summary: data.docker?.summary ?? null,
            topContainer: data.docker?.top_container ?? null,
            containers: Array.isArray(data.docker?.containers)
                ? data.docker.containers
                : [],
            sample: Array.isArray(data.docker?.sample)
                ? data.docker.sample
                : [],
            error: data.docker?.error ?? null,
        },
        detectedAt: data.detected_at ?? null,
        stoppedAt: data.stopped_at ?? null,
        acknowledgedAt: data.acknowledged_at ?? null,
    }
}

export const acknowledgeServerSecurityLock = async (
    uuid: string
): Promise<ServerSecurityLock | null> => {
    const { data } = await http.post(
        `/api/client/servers/${uuid}/security/ddos-lock/acknowledge`,
        {},
        { showSuccessNotification: 'Security notice acknowledged.' }
    )

    return mapServerSecurityLock(data?.data?.security_lock)
}
