import http from '@/api/http'

export interface ReviewPromptStatus {
    enabled: boolean
    shouldPrompt: boolean
    completed: boolean
    reviewUrl: string | null
    pageViews: number | null
    viewThreshold: number | null
    delayDays: number | null
    panelName: string | null
}

const mapReviewPromptStatus = (data: any): ReviewPromptStatus => ({
    enabled: Boolean(data?.enabled),
    shouldPrompt: Boolean(data?.should_prompt),
    completed: Boolean(data?.completed),
    reviewUrl:
        typeof data?.review_url === 'string' && data.review_url.trim() !== ''
            ? data.review_url.trim()
            : null,
    pageViews:
        data?.page_views === null || data?.page_views === undefined
            ? null
            : Number(data.page_views),
    viewThreshold:
        data?.view_threshold === null || data?.view_threshold === undefined
            ? null
            : Number(data.view_threshold),
    delayDays:
        data?.delay_days === null || data?.delay_days === undefined
            ? null
            : Number(data.delay_days),
    panelName:
        typeof data?.panel_name === 'string' && data.panel_name.trim() !== ''
            ? data.panel_name.trim()
            : null,
})

export const tickReviewPrompt = async (): Promise<ReviewPromptStatus> => {
    const {
        data: { data },
    } = await http.post(
        '/api/client/review-prompt/tick',
        {},
        { showProgress: false } as any
    )

    return mapReviewPromptStatus(data)
}

export const completeReviewPrompt = async (): Promise<boolean> => {
    const {
        data: { data },
    } = await http.post(
        '/api/client/review-prompt/complete',
        {},
        { showProgress: false } as any
    )

    return Boolean(data?.completed)
}
