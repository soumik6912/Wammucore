import http, { getPaginationSet, PaginatedResult } from '@/api/http'

export interface ResellerTicketMessage {
    id: number
    actorType: string
    body: string
    user: {
        id: number
        name: string
        email: string
    } | null
    createdAt: string | null
}

export interface ResellerTicket {
    id: number
    uuid: string
    ticketNumber: string
    subject: string
    priority: string
    status: string
    customerName: string | null
    customerEmail: string | null
    serverId: number | null
    messagesCount: number
    lastReplyAt: string | null
    lastReplyByType: string | null
    resolvedAt: string | null
    user: {
        id: number
        name: string
        email: string
    } | null
    assignedTo: {
        id: number
        name: string
        email: string
    } | null
    messages: ResellerTicketMessage[]
    createdAt: string | null
    updatedAt: string | null
}

export interface ResellerTicketsResponse extends PaginatedResult<ResellerTicket> {
    summary: {
        countsByStatus: Record<string, number>
        countsByPriority: Record<string, number>
    }
}

const rawToMessage = (data: any): ResellerTicketMessage => ({
    id: Number(data.id ?? 0),
    actorType: String(data.actor_type ?? 'reseller'),
    body: String(data.body ?? ''),
    user: data.user
        ? {
              id: Number(data.user.id ?? 0),
              name: String(data.user.name ?? ''),
              email: String(data.user.email ?? ''),
          }
        : null,
    createdAt: data.created_at ?? null,
})

const rawToTicket = (data: any): ResellerTicket => ({
    id: Number(data.id ?? 0),
    uuid: String(data.uuid ?? ''),
    ticketNumber: String(data.ticket_number ?? ''),
    subject: String(data.subject ?? ''),
    priority: String(data.priority ?? 'medium'),
    status: String(data.status ?? 'open'),
    customerName: data.customer_name ?? null,
    customerEmail: data.customer_email ?? null,
    serverId:
        typeof data.server_id === 'number'
            ? data.server_id
            : data.server_id
              ? Number(data.server_id)
              : null,
    messagesCount: Number(data.messages_count ?? 0),
    lastReplyAt: data.last_reply_at ?? null,
    lastReplyByType: data.last_reply_by_type ?? null,
    resolvedAt: data.resolved_at ?? null,
    user: data.user
        ? {
              id: Number(data.user.id ?? 0),
              name: String(data.user.name ?? ''),
              email: String(data.user.email ?? ''),
          }
        : null,
    assignedTo: data.assigned_to
        ? {
              id: Number(data.assigned_to.id ?? 0),
              name: String(data.assigned_to.name ?? ''),
              email: String(data.assigned_to.email ?? ''),
          }
        : null,
    messages: Array.isArray(data.messages)
        ? data.messages.map(rawToMessage)
        : [],
    createdAt: data.created_at ?? null,
    updatedAt: data.updated_at ?? null,
})

export const getResellerTickets = async ({
    page = 1,
    perPage = 25,
    query,
    status,
    priority,
}: {
    page?: number
    perPage?: number
    query?: string
    status?: string
    priority?: string
}): Promise<ResellerTicketsResponse> => {
    const { data } = await http.get('/api/admin/reseller-panel/tickets', {
        params: {
            page,
            per_page: perPage,
            query: query || undefined,
            status: status || undefined,
            priority: priority || undefined,
        },
    })

    return {
        items: (data.data ?? []).map(rawToTicket),
        pagination: getPaginationSet(data.meta.pagination),
        summary: {
            countsByStatus: data.meta?.summary?.counts_by_status ?? {},
            countsByPriority: data.meta?.summary?.counts_by_priority ?? {},
        },
    }
}

export const getResellerTicket = async (ticketId: number): Promise<ResellerTicket> => {
    const {
        data: { data },
    } = await http.get(`/api/admin/reseller-panel/tickets/${ticketId}`)

    return rawToTicket(data)
}

export const createResellerTicket = async (payload: {
    subject: string
    priority: string
    userId?: number | null
    serverId?: number | null
    customerName?: string | null
    customerEmail?: string | null
    body: string
}): Promise<ResellerTicket> => {
    const {
        data: { data },
    } = await http.post('/api/admin/reseller-panel/tickets', {
        subject: payload.subject,
        priority: payload.priority,
        user_id: payload.userId ?? null,
        server_id: payload.serverId ?? null,
        customer_name: payload.customerName ?? null,
        customer_email: payload.customerEmail ?? null,
        body: payload.body,
    })

    return rawToTicket(data)
}

export const updateResellerTicket = async (
    ticketId: number,
    payload: {
        subject?: string
        priority?: string
        status?: string
        assignedToUserId?: number | null
        customerName?: string | null
        customerEmail?: string | null
    }
): Promise<ResellerTicket> => {
    const {
        data: { data },
    } = await http.patch(`/api/admin/reseller-panel/tickets/${ticketId}`, {
        subject: payload.subject,
        priority: payload.priority,
        status: payload.status,
        assigned_to_user_id: payload.assignedToUserId ?? null,
        customer_name: payload.customerName ?? null,
        customer_email: payload.customerEmail ?? null,
    })

    return rawToTicket(data)
}

export const replyToResellerTicket = async (
    ticketId: number,
    payload: { body: string; status?: string | null }
): Promise<ResellerTicket> => {
    const {
        data: { data },
    } = await http.post(`/api/admin/reseller-panel/tickets/${ticketId}/reply`, {
        body: payload.body,
        status: payload.status ?? null,
    })

    return rawToTicket(data)
}
