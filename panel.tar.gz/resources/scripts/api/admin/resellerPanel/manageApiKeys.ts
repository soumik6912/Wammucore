import http from '@/api/http'

export interface ResellerApiKey {
    id: number
    name: string
    keyPrefix: string
    scopes: string[]
    lastUsedAt: string | null
    expiresAt: string | null
    revokedAt: string | null
    createdAt: string | null
    plainTextKey?: string
}

export const getResellerApiKeys = async (): Promise<ResellerApiKey[]> => {
    const {
        data: { data },
    } = await http.get('/api/admin/reseller-panel/api-keys')

    return (data ?? []).map((item: any) => ({
        id: item.id,
        name: item.name,
        keyPrefix: item.key_prefix,
        scopes: item.scopes ?? [],
        lastUsedAt: item.last_used_at ?? null,
        expiresAt: item.expires_at ?? null,
        revokedAt: item.revoked_at ?? null,
        createdAt: item.created_at ?? null,
    }))
}

export const createResellerApiKey = async (payload: {
    name: string
    scopes: string[]
    expiresAt?: string | null
}): Promise<ResellerApiKey> => {
    const {
        data: { data },
    } = await http.post('/api/admin/reseller-panel/api-keys', {
        name: payload.name,
        scopes: payload.scopes,
        expires_at: payload.expiresAt ?? null,
    })

    return {
        id: data.id,
        name: data.name,
        keyPrefix: data.key_prefix,
        scopes: data.scopes ?? [],
        lastUsedAt: data.last_used_at ?? null,
        expiresAt: data.expires_at ?? null,
        revokedAt: data.revoked_at ?? null,
        createdAt: data.created_at ?? null,
        plainTextKey: data.plain_text_key,
    }
}

export const revokeResellerApiKey = async (
    credentialId: number
): Promise<ResellerApiKey> => {
    const {
        data: { data },
    } = await http.post(
        `/api/admin/reseller-panel/api-keys/${credentialId}/revoke`
    )

    return {
        id: data.id,
        name: data.name,
        keyPrefix: data.key_prefix,
        scopes: data.scopes ?? [],
        lastUsedAt: data.last_used_at ?? null,
        expiresAt: data.expires_at ?? null,
        revokedAt: data.revoked_at ?? null,
        createdAt: data.created_at ?? null,
    }
}
