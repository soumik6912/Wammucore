import http, { getPaginationSet, PaginatedResult } from '@/api/http'

export interface ResellerOrder {
    id: number
    uuid: string
    orderNumber: string
    externalOrderId: string | null
    billingSource: 'external' | 'manual' | 'api' | string
    status: string
    totalAmount: string
    currency: string
    billingCycle: string | null
    dueAt: string | null
    paidAt: string | null
    autoSuspendEnabled: boolean
    graceDays: number
    suspendedAt: string | null
    cancelledAt: string | null
    user: {
        id: number
        name: string
        email: string
    } | null
    plan: {
        id: number
        name: string
        slug: string
    } | null
    server: {
        id: number
        uuid: string
        name: string
        hostname: string
        status: string | null
    } | null
    metadata: Record<string, any>
    createdAt: string | null
    updatedAt: string | null
}

export interface ManualBillingSettings {
    enabled: boolean
    autoSuspendEnabled: boolean
    graceDays: number
    deleteSuspendedEnabled: boolean
    deleteSuspendedDays: number
}

export interface ResellerOrdersResponse extends PaginatedResult<ResellerOrder> {
    manualBilling: ManualBillingSettings
    summary: {
        countsByStatus: Record<string, number>
        totalsByCurrency: Array<{
            currency: string
            total: number
        }>
    }
}

const rawToOrder = (data: any): ResellerOrder => ({
    id: data.id,
    uuid: data.uuid,
    orderNumber: data.order_number,
    externalOrderId: data.external_order_id ?? null,
    billingSource: data.billing_source ?? 'external',
    status: data.status,
    totalAmount: data.total_amount,
    currency: data.currency,
    billingCycle: data.billing_cycle ?? null,
    dueAt: data.due_at ?? null,
    paidAt: data.paid_at ?? null,
    autoSuspendEnabled: Boolean(data.auto_suspend_enabled),
    graceDays: Number(data.grace_days ?? 0),
    suspendedAt: data.suspended_at ?? null,
    cancelledAt: data.cancelled_at ?? null,
    user: data.user
        ? {
              id: data.user.id,
              name: data.user.name,
              email: data.user.email,
          }
        : null,
    plan: data.plan
        ? {
              id: data.plan.id,
              name: data.plan.name,
              slug: data.plan.slug,
          }
        : null,
    server: data.server
        ? {
              id: Number(data.server.id),
              uuid: String(data.server.uuid ?? ''),
              name: String(data.server.name ?? ''),
              hostname: String(data.server.hostname ?? ''),
              status: data.server.status ?? null,
          }
        : null,
    metadata: data.metadata ?? {},
    createdAt: data.created_at ?? null,
    updatedAt: data.updated_at ?? null,
})

const rawManualBillingSettings = (data: any): ManualBillingSettings => ({
    enabled: Boolean(data?.enabled ?? true),
    autoSuspendEnabled: Boolean(data?.auto_suspend_enabled ?? true),
    graceDays: Number(data?.grace_days ?? 30),
    deleteSuspendedEnabled: Boolean(data?.delete_suspended_enabled ?? false),
    deleteSuspendedDays: Number(data?.delete_suspended_days ?? 3),
})

export const getResellerOrders = async ({
    page = 1,
    perPage = 50,
    query,
    status,
}: {
    page?: number
    perPage?: number
    query?: string
    status?: string
}): Promise<ResellerOrdersResponse> => {
    const { data } = await http.get('/api/admin/reseller-panel/orders', {
        params: {
            page,
            per_page: perPage,
            query: query || undefined,
            status: status || undefined,
        },
    })

    return {
        items: (data.data ?? []).map(rawToOrder),
        pagination: getPaginationSet(data.meta.pagination),
        manualBilling: rawManualBillingSettings(data.meta?.manual_billing),
        summary: {
            countsByStatus: data.meta?.summary?.counts_by_status ?? {},
            totalsByCurrency: data.meta?.summary?.totals_by_currency ?? [],
        },
    }
}

export const getResellerOrdersCsvUrl = (): string =>
    '/api/admin/reseller-panel/orders/export.csv'

export interface ManualOrderPayload {
    userId?: number | null
    customerName?: string | null
    customerEmail?: string | null
    customerPassword?: string | null
    catalogPlanId?: number | null
    hostname?: string | null
    operatingSystem?: string | null
    rootPassword?: string | null
    locationId?: number | null
    locationCode?: string | null
    amount: string
    currency: string
    billingCycle: 'one_time' | 'monthly' | 'quarterly' | 'semi_annually' | 'yearly'
    dueAt?: string | null
    graceDays?: number | null
    autoSuspendEnabled?: boolean
    provisionOnPaid?: boolean
    markPaidNow?: boolean
    notes?: string | null
}

export interface ManualOrderActionResponse {
    order: ResellerOrder
    provisioning: {
        service_id: number | null
        service_uuid: string | null
        root_password: string | null
    } | null
}

const rawActionResponse = (data: any): ManualOrderActionResponse => ({
    order: rawToOrder(data.order ?? data),
    provisioning: data.provisioning ?? null,
})

export const updateManualBillingSettings = async (
    payload: ManualBillingSettings
): Promise<ManualBillingSettings> => {
    const {
        data: { data },
    } = await http.patch('/api/admin/reseller-panel/orders/manual-settings', {
        enabled: payload.enabled,
        auto_suspend_enabled: payload.autoSuspendEnabled,
        grace_days: payload.graceDays,
        delete_suspended_enabled: payload.deleteSuspendedEnabled,
        delete_suspended_days: payload.deleteSuspendedDays,
    })

    return rawManualBillingSettings(data)
}

export const createManualOrder = async (
    payload: ManualOrderPayload
): Promise<ManualOrderActionResponse> => {
    const {
        data: { data },
    } = await http.post('/api/admin/reseller-panel/orders/manual', {
        user_id: payload.userId ?? null,
        customer_name: payload.customerName ?? null,
        customer_email: payload.customerEmail ?? null,
        customer_password: payload.customerPassword ?? null,
        catalog_plan_id: payload.catalogPlanId ?? null,
        hostname: payload.hostname ?? null,
        operating_system: payload.operatingSystem ?? null,
        root_password: payload.rootPassword ?? null,
        location_id: payload.locationId ?? null,
        location_code: payload.locationCode ?? null,
        amount: payload.amount,
        currency: payload.currency,
        billing_cycle: payload.billingCycle,
        due_at: payload.dueAt ?? null,
        grace_days: payload.graceDays ?? null,
        auto_suspend_enabled: payload.autoSuspendEnabled ?? true,
        provision_on_paid: payload.provisionOnPaid ?? false,
        mark_paid_now: payload.markPaidNow ?? false,
        notes: payload.notes ?? null,
    })

    return rawActionResponse(data)
}

export const markManualOrderPaid = async (
    orderId: number | string,
    rootPassword?: string
): Promise<ManualOrderActionResponse> => {
    const {
        data: { data },
    } = await http.post(`/api/admin/reseller-panel/orders/${orderId}/mark-paid`, {
        root_password: rootPassword || null,
    })

    return rawActionResponse(data)
}

export const suspendManualOrder = async (
    orderId: number | string,
    reason?: string
): Promise<ResellerOrder> => {
    const {
        data: { data },
    } = await http.post(`/api/admin/reseller-panel/orders/${orderId}/suspend`, {
        reason: reason || null,
    })

    return rawToOrder(data)
}

export const unsuspendManualOrder = async (
    orderId: number | string
): Promise<ResellerOrder> => {
    const {
        data: { data },
    } = await http.post(`/api/admin/reseller-panel/orders/${orderId}/unsuspend`)

    return rawToOrder(data)
}

export const cancelManualOrder = async (
    orderId: number | string
): Promise<ResellerOrder> => {
    const {
        data: { data },
    } = await http.post(`/api/admin/reseller-panel/orders/${orderId}/cancel`)

    return rawToOrder(data)
}
