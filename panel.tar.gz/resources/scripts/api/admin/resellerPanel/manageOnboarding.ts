import http from '@/api/http'

export type OnboardingStepStatus =
    | 'pending'
    | 'in_progress'
    | 'completed'
    | 'skipped'
    | 'rejected'
    | 'suspended'

export interface ResellerOnboardingStep {
    key: string
    title: string
    description: string
    path: string
    status: OnboardingStepStatus
    note: string | null
    payload: Record<string, unknown>
    completedAt: string | null
    reviewedAt: string | null
}

export interface ResellerOnboardingSnapshot {
    status: string
    currentStep: string
    currentPath: string
    completed: boolean
    suspended: boolean
    canAccessPanel: boolean
    blockedReason: string | null
    completedAt: string | null
    suspendedAt: string | null
    suspendedReason: string | null
    overrideAt: string | null
    overrideNote: string | null
    owner: {
        email: string | null
        emailVerified: boolean
        mustChangePassword: boolean
    }
    personalDetails: {
        submitted: boolean
        locked: boolean
        firstName: string | null
        lastName: string | null
        contactEmail: string | null
        phoneNumber: string | null
        addressLine1: string | null
        addressLine2: string | null
        city: string | null
        stateName: string | null
        postalCode: string | null
        countryName: string | null
        submittedAt: string | null
        lockedAt: string | null
    }
    identity: {
        status: string
        aadhaarMasked: string | null
        panMasked: string | null
        businessName: string | null
        businessRegistrationMasked: string | null
        documentsUploaded: boolean
        documents: Array<{
            type: string
            label: string
            available: boolean
            mime: string | null
            sizeBytes: number
            uploadedAt: string | null
        }>
        fraudFlags: string[]
        malwareScanStatus: string | null
        submittedAt: string | null
        approvedAt: string | null
        rejectedAt: string | null
        reverificationRequestedAt: string | null
        reviewNote: string | null
    }
    branding: {
        displayName: string
        logoUrl: string | null
        supportUrl: string | null
        tosUrl: string | null
        privacyUrl: string | null
        primaryColor: string | null
        secondaryColor: string | null
        accentColor: string | null
        customCss: string | null
    }
    domains: {
        primaryHostname: string | null
        edgeGatewayHost: string
        verificationPrefix: string
        dnsStatus: string
        sslStatus: string
        routingStatus: string
        verifiedAt: string | null
        items: Array<{
            id: number
            hostname: string
            purpose: string
            isPrimary: boolean
            isWildcard: boolean
            dnsStatus: string
            sslStatus: string
            routingStatus: string
            cnameTarget: string
            verificationHost: string
            verificationToken: string | null
            verificationValue: string | null
            probeHostname: string
            verifiedAt: string | null
            verificationRequestedAt: string | null
            lastCheckedAt: string | null
            ownershipVerifiedAt: string | null
            sslProvisionedAt: string | null
            activatedAt: string | null
            lastError: string | null
            edgeGatewayHost: string
        }>
    }
    activation: {
        resellerStatus: string
        verificationStatus: string
    }
    kycPolicy: {
        allowedProofTypes: Array<'aadhaar' | 'pan'>
        aadhaarEnabled: boolean
        panEnabled: boolean
        digilockerEnabled: boolean
        digilockerUrl: string | null
    }
    steps: ResellerOnboardingStep[]
}

const mapSnapshot = (data: any): ResellerOnboardingSnapshot => ({
    status: String(data.status ?? 'pending'),
    currentStep: String(data.current_step ?? 'personal_details'),
    currentPath: String(
        data.current_path ??
            '/admin/reseller-panel/onboarding/personal-details'
    ),
    completed: Boolean(data.completed),
    suspended: Boolean(data.suspended),
    canAccessPanel: Boolean(data.can_access_panel),
    blockedReason: data.blocked_reason ?? null,
    completedAt: data.completed_at ?? null,
    suspendedAt: data.suspended_at ?? null,
    suspendedReason: data.suspended_reason ?? null,
    overrideAt: data.override_at ?? null,
    overrideNote: data.override_note ?? null,
    owner: {
        email: data.owner?.email ?? null,
        emailVerified: Boolean(data.owner?.email_verified),
        mustChangePassword: Boolean(data.owner?.must_change_password),
    },
    personalDetails: {
        submitted: Boolean(data.personal_details?.submitted),
        locked: Boolean(data.personal_details?.locked),
        firstName: data.personal_details?.first_name ?? null,
        lastName: data.personal_details?.last_name ?? null,
        contactEmail: data.personal_details?.contact_email ?? null,
        phoneNumber: data.personal_details?.phone_number ?? null,
        addressLine1: data.personal_details?.address_line_1 ?? null,
        addressLine2: data.personal_details?.address_line_2 ?? null,
        city: data.personal_details?.city ?? null,
        stateName: data.personal_details?.state_name ?? null,
        postalCode: data.personal_details?.postal_code ?? null,
        countryName: data.personal_details?.country_name ?? null,
        submittedAt: data.personal_details?.submitted_at ?? null,
        lockedAt: data.personal_details?.locked_at ?? null,
    },
    identity: {
        status: String(data.identity?.status ?? 'pending'),
        aadhaarMasked: data.identity?.aadhaar_masked ?? null,
        panMasked: data.identity?.pan_masked ?? null,
        businessName: data.identity?.business_name ?? null,
        businessRegistrationMasked:
            data.identity?.business_registration_masked ?? null,
        documentsUploaded: Boolean(data.identity?.documents_uploaded),
        documents: Array.isArray(data.identity?.documents)
            ? data.identity.documents.map((document: any) => ({
                  type: String(document.type ?? ''),
                  label: String(document.label ?? 'Document'),
                  available: Boolean(document.available),
                  mime: document.mime ?? null,
                  sizeBytes: Number(document.size_bytes ?? 0),
                  uploadedAt: document.uploaded_at ?? null,
              }))
            : [],
        fraudFlags: Array.isArray(data.identity?.fraud_flags)
            ? data.identity.fraud_flags.map((flag: any) => String(flag))
            : [],
        malwareScanStatus: data.identity?.malware_scan_status ?? null,
        submittedAt: data.identity?.submitted_at ?? null,
        approvedAt: data.identity?.approved_at ?? null,
        rejectedAt: data.identity?.rejected_at ?? null,
        reverificationRequestedAt:
            data.identity?.reverification_requested_at ?? null,
        reviewNote: data.identity?.review_note ?? null,
    },
    branding: {
        displayName: String(data.branding?.display_name ?? ''),
        logoUrl: data.branding?.logo_url ?? null,
        supportUrl: data.branding?.support_url ?? null,
        tosUrl: data.branding?.tos_url ?? null,
        privacyUrl: data.branding?.privacy_url ?? null,
        primaryColor: data.branding?.primary_color ?? null,
        secondaryColor: data.branding?.secondary_color ?? null,
        accentColor: data.branding?.accent_color ?? null,
        customCss: data.branding?.custom_css ?? null,
    },
    domains: {
        primaryHostname: data.domains?.primary_hostname ?? null,
        edgeGatewayHost: String(
            data.domains?.edge_gateway_host ?? 'edge.wammuhost.com'
        ),
        verificationPrefix: String(
            data.domains?.verification_prefix ?? '_wammuhost-verify'
        ),
        dnsStatus: String(data.domains?.dns_status ?? 'pending'),
        sslStatus: String(data.domains?.ssl_status ?? 'pending'),
        routingStatus: String(data.domains?.routing_status ?? 'pending'),
        verifiedAt: data.domains?.verified_at ?? null,
        items: Array.isArray(data.domains?.items)
            ? data.domains.items.map((item: any) => ({
                  id: Number(item.id),
                  hostname: String(item.hostname ?? ''),
                  purpose: String(item.purpose ?? 'panel'),
                  isPrimary: Boolean(item.is_primary),
                  isWildcard: Boolean(item.is_wildcard),
                  dnsStatus: String(item.dns_status ?? 'pending'),
                  sslStatus: String(item.ssl_status ?? 'pending'),
                  routingStatus: String(item.routing_status ?? 'pending'),
                  cnameTarget: String(
                      item.cname_target ?? item.edge_gateway_host ?? 'edge.wammuhost.com'
                  ),
                  verificationHost: String(item.verification_host ?? ''),
                  verificationToken:
                      typeof item.verification_token === 'string'
                          ? item.verification_token
                          : null,
                  verificationValue:
                      typeof item.verification_value === 'string'
                          ? item.verification_value
                          : null,
                  probeHostname: String(item.probe_hostname ?? item.hostname ?? ''),
                  verifiedAt: item.verified_at ?? null,
                  verificationRequestedAt:
                      item.verification_requested_at ?? null,
                  lastCheckedAt: item.last_checked_at ?? null,
                  ownershipVerifiedAt:
                      item.ownership_verified_at ?? null,
                  sslProvisionedAt: item.ssl_provisioned_at ?? null,
                  activatedAt: item.activated_at ?? null,
                  lastError: item.last_error ?? null,
                  edgeGatewayHost: String(
                      item.edge_gateway_host ?? 'edge.wammuhost.com'
                  ),
              }))
            : [],
    },
    activation: {
        resellerStatus: String(data.activation?.reseller_status ?? 'pending'),
        verificationStatus: String(
            data.activation?.verification_status ?? 'pending'
        ),
    },
    kycPolicy: {
        allowedProofTypes: Array.isArray(data.kyc_policy?.allowed_proof_types)
            ? data.kyc_policy.allowed_proof_types
                  .map((type: any) => String(type))
                  .filter((type: string): type is 'aadhaar' | 'pan' =>
                      type === 'aadhaar' || type === 'pan'
                  )
            : ['aadhaar', 'pan'],
        aadhaarEnabled: Boolean(data.kyc_policy?.aadhaar_enabled ?? true),
        panEnabled: Boolean(data.kyc_policy?.pan_enabled ?? true),
        digilockerEnabled: Boolean(data.kyc_policy?.digilocker_enabled),
        digilockerUrl: data.kyc_policy?.digilocker_url ?? null,
    },
    steps: Array.isArray(data.steps)
        ? data.steps.map((step: any) => ({
              key: String(step.key),
              title: String(step.title),
              description: String(step.description),
              path: String(step.path),
              status: (step.status ?? 'pending') as OnboardingStepStatus,
              note: step.note ?? null,
              payload: step.payload ?? {},
              completedAt: step.completed_at ?? null,
              reviewedAt: step.reviewed_at ?? null,
          }))
        : [],
})

export const getResellerOnboarding =
    async (): Promise<ResellerOnboardingSnapshot> => {
        const {
            data: { data },
        } = await http.get('/api/admin/reseller-panel/onboarding')

        return mapSnapshot(data)
    }

export const resendResellerOnboardingVerification = async (): Promise<string> => {
    const {
        data: { data },
    } = await http.post(
        '/api/admin/reseller-panel/onboarding/email-verification/resend'
    )

    return String(data.message ?? 'Verification email sent.')
}

export const submitResellerOnboardingKyc = async (payload: {
    identityProofType: 'aadhaar' | 'pan'
    aadhaarNumber: string
    panNumber: string
    businessName: string
    businessRegistrationNumber: string
    aadhaarFront: File | null
    aadhaarBack: File | null
    panDocument: File | null
    supportingDocuments?: File[]
}): Promise<{
    message: string
    aadhaarMasked: string | null
    panMasked: string | null
    businessRegistrationMasked: string | null
}> => {
    const body = new FormData()
    body.append('identity_proof_type', payload.identityProofType)
    if (payload.identityProofType === 'aadhaar') {
        body.append('aadhaar_number', payload.aadhaarNumber)
        if (payload.aadhaarFront) {
            body.append('aadhaar_front', payload.aadhaarFront)
        }
        if (payload.aadhaarBack) {
            body.append('aadhaar_back', payload.aadhaarBack)
        }
    }
    if (payload.identityProofType === 'pan') {
        body.append('pan_number', payload.panNumber)
        if (payload.panDocument) {
            body.append('pan_document', payload.panDocument)
        }
    }
    if (payload.businessName.trim().length > 0) {
        body.append('business_name', payload.businessName)
    }
    if (payload.businessRegistrationNumber.trim().length > 0) {
        body.append(
            'business_registration_number',
            payload.businessRegistrationNumber
        )
    }
    ;(payload.supportingDocuments || []).forEach(document => {
        body.append('supporting_documents[]', document)
    })

    const {
        data: { data },
    } = await http.post('/api/admin/reseller-panel/onboarding/kyc', body)

    return {
        message: String(data.message ?? 'KYC submitted.'),
        aadhaarMasked: data.aadhaar_masked ?? null,
        panMasked: data.pan_masked ?? null,
        businessRegistrationMasked:
            data.business_registration_masked ?? null,
    }
}

export const submitResellerOnboardingPersonalDetails = async (payload: {
    firstName: string
    lastName: string
    contactEmail: string
    phoneNumber: string
    addressLine1: string
    addressLine2: string
    city: string
    stateName: string
    postalCode: string
    countryName: string
}): Promise<{
    message: string
}> => {
    const {
        data: { data },
    } = await http.post('/api/admin/reseller-panel/onboarding/personal-details', {
        first_name: payload.firstName,
        last_name: payload.lastName,
        contact_email: payload.contactEmail,
        phone_number: payload.phoneNumber,
        address_line_1: payload.addressLine1,
        address_line_2: payload.addressLine2.trim() || null,
        city: payload.city,
        state_name: payload.stateName,
        postal_code: payload.postalCode,
        country_name: payload.countryName,
    })

    return {
        message: String(
            data.message ??
                'Personal details submitted.'
        ),
    }
}

export const saveResellerOnboardingBranding = async (
    payload: Record<string, string | null>
): Promise<ResellerOnboardingSnapshot> => {
    const {
        data: { data },
    } = await http.patch('/api/admin/reseller-panel/onboarding/branding', payload)

    return mapSnapshot(data.onboarding)
}

export const saveResellerOnboardingDomains = async (
    payload: { hostname: string }
): Promise<ResellerOnboardingSnapshot> => {
    const {
        data: { data },
    } = await http.patch('/api/admin/reseller-panel/onboarding/domains', {
        hostname: payload.hostname,
    })

    return mapSnapshot(data.onboarding)
}

export const verifyResellerOnboardingDns = async (): Promise<{
    snapshot: ResellerOnboardingSnapshot
    verification: any
}> => {
    const {
        data: { data },
    } = await http.post('/api/admin/reseller-panel/onboarding/dns/verify')

    return {
        snapshot: mapSnapshot(data.onboarding),
        verification: data.verification,
    }
}

export const requestResellerOnboardingSsl =
    async (): Promise<ResellerOnboardingSnapshot> => {
        const {
            data: { data },
        } = await http.post('/api/admin/reseller-panel/onboarding/ssl/request')

        return mapSnapshot(data.onboarding)
    }
