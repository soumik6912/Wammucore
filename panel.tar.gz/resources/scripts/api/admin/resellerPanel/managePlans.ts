import http from '@/api/http'

export interface ResellerCatalogOffer {
    catalogPlanId: number
    catalogName: string
    name: string
    slug: string
    category: string
    description: string | null
    cpuCores: number
    cpuLimit: number
    cpuUnits: number
    cpuSockets: number
    ramMb: number
    diskGb: number
    bandwidthGb: number | null
    snapshotLimit: number
    backupLimit: number
    effectiveBackupLimit: number
    allowResellerBackupOverride: boolean
    defaultIpQuantity: number
    sortOrder: number
    isActive: boolean
    pricing: {
        monthlyPrice: string | null
        planDisplayName: string | null
        currency: string
        ipQuantity: number
        addressPoolId: number | null
        addressPool: {
            id: number
            name: string
            resellerIpPriceEach: string
        } | null
        backupLimitOverride: number | null
        ipPriceEach: string
        paymenterCheckoutUrl: string | null
        isVisible: boolean
    }
}

export interface ResellerPlanPoolOption {
    id: number
    name: string
    resellerIpPriceEach: string
    resellerAccessMode: 'shared' | 'exclusive' | 'platform_only'
    resellerDisplayName: string | null
    addressesCount: number
    nodesCount: number
}

export interface ResellerCatalogOffersResponse {
    items: ResellerCatalogOffer[]
    poolOptions: ResellerPlanPoolOption[]
}

export interface UpdateResellerCatalogOfferPayload {
    monthlyPrice: string | null
    planDisplayName: string | null
    ipQuantity: number
    addressPoolId: number | null
    ipPriceEach: string
    backupLimitOverride: number | null
    isVisible: boolean
}

const rawOffer = (item: any): ResellerCatalogOffer => ({
    catalogPlanId: Number(item.catalog_plan_id),
    catalogName: String(item.catalog_name ?? item.name ?? ''),
    name: String(item.name ?? ''),
    slug: String(item.slug ?? ''),
    category: String(item.category ?? 'General'),
    description: item.description ?? null,
    cpuCores: Number(item.cpu_cores ?? 0),
    cpuLimit: Number(item.cpu_limit ?? 0),
    cpuUnits: Number(item.cpu_units ?? 1024),
    cpuSockets: Number(item.cpu_sockets ?? 1),
    ramMb: Number(item.ram_mb ?? 0),
    diskGb: Number(item.disk_gb ?? 0),
    bandwidthGb:
        item.bandwidth_gb === null || item.bandwidth_gb === undefined
            ? null
            : Number(item.bandwidth_gb),
    snapshotLimit: Number(item.snapshot_limit ?? 0),
    backupLimit: Number(item.backup_limit ?? 0),
    effectiveBackupLimit: Number(item.effective_backup_limit ?? item.backup_limit ?? 0),
    allowResellerBackupOverride: Boolean(item.allow_reseller_backup_override),
    defaultIpQuantity: Number(item.default_ip_quantity ?? 0),
    sortOrder: Number(item.sort_order ?? 0),
    isActive: Boolean(item.is_active),
    pricing: {
        monthlyPrice: item.pricing?.monthly_price ?? null,
        planDisplayName: item.pricing?.plan_display_name ?? null,
        currency: String(item.pricing?.currency ?? 'USD'),
        ipQuantity: Number(item.pricing?.ip_quantity ?? item.default_ip_quantity ?? 0),
        addressPoolId:
            item.pricing?.address_pool_id === null ||
            item.pricing?.address_pool_id === undefined
                ? null
                : Number(item.pricing.address_pool_id),
        addressPool: item.pricing?.address_pool
            ? {
                  id: Number(item.pricing.address_pool.id),
                  name: String(item.pricing.address_pool.name ?? ''),
                  resellerIpPriceEach: String(
                      item.pricing.address_pool.reseller_ip_price_each ?? '0.00'
                  ),
              }
            : null,
        backupLimitOverride:
            item.pricing?.backup_limit_override === null ||
            item.pricing?.backup_limit_override === undefined
                ? null
                : Number(item.pricing.backup_limit_override),
        ipPriceEach: String(item.pricing?.ip_price_each ?? '0.00'),
        paymenterCheckoutUrl: item.pricing?.paymenter_checkout_url ?? null,
        isVisible: Boolean(item.pricing?.is_visible ?? true),
    },
})

const rawPoolOption = (item: any): ResellerPlanPoolOption => ({
    id: Number(item.id),
    name: String(item.name ?? ''),
    resellerIpPriceEach: String(item.reseller_ip_price_each ?? '0.00'),
    resellerAccessMode: (item.reseller_access_mode ?? 'shared') as
        | 'shared'
        | 'exclusive'
        | 'platform_only',
    resellerDisplayName: item.reseller_display_name ?? null,
    addressesCount: Number(item.addresses_count ?? 0),
    nodesCount: Number(item.nodes_count ?? 0),
})

export const getResellerCatalogOffers = async (): Promise<
    ResellerCatalogOffersResponse
> => {
    const {
        data: { data },
    } = await http.get('/api/admin/reseller-panel/plans')

    return {
        items: Array.isArray(data?.items) ? data.items.map(rawOffer) : [],
        poolOptions: Array.isArray(data?.pool_options)
            ? data.pool_options.map(rawPoolOption)
            : [],
    }
}

export const updateResellerCatalogOffer = async (
    catalogPlanId: number,
    payload: UpdateResellerCatalogOfferPayload
): Promise<ResellerCatalogOffer> => {
    const {
        data: { data },
    } = await http.put(`/api/admin/reseller-panel/plans/${catalogPlanId}`, {
        monthly_price: payload.monthlyPrice,
        plan_display_name: payload.planDisplayName,
        ip_quantity: payload.ipQuantity,
        address_pool_id: payload.addressPoolId,
        ip_price_each: payload.ipPriceEach,
        backup_limit_override: payload.backupLimitOverride,
        is_visible: payload.isVisible,
    })

    return rawOffer(data)
}
