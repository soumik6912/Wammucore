import http from '@/api/http'

export interface ResellerOverviewResponse {
    reseller: {
        id: number
        uuid: string | null
        slug: string | null
        displayName: string
        domain: string | null
        status: string
        verificationStatus:
            | 'pending'
            | 'under_review'
            | 'approved'
            | 'rejected'
            | 'suspended'
        verificationSubmittedAt: string | null
        verificationRejectionReason: string | null
        documents: {
            frontAvailable: boolean
            backAvailable: boolean
            hasDocuments: boolean
            count?: number
        }
    }
    access: {
        canOperate: boolean
        blockedReason: string | null
    }
    onboarding: {
        status: string
        currentStep: string
        currentPath: string
        completed: boolean
        suspended: boolean
        canAccessPanel: boolean
        blockedReason: string | null
    }
    stats: {
        totalVms: number
        activeUsers: number
        orders: number
        suspendedUsers: number
    }
    pool: {
        maxRamMb: number
        maxCpuCores: number
        maxDiskGb: number
        maxVms: number
        usedRamMb: number
        usedCpuCores: number
        usedDiskGb: number
        usedVms: number
        percentages: {
            ram: number
            cpu: number
            disk: number
            vms: number
        }
    }
    resources: {
        plans: Array<{
            catalogPlanId: number
            name: string
            slug: string
            quantityTotal: number
            quantityUsed: number
            quantityAvailable: number
            specs: {
                cpuCores: number
                ramMb: number
                diskGb: number
                bandwidthGb: number | null
                defaultIpQuantity: number
            }
        }>
        ipPools: Array<{
            addressPoolId: number
            name: string
            priceEach: string
            quantityTotal: number
            quantityUsed: number
            quantityAvailable: number
        }>
        updatedAt: string | null
    }
    billing: {
        countsByStatus: Record<string, number>
        grossRevenueByCurrency: Array<{ currency: string; total: number }>
        settledRevenueByCurrency: Array<{ currency: string; total: number }>
        averageOrderValueByCurrency: Array<{ currency: string; total: number }>
    }
    tickets: {
        countsByStatus: Record<string, number>
        openTotal: number
        urgentTotal: number
        items: Array<{
            id: number
            ticketNumber: string
            subject: string
            priority: string
            status: string
            customerEmail: string
            lastReplyAt: string | null
        }>
    }
    alerts: {
        countsBySeverity: Record<string, number>
        openTotal: number
        criticalTotal: number
        items: Array<{
            id: number
            type: string
            severity: string
            title: string
            status: string
            serverName: string
            customerEmail: string
            createdAt: string | null
        }>
    }
    queueHealth: {
        building: number
        deleting: number
        errors: number
    }
    failedTasks: {
        count: number
        items: Array<{
            id: number
            uuid: string
            queue: string
            name: string
            error: string
            failedAt: string
        }>
    }
    timeline: {
        serversCreatedLast7Days: { day: string; total: number }[]
    }
    impersonation: {
        ownerImpersonating: boolean
    }
}

const getResellerOverview = async (): Promise<ResellerOverviewResponse> => {
    const {
        data: { data },
    } = await http.get('/api/admin/reseller-panel/overview')

    return {
        reseller: {
            id: Number(data.reseller?.id ?? 0),
            uuid: data.reseller?.uuid ?? null,
            slug: data.reseller?.slug ?? null,
            displayName: String(data.reseller?.display_name ?? 'Reseller'),
            domain: data.reseller?.domain ?? null,
            status: String(data.reseller?.status ?? 'pending'),
            verificationStatus: data.reseller?.verification_status ?? 'approved',
            verificationSubmittedAt:
                data.reseller?.verification_submitted_at ?? null,
            verificationRejectionReason:
                data.reseller?.verification_rejection_reason ?? null,
            documents: {
                frontAvailable: Boolean(data.reseller?.documents?.front_available),
                backAvailable: Boolean(data.reseller?.documents?.back_available),
                hasDocuments: Boolean(data.reseller?.documents?.has_documents),
                count: Number(data.reseller?.documents?.count ?? 0),
            },
        },
        access: {
            canOperate: Boolean(data.access?.can_operate),
            blockedReason: data.access?.blocked_reason ?? null,
        },
        onboarding: {
            status: data.onboarding?.status ?? 'pending',
            currentStep: data.onboarding?.current_step ?? 'personal_details',
            currentPath:
                data.onboarding?.current_path ??
                '/admin/reseller-panel/onboarding/personal-details',
            completed: Boolean(data.onboarding?.completed),
            suspended: Boolean(data.onboarding?.suspended),
            canAccessPanel: Boolean(data.onboarding?.can_access_panel),
            blockedReason: data.onboarding?.blocked_reason ?? null,
        },
        stats: {
            totalVms: Number(data.stats?.total_vms ?? 0),
            activeUsers: Number(data.stats?.active_users ?? 0),
            orders: Number(data.stats?.orders ?? 0),
            suspendedUsers: Number(data.stats?.suspended_users ?? 0),
        },
        pool: {
            maxRamMb: Number(data.pool?.max_ram_mb ?? 0),
            maxCpuCores: Number(data.pool?.max_cpu_cores ?? 0),
            maxDiskGb: Number(data.pool?.max_disk_gb ?? 0),
            maxVms: Number(data.pool?.max_vms ?? 0),
            usedRamMb: Number(data.pool?.used_ram_mb ?? 0),
            usedCpuCores: Number(data.pool?.used_cpu_cores ?? 0),
            usedDiskGb: Number(data.pool?.used_disk_gb ?? 0),
            usedVms: Number(data.pool?.used_vms ?? 0),
            percentages: {
                ram: Number(data.pool?.percentages?.ram ?? 0),
                cpu: Number(data.pool?.percentages?.cpu ?? 0),
                disk: Number(data.pool?.percentages?.disk ?? 0),
                vms: Number(data.pool?.percentages?.vms ?? 0),
            },
        },
        resources: {
            plans: Array.isArray(data.resources?.plans)
                ? data.resources.plans.map((item: any) => ({
                      catalogPlanId: Number(item.catalog_plan_id ?? 0),
                      name: String(item.name ?? ''),
                      slug: String(item.slug ?? ''),
                      quantityTotal: Number(item.quantity_total ?? 0),
                      quantityUsed: Number(item.quantity_used ?? 0),
                      quantityAvailable: Number(item.quantity_available ?? 0),
                      specs: {
                          cpuCores: Number(item.specs?.cpu_cores ?? 0),
                          ramMb: Number(item.specs?.ram_mb ?? 0),
                          diskGb: Number(item.specs?.disk_gb ?? 0),
                          bandwidthGb:
                              item.specs?.bandwidth_gb === null ||
                              item.specs?.bandwidth_gb === undefined
                                  ? null
                                  : Number(item.specs.bandwidth_gb),
                          defaultIpQuantity: Number(
                              item.specs?.default_ip_quantity ?? 0
                          ),
                      },
                  }))
                : [],
            ipPools: Array.isArray(data.resources?.ip_pools)
                ? data.resources.ip_pools.map((item: any) => ({
                      addressPoolId: Number(item.address_pool_id ?? 0),
                      name: String(item.name ?? ''),
                      priceEach: String(item.price_each ?? '0.00'),
                      quantityTotal: Number(item.quantity_total ?? 0),
                      quantityUsed: Number(item.quantity_used ?? 0),
                      quantityAvailable: Number(item.quantity_available ?? 0),
                  }))
                : [],
            updatedAt: data.resources?.updated_at ?? null,
        },
        billing: {
            countsByStatus: data.billing?.counts_by_status ?? {},
            grossRevenueByCurrency: data.billing?.gross_revenue_by_currency ?? [],
            settledRevenueByCurrency:
                data.billing?.settled_revenue_by_currency ?? [],
            averageOrderValueByCurrency:
                data.billing?.average_order_value_by_currency ?? [],
        },
        tickets: {
            countsByStatus: data.tickets?.counts_by_status ?? {},
            openTotal: Number(data.tickets?.open_total ?? 0),
            urgentTotal: Number(data.tickets?.urgent_total ?? 0),
            items: Array.isArray(data.tickets?.items)
                ? data.tickets.items.map((item: any) => ({
                      id: Number(item.id ?? 0),
                      ticketNumber: String(item.ticket_number ?? ''),
                      subject: String(item.subject ?? ''),
                      priority: String(item.priority ?? 'medium'),
                      status: String(item.status ?? 'open'),
                      customerEmail: String(item.customer_email ?? '-'),
                      lastReplyAt: item.last_reply_at ?? null,
                  }))
                : [],
        },
        alerts: {
            countsBySeverity: data.alerts?.counts_by_severity ?? {},
            openTotal: Number(data.alerts?.open_total ?? 0),
            criticalTotal: Number(data.alerts?.critical_total ?? 0),
            items: Array.isArray(data.alerts?.items)
                ? data.alerts.items.map((item: any) => ({
                      id: Number(item.id ?? 0),
                      type: String(item.type ?? ''),
                      severity: String(item.severity ?? 'medium'),
                      title: String(item.title ?? ''),
                      status: String(item.status ?? 'open'),
                      serverName: String(item.server_name ?? '-'),
                      customerEmail: String(item.customer_email ?? '-'),
                      createdAt: item.created_at ?? null,
                  }))
                : [],
        },
        queueHealth: {
            building: Number(data.queue_health?.building ?? 0),
            deleting: Number(data.queue_health?.deleting ?? 0),
            errors: Number(data.queue_health?.errors ?? 0),
        },
        failedTasks: {
            count: Number(data.failed_tasks?.count ?? 0),
            items: Array.isArray(data.failed_tasks?.items)
                ? data.failed_tasks.items.map((item: any) => ({
                      id: Number(item.id ?? 0),
                      uuid: String(item.uuid ?? ''),
                      queue: String(item.queue ?? 'default'),
                      name: String(item.name ?? 'Queue Job'),
                      error: String(item.error ?? ''),
                      failedAt: String(item.failed_at ?? ''),
                  }))
                : [],
        },
        timeline: {
            serversCreatedLast7Days:
                data.timeline?.servers_created_last_7_days ?? [],
        },
        impersonation: {
            ownerImpersonating:
                data.impersonation?.owner_impersonating ?? false,
        },
    }
}

export default getResellerOverview
