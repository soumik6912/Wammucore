import http from '@/api/http'

export interface ResellerStatisticsResponse {
    aggregate: {
        servers: number
        customers: number
        orders: number
        openAlerts: number
        cpuTotal: number
        memoryMbTotal: number
        diskGbTotal: number
        bandwidthUsedMbTotal: number
        avgCpuPerServer: number
        avgMemoryMbPerServer: number
        avgDiskGbPerServer: number
        avgBandwidthMbPerServer: number
    }
    capacity: {
        used: {
            ramMb: number
            cpuCores: number
            diskGb: number
            vms: number
        }
        max: {
            ramMb: number
            cpuCores: number
            diskGb: number
            vms: number
        }
        percentages: {
            ram: number
            cpu: number
            disk: number
            vms: number
        }
    }
    trends: {
        windowDays: number
        createdCurrentWindow: number
        createdPreviousWindow: number
        createdChangePercent: number
    }
    charts: {
        serverGrowth: { day: string; total: number }[]
        serverGrowthCumulative: { day: string; total: number }[]
        customerGrowth: { day: string; total: number }[]
        orderVolume: { day: string; total: number }[]
        statusBreakdown: { status: string; total: number; percentage: number }[]
        alertSeverityBreakdown: { severity: string; total: number }[]
    }
}

const getResellerStatistics = async (): Promise<ResellerStatisticsResponse> => {
    const {
        data: { data },
    } = await http.get('/api/admin/reseller-panel/statistics')

    return {
        aggregate: {
            servers: data.aggregate.servers,
            customers: Number(data.aggregate.customers ?? 0),
            orders: Number(data.aggregate.orders ?? 0),
            openAlerts: Number(data.aggregate.open_alerts ?? 0),
            cpuTotal: data.aggregate.cpu_total,
            memoryMbTotal: data.aggregate.memory_mb_total,
            diskGbTotal: data.aggregate.disk_gb_total,
            bandwidthUsedMbTotal: data.aggregate.bandwidth_used_mb_total,
            avgCpuPerServer: Number(data.aggregate.avg_cpu_per_server ?? 0),
            avgMemoryMbPerServer: Number(
                data.aggregate.avg_memory_mb_per_server ?? 0
            ),
            avgDiskGbPerServer: Number(data.aggregate.avg_disk_gb_per_server ?? 0),
            avgBandwidthMbPerServer: Number(
                data.aggregate.avg_bandwidth_mb_per_server ?? 0
            ),
        },
        capacity: {
            used: {
                ramMb: Number(data.capacity?.used?.ram_mb ?? 0),
                cpuCores: Number(data.capacity?.used?.cpu_cores ?? 0),
                diskGb: Number(data.capacity?.used?.disk_gb ?? 0),
                vms: Number(data.capacity?.used?.vms ?? 0),
            },
            max: {
                ramMb: Number(data.capacity?.max?.ram_mb ?? 1),
                cpuCores: Number(data.capacity?.max?.cpu_cores ?? 1),
                diskGb: Number(data.capacity?.max?.disk_gb ?? 1),
                vms: Number(data.capacity?.max?.vms ?? 1),
            },
            percentages: {
                ram: Number(data.capacity?.percentages?.ram ?? 0),
                cpu: Number(data.capacity?.percentages?.cpu ?? 0),
                disk: Number(data.capacity?.percentages?.disk ?? 0),
                vms: Number(data.capacity?.percentages?.vms ?? 0),
            },
        },
        trends: {
            windowDays: Number(data.trends?.window_days ?? 30),
            createdCurrentWindow: Number(data.trends?.created_current_window ?? 0),
            createdPreviousWindow: Number(
                data.trends?.created_previous_window ?? 0
            ),
            createdChangePercent: Number(
                data.trends?.created_change_percent ?? 0
            ),
        },
        charts: {
            serverGrowth: data.charts.server_growth ?? [],
            serverGrowthCumulative: data.charts.server_growth_cumulative ?? [],
            customerGrowth: data.charts.customer_growth ?? [],
            orderVolume: data.charts.order_volume ?? [],
            statusBreakdown: (data.charts.status_breakdown ?? []).map(
                (item: any) => ({
                    status: String(item.status ?? 'unknown'),
                    total: Number(item.total ?? 0),
                    percentage: Number(item.percentage ?? 0),
                })
            ),
            alertSeverityBreakdown: (
                data.charts.alert_severity_breakdown ?? []
            ).map((item: any) => ({
                severity: String(item.severity ?? 'medium'),
                total: Number(item.total ?? 0),
            })),
        },
    }
}

export default getResellerStatistics
