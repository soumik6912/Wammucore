import http, { getPaginationSet, PaginatedResult } from '@/api/http'

export interface ResellerIpamAddress {
    id: number
    address: string
    type: 'ipv4' | 'ipv6' | string
    cidr: number
    gateway: string
    macAddress: string | null
    status:
        | 'connected_to_vps'
        | 'reserved_for_customer'
        | 'reserved_for_reseller'
        | 'available'
        | string
    pool: {
        id: number
        name: string
        resellerIpPriceEach: string
    }
    server: {
        id: number
        uuid: string
        name: string
        hostname: string
        status: string
    } | null
    user: {
        id: number
        name: string
        email: string
    } | null
}

export interface ResellerIpamResponse {
    reseller: {
        id: number
        displayName: string
    }
    summary: {
        totalIps: number
        connectedIps: number
        customerReservedIps: number
        resellerReservedIps: number
        availableIps: number
        ipv4Total: number
        ipv6Total: number
        poolsTotal: number
        assignedServers: number
    }
    items: PaginatedResult<ResellerIpamAddress>
}

const rawToAddress = (data: any): ResellerIpamAddress => ({
    id: Number(data.id),
    address: String(data.address ?? ''),
    type: data.type ?? 'ipv4',
    cidr: Number(data.cidr ?? 0),
    gateway: String(data.gateway ?? ''),
    macAddress: data.mac_address ?? null,
    status: data.status ?? 'available',
    pool: {
        id: Number(data.pool?.id ?? 0),
        name: String(data.pool?.name ?? 'Unassigned Pool'),
        resellerIpPriceEach: String(data.pool?.reseller_ip_price_each ?? '0.00'),
    },
    server: data.server
        ? {
              id: Number(data.server.id),
              uuid: String(data.server.uuid),
              name: String(data.server.name),
              hostname: String(data.server.hostname),
              status: String(data.server.status ?? ''),
          }
        : null,
    user: data.user
        ? {
              id: Number(data.user.id),
              name: String(data.user.name),
              email: String(data.user.email),
          }
        : null,
})

export const getResellerIpam = async ({
    page = 1,
    perPage = 25,
    query,
    type,
    status,
}: {
    page?: number
    perPage?: number
    query?: string
    type?: 'all' | 'ipv4' | 'ipv6'
    status?:
        | 'all'
        | 'connected_to_vps'
        | 'reserved_for_customer'
        | 'reserved_for_reseller'
        | 'available'
}): Promise<ResellerIpamResponse> => {
    const {
        data: { data },
    } = await http.get('/api/admin/reseller-panel/ipam', {
        params: {
            page,
            per_page: perPage,
            query: query || undefined,
            type: type || undefined,
            status: status || undefined,
        },
    })

    const rawItems = (data.items ?? []).map(rawToAddress)

    return {
        reseller: {
            id: Number(data.reseller?.id ?? 0),
            displayName: String(data.reseller?.display_name ?? 'Reseller'),
        },
        summary: {
            totalIps: Number(data.summary?.total_ips ?? 0),
            connectedIps: Number(data.summary?.connected_ips ?? 0),
            customerReservedIps: Number(data.summary?.customer_reserved_ips ?? 0),
            resellerReservedIps: Number(data.summary?.reseller_reserved_ips ?? 0),
            availableIps: Number(data.summary?.available_ips ?? 0),
            ipv4Total: Number(data.summary?.ipv4_total ?? 0),
            ipv6Total: Number(data.summary?.ipv6_total ?? 0),
            poolsTotal: Number(data.summary?.pools_total ?? 0),
            assignedServers: Number(data.summary?.assigned_servers ?? 0),
        },
        items: {
            items: rawItems,
            pagination: getPaginationSet(data.meta?.pagination),
        },
    }
}
