import http, { getPaginationSet, PaginatedResult } from '@/api/http'

export interface ResellerPanelUser {
    id: number
    name: string
    email: string
    supportPin: string | null
    mustChangePassword: boolean
    isDisabled: boolean
    serversCount: number
    createdAt: string | null
}

const rawToUser = (data: any): ResellerPanelUser => ({
    id: data.id,
    name: data.name,
    email: data.email,
    supportPin: data.support_pin ?? null,
    mustChangePassword: Boolean(data.must_change_password),
    isDisabled: Boolean(data.is_disabled),
    serversCount: data.servers_count ?? 0,
    createdAt: data.created_at ?? null,
})

export const getResellerPanelUsers = async ({
    page = 1,
    perPage = 50,
    query,
    isDisabled,
}: {
    page?: number
    perPage?: number
    query?: string
    isDisabled?: boolean
}): Promise<PaginatedResult<ResellerPanelUser>> => {
    const { data } = await http.get('/api/admin/reseller-panel/users', {
        params: {
            page,
            per_page: perPage,
            query: query || undefined,
            is_disabled:
                typeof isDisabled === 'boolean' ? Number(isDisabled) : undefined,
        },
    })

    return {
        items: (data.data ?? []).map(rawToUser),
        pagination: getPaginationSet(data.meta.pagination),
    }
}

export const createResellerPanelUser = async (payload: {
    name: string
    email: string
    password?: string
    autoGeneratePassword?: boolean
    supportPin?: string | null
    mustChangePassword?: boolean
}): Promise<{ user: ResellerPanelUser; generatedPassword: string | null }> => {
    const {
        data: { data, generated_password },
    } = await http.post('/api/admin/reseller-panel/users', {
        name: payload.name,
        email: payload.email,
        password: payload.password ?? null,
        auto_generate_password: payload.autoGeneratePassword ?? true,
        support_pin: payload.supportPin ?? null,
        must_change_password: payload.mustChangePassword ?? true,
    })

    return {
        user: rawToUser(data),
        generatedPassword: generated_password ?? null,
    }
}

export const updateResellerPanelUser = async (
    userId: number,
    payload: {
        name: string
        email: string
        supportPin?: string | null
        mustChangePassword: boolean
        isDisabled: boolean
    }
): Promise<ResellerPanelUser> => {
    const {
        data: { data },
    } = await http.put(`/api/admin/reseller-panel/users/${userId}`, {
        name: payload.name,
        email: payload.email,
        support_pin: payload.supportPin ?? null,
        must_change_password: payload.mustChangePassword,
        is_disabled: payload.isDisabled,
    })

    return rawToUser(data)
}

export const resetResellerPanelUserPassword = async (
    userId: number,
    payload: {
        password?: string
        autoGeneratePassword?: boolean
        mustChangePassword?: boolean
    }
): Promise<{ user: ResellerPanelUser; generatedPassword: string | null }> => {
    const {
        data: { data, generated_password },
    } = await http.post(`/api/admin/reseller-panel/users/${userId}/reset-password`, {
        password: payload.password ?? null,
        auto_generate_password: payload.autoGeneratePassword ?? true,
        must_change_password: payload.mustChangePassword ?? true,
    })

    return {
        user: rawToUser(data),
        generatedPassword: generated_password ?? null,
    }
}

export const deleteResellerPanelUser = async (userId: number): Promise<void> => {
    await http.delete(`/api/admin/reseller-panel/users/${userId}`)
}

export const getResellerPanelUserServices = async (
    userId: number
): Promise<any[]> => {
    const {
        data: { data },
    } = await http.get(`/api/admin/reseller-panel/users/${userId}/services`)

    return data.services ?? []
}
