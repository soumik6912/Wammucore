import http from '@/api/http'

export interface ResellerSettings {
    id: number
    displayName: string
    logoUrl: string | null
    faviconUrl: string | null
    loadingLogoUrl: string | null
    status: string
    supportUrl: string | null
    billingUrl: string | null
    tosUrl: string | null
    privacyUrl: string | null
    footerText: string | null
    footerUrl: string | null
    upgradeButtonEnabled: boolean
    upgradeUrlTemplate: string | null
    primaryColor: string | null
    secondaryColor: string | null
    accentColor: string | null
    themeKey: string | null
    customNameservers: string[]
    customCss: string | null
    oauth: {
        githubClientId: string | null
        githubClientSecretSet: boolean
        discordClientId: string | null
        discordClientSecretSet: boolean
    }
    smtp: {
        enabled: boolean
        host: string | null
        port: number | null
        encryption: string | null
        username: string | null
        passwordSet: boolean
        fromEmail: string | null
        fromName: string | null
        replyToEmail: string | null
    }
    domains: Array<{
        id: number
        hostname: string
        purpose: string
        isPrimary: boolean
        isWildcard: boolean
        dnsStatus: string
        sslStatus: string
        routingStatus: string
        cnameTarget: string
        verificationHost: string
        verificationToken: string | null
        verificationValue: string | null
        probeHostname: string
        verifiedAt: string | null
        verificationRequestedAt: string | null
        lastCheckedAt: string | null
        ownershipVerifiedAt: string | null
        sslProvisionedAt: string | null
        activatedAt: string | null
        lastError: string | null
        edgeGatewayHost: string
    }>
    domainMeta: {
        edgeGatewayHost: string
        verificationPrefix: string
    }
    featureFlags: Record<string, boolean>
    allowSubResellers: boolean
    impersonation: {
        ownerImpersonating: boolean
    }
}

export interface ResellerDomainVerificationResult {
    hostname: string
    probeHostname: string
    edgeGatewayHost: string
    cloudflareDetected: boolean
    directCnameVerified: boolean
    ownershipVerified: boolean
    dnsStatus: string
    sslStatus: string
    routingStatus: string
    verifiedAt: string | null
    lastCheckedAt: string | null
    passed: boolean
    errors: string[]
    instructions?: {
        edge_gateway_host?: string
        cname_host?: string
        cname_target?: string
        ownership_host?: string
        ownership_value?: string
        probe_hostname?: string
        wildcard?: boolean
    } | null
}

export interface UpdateResellerSettingsPayload {
    displayName: string
    logoUrl?: string | null
    faviconUrl?: string | null
    loadingLogoUrl?: string | null
    supportUrl?: string | null
    billingUrl?: string | null
    tosUrl?: string | null
    privacyUrl?: string | null
    footerText?: string | null
    footerUrl?: string | null
    upgradeButtonEnabled?: boolean
    upgradeUrlTemplate?: string | null
    primaryColor?: string | null
    secondaryColor?: string | null
    accentColor?: string | null
    themeKey?: string | null
    customNameservers?: string[]
    customCss?: string | null
    oauthGithubClientId?: string | null
    oauthGithubClientSecret?: string | null
    oauthDiscordClientId?: string | null
    oauthDiscordClientSecret?: string | null
    smtp?: {
        enabled: boolean
        host?: string | null
        port?: number | null
        encryption?: string | null
        username?: string | null
        password?: string | null
        fromEmail?: string | null
        fromName?: string | null
        replyToEmail?: string | null
    }
    featureFlags: Record<string, boolean>
    allowSubResellers?: boolean
}

const rawToDomain = (domain: any): ResellerSettings['domains'][number] => {
    const parsedId = Number(domain.id)

    return {
        id: Number.isFinite(parsedId) ? parsedId : -1,
        hostname: String(domain.hostname ?? domain.domain ?? ''),
        purpose: String(domain.purpose ?? 'panel'),
        isPrimary: Boolean(domain.is_primary),
        isWildcard: Boolean(domain.is_wildcard),
        dnsStatus: String(domain.dns_status ?? 'pending'),
        sslStatus: String(domain.ssl_status ?? 'pending'),
        routingStatus: String(domain.routing_status ?? 'pending'),
        cnameTarget: String(
            domain.cname_target ?? domain.edge_gateway_host ?? 'edge.wammuhost.com'
        ),
        verificationHost: String(domain.verification_host ?? ''),
        verificationToken:
            typeof domain.verification_token === 'string'
                ? domain.verification_token
                : null,
        verificationValue:
            typeof domain.verification_value === 'string'
                ? domain.verification_value
                : null,
        probeHostname: String(domain.probe_hostname ?? domain.hostname ?? ''),
        verifiedAt: domain.verified_at ?? null,
        verificationRequestedAt: domain.verification_requested_at ?? null,
        lastCheckedAt: domain.last_checked_at ?? null,
        ownershipVerifiedAt: domain.ownership_verified_at ?? null,
        sslProvisionedAt: domain.ssl_provisioned_at ?? null,
        activatedAt: domain.activated_at ?? null,
        lastError: domain.last_error ?? null,
        edgeGatewayHost: String(
            domain.edge_gateway_host ?? 'edge.wammuhost.com'
        ),
    }
}

const rawToVerificationResult = (
    payload: any
): ResellerDomainVerificationResult => ({
    hostname: String(payload?.hostname ?? ''),
    probeHostname: String(payload?.probe_hostname ?? payload?.probeHostname ?? ''),
    edgeGatewayHost: String(
        payload?.edge_gateway_host ?? payload?.edgeGatewayHost ?? 'edge.wammuhost.com'
    ),
    cloudflareDetected: Boolean(
        payload?.cloudflare_detected ?? payload?.cloudflareDetected ?? false
    ),
    directCnameVerified: Boolean(
        payload?.direct_cname_verified ?? payload?.directCnameVerified ?? false
    ),
    ownershipVerified: Boolean(
        payload?.ownership_verified ?? payload?.ownershipVerified ?? false
    ),
    dnsStatus: String(payload?.dns_status ?? payload?.dnsStatus ?? 'pending'),
    sslStatus: String(payload?.ssl_status ?? payload?.sslStatus ?? 'pending'),
    routingStatus: String(
        payload?.routing_status ?? payload?.routingStatus ?? 'pending'
    ),
    verifiedAt: payload?.verified_at ?? payload?.verifiedAt ?? null,
    lastCheckedAt: payload?.last_checked_at ?? payload?.lastCheckedAt ?? null,
    passed: Boolean(payload?.passed ?? false),
    errors: Array.isArray(payload?.errors) ? payload.errors : [],
    instructions: payload?.instructions ?? null,
})

const rawToSettings = (data: any): ResellerSettings => ({
    id: data.id,
    displayName: data.display_name,
    logoUrl: data.logo_url ?? null,
    faviconUrl: data.favicon_url ?? null,
    loadingLogoUrl: data.loading_logo_url ?? null,
    status: data.status,
    supportUrl: data.support_url ?? null,
    billingUrl: data.billing_url ?? null,
    tosUrl: data.tos_url ?? null,
    privacyUrl: data.privacy_url ?? null,
    footerText: data.footer_text ?? data.display_name ?? null,
    footerUrl: data.footer_url ?? data.support_url ?? null,
    upgradeButtonEnabled: Boolean(data.upgrade_button_enabled ?? true),
    upgradeUrlTemplate: data.upgrade_url_template ?? null,
    primaryColor: data.primary_color ?? null,
    secondaryColor: data.secondary_color ?? null,
    accentColor: data.accent_color ?? null,
    themeKey: data.theme_key ?? 'wammuhost',
    customNameservers: Array.isArray(data.custom_nameservers)
        ? data.custom_nameservers.map((value: any) => String(value)).filter(Boolean)
        : [],
    customCss: data.custom_css ?? null,
    oauth: {
        githubClientId: data.oauth.github_client_id ?? null,
        githubClientSecretSet: Boolean(data.oauth.github_client_secret_set),
        discordClientId: data.oauth.discord_client_id ?? null,
        discordClientSecretSet: Boolean(data.oauth.discord_client_secret_set),
    },
    smtp: {
        enabled: Boolean(data.smtp?.enabled ?? false),
        host: data.smtp?.host ?? null,
        port:
            typeof data.smtp?.port === 'number'
                ? data.smtp.port
                : data.smtp?.port
                  ? Number(data.smtp.port)
                  : null,
        encryption: data.smtp?.encryption ?? null,
        username: data.smtp?.username ?? null,
        passwordSet: Boolean(data.smtp?.password_set),
        fromEmail: data.smtp?.from_email ?? null,
        fromName: data.smtp?.from_name ?? null,
        replyToEmail: data.smtp?.reply_to_email ?? null,
    },
    domains: (data.domains ?? []).map(rawToDomain),
    domainMeta: {
        edgeGatewayHost: String(
            data.domain_meta?.edge_gateway_host ?? 'edge.wammuhost.com'
        ),
        verificationPrefix: String(
            data.domain_meta?.verification_prefix ?? '_wammuhost-verify'
        ),
    },
    featureFlags: data.feature_flags ?? {},
    allowSubResellers: Boolean(data.allow_sub_resellers),
    impersonation: {
        ownerImpersonating: Boolean(
            data.impersonation?.owner_impersonating ?? false
        ),
    },
})

export const getResellerSettings = async (): Promise<ResellerSettings> => {
    const {
        data: { data },
    } = await http.get('/api/admin/reseller-panel/settings')

    return rawToSettings(data)
}

export const updateResellerSettings = async (
    payload: UpdateResellerSettingsPayload
): Promise<ResellerSettings> => {
    const {
        data: { data },
    } = await http.patch('/api/admin/reseller-panel/settings', {
        display_name: payload.displayName,
        logo_url: payload.logoUrl ?? null,
        favicon_url: payload.faviconUrl ?? null,
        loading_logo_url: payload.loadingLogoUrl ?? null,
        support_url: payload.supportUrl ?? null,
        billing_url: payload.billingUrl ?? null,
        tos_url: payload.tosUrl ?? null,
        privacy_url: payload.privacyUrl ?? null,
        footer_text: payload.footerText ?? null,
        footer_url: payload.footerUrl ?? null,
        upgrade_button_enabled: payload.upgradeButtonEnabled ?? true,
        upgrade_url_template: payload.upgradeUrlTemplate ?? null,
        primary_color: payload.primaryColor ?? null,
        secondary_color: payload.secondaryColor ?? null,
        accent_color: payload.accentColor ?? null,
        theme_key: payload.themeKey ?? null,
        custom_nameservers: payload.customNameservers ?? [],
        custom_css: payload.customCss ?? null,
        oauth_github_client_id: payload.oauthGithubClientId ?? null,
        oauth_github_client_secret: payload.oauthGithubClientSecret ?? null,
        oauth_discord_client_id: payload.oauthDiscordClientId ?? null,
        oauth_discord_client_secret: payload.oauthDiscordClientSecret ?? null,
        smtp: payload.smtp
            ? {
                  enabled: payload.smtp.enabled ?? false,
                  host: payload.smtp.host ?? null,
                  port: payload.smtp.port ?? null,
                  encryption: payload.smtp.encryption ?? null,
                  username: payload.smtp.username ?? null,
                  ...(typeof payload.smtp.password !== 'undefined'
                      ? { password: payload.smtp.password }
                      : {}),
                  from_email: payload.smtp.fromEmail ?? null,
                  from_name: payload.smtp.fromName ?? null,
                  reply_to_email: payload.smtp.replyToEmail ?? null,
              }
            : undefined,
        feature_flags: payload.featureFlags ?? {},
        allow_sub_resellers: payload.allowSubResellers ?? false,
    })

    return rawToSettings(data)
}

export const createResellerSettingsDomain = async (payload: {
    hostname: string
    isPrimary?: boolean
}): Promise<ResellerSettings> => {
    const {
        data: { data },
    } = await http.post('/api/admin/reseller-panel/settings/domains', {
        hostname: payload.hostname,
        is_primary: payload.isPrimary ?? false,
    })

    return rawToSettings(data)
}

export const updateResellerSettingsDomain = async (
    domainId: number,
    payload: { hostname: string; isPrimary?: boolean }
): Promise<ResellerSettings> => {
    const {
        data: { data },
    } = await http.put(`/api/admin/reseller-panel/settings/domains/${domainId}`, {
        hostname: payload.hostname,
        is_primary: payload.isPrimary ?? false,
    })

    return rawToSettings(data)
}

export const verifyResellerSettingsDomain = async (
    domainId: number
): Promise<{ settings: ResellerSettings; verification: ResellerDomainVerificationResult | null }> => {
    const {
        data: { data },
    } = await http.post(
        `/api/admin/reseller-panel/settings/domains/${domainId}/verify`
    )

    return {
        settings: rawToSettings(data.settings),
        verification: data.verification ? rawToVerificationResult(data.verification) : null,
    }
}

export const syncResellerSettingsDomains = async (): Promise<{
    settings: ResellerSettings
    results: ResellerDomainVerificationResult[]
}> => {
    const {
        data: { data },
    } = await http.post('/api/admin/reseller-panel/settings/domains/sync')

    return {
        settings: rawToSettings(data.settings),
        results: Array.isArray(data.results)
            ? data.results.map(rawToVerificationResult)
            : [],
    }
}

export const regenerateResellerSettingsDomainToken = async (
    domainId: number
): Promise<{ settings: ResellerSettings; domain: ResellerSettings['domains'][number] | null }> => {
    const {
        data: { data },
    } = await http.post(
        `/api/admin/reseller-panel/settings/domains/${domainId}/regenerate-token`
    )

    return {
        settings: rawToSettings(data.settings),
        domain: data.domain ? rawToDomain(data.domain) : null,
    }
}

export const deleteResellerSettingsDomain = async (
    domainId: number
): Promise<ResellerSettings> => {
    const {
        data: { data },
    } = await http.delete(`/api/admin/reseller-panel/settings/domains/${domainId}`)

    return rawToSettings(data)
}
