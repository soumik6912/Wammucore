import http from '@/api/http'

export interface ResellerWholesaleCatalogPlan {
    id: number
    uuid: string
    name: string
    slug: string
    category: string
    description: string | null
    cpuCores: number
    cpuLimit: number
    cpuUnits: number
    cpuSockets: number
    ramMb: number
    diskGb: number
    bandwidthGb: number | null
    defaultIpQuantity: number
    priceEach: string
    currency: string
}

export interface ResellerWholesaleIpPool {
    id: number
    name: string
    priceEach: string
    exclusiveResellerId: number | null
    inStock: number
    availableIpv4: number
    resellerClaimedIpv4: number
    attachedToVpsIpv4: number
    reservedForCustomerIpv4: number
}

export interface ResellerWholesaleCatalog {
    plans: ResellerWholesaleCatalogPlan[]
    ipPools: ResellerWholesaleIpPool[]
}

const rawPlan = (item: any): ResellerWholesaleCatalogPlan => ({
    id: Number(item.id ?? 0),
    uuid: String(item.uuid ?? ''),
    name: String(item.name ?? ''),
    slug: String(item.slug ?? ''),
    category: String(item.category ?? 'General'),
    description: item.description ?? null,
    cpuCores: Number(item.cpu_cores ?? 0),
    cpuLimit: Number(item.cpu_limit ?? 0),
    cpuUnits: Number(item.cpu_units ?? 1024),
    cpuSockets: Number(item.cpu_sockets ?? 1),
    ramMb: Number(item.ram_mb ?? 0),
    diskGb: Number(item.disk_gb ?? 0),
    bandwidthGb:
        item.bandwidth_gb === null || item.bandwidth_gb === undefined
            ? null
            : Number(item.bandwidth_gb),
    defaultIpQuantity: Number(item.default_ip_quantity ?? 0),
    priceEach: String(item.price_each ?? '0.00'),
    currency: String(item.currency ?? 'INR'),
})

const rawIpPool = (item: any): ResellerWholesaleIpPool => ({
    id: Number(item.id ?? 0),
    name: String(item.name ?? ''),
    priceEach: String(item.price_each ?? '0.00'),
    exclusiveResellerId:
        item.exclusive_reseller_id === null ||
        item.exclusive_reseller_id === undefined
            ? null
            : Number(item.exclusive_reseller_id),
    inStock: Number(item.in_stock ?? 0),
    availableIpv4: Number(item.available_ipv4 ?? 0),
    resellerClaimedIpv4: Number(item.reseller_claimed_ipv4 ?? 0),
    attachedToVpsIpv4: Number(item.attached_to_vps_ipv4 ?? 0),
    reservedForCustomerIpv4: Number(item.reserved_for_customer_ipv4 ?? 0),
})

export const getResellerWholesaleCatalog =
    async (): Promise<ResellerWholesaleCatalog> => {
        const {
            data: { data },
        } = await http.get('/api/admin/reseller-panel/resources/catalog')

        return {
            plans: Array.isArray(data?.plans) ? data.plans.map(rawPlan) : [],
            ipPools: Array.isArray(data?.ip_pools)
                ? data.ip_pools.map(rawIpPool)
                : [],
        }
    }
