import http, { getPaginationSet, PaginatedResult } from '@/api/http'

export interface ResellerAlert {
    id: number
    type: string
    severity: string
    title: string
    message: string | null
    status: string
    server: {
        id: number
        uuid: string
        name: string
        customerEmail: string
        ips: string[]
    } | null
    createdAt: string | null
    resolvedAt: string | null
}

export interface ResellerAlertsResponse extends PaginatedResult<ResellerAlert> {
    summary: {
        countsBySeverity: Record<string, number>
        countsByStatus: Record<string, number>
    }
}

const rawToAlert = (data: any): ResellerAlert => ({
    id: Number(data.id ?? 0),
    type: String(data.type ?? ''),
    severity: String(data.severity ?? 'medium'),
    title: String(data.title ?? ''),
    message: data.message ?? null,
    status: String(data.status ?? 'open'),
    server: data.server
        ? {
              id: Number(data.server.id ?? 0),
              uuid: String(data.server.uuid ?? ''),
              name: String(data.server.name ?? ''),
              customerEmail: String(data.server.customer_email ?? '-'),
              ips: Array.isArray(data.server.ips)
                  ? data.server.ips.map((value: any) => String(value))
                  : [],
          }
        : null,
    createdAt: data.created_at ?? null,
    resolvedAt: data.resolved_at ?? null,
})

export const getResellerAlerts = async ({
    page = 1,
    perPage = 25,
    query,
    status,
    severity,
}: {
    page?: number
    perPage?: number
    query?: string
    status?: string
    severity?: string
}): Promise<ResellerAlertsResponse> => {
    const { data } = await http.get('/api/admin/reseller-panel/alerts', {
        params: {
            page,
            per_page: perPage,
            query: query || undefined,
            status: status || undefined,
            severity: severity || undefined,
        },
    })

    return {
        items: (data.data ?? []).map(rawToAlert),
        pagination: getPaginationSet(data.meta.pagination),
        summary: {
            countsBySeverity: data.meta?.summary?.counts_by_severity ?? {},
            countsByStatus: data.meta?.summary?.counts_by_status ?? {},
        },
    }
}
