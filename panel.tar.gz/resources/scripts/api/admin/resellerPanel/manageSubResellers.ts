import http from '@/api/http'

export interface SubReseller {
    id: number
    displayName: string
    domain: string | null
    backendDomain: string | null
    liveDataDomain: string | null
    novncDomain: string | null
    cdnDomain: string | null
    parentResellerId: number | null
    status: string
    maxRamMb: number
    maxCpuCores: number
    maxDiskGb: number
    maxVms: number
    usedRamMb: number
    usedCpuCores: number
    usedDiskGb: number
    usedVms: number
    createdAt: string | null
}

const rawToSubReseller = (data: any): SubReseller => ({
    id: data.id,
    displayName: data.display_name,
    domain: data.domain ?? null,
    backendDomain: data.backend_domain ?? null,
    liveDataDomain: data.live_data_domain ?? null,
    novncDomain: data.novnc_domain ?? null,
    cdnDomain: data.cdn_domain ?? null,
    parentResellerId: data.parent_reseller_id ?? null,
    status: data.status,
    maxRamMb: data.max_ram_mb,
    maxCpuCores: data.max_cpu_cores,
    maxDiskGb: data.max_disk_gb,
    maxVms: data.max_vms,
    usedRamMb: data.used_ram_mb,
    usedCpuCores: data.used_cpu_cores,
    usedDiskGb: data.used_disk_gb,
    usedVms: data.used_vms,
    createdAt: data.created_at ?? null,
})

export const getSubResellers = async (): Promise<SubReseller[]> => {
    const {
        data: { data },
    } = await http.get('/api/admin/reseller-panel/sub-resellers')

    return (data ?? []).map(rawToSubReseller)
}

export const createSubReseller = async (payload: {
    displayName: string
    logoUrl?: string | null
    domain: string
    backendDomain?: string | null
    liveDataDomain?: string | null
    novncDomain?: string | null
    cdnDomain?: string | null
    status?: string
    maxRamMb: number
    maxCpuCores: number
    maxDiskGb: number
    maxVms: number
    supportUrl?: string | null
    tosUrl?: string | null
    privacyUrl?: string | null
}): Promise<SubReseller> => {
    const {
        data: { data },
    } = await http.post('/api/admin/reseller-panel/sub-resellers', {
        display_name: payload.displayName,
        logo_url: payload.logoUrl ?? null,
        domain: payload.domain,
        backend_domain: payload.backendDomain ?? null,
        live_data_domain: payload.liveDataDomain ?? null,
        novnc_domain: payload.novncDomain ?? null,
        cdn_domain: payload.cdnDomain ?? null,
        status: payload.status ?? 'pending',
        max_ram_mb: payload.maxRamMb,
        max_cpu_cores: payload.maxCpuCores,
        max_disk_gb: payload.maxDiskGb,
        max_vms: payload.maxVms,
        support_url: payload.supportUrl ?? null,
        tos_url: payload.tosUrl ?? null,
        privacy_url: payload.privacyUrl ?? null,
    })

    return rawToSubReseller(data)
}

export const updateSubReseller = async (
    subResellerId: number,
    payload: {
        displayName: string
        status: string
        maxRamMb: number
        maxCpuCores: number
        maxDiskGb: number
        maxVms: number
        backendDomain?: string | null
        liveDataDomain?: string | null
        novncDomain?: string | null
        cdnDomain?: string | null
    }
): Promise<SubReseller> => {
    const {
        data: { data },
    } = await http.put(
        `/api/admin/reseller-panel/sub-resellers/${subResellerId}`,
        {
            display_name: payload.displayName,
            status: payload.status,
            max_ram_mb: payload.maxRamMb,
            max_cpu_cores: payload.maxCpuCores,
            max_disk_gb: payload.maxDiskGb,
            max_vms: payload.maxVms,
            backend_domain: payload.backendDomain ?? null,
            live_data_domain: payload.liveDataDomain ?? null,
            novnc_domain: payload.novncDomain ?? null,
            cdn_domain: payload.cdnDomain ?? null,
        }
    )

    return rawToSubReseller(data)
}

export const deleteSubReseller = async (
    subResellerId: number
): Promise<void> => {
    await http.delete(`/api/admin/reseller-panel/sub-resellers/${subResellerId}`)
}
