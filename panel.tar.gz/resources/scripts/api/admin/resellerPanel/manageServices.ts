import http, { getPaginationSet, PaginatedResult } from '@/api/http'
import {
    mapPowerActionResponse,
    PowerActionResponse,
} from '@/api/server/resourceGuard'

export interface ResellerPanelService {
    id: string
    name: string
    hostname: string
    status: string | null
    vmid: number
    user: {
        id: number
        name: string
        email: string
    } | null
    node: {
        id: number
        name: string
    } | null
    addresses: Array<{
        id: number
        type: string
        address: string
    }>
}

const rawToService = (data: any): ResellerPanelService => ({
    id: data.id,
    name: data.name,
    hostname: data.hostname,
    status: data.status ?? null,
    vmid: data.vmid,
    user: data.user
        ? {
              id: data.user.id,
              name: data.user.name,
              email: data.user.email,
          }
        : null,
    node: data.node
        ? {
              id: data.node.id,
              name: data.node.name,
          }
        : null,
    addresses: (data.addresses ?? []).map((address: any) => ({
        id: address.id,
        type: address.type,
        address: address.address,
    })),
})

export const getResellerPanelServices = async ({
    page = 1,
    perPage = 50,
    query,
    userId,
}: {
    page?: number
    perPage?: number
    query?: string
    userId?: number
}): Promise<PaginatedResult<ResellerPanelService>> => {
    const { data } = await http.get('/api/admin/reseller-panel/services', {
        params: {
            page,
            per_page: perPage,
            query: query || undefined,
            user_id: userId ?? undefined,
        },
    })

    return {
        items: (data.data ?? []).map(rawToService),
        pagination: getPaginationSet(data.meta.pagination),
    }
}

export const servicePowerAction = async (
    serverId: string,
    action: 'start' | 'stop' | 'restart'
): Promise<PowerActionResponse> => {
    const { data } = await http.post(
        `/api/admin/reseller-panel/services/${serverId}/power/${action}`
    )

    return mapPowerActionResponse(data?.data || {})
}

export const suspendResellerService = async (serverId: string): Promise<void> => {
    await http.post(`/api/admin/reseller-panel/services/${serverId}/suspend`)
}

export const unsuspendResellerService = async (
    serverId: string
): Promise<void> => {
    await http.post(`/api/admin/reseller-panel/services/${serverId}/unsuspend`)
}

export const reassignResellerService = async (
    serverId: string,
    userId: number
): Promise<ResellerPanelService> => {
    const {
        data: { data },
    } = await http.post(`/api/admin/reseller-panel/services/${serverId}/reassign`, {
        user_id: userId,
    })

    return rawToService(data)
}

export const reinstallResellerService = async (
    serverId: string,
    payload: {
        templateUuid: string
        accountPassword: string
        startOnCompletion?: boolean
    }
): Promise<void> => {
    await http.post(`/api/admin/reseller-panel/services/${serverId}/reinstall`, {
        template_uuid: payload.templateUuid,
        account_password: payload.accountPassword,
        start_on_completion: payload.startOnCompletion ?? false,
    })
}

export const getResellerServiceVnc = async (
    serverId: string
): Promise<{
    isTlsEnabled: boolean
    fqdn: string
    port: number
    token: string
}> => {
    const {
        data: { data },
    } = await http.post(`/api/admin/reseller-panel/services/${serverId}/vnc`)

    return {
        isTlsEnabled: Boolean(data.is_tls_enabled),
        fqdn: data.fqdn,
        port: data.port,
        token: data.token,
    }
}
