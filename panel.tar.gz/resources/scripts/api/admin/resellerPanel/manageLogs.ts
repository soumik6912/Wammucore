import http from '@/api/http'

export interface ResellerAuditItem {
    id: number
    actorType: string
    actorLabel: string
    area: string
    actionLabel: string
    targetLabel: string
    description: string | null
    statusCode: number | null
    statusTone: 'success' | 'warning' | 'danger' | 'neutral'
    requestMethod: string | null
    path: string | null
    ipAddress: string | null
    userAgent: string | null
    changedFields: string[]
    errorMessage: string | null
    internalDetailsHidden: boolean
    createdAt: string | null
}

export interface ResellerLoginLogItem {
    id: number
    email: string | null
    role: string
    event: string
    eventLabel: string
    ipAddress: string | null
    locationLabel: string | null
    userAgent: string | null
    isSuspicious: boolean
    reason: string | null
    createdAt: string | null
}

export interface ResellerLogsResponse {
    metrics: {
        actionsToday: number
        failedActions48h: number
        adminSignins48h: number
        suspiciousSignins48h: number
    }
    auditItems: ResellerAuditItem[]
    loginItems: ResellerLoginLogItem[]
}

export const getResellerLogs = async (): Promise<ResellerLogsResponse> => {
    const {
        data: { data },
    } = await http.get('/api/admin/reseller-panel/logs')

    return {
        metrics: {
            actionsToday: Number(data.metrics?.actions_today ?? 0),
            failedActions48h: Number(data.metrics?.failed_actions_48h ?? 0),
            adminSignins48h: Number(data.metrics?.admin_signins_48h ?? 0),
            suspiciousSignins48h: Number(
                data.metrics?.suspicious_signins_48h ?? 0
            ),
        },
        auditItems: Array.isArray(data.audit_items)
            ? data.audit_items.map((item: any) => ({
                  id: Number(item.id ?? 0),
                  actorType: String(item.actor_type ?? 'reseller_admin'),
                  actorLabel: String(item.actor_label ?? 'Reseller admin'),
                  area: String(item.area ?? 'Reseller panel'),
                  actionLabel: String(item.action_label ?? 'Panel action'),
                  targetLabel: String(item.target_label ?? 'Platform'),
                  description: item.description ?? null,
                  statusCode:
                      item.status_code === null || item.status_code === undefined
                          ? null
                          : Number(item.status_code),
                  statusTone: item.status_tone ?? 'neutral',
                  requestMethod: item.request_method ?? null,
                  path: item.path ?? null,
                  ipAddress: item.ip_address ?? null,
                  userAgent: item.user_agent ?? null,
                  changedFields: Array.isArray(item.changed_fields)
                      ? item.changed_fields.map((field: any) => String(field))
                      : [],
                  errorMessage: item.error_message ?? null,
                  internalDetailsHidden: Boolean(
                      item.internal_details_hidden ?? true
                  ),
                  createdAt: item.created_at ?? null,
              }))
            : [],
        loginItems: Array.isArray(data.login_items)
            ? data.login_items.map((item: any) => ({
                  id: Number(item.id ?? 0),
                  email: item.email ?? null,
                  role: String(item.role ?? 'reseller_admin'),
                  event: String(item.event ?? ''),
                  eventLabel: String(item.event_label ?? item.event ?? ''),
                  ipAddress: item.ip_address ?? null,
                  locationLabel: item.location_label ?? null,
                  userAgent: item.user_agent ?? null,
                  isSuspicious: Boolean(item.is_suspicious),
                  reason: item.reason ?? null,
                  createdAt: item.created_at ?? null,
              }))
            : [],
    }
}
