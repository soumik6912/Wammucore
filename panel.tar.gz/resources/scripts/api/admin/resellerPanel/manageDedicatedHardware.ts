import http from '@/api/http'

export interface ResellerDedicatedHardware {
    id: number
    uuid: string
    name: string
    status: 'pending' | 'ready' | 'active' | 'suspended' | 'retired'
    providerOrderRef: string | null
    paymenterServiceId: string | null
    proxmoxHost: string
    proxmoxPort: number
    proxmoxUsername: string | null
    proxmoxPasswordSet: boolean
    publicNotes: string | null
    assignedAt: string | null
    configuredAt: string | null
    location: {
        id: number
        shortCode: string
        description: string | null
    } | null
    node: {
        id: number
        name: string
        cluster: string
        fqdn: string
        status: string
        provisioningEnabled: boolean
        maintenanceMode: boolean
    } | null
}

export interface ResellerDedicatedHardwareResponse {
    canAssign: boolean
    canManageDedicatedPlans: boolean
    warning: string | null
    reseller: {
        id: number
        displayName: string
        domain: string | null
    }
    items: ResellerDedicatedHardware[]
    dedicatedPlans: ResellerDedicatedHardwarePlan[]
}

export interface ResellerDedicatedHardwarePlan {
    id: string
    name: string
    slug: string
    description: string
    currency: string
    monthlyPrice: string
    setupFee: string
    cpuCores: number
    ramGb: number
    diskGb: number
    bandwidthTb: number
    sortOrder: number
    isActive: boolean
}

export interface AssignDedicatedHardwarePayload {
    name: string
    providerOrderRef?: string | null
    paymenterServiceId?: string | null
    proxmoxHost: string
    proxmoxPort: number
    proxmoxUsername?: string | null
    proxmoxPassword?: string | null
    status?: 'pending' | 'ready' | 'suspended'
    publicNotes?: string | null
    internalNotes?: string | null
}

export interface ConfigureDedicatedHardwarePayload {
    locationId?: number | null
    locationShortCode?: string | null
    locationDescription?: string | null
    nodeName: string
    cluster: string
    apiTokenId: string
    apiTokenSecret: string
    verifyTls: boolean
    memoryGb: number
    memoryOverallocate: number
    diskGb: number
    diskOverallocate: number
    vmStorage: string
    backupStorage: string
    isoStorage: string
    network: string
    provisioningEnabled: boolean
    maintenanceMode: boolean
    provisioningPriority: number
    provisioningMemoryThresholdPercent: number
    provisioningDiskThresholdPercent: number
    reinstallLimitPerWeek: number
}

const rawHardware = (item: any): ResellerDedicatedHardware => ({
    id: Number(item.id ?? 0),
    uuid: String(item.uuid ?? ''),
    name: String(item.name ?? ''),
    status: item.status ?? 'pending',
    providerOrderRef: item.provider_order_ref ?? null,
    paymenterServiceId: item.paymenter_service_id ?? null,
    proxmoxHost: String(item.proxmox_host ?? ''),
    proxmoxPort: Number(item.proxmox_port ?? 8006),
    proxmoxUsername: item.proxmox_username ?? null,
    proxmoxPasswordSet: Boolean(item.proxmox_password_set),
    publicNotes: item.public_notes ?? null,
    assignedAt: item.assigned_at ?? null,
    configuredAt: item.configured_at ?? null,
    location: item.location
        ? {
              id: Number(item.location.id ?? 0),
              shortCode: String(item.location.short_code ?? ''),
              description: item.location.description ?? null,
          }
        : null,
    node: item.node
        ? {
              id: Number(item.node.id ?? 0),
              name: String(item.node.name ?? ''),
              cluster: String(item.node.cluster ?? ''),
              fqdn: String(item.node.fqdn ?? ''),
              status: String(item.node.status ?? 'active'),
              provisioningEnabled: Boolean(
                  item.node.provisioning_enabled ?? true
              ),
              maintenanceMode: Boolean(item.node.maintenance_mode ?? false),
          }
        : null,
})

const rawDedicatedPlan = (item: any): ResellerDedicatedHardwarePlan => ({
    id: String(item.id ?? item.slug ?? ''),
    name: String(item.name ?? ''),
    slug: String(item.slug ?? ''),
    description: String(item.description ?? ''),
    currency: String(item.currency ?? 'USD'),
    monthlyPrice: String(item.monthly_price ?? '0.00'),
    setupFee: String(item.setup_fee ?? '0.00'),
    cpuCores: Number(item.cpu_cores ?? 0),
    ramGb: Number(item.ram_gb ?? 0),
    diskGb: Number(item.disk_gb ?? 0),
    bandwidthTb: Number(item.bandwidth_tb ?? 0),
    sortOrder: Number(item.sort_order ?? 0),
    isActive: Boolean(item.is_active ?? true),
})

const snakeDedicatedPlan = (plan: ResellerDedicatedHardwarePlan) => ({
    id: plan.id,
    name: plan.name,
    slug: plan.slug,
    description: plan.description,
    currency: plan.currency,
    monthly_price: plan.monthlyPrice,
    setup_fee: plan.setupFee,
    cpu_cores: plan.cpuCores,
    ram_gb: plan.ramGb,
    disk_gb: plan.diskGb,
    bandwidth_tb: plan.bandwidthTb,
    sort_order: plan.sortOrder,
    is_active: plan.isActive,
})

const snakeAssignPayload = (payload: AssignDedicatedHardwarePayload) => ({
    name: payload.name,
    provider_order_ref: payload.providerOrderRef,
    paymenter_service_id: payload.paymenterServiceId,
    proxmox_host: payload.proxmoxHost,
    proxmox_port: payload.proxmoxPort,
    proxmox_username: payload.proxmoxUsername,
    proxmox_password: payload.proxmoxPassword,
    status: payload.status,
    public_notes: payload.publicNotes,
    internal_notes: payload.internalNotes,
})

const snakeConfigurePayload = (payload: ConfigureDedicatedHardwarePayload) => ({
    location_id: payload.locationId,
    location_short_code: payload.locationShortCode,
    location_description: payload.locationDescription,
    node_name: payload.nodeName,
    cluster: payload.cluster,
    api_token_id: payload.apiTokenId,
    api_token_secret: payload.apiTokenSecret,
    verify_tls: payload.verifyTls,
    memory_gb: payload.memoryGb,
    memory_overallocate: payload.memoryOverallocate,
    disk_gb: payload.diskGb,
    disk_overallocate: payload.diskOverallocate,
    vm_storage: payload.vmStorage,
    backup_storage: payload.backupStorage,
    iso_storage: payload.isoStorage,
    network: payload.network,
    provisioning_enabled: payload.provisioningEnabled,
    maintenance_mode: payload.maintenanceMode,
    provisioning_priority: payload.provisioningPriority,
    provisioning_memory_threshold_percent:
        payload.provisioningMemoryThresholdPercent,
    provisioning_disk_threshold_percent:
        payload.provisioningDiskThresholdPercent,
    reinstall_limit_per_week: payload.reinstallLimitPerWeek,
})

export const getResellerDedicatedHardware =
    async (): Promise<ResellerDedicatedHardwareResponse> => {
        const {
            data: { data },
        } = await http.get('/api/admin/reseller-panel/dedicated-hardware')

        return {
            canAssign: Boolean(data?.can_assign),
            canManageDedicatedPlans: Boolean(data?.can_manage_dedicated_plans),
            warning: data?.warning ?? null,
            reseller: {
                id: Number(data?.reseller?.id ?? 0),
                displayName: String(data?.reseller?.display_name ?? ''),
                domain: data?.reseller?.domain ?? null,
            },
            items: Array.isArray(data?.items)
                ? data.items.map(rawHardware)
                : [],
            dedicatedPlans: Array.isArray(data?.dedicated_plans)
                ? data.dedicated_plans.map(rawDedicatedPlan)
                : [],
        }
    }

export const updateResellerDedicatedHardwarePlans = async (
    plans: ResellerDedicatedHardwarePlan[]
): Promise<ResellerDedicatedHardwarePlan[]> => {
    const {
        data: { data },
    } = await http.patch('/api/admin/reseller-panel/dedicated-hardware/plans', {
        plans: plans.map(snakeDedicatedPlan),
    })

    return Array.isArray(data?.dedicated_plans)
        ? data.dedicated_plans.map(rawDedicatedPlan)
        : []
}

export const assignResellerDedicatedHardware = async (
    payload: AssignDedicatedHardwarePayload
): Promise<ResellerDedicatedHardware> => {
    const {
        data: { data },
    } = await http.post(
        '/api/admin/reseller-panel/dedicated-hardware',
        snakeAssignPayload(payload)
    )

    return rawHardware(data)
}

export const configureResellerDedicatedHardware = async (
    hardwareId: number,
    payload: ConfigureDedicatedHardwarePayload
): Promise<ResellerDedicatedHardware> => {
    const {
        data: { data },
    } = await http.post(
        `/api/admin/reseller-panel/dedicated-hardware/${hardwareId}/configure-node`,
        snakeConfigurePayload(payload)
    )

    return rawHardware(data)
}
