import { ServerInclude } from '@/api/admin/servers/getServers'
import { rawDataToUser } from '@/api/admin/users/getUsers'
import http, { WammuCoreRequestConfig } from '@/api/http'
import {
    ServerBuild as BaseServerBuild,
    rawDataToServerBuild,
} from '@/api/server/getServer'

export interface AdminServerBuild extends BaseServerBuild {
    userId: number
    nodeId: number
    vmid: number
}

export const rawDataToAdminServer = (data: any): AdminServerBuild => ({
    ...rawDataToServerBuild(data),
    userId: data.user_id,
    nodeId: data.node_id,
    vmid: data.vmid,
    user: data?.user?.data ? rawDataToUser(data.user.data) : undefined,
})

export const getServer = async (
    uuid: string,
    include?: ServerInclude[],
    options?: WammuCoreRequestConfig
): Promise<AdminServerBuild> => {
    const {
        data: { data },
    } = await http.get(`/api/admin/servers/${uuid}`, {
        params: {
            include: include?.join(','),
        },
        ...options,
    })

    return rawDataToAdminServer(data)
}
