import http from '@/api/http'
import {
    ConsoleCredentials,
    ConsoleType,
    rawDataToConsoleCredentials,
} from '@/api/server/createConsoleSession'

const createAdminConsoleSession = async (
    uuid: string,
    consoleType: ConsoleType = 'novnc'
): Promise<ConsoleCredentials> => {
    const {
        data: { data },
    } = await http.post(`/api/admin/servers/${uuid}/create-console-session`, {
        type: consoleType,
    })

    return rawDataToConsoleCredentials(data)
}

export default createAdminConsoleSession
