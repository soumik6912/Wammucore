import http from '@/api/http'

interface TransferServerResponse {
    serverId: string
    targetNodeId: number
    task: string
    transferring: boolean
}

const transferServer = async (
    serverUuid: string,
    targetNodeId: number,
    withLocalDisks = true
): Promise<TransferServerResponse> => {
    const {
        data: { data },
    } = await http.post(`/api/admin/servers/${serverUuid}/transfer`, {
        target_node_id: targetNodeId,
        with_local_disks: withLocalDisks,
    })

    return {
        serverId: data.server_id,
        targetNodeId: data.target_node_id,
        task: data.task,
        transferring: data.transferring,
    }
}

export default transferServer
