import { rawDataToAdminServer } from '@/api/admin/servers/getServer'
import http from '@/api/http'
import { EloquentStatus } from '@/api/server/types'

interface UpdateServerParameters {
    name?: string | null
    hostname?: string | null
    vmid?: number | null
    userId?: number | null
    billingServiceId?: string | null
    status?: EloquentStatus
}

const updateServer = async (
    serverUuid: string,
    { userId, billingServiceId, ...params }: UpdateServerParameters
) => {
    const {
        data: { data },
    } = await http.patch(`/api/admin/servers/${serverUuid}`, {
        user_id: userId,
        billing_service_id: billingServiceId,
        ...params,
    })

    return rawDataToAdminServer(data)
}

export default updateServer
