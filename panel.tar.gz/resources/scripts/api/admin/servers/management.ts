import http from '@/api/http'
import { SimplePowerAction } from '@/api/server/management'
import {
    mapPowerActionResponse,
    PowerActionResponse,
} from '@/api/server/resourceGuard'

export interface AdminManagementStatus {
    serverId: string
    status: string | null
    state: string
    liveUnavailable?: boolean
    liveUnavailableMessage?: string | null
    metrics: {
        cpuUsed: number
        memoryTotal: number
        memoryUsed: number
        uptime: number
    }
    availableActions: SimplePowerAction[]
}

export const getAdminManagementStatus = async (
    serverUuid: string
): Promise<AdminManagementStatus> => {
    const { data } = await http.get(`/api/admin/servers/${serverUuid}/management`)
    const payload = data?.data || {}
    const rawCpuUsed = Number(payload.metrics?.cpu_used ?? 0)
    const cpuUsed = rawCpuUsed > 1 ? rawCpuUsed : rawCpuUsed * 100
    const rawState = String(payload.state ?? '').trim().toLowerCase()
    const normalizedState =
        rawState === '' || rawState === 'unknown' ? 'loading' : rawState

    return {
        serverId: payload.server_id,
        status: payload.status,
        state: normalizedState,
        liveUnavailable: !!payload.live_unavailable,
        liveUnavailableMessage: payload.live_unavailable_message ?? null,
        metrics: {
            cpuUsed: Number.isFinite(cpuUsed) ? Math.max(0, Math.min(100, cpuUsed)) : 0,
            memoryTotal: payload.metrics?.memory_total ?? 0,
            memoryUsed: payload.metrics?.memory_used ?? 0,
            uptime: payload.metrics?.uptime ?? 0,
        },
        availableActions: payload.available_actions ?? [],
    }
}

export const sendAdminManagementAction = async (
    serverUuid: string,
    action: SimplePowerAction
): Promise<PowerActionResponse> => {
    const { data } = await http.post(
        `/api/admin/servers/${serverUuid}/management/${action}`
    )

    return mapPowerActionResponse(data?.data || {})
}
