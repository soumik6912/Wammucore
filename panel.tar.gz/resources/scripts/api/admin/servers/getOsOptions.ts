import http from '@/api/http'

export interface OsTemplateOption {
    uuid: string
    name: string
    isWindows: boolean
    osFamily: 'windows' | 'linux'
}

export interface OsTemplateGroup {
    uuid: string
    name: string
    templates: OsTemplateOption[]
}

const getOsOptions = async (serverUuid: string): Promise<OsTemplateGroup[]> => {
    const { data } = await http.get(`/api/admin/servers/${serverUuid}/settings/os-options`)
    const groups = data?.data || []

    return groups.map((group: any) => ({
        uuid: group.uuid,
        name: group.name,
        templates: (group.templates || []).map((template: any) => ({
            uuid: template.uuid,
            name: template.name,
            isWindows: !!template.is_windows,
            osFamily: template.os_family === 'windows' ? 'windows' : 'linux',
        })),
    }))
}

export default getOsOptions
