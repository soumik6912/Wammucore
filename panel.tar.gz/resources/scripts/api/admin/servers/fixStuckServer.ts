import http from '@/api/http'

export interface FixStuckResponse {
    serverId: string
    vmExists: boolean
    proxmoxState: string
    previousStatus: string | null
    newStatus: string | null
    statusUpdated: boolean
    lockCleared: boolean
    syncApplied: boolean
    checks: { key: string; ok: boolean; message: string }[]
    checkWarnings: string[]
    message: string
}

const fixStuckServer = async (serverUuid: string): Promise<FixStuckResponse> => {
    const {
        data: { data },
    } = await http.post(`/api/admin/servers/${serverUuid}/fix-stuck`)

    return {
        serverId: data.server_id,
        vmExists: !!data.vm_exists,
        proxmoxState: data.proxmox_state ?? 'unknown',
        previousStatus: data.previous_status ?? null,
        newStatus: data.new_status ?? null,
        statusUpdated: !!data.status_updated,
        lockCleared: !!data.lock_cleared,
        syncApplied: !!data.sync_applied,
        checks: Array.isArray(data.checks) ? data.checks : [],
        checkWarnings: Array.isArray(data.check_warnings) ? data.check_warnings : [],
        message: data.message ?? 'Recovery completed.',
    }
}

export default fixStuckServer
