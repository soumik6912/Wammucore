import http from '@/api/http'

export interface AdminServerActivityLogRow {
    id: number
    event: string
    description: string | null
    ip: string | null
    timestamp: string | null
    actorLabel: string | null
}

export interface AdminServerActivityLogsResponse {
    items: AdminServerActivityLogRow[]
    pagination: {
        total: number
        count: number
        perPage: number
        currentPage: number
        totalPages: number
    }
}

const getAdminServerActivityLogs = async (
    serverUuid: string,
    params?: {
        query?: string
        event?: string
        page?: number
        perPage?: number
    }
): Promise<AdminServerActivityLogsResponse> => {
    const { data } = await http.get(`/api/admin/servers/${serverUuid}/activity`, {
        params: {
            q: params?.query || undefined,
            event: params?.event || undefined,
            page: params?.page ?? 1,
            per_page: params?.perPage ?? 25,
        },
    })

    const rows = Array.isArray(data?.data?.items) ? data.data.items : []
    const pagination = data?.data?.meta || {}

    return {
        items: rows.map((item: any) => ({
            id: Number(item.id || 0),
            event: item.event || 'activity',
            description: item.description ?? null,
            ip: item.ip ?? null,
            timestamp: item.timestamp || null,
            actorLabel: item.actor?.label ?? null,
        })),
        pagination: {
            total: Number(pagination.total || 0),
            count: Number(pagination.count || rows.length),
            perPage: Number(pagination.per_page || params?.perPage || 25),
            currentPage: Number(pagination.current_page || params?.page || 1),
            totalPages: Number(pagination.total_pages || 1),
        },
    }
}

export default getAdminServerActivityLogs
