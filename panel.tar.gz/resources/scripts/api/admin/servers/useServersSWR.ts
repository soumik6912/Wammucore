import useSWR from 'swr'

import getServers, {
    QueryParams,
    ServerResponse,
} from '@/api/admin/servers/getServers'


const useServersSWR = ({
    page,
    nodeId,
    userId,
    addressPoolId,
    scope,
    query,
    ...params
}: QueryParams) => {
    return useSWR<ServerResponse>(
        ['admin:servers', page, query, nodeId, userId, addressPoolId, scope],
        () =>
            getServers({
                page,
                query,
                nodeId,
                userId,
                addressPoolId,
                scope,
                ...params,
            }, { showProgress: false }),
        {
            refreshInterval: 60000,
            revalidateOnFocus: false,
            refreshWhenHidden: false,
            refreshWhenOffline: false,
            dedupingInterval: 30000,
        }
    )
}

export default useServersSWR
