import { rawDataToAdminServer } from '@/api/admin/servers/getServer'
import http from '@/api/http'

interface UpdateServerBuildParameters {
    cpu: number
    cpuLimit: number
    cpuUnits: number
    cpuSockets: number
    memory: number
    swap: number
    disk: number
    addressIds: number[]
    snapshotLimit: number | null
    backupLimit: number | null
    bandwidthLimit: number | null
    networkRateLimit: number | null
    bandwidthUsage: number
}

const updateBuild = async (
    serverUuid: string,
    {
        addressIds,
        cpuLimit,
        cpuUnits,
        cpuSockets,
        snapshotLimit,
        backupLimit,
        bandwidthLimit,
        networkRateLimit,
        bandwidthUsage,
        ...params
    }: UpdateServerBuildParameters
) => {
    const {
        data: { data },
    } = await http.patch(`/api/admin/servers/${serverUuid}/settings/build`, {
        address_ids: addressIds,
        cpu_limit: cpuLimit,
        cpu_units: cpuUnits,
        cpu_sockets: cpuSockets,
        snapshot_limit: snapshotLimit,
        backup_limit: backupLimit,
        bandwidth_limit: bandwidthLimit,
        network_rate_limit: networkRateLimit,
        bandwidth_usage: bandwidthUsage,
        ...params,
    })

    return rawDataToAdminServer(data)
}

export default updateBuild
