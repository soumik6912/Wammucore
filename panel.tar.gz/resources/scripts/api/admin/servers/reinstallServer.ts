import http from '@/api/http'

interface ReinstallServerPayload {
    templateUuid: string
    accountPassword: string
    startOnCompletion: boolean
}

const reinstallServer = async (
    serverUuid: string,
    payload: ReinstallServerPayload
): Promise<void> => {
    await http.post(`/api/admin/servers/${serverUuid}/settings/reinstall`, {
        template_uuid: payload.templateUuid,
        account_password: payload.accountPassword,
        start_on_completion: payload.startOnCompletion,
    })
}

export default reinstallServer
