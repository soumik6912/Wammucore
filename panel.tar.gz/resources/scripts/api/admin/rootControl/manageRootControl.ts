import http from '@/api/http'

export interface RootControlMetricSnapshot {
    tenants: number
    platformAdmins: number
    users: number
    servers: number
    nodes: number
    openAdminAlerts: number
    criticalSecurityAlerts: number
    highRiskProfiles: number
    suspiciousAdminLogins24h: number
}

export interface RootControlAuditLog {
    id: number
    actorType: string
    actorId: number | null
    subjectType: string | null
    subjectId: number | null
    resellerId: number | null
    action: string
    description: string | null
    ipAddress: string | null
    userAgent: string | null
    statusCode: number | null
    requestMethod: string | null
    routeName: string | null
    path: string | null
    context: Record<string, any>
    createdAt: Date | null
}

export interface RootControlActivityItem {
    id: number
    event: string
    description: string | null
    ip: string
    timestamp: Date | null
    actor: {
        id: number
        type: string
        label: string
    } | null
    properties: Record<string, any>
}

export interface RootControlIpLog {
    id: number
    userId: number | null
    email: string | null
    event: string
    ipAddress: string | null
    countryCode: string | null
    region: string | null
    city: string | null
    isSuspicious: boolean
    createdAt: Date | null
    userAgent: string | null
    role: string | null
}

export interface RootControlAdminAlert {
    id: number
    type: string
    severity: string
    status: string
    title: string
    message: string | null
    source: string | null
    reseller: { id: number; displayName: string } | null
    user: { id: number; email: string } | null
    server: { id: number; uuid: string; name: string } | null
    context: Record<string, any>
    triggeredAt: Date | null
    acknowledgedAt: Date | null
    acknowledgedBy: { id: number; email: string } | null
}

export interface RootControlTenantPreview {
    id: number
    displayName: string
    status: string
    verificationStatus: string
    usersCount: number
    serversCount: number
    usedVms: number
    maxVms: number
}

export interface RootControlAbuseHotspot {
    serverId: number | null
    serverUuid: string | null
    serverName: string | null
    ownerEmail: string | null
    resellerName: string | null
    score: number
    lastOutboundMbps: number
    suspendThreshold: number
}

export interface RootControlPermissionDefinition {
    key: string
    group: string
    label: string
    description: string
}

export interface RootControlRole {
    id: number
    name: string
    slug: string
    description: string | null
    isSystem: boolean
    permissions: string[]
    usersCount: number
    createdAt: Date | null
    updatedAt: Date | null
}

export interface RootControlStaffMember {
    id: number
    name: string
    email: string
    roleName: string
    rootAdmin: boolean
    isPlatformAdmin: boolean
    lastLoginAt: Date | null
    lastLoginIp: string | null
    lastLoginCountry: string | null
    adminRoles: Array<{
        id: number
        name: string
        slug: string
    }>
}

export interface RootControlOverview {
    metrics: RootControlMetricSnapshot
    recentTenants: RootControlTenantPreview[]
    recentAuditLogs: RootControlAuditLog[]
    abuseHotspots: RootControlAbuseHotspot[]
    openAlerts: RootControlAdminAlert[]
}

export interface RootControlPaymenterIntegrationItem {
    id: number
    reseller: { id: number; displayName: string; status: string }
    status: string
    paymenterUrl: string | null
    effectivePaymenterUrl: string | null
    billingEnabled: boolean
    effectiveBillingEnabled: boolean
    planSyncEnabled: boolean
    usageSyncEnabled: boolean
    renewalSyncEnabled: boolean
    upgradeSyncEnabled: boolean
    connectedAt: Date | null
    lastPlanSyncAt: Date | null
    lastUsageSyncAt: Date | null
    lastWebhookReceivedAt: Date | null
    lastError: string | null
    webhook: {
        url: string
        signingHeader: string
        supportedEvents: string[]
    }
    module: {
        centralApiEndpoint: string
        panelUrl: string
    }
    rootOverride: {
        enabled: boolean
        paymenterUrl: string | null
        billingDisabled: boolean
        note: string | null
    } | null
}

export interface RootControlPaymenterWebhookLog {
    id: number
    reseller: { id: number; displayName: string } | null
    event: string
    status: string
    externalOrderId: string | null
    externalInvoiceId: string | null
    externalServiceId: string | null
    requestIp: string | null
    errorMessage: string | null
    processedAt: Date | null
    createdAt: Date | null
}

export interface RootControlPaymenterOverview {
    summary: {
        integrationsTotal: number
        connectedTotal: number
        disabledTotal: number
        webhooksToday: number
        webhookFailuresToday: number
    }
    items: RootControlPaymenterIntegrationItem[]
    logs: RootControlPaymenterWebhookLog[]
}

const rawAuditLog = (data: any): RootControlAuditLog => ({
    id: data.id,
    actorType: data.actor_type,
    actorId: data.actor_id ?? null,
    subjectType: data.subject_type ?? null,
    subjectId: data.subject_id ?? null,
    resellerId: data.reseller_id ?? null,
    action: data.action,
    description: data.description ?? null,
    ipAddress: data.ip_address ?? null,
    userAgent: data.user_agent ?? null,
    statusCode: data.status_code ?? null,
    requestMethod: data.request_method ?? null,
    routeName: data.route_name ?? null,
    path: data.path ?? null,
    context: data.context || {},
    createdAt: data.created_at ? new Date(data.created_at) : null,
})

const rawAlert = (data: any): RootControlAdminAlert => ({
    id: data.id,
    type: data.type,
    severity: data.severity,
    status: data.status,
    title: data.title,
    message: data.message ?? null,
    source: data.source ?? null,
    reseller: data.reseller
        ? {
              id: data.reseller.id,
              displayName: data.reseller.display_name,
          }
        : null,
    user: data.user
        ? {
              id: data.user.id,
              email: data.user.email,
          }
        : null,
    server: data.server
        ? {
              id: data.server.id,
              uuid: data.server.uuid,
              name: data.server.name,
          }
        : null,
    context: data.context || {},
    triggeredAt: data.triggered_at ? new Date(data.triggered_at) : null,
    acknowledgedAt: data.acknowledged_at ? new Date(data.acknowledged_at) : null,
    acknowledgedBy: data.acknowledged_by
        ? {
              id: data.acknowledged_by.id,
              email: data.acknowledged_by.email,
          }
        : null,
})

export const getRootControlOverview = async (): Promise<RootControlOverview> => {
    const { data } = await http.get('/api/admin/root-control/overview')
    const payload = data.data

    return {
        metrics: {
            tenants: payload.metrics.tenants,
            platformAdmins: payload.metrics.platform_admins,
            users: payload.metrics.users,
            servers: payload.metrics.servers,
            nodes: payload.metrics.nodes,
            openAdminAlerts: payload.metrics.open_admin_alerts,
            criticalSecurityAlerts: payload.metrics.critical_security_alerts,
            highRiskProfiles: payload.metrics.high_risk_profiles,
            suspiciousAdminLogins24h:
                payload.metrics.suspicious_admin_logins_24h,
        },
        recentTenants: (payload.recent_tenants || []).map((item: any) => ({
            id: item.id,
            displayName: item.display_name,
            status: item.status,
            verificationStatus: item.verification_status,
            usersCount: item.users_count,
            serversCount: item.servers_count,
            usedVms: item.used_vms,
            maxVms: item.max_vms,
        })),
        recentAuditLogs: (payload.recent_audit_logs || []).map(rawAuditLog),
        abuseHotspots: (payload.abuse_hotspots || []).map((item: any) => ({
            serverId: item.server_id ?? null,
            serverUuid: item.server_uuid ?? null,
            serverName: item.server_name ?? null,
            ownerEmail: item.owner_email ?? null,
            resellerName: item.reseller_name ?? null,
            score: item.score,
            lastOutboundMbps: item.last_outbound_mbps,
            suspendThreshold: item.suspend_threshold,
        })),
        openAlerts: (payload.open_alerts || []).map(rawAlert),
    }
}

export const getRootControlAuditLogs = async (): Promise<RootControlAuditLog[]> => {
    const { data } = await http.get('/api/admin/root-control/audit-logs', {
        params: { per_page: 20 },
    })

    return (data.data?.items || []).map(rawAuditLog)
}

export const getRootControlActivity = async (): Promise<RootControlActivityItem[]> => {
    const { data } = await http.get('/api/admin/root-control/activity', {
        params: { per_page: 20 },
    })

    return (data.data?.items || []).map((item: any) => ({
        id: item.id,
        event: item.event,
        description: item.description ?? null,
        ip: item.ip,
        timestamp: item.timestamp ? new Date(item.timestamp) : null,
        actor: item.actor ?? null,
        properties: item.properties || {},
    }))
}

export const getRootControlIpLogs = async (): Promise<RootControlIpLog[]> => {
    const { data } = await http.get('/api/admin/root-control/ip-logs', {
        params: { per_page: 20 },
    })

    return (data.data?.items || []).map((item: any) => ({
        id: item.id,
        userId: item.user_id ?? null,
        email: item.email ?? null,
        event: item.event,
        ipAddress: item.ip_address ?? null,
        countryCode: item.country_code ?? null,
        region: item.region ?? null,
        city: item.city ?? null,
        isSuspicious: Boolean(item.is_suspicious),
        createdAt: item.created_at ? new Date(item.created_at) : null,
        userAgent: item.user_agent ?? null,
        role: item.role ?? null,
    }))
}

export const getRootControlAlerts = async (): Promise<RootControlAdminAlert[]> => {
    const { data } = await http.get('/api/admin/root-control/alerts', {
        params: { per_page: 20 },
    })

    return (data.data?.items || []).map(rawAlert)
}

export const acknowledgeRootControlAlert = async (
    alertId: number
): Promise<RootControlAdminAlert> => {
    const { data } = await http.patch(
        `/api/admin/root-control/alerts/${alertId}/acknowledge`
    )

    return rawAlert(data.data)
}

export const getRootControlPermissions = async (): Promise<
    RootControlPermissionDefinition[]
> => {
    const { data } = await http.get('/api/admin/root-control/permissions')

    return data.data?.items || []
}

export const getRootControlRoles = async (): Promise<RootControlRole[]> => {
    const { data } = await http.get('/api/admin/root-control/roles')

    return (data.data?.items || []).map((item: any) => ({
        id: item.id,
        name: item.name,
        slug: item.slug,
        description: item.description ?? null,
        isSystem: Boolean(item.is_system),
        permissions: item.permissions || [],
        usersCount: item.users_count,
        createdAt: item.created_at ? new Date(item.created_at) : null,
        updatedAt: item.updated_at ? new Date(item.updated_at) : null,
    }))
}

export const createRootControlRole = async (payload: {
    name: string
    slug: string
    description?: string | null
    permissions: string[]
}): Promise<RootControlRole> => {
    const { data } = await http.post('/api/admin/root-control/roles', payload)

    return {
        id: data.data.id,
        name: data.data.name,
        slug: data.data.slug,
        description: data.data.description ?? null,
        isSystem: Boolean(data.data.is_system),
        permissions: data.data.permissions || [],
        usersCount: data.data.users_count,
        createdAt: data.data.created_at ? new Date(data.data.created_at) : null,
        updatedAt: data.data.updated_at ? new Date(data.data.updated_at) : null,
    }
}

export const updateRootControlRole = async (
    roleId: number,
    payload: {
        name: string
        slug: string
        description?: string | null
        permissions: string[]
    }
): Promise<RootControlRole> => {
    const { data } = await http.put(`/api/admin/root-control/roles/${roleId}`, payload)

    return {
        id: data.data.id,
        name: data.data.name,
        slug: data.data.slug,
        description: data.data.description ?? null,
        isSystem: Boolean(data.data.is_system),
        permissions: data.data.permissions || [],
        usersCount: data.data.users_count,
        createdAt: data.data.created_at ? new Date(data.data.created_at) : null,
        updatedAt: data.data.updated_at ? new Date(data.data.updated_at) : null,
    }
}

export const deleteRootControlRole = async (roleId: number): Promise<void> => {
    await http.delete(`/api/admin/root-control/roles/${roleId}`)
}

export const getRootControlStaff = async (): Promise<RootControlStaffMember[]> => {
    const { data } = await http.get('/api/admin/root-control/staff', {
        params: { per_page: 50 },
    })

    return (data.data?.items || []).map((item: any) => ({
        id: item.id,
        name: item.name,
        email: item.email,
        roleName: item.role_name,
        rootAdmin: Boolean(item.root_admin),
        isPlatformAdmin: Boolean(item.is_platform_admin),
        lastLoginAt: item.last_login_at ? new Date(item.last_login_at) : null,
        lastLoginIp: item.last_login_ip ?? null,
        lastLoginCountry: item.last_login_country ?? null,
        adminRoles: item.admin_roles || [],
    }))
}

export const syncRootControlStaffRoles = async (
    userId: number,
    roleIds: number[]
): Promise<void> => {
    await http.put(`/api/admin/root-control/staff/${userId}/roles`, {
        role_ids: roleIds,
    })
}

export const getRootControlPaymenterOverview = async (): Promise<RootControlPaymenterOverview> => {
    const { data } = await http.get('/api/admin/root-control/billing/paymenter', {
        params: { per_page: 25 },
    })

    return {
        summary: {
            integrationsTotal: Number(data.data?.summary?.integrations_total ?? 0),
            connectedTotal: Number(data.data?.summary?.connected_total ?? 0),
            disabledTotal: Number(data.data?.summary?.disabled_total ?? 0),
            webhooksToday: Number(data.data?.summary?.webhooks_today ?? 0),
            webhookFailuresToday: Number(
                data.data?.summary?.webhook_failures_today ?? 0
            ),
        },
        items: Array.isArray(data.data?.items)
            ? data.data.items.map((item: any) => ({
                  id: Number(item.id),
                  reseller: {
                      id: Number(item.reseller?.id ?? 0),
                      displayName: String(item.reseller?.display_name ?? 'Reseller'),
                      status: String(item.reseller?.status ?? 'pending'),
                  },
                  status: String(item.status ?? 'disconnected'),
                  paymenterUrl: item.paymenter_url ?? null,
                  effectivePaymenterUrl: item.effective_paymenter_url ?? null,
                  billingEnabled: Boolean(item.billing_enabled),
                  effectiveBillingEnabled: Boolean(item.effective_billing_enabled),
                  planSyncEnabled: Boolean(item.plan_sync_enabled),
                  usageSyncEnabled: Boolean(item.usage_sync_enabled),
                  renewalSyncEnabled: Boolean(item.renewal_sync_enabled),
                  upgradeSyncEnabled: Boolean(item.upgrade_sync_enabled),
                  connectedAt: item.connected_at
                      ? new Date(item.connected_at)
                      : null,
                  lastPlanSyncAt: item.last_plan_sync_at
                      ? new Date(item.last_plan_sync_at)
                      : null,
                  lastUsageSyncAt: item.last_usage_sync_at
                      ? new Date(item.last_usage_sync_at)
                      : null,
                  lastWebhookReceivedAt: item.last_webhook_received_at
                      ? new Date(item.last_webhook_received_at)
                      : null,
                  lastError: item.last_error ?? null,
                  webhook: {
                      url: String(item.webhook?.url ?? ''),
                      signingHeader: String(item.webhook?.signing_header ?? ''),
                      supportedEvents: Array.isArray(item.webhook?.supported_events)
                          ? item.webhook.supported_events.map((event: any) =>
                                String(event)
                            )
                          : [],
                  },
                  module: {
                      centralApiEndpoint: String(
                          item.module?.central_api_endpoint ?? ''
                      ),
                      panelUrl: String(item.module?.panel_url ?? ''),
                  },
                  rootOverride: item.root_override
                      ? {
                            enabled: Boolean(item.root_override.enabled),
                            paymenterUrl:
                                item.root_override.paymenter_url ?? null,
                            billingDisabled: Boolean(
                                item.root_override.billing_disabled
                            ),
                            note: item.root_override.note ?? null,
                        }
                      : null,
              }))
            : [],
        logs: Array.isArray(data.data?.logs)
            ? data.data.logs.map((item: any) => ({
                  id: Number(item.id),
                  reseller: item.reseller
                      ? {
                            id: Number(item.reseller.id ?? 0),
                            displayName: String(
                                item.reseller.display_name ?? 'Reseller'
                            ),
                        }
                      : null,
                  event: String(item.event ?? ''),
                  status: String(item.status ?? 'received'),
                  externalOrderId: item.external_order_id ?? null,
                  externalInvoiceId: item.external_invoice_id ?? null,
                  externalServiceId: item.external_service_id ?? null,
                  requestIp: item.request_ip ?? null,
                  errorMessage: item.error_message ?? null,
                  processedAt: item.processed_at
                      ? new Date(item.processed_at)
                      : null,
                  createdAt: item.created_at ? new Date(item.created_at) : null,
              }))
            : [],
    }
}

export const updateRootControlPaymenterOverride = async (
    integrationId: number,
    payload: {
        rootOverrideEnabled?: boolean
        rootOverridePaymenterUrl?: string | null
        rootOverridePaymenterApiKey?: string | null
        rootOverrideBillingDisabled?: boolean
        rootOverrideNote?: string | null
    }
): Promise<void> => {
    const normalizedOverrideUrl =
        typeof payload.rootOverridePaymenterUrl === 'string'
            ? payload.rootOverridePaymenterUrl.trim() || null
            : payload.rootOverridePaymenterUrl

    await http.patch(`/api/admin/root-control/billing/paymenter/${integrationId}`, {
        ...(typeof payload.rootOverrideEnabled !== 'undefined'
            ? { root_override_enabled: payload.rootOverrideEnabled }
            : {}),
        ...(typeof payload.rootOverridePaymenterUrl !== 'undefined'
            ? { root_override_paymenter_url: normalizedOverrideUrl }
            : {}),
        ...(typeof payload.rootOverridePaymenterApiKey !== 'undefined'
            ? { root_override_paymenter_api_key: payload.rootOverridePaymenterApiKey }
            : {}),
        ...(typeof payload.rootOverrideBillingDisabled !== 'undefined'
            ? { root_override_billing_disabled: payload.rootOverrideBillingDisabled }
            : {}),
        ...(typeof payload.rootOverrideNote !== 'undefined'
            ? { root_override_note: payload.rootOverrideNote }
            : {}),
    })
}
