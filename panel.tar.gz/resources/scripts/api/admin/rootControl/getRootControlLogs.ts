import http from '@/api/http'

export type RootControlLogSource =
    | 'all'
    | 'application'
    | 'audit'
    | 'activity'
    | 'auth'
    | 'admin_alert'
    | 'security_event'
    | 'security_alert'
    | 'paymenter'
    | 'provisioning'
    | 'resource_guard'

export type RootControlLogCategory =
    | 'all'
    | 'admin'
    | 'alert'
    | 'application'
    | 'audit'
    | 'auth'
    | 'error'
    | 'paymenter'
    | 'provisioning'
    | 'resource_guard'
    | 'security'
    | 'server'
    | 'suspension'

export type RootControlLogSeverity =
    | 'all'
    | 'critical'
    | 'debug'
    | 'error'
    | 'info'
    | 'warning'

export interface RootControlLogItem {
    id: string
    sourceId: number
    source: Exclude<RootControlLogSource, 'all'>
    category: Exclude<RootControlLogCategory, 'all'>
    severity: Exclude<RootControlLogSeverity, 'all'>
    occurredAt: Date | null
    title: string
    message: string | null
    reason: string | null
    actor: {
        type: string | null
        id: number | null
    }
    subject: {
        type: string | null
        id: number | null
    }
    resellerId: number | null
    server: {
        id: number
        uuid: string | null
        name: string | null
    } | null
    userEmail: string | null
    ipAddress: string | null
    requestMethod: string | null
    path: string | null
    context: Record<string, unknown>
}

export interface RootControlLogsResponse {
    items: RootControlLogItem[]
    meta: {
        total: number
        count: number
        perPage: number
        currentPage: number
        totalPages: number
        windowDays: number
        cutoff: Date | null
    }
}

export interface RootControlLogQuery {
    page: number
    perPage: 50 | 100
    source: RootControlLogSource
    category: RootControlLogCategory
    severity: RootControlLogSeverity
    query: string
}

const rawLogItem = (item: any): RootControlLogItem => ({
    id: String(item.id),
    sourceId: Number(item.source_id ?? 0),
    source: String(item.source ?? 'audit') as RootControlLogItem['source'],
    category: String(item.category ?? 'audit') as RootControlLogItem['category'],
    severity: String(item.severity ?? 'info') as RootControlLogItem['severity'],
    occurredAt: item.occurred_at ? new Date(item.occurred_at) : null,
    title: String(item.title ?? 'Log entry'),
    message: item.message ?? null,
    reason: item.reason ?? null,
    actor: {
        type: item.actor?.type ?? null,
        id:
            item.actor?.id === null || item.actor?.id === undefined
                ? null
                : Number(item.actor.id),
    },
    subject: {
        type: item.subject?.type ?? null,
        id:
            item.subject?.id === null || item.subject?.id === undefined
                ? null
                : Number(item.subject.id),
    },
    resellerId:
        item.reseller_id === null || item.reseller_id === undefined
            ? null
            : Number(item.reseller_id),
    server: item.server
        ? {
              id: Number(item.server.id ?? 0),
              uuid: item.server.uuid ?? null,
              name: item.server.name ?? null,
          }
        : null,
    userEmail: item.user_email ?? null,
    ipAddress: item.ip_address ?? null,
    requestMethod: item.request_method ?? null,
    path: item.path ?? null,
    context:
        item.context && typeof item.context === 'object'
            ? (item.context as Record<string, unknown>)
            : {},
})

export const getRootControlLogs = async (
    params: RootControlLogQuery
): Promise<RootControlLogsResponse> => {
    const { data } = await http.get('/api/admin/root-control/logs', {
        params: {
            page: params.page,
            per_page: params.perPage,
            source: params.source,
            category: params.category,
            severity: params.severity,
            query: params.query.trim() || undefined,
        },
    })

    const meta = data.data?.meta || {}

    return {
        items: Array.isArray(data.data?.items)
            ? data.data.items.map(rawLogItem)
            : [],
        meta: {
            total: Number(meta.total ?? 0),
            count: Number(meta.count ?? 0),
            perPage: Number(meta.per_page ?? params.perPage),
            currentPage: Number(meta.current_page ?? params.page),
            totalPages: Number(meta.total_pages ?? meta.last_page ?? 1),
            windowDays: Number(meta.window_days ?? 90),
            cutoff: meta.cutoff ? new Date(meta.cutoff) : null,
        },
    }
}
