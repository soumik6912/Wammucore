import http from '@/api/http'

export interface ProxmoxNodeResource {
    type?: string
    node?: string
    status?: string
    cpu?: number
    maxcpu?: number
    mem?: number
    maxmem?: number
    disk?: number
    maxdisk?: number
    uptime?: number
    [key: string]: any
}

export interface ProxmoxNodeStatus {
    cpu?: number
    wait?: number
    loadavg?: number[]
    uptime?: number
    pveversion?: string
    kversion?: string
    cpuinfo?: {
        cpus?: number
        model?: string
        sockets?: number
    }
    memory?: {
        total?: number
        used?: number
        free?: number
    }
    rootfs?: {
        total?: number
        used?: number
        free?: number
    }
    [key: string]: any
}

export interface ProxmoxVmSummary {
    total: number
    running: number
    stopped: number
    qemu: number
    lxc: number
}

export interface NodeResourcesResponse {
    nodeId: number
    cluster: string
    node: ProxmoxNodeResource | null
    vms: any[]
    status: ProxmoxNodeStatus | null
    storages: any[]
    networks: any[]
    vmsSummary: ProxmoxVmSummary
}

const getNodeResources = async (nodeId: number): Promise<NodeResourcesResponse> => {
    const { data } = await http.get(`/api/admin/nodes/${nodeId}/resources`)
    const payload = data?.data || {}

    return {
        nodeId: payload.node_id,
        cluster: payload.cluster,
        node: payload.node || null,
        vms: payload.vms || [],
        status: payload.status || null,
        storages: payload.storages || [],
        networks: payload.networks || [],
        vmsSummary: payload.vms_summary || {
            total: 0,
            running: 0,
            stopped: 0,
            qemu: 0,
            lxc: 0,
        },
    }
}

export default getNodeResources
