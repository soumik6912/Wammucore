import useSWR from 'swr'

import getNodes, {NodeResponse, QueryParams} from '@/api/admin/nodes/getNodes'


const useNodesSWR = ({page, query, id, cotermId, ...params}: QueryParams) => {
    return useSWR<NodeResponse>(
        ['admin:nodes', page, query, id, cotermId, params.perPage],
        () => getNodes({page, query, id, cotermId, ...params}),
        {
            dedupingInterval: 20000,
            keepPreviousData: true,
            revalidateOnFocus: false,
            revalidateOnReconnect: false,
        }
    )
}

export default useNodesSWR
