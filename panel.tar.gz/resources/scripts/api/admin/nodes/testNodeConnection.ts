import http from '@/api/http'

interface TestNodeConnectionResponse {
    nodeId: number
    connected: boolean
    cluster: string
}

const testNodeConnection = async (
    nodeId: number
): Promise<TestNodeConnectionResponse> => {
    const {
        data: { data },
    } = await http.post(`/api/admin/nodes/${nodeId}/test-connection`)

    return {
        nodeId: data.node_id,
        connected: data.connected,
        cluster: data.cluster,
    }
}

export default testNodeConnection
