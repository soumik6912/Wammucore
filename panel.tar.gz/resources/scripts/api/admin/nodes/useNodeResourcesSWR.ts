import getNodeResources, { NodeResourcesResponse } from '@/api/admin/nodes/getNodeResources'
import useSWR from 'swr'

const useNodeResourcesSWR = (nodeId?: number) => {
    return useSWR<NodeResourcesResponse>(
        nodeId ? ['admin:nodes:resources', nodeId] : null,
        () => getNodeResources(nodeId!),
        {
            refreshInterval: 30000,
            revalidateOnFocus: false,
            refreshWhenHidden: false,
            refreshWhenOffline: false,
        }
    )
}

export default useNodeResourcesSWR
