import { rawDataToAddressPool } from '@/api/admin/addressPools/getAddressPools'
import http from '@/api/http'

interface CreateAddressParameters {
    name: string
    nodeIds?: number[] | string[]
    resellerId?: number | null
    enableForResellers: boolean
    resellerIpPriceEach: string
}

const createAddressPool = async ({
    name,
    nodeIds,
    resellerId,
    enableForResellers,
    resellerIpPriceEach,
}: CreateAddressParameters) => {
    const {
        data: { data },
    } = await http.post('/api/admin/address-pools', {
        name,
        node_ids: nodeIds,
        reseller_id: resellerId,
        enable_for_resellers: enableForResellers,
        reseller_ip_price_each: resellerIpPriceEach,
    })

    return rawDataToAddressPool(data)
}

export default createAddressPool
