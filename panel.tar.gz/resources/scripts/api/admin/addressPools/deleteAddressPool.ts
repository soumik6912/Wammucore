import http from '@/api/http'

const deleteAddressPool = (id: number, force = false) =>
    http.delete(`/api/admin/address-pools/${id}`, {
        data: {
            force,
        },
    })

export default deleteAddressPool
