import http, { PaginatedResult, getPaginationSet } from '@/api/http'

export interface AddressPool {
    id: number
    name: string
    resellerIpPriceEach: string
    enableForResellers: boolean
    resellerAccessMode: 'platform_only' | 'shared' | 'exclusive'
    resellerId: number | null
    resellerDisplayName: string | null
    nodesCount: number
    addressesCount: number
}

export interface QueryParams {
    query?: string
    page?: number
    perPage?: number
}

export type AddressPoolResponse = PaginatedResult<AddressPool>

const getAddressPools = async ({
    query,
    page,
    perPage = 50,
}: QueryParams): Promise<AddressPoolResponse> => {
    const { data } = await http.get('/api/admin/address-pools', {
        params: {
            'filter[*]': query,
            page,
            'per_page': perPage,
        },
        showProgress: false,
    })

    return {
        items: data.data.map(rawDataToAddressPool),
        pagination: getPaginationSet(data.meta.pagination),
    }
}

export const rawDataToAddressPool = (data: any): AddressPool => ({
    id: data.id,
    name: data.name,
    resellerIpPriceEach: String(data.reseller_ip_price_each ?? '0.00'),
    enableForResellers: Boolean(data.enable_for_resellers ?? true),
    resellerAccessMode: (data.reseller_access_mode ?? 'shared') as
        | 'platform_only'
        | 'shared'
        | 'exclusive',
    resellerId: data.reseller_id ?? null,
    resellerDisplayName: data.reseller_display_name ?? null,
    nodesCount: data.nodes_count,
    addressesCount: data.addresses_count,
})

export default getAddressPools
