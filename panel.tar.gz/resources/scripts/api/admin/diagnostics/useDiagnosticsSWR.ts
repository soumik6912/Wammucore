import useSWR from 'swr'

import getDiagnostics from '@/api/admin/diagnostics/getDiagnostics'
import { DiagnosticsData } from '@/api/admin/diagnostics/types'

const useDiagnosticsSWR = (query: string) => {
    return useSWR<DiagnosticsData>(
        ['admin:diagnostics', query],
        ([, currentQuery]: [string, string]) =>
            getDiagnostics(currentQuery, { showProgress: false }),
        {
            refreshInterval: 30000,
            revalidateOnFocus: false,
            refreshWhenHidden: false,
            refreshWhenOffline: false,
        }
    )
}

export default useDiagnosticsSWR
