export interface DiagnosticsSummary {
    failedJobs: number
    provisioningFailures: number
    paymenterRelatedErrors: number
    recentApplicationErrors: number
    workerFailures: number
}

export interface DiagnosticsFailedJob {
    uuid: string
    job: string
    failedAt: string
    serverId: number | null
    templateId: number | null
    nodeId: number | null
    category: string
    headline: string
    snippet: string
}

export interface DiagnosticsErrorEntry {
    timestamp: string
    level: string
    category: string
    headline: string
    snippet: string
    source: string
}

export interface DiagnosticsServiceLine {
    line: string
    severity: 'info' | 'error'
}

export interface DiagnosticsData {
    summary: DiagnosticsSummary
    failedJobs: DiagnosticsFailedJob[]
    applicationErrors: DiagnosticsErrorEntry[]
    serviceLogs: {
        horizon: DiagnosticsServiceLine[]
        scheduler: DiagnosticsServiceLine[]
        supervisord: DiagnosticsServiceLine[]
        diagnostics: DiagnosticsServiceLine[]
    }
}

export const rawDataToDiagnostics = (data: any): DiagnosticsData => ({
    summary: {
        failedJobs: Number(data.summary?.failed_jobs ?? 0),
        provisioningFailures: Number(data.summary?.provisioning_failures ?? 0),
        paymenterRelatedErrors: Number(data.summary?.paymenter_related_errors ?? 0),
        recentApplicationErrors: Number(data.summary?.recent_application_errors ?? 0),
        workerFailures: Number(data.summary?.worker_failures ?? 0),
    },
    failedJobs: Array.isArray(data.failed_jobs)
        ? data.failed_jobs.map((item: any) => ({
              uuid: item.uuid ?? '',
              job: item.job ?? 'Unknown job',
              failedAt: item.failed_at ?? '',
              serverId: item.server_id ?? null,
              templateId: item.template_id ?? null,
              nodeId: item.node_id ?? null,
              category: item.category ?? 'application',
              headline: item.headline ?? '',
              snippet: item.snippet ?? '',
          }))
        : [],
    applicationErrors: Array.isArray(data.application_errors)
        ? data.application_errors.map((item: any) => ({
              timestamp: item.timestamp ?? '',
              level: item.level ?? 'error',
              category: item.category ?? 'application',
              headline: item.headline ?? '',
              snippet: item.snippet ?? '',
              source: item.source ?? 'laravel.log',
          }))
        : [],
    serviceLogs: {
        horizon: Array.isArray(data.service_logs?.horizon) ? data.service_logs.horizon : [],
        scheduler: Array.isArray(data.service_logs?.scheduler) ? data.service_logs.scheduler : [],
        supervisord: Array.isArray(data.service_logs?.supervisord) ? data.service_logs.supervisord : [],
        diagnostics: Array.isArray(data.service_logs?.diagnostics) ? data.service_logs.diagnostics : [],
    },
})
