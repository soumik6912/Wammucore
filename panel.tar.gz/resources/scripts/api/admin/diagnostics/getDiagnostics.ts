import http, { WammuCoreRequestConfig } from '@/api/http'

import { DiagnosticsData, rawDataToDiagnostics } from '@/api/admin/diagnostics/types'

const getDiagnostics = async (
    query?: string,
    config?: WammuCoreRequestConfig
): Promise<DiagnosticsData> => {
    const { data } = await http.get('/api/admin/diagnostics', {
        params: query && query.trim() !== '' ? { query } : undefined,
        ...(config ?? {}),
    })

    return rawDataToDiagnostics(data.data)
}

export default getDiagnostics
