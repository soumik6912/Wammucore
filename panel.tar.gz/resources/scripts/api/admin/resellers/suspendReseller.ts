import http from '@/api/http'

export interface SuspendResellerResponse {
    id: number
    status: string
    message: string
}

const suspendReseller = async (id: number): Promise<SuspendResellerResponse> => {
    const {
        data: { data },
    } = await http.post(`/api/admin/resellers/${id}/suspend`)

    return {
        id: data.id,
        status: data.status,
        message: data.message,
    }
}

export default suspendReseller
