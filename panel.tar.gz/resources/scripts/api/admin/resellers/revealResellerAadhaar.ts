import http from '@/api/http'

export interface RevealedResellerAadhaar {
    aadhaarFull: string
    visibleForSeconds: number
}

const revealResellerAadhaar = async (
    resellerId: number
): Promise<RevealedResellerAadhaar> => {
    const {
        data: { data },
    } = await http.post(`/api/admin/resellers/${resellerId}/verification/reveal-aadhaar`)

    return {
        aadhaarFull: String(data.aadhaar_full ?? ''),
        visibleForSeconds: Number(data.visible_for_seconds ?? 15),
    }
}

export default revealResellerAadhaar
