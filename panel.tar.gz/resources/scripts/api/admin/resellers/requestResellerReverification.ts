import http from '@/api/http'

const requestResellerReverification = async (
    resellerId: number,
    reason: string
): Promise<string> => {
    const {
        data: { data },
    } = await http.post(
        `/api/admin/resellers/${resellerId}/verification/request-reverification`,
        { reason }
    )

    return String(data.message ?? 'Re-verification requested.')
}

export default requestResellerReverification
