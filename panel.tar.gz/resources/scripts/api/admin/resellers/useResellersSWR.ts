import useSWR from 'swr'

import getResellers, {
    QueryParams,
    ResellerResponse,
} from '@/api/admin/resellers/getResellers'

const useResellersSWR = ({ page, query, ...params }: QueryParams) => {
    return useSWR<ResellerResponse>(
        ['admin:resellers', page, query, params.perPage],
        () => getResellers({ page, query, ...params })
    )
}

export default useResellersSWR
