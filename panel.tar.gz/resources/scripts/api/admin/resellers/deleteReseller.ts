import http from '@/api/http'

export default async (id: number): Promise<void> => {
    await http.delete(`/api/admin/resellers/${id}`)
}
