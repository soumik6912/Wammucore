import http, {
    FractalResponseData,
    PaginatedResult,
    getPaginationSet,
} from '@/api/http'

export type ResellerStatus = 'pending' | 'active' | 'suspended'
export type ResellerVerificationStatus =
    | 'pending'
    | 'under_review'
    | 'approved'
    | 'rejected'
    | 'suspended'

export interface ResellerDomain {
    id: number
    domain: string
    purpose: string
    isPrimary: boolean
    verifiedAt: Date | null
}

export interface Reseller {
    id: number
    uuid: string | null
    slug: string | null
    parentResellerId: number | null
    displayName: string
    logoUrl: string | null
    domain: string | null
    backendDomain: string | null
    liveDataDomain: string | null
    novncDomain: string | null
    cdnDomain: string | null
    status: ResellerStatus
    verificationStatus: ResellerVerificationStatus
    onboardingStatus: string
    onboardingCurrentStep: string | null
    isRegistrationDraft: boolean
    isDefault: boolean
    maxRamMb: number
    maxCpuCores: number
    maxDiskGb: number
    maxVms: number
    usedRamMb: number
    usedCpuCores: number
    usedDiskGb: number
    usedVms: number
    usersCount: number
    serversCount: number
    nodesCount: number
    adminUser: {
        id: number
        name: string
        email: string
    } | null
    domains: ResellerDomain[]
    verification: {
        hasDocuments: boolean
        submittedAt: Date | null
        verifiedAt: Date | null
        verifiedByUserId: number | null
        rejectionReason: string | null
        aadhaarMasked: string | null
        panMasked: string | null
        fraudFlags: string[]
    }
}

const rawDataToDomain = (data: FractalResponseData): ResellerDomain => ({
    id: data.id,
    domain: data.domain,
    purpose: data.purpose,
    isPrimary: data.is_primary,
    verifiedAt: data.verified_at ? new Date(data.verified_at) : null,
})

export const rawDataToReseller = (data: FractalResponseData): Reseller => ({
    id: data.id,
    uuid: data.uuid ?? null,
    slug: data.slug ?? null,
    parentResellerId: data.parent_reseller_id ?? null,
    displayName: data.display_name,
    logoUrl: data.logo_url,
    domain: data.domain,
    backendDomain: data.backend_domain,
    liveDataDomain: data.live_data_domain,
    novncDomain: data.novnc_domain,
    cdnDomain: data.cdn_domain,
    status: data.status,
    verificationStatus: (data.verification_status ?? 'approved') as ResellerVerificationStatus,
    onboardingStatus: data.onboarding_status ?? 'pending',
    onboardingCurrentStep: data.onboarding_current_step ?? null,
    isRegistrationDraft: Boolean(data.is_registration_draft),
    isDefault: data.is_default,
    maxRamMb: data.max_ram_mb,
    maxCpuCores: data.max_cpu_cores,
    maxDiskGb: data.max_disk_gb,
    maxVms: data.max_vms,
    usedRamMb: data.used_ram_mb,
    usedCpuCores: data.used_cpu_cores,
    usedDiskGb: data.used_disk_gb,
    usedVms: data.used_vms,
    usersCount: data.users_count ?? 0,
    serversCount: data.servers_count ?? 0,
    nodesCount: data.nodes_count ?? 0,
    adminUser: data.admin_user
        ? {
              id: Number(data.admin_user.id),
              name: String(data.admin_user.name ?? ''),
              email: String(data.admin_user.email ?? ''),
          }
        : null,
    domains: Array.isArray(data.domains)
        ? data.domains.map(rawDataToDomain)
        : [],
    verification: {
        hasDocuments: Boolean(data.verification?.has_documents),
        submittedAt: data.verification?.submitted_at
            ? new Date(data.verification.submitted_at)
            : null,
        verifiedAt: data.verification?.verified_at
            ? new Date(data.verification.verified_at)
            : null,
        verifiedByUserId:
            typeof data.verification?.verified_by_user_id === 'number'
                ? data.verification.verified_by_user_id
                : null,
        rejectionReason: data.verification?.rejection_reason ?? null,
        aadhaarMasked: data.verification?.aadhaar_masked ?? null,
        panMasked: data.verification?.pan_masked ?? null,
        fraudFlags: Array.isArray(data.verification?.fraud_flags)
            ? data.verification.fraud_flags.map((flag: any) => String(flag))
            : [],
    },
})

export interface QueryParams {
    query?: string
    page?: number
    perPage?: number
}

export type ResellerResponse = PaginatedResult<Reseller>

const getResellers = async ({
    query,
    perPage = 50,
    ...params
}: QueryParams): Promise<ResellerResponse> => {
    const { data } = await http.get('/api/admin/resellers', {
        params: {
            'filter[*]': query,
            'per_page': perPage,
            ...params,
        },
    })

    return {
        // The platform compatibility reseller is internal-only and should
        // never be shown in the operational reseller list UI.
        items: data.data
            .map(rawDataToReseller)
            .filter((reseller: Reseller) => !reseller.isDefault),
        pagination: getPaginationSet(data.meta.pagination),
    }
}

export default getResellers
