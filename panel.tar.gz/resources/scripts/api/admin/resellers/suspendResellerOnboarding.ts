import http from '@/api/http'

const suspendResellerOnboarding = async (
    resellerId: number,
    reason: string
): Promise<string> => {
    const {
        data: { data },
    } = await http.post(`/api/admin/resellers/${resellerId}/onboarding/suspend`, {
        reason,
    })

    return String(data.message ?? 'Onboarding suspended.')
}

export default suspendResellerOnboarding
