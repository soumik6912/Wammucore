import http from '@/api/http'

export interface ApproveResellerResponse {
    id: number
    status: string
    message: string
}

const approveReseller = async (id: number): Promise<ApproveResellerResponse> => {
    const {
        data: { data },
    } = await http.post(`/api/admin/resellers/${id}/approve`)

    return {
        id: data.id,
        status: data.status,
        message: data.message,
    }
}

export default approveReseller
