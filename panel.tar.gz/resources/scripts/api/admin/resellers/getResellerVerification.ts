import http from '@/api/http'

export interface ResellerVerificationDetails {
    resellerId: number
    displayName: string
    status: 'pending' | 'active' | 'suspended'
    verificationStatus:
        | 'pending'
        | 'under_review'
        | 'approved'
        | 'rejected'
        | 'suspended'
    submittedAt: string | null
    verifiedAt: string | null
    verifiedByUserId: number | null
    rejectionReason: string | null
    identity: {
        status: string
        aadhaarMasked: string | null
        panMasked: string | null
        businessName: string | null
        businessRegistrationMasked: string | null
        fraudFlags: string[]
        malwareScanStatus: string | null
        reviewNote: string | null
    }
    ownerProfile: {
        submitted: boolean
        locked: boolean
        firstName: string | null
        lastName: string | null
        contactEmail: string | null
        phoneNumber: string | null
        addressLine1: string | null
        addressLine2: string | null
        city: string | null
        stateName: string | null
        postalCode: string | null
        countryName: string | null
        submittedAt: string | null
        lockedAt: string | null
    }
    documents: {
        count: number
        items: Array<{
            type: string
            label: string
            available: boolean
            mime: string | null
            url: string | null
        }>
    }
}

const getResellerVerification = async (
    resellerId: number
): Promise<ResellerVerificationDetails> => {
    const {
        data: { data },
    } = await http.get(`/api/admin/resellers/${resellerId}/verification`)

    return {
        resellerId: Number(data.reseller_id),
        displayName: String(data.display_name ?? ''),
        status: data.status,
        verificationStatus: data.verification_status ?? 'pending',
        submittedAt: data.submitted_at ?? null,
        verifiedAt: data.verified_at ?? null,
        verifiedByUserId:
            typeof data.verified_by_user_id === 'number'
                ? data.verified_by_user_id
                : null,
        rejectionReason: data.rejection_reason ?? null,
        identity: {
            status: String(data.identity?.status ?? 'pending'),
            aadhaarMasked: data.identity?.aadhaar_masked ?? null,
            panMasked: data.identity?.pan_masked ?? null,
            businessName: data.identity?.business_name ?? null,
            businessRegistrationMasked:
                data.identity?.business_registration_masked ?? null,
            fraudFlags: Array.isArray(data.identity?.fraud_flags)
                ? data.identity.fraud_flags.map((flag: any) => String(flag))
                : [],
            malwareScanStatus: data.identity?.malware_scan_status ?? null,
            reviewNote: data.identity?.review_note ?? null,
        },
        ownerProfile: {
            submitted: Boolean(data.owner_profile?.submitted),
            locked: Boolean(data.owner_profile?.locked),
            firstName: data.owner_profile?.first_name ?? null,
            lastName: data.owner_profile?.last_name ?? null,
            contactEmail: data.owner_profile?.contact_email ?? null,
            phoneNumber: data.owner_profile?.phone_number ?? null,
            addressLine1: data.owner_profile?.address_line_1 ?? null,
            addressLine2: data.owner_profile?.address_line_2 ?? null,
            city: data.owner_profile?.city ?? null,
            stateName: data.owner_profile?.state_name ?? null,
            postalCode: data.owner_profile?.postal_code ?? null,
            countryName: data.owner_profile?.country_name ?? null,
            submittedAt: data.owner_profile?.submitted_at ?? null,
            lockedAt: data.owner_profile?.locked_at ?? null,
        },
        documents: {
            count: Number(data.documents?.count ?? 0),
            items: Array.isArray(data.documents?.items)
                ? data.documents.items.map((document: any) => ({
                      type: String(document.type ?? ''),
                      label: String(document.label ?? 'Document'),
                      available: Boolean(document.available),
                      mime:
                          typeof document.mime === 'string'
                              ? document.mime
                              : null,
                      url: document.url ?? null,
                  }))
                : [],
        },
    }
}

export default getResellerVerification
