import http from '@/api/http'

const manualOverrideResellerOnboarding = async (
    resellerId: number,
    note: string,
    options?: { stepKey?: string | null; completeAll?: boolean }
): Promise<string> => {
    const {
        data: { data },
    } = await http.post(`/api/admin/resellers/${resellerId}/onboarding/manual-override`, {
        note,
        step_key: options?.stepKey ?? null,
        complete_all: options?.completeAll ?? false,
    })

    return String(data.message ?? 'Manual override applied.')
}

export default manualOverrideResellerOnboarding
