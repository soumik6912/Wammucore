import {
    Reseller,
    ResellerStatus,
    rawDataToReseller,
} from '@/api/admin/resellers/getResellers'
import http from '@/api/http'

export interface UpdateResellerPayload {
    id: number
    displayName: string
    status?: ResellerStatus
    domain: string | null
    logoUrl: string | null
    backendDomain: string | null
    liveDataDomain: string | null
    novncDomain: string | null
    cdnDomain: string | null
    maxRamMb?: number
    maxCpuCores?: number
    maxDiskGb?: number
    maxVms?: number
    adminEmail?: string
    adminPassword?: string
    adminPasswordConfirmation?: string
}

export default async (payload: UpdateResellerPayload): Promise<Reseller> => {
    const body: Record<string, unknown> = {
        display_name: payload.displayName,
        domain: payload.domain,
        logo_url: payload.logoUrl,
        backend_domain: payload.backendDomain,
        live_data_domain: payload.liveDataDomain,
        novnc_domain: payload.novncDomain,
        cdn_domain: payload.cdnDomain,
    }

    if (payload.status !== undefined) {
        body.status = payload.status
    }

    if (payload.maxRamMb !== undefined) {
        body.max_ram_mb = payload.maxRamMb
    }

    if (payload.maxCpuCores !== undefined) {
        body.max_cpu_cores = payload.maxCpuCores
    }

    if (payload.maxDiskGb !== undefined) {
        body.max_disk_gb = payload.maxDiskGb
    }

    if (payload.maxVms !== undefined) {
        body.max_vms = payload.maxVms
    }

    if (payload.adminEmail) {
        body.admin_email = payload.adminEmail
    }

    if (payload.adminPassword) {
        body.admin_password = payload.adminPassword
        body.admin_password_confirmation =
            payload.adminPasswordConfirmation ?? ''
    }

    const {
        data: { data },
    } = await http.put(`/api/admin/resellers/${payload.id}`, body)

    return rawDataToReseller(data)
}
