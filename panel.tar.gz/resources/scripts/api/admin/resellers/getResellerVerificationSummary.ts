import http from '@/api/http'

export interface ResellerVerificationSummary {
    total: number
    pending: number
    underReview: number
    rejected: number
    suspended: number
}

const getResellerVerificationSummary =
    async (): Promise<ResellerVerificationSummary> => {
        const {
            data: { data },
        } = await http.get('/api/admin/resellers/verification-summary')

        return {
            total: Number(data.total ?? 0),
            pending: Number(data.pending ?? 0),
            underReview: Number(data.under_review ?? 0),
            rejected: Number(data.rejected ?? 0),
            suspended: Number(data.suspended ?? 0),
        }
    }

export default getResellerVerificationSummary
