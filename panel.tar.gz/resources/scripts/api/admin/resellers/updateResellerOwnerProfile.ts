import http from '@/api/http'

export interface ResellerOwnerProfilePayload {
    firstName: string
    lastName: string
    contactEmail: string
    phoneNumber: string
    addressLine1: string
    addressLine2: string
    city: string
    stateName: string
    postalCode: string
    countryName: string
}

const updateResellerOwnerProfile = async (
    resellerId: number,
    payload: ResellerOwnerProfilePayload
): Promise<string> => {
    const {
        data: { data },
    } = await http.put(`/api/admin/resellers/${resellerId}/owner-profile`, {
        first_name: payload.firstName,
        last_name: payload.lastName,
        contact_email: payload.contactEmail,
        phone_number: payload.phoneNumber,
        address_line_1: payload.addressLine1,
        address_line_2: payload.addressLine2.trim() || null,
        city: payload.city,
        state_name: payload.stateName,
        postal_code: payload.postalCode,
        country_name: payload.countryName,
    })

    return String(
        data.message ?? 'Reseller owner personal details updated.'
    )
}

export default updateResellerOwnerProfile
