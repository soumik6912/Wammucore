import http from '@/api/http'

export interface ResellerOnboardingMeta {
    edgeGatewayHost: string
    verificationPrefix: string
    selfRegistrationEnabled: boolean
}

const getResellerOnboardingMeta = async (): Promise<ResellerOnboardingMeta> => {
    const {
        data: { data },
    } = await http.get('/api/admin/resellers/onboarding/meta')

    return {
        edgeGatewayHost: String(
            data.edge_gateway_host ?? 'edge.wammuhost.com'
        ),
        verificationPrefix: String(
            data.verification_prefix ?? '_wammuhost-verify'
        ),
        selfRegistrationEnabled: Boolean(data.self_registration_enabled),
    }
}

export default getResellerOnboardingMeta
