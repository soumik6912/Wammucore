import http from '@/api/http'

interface RejectResellerVerificationResponse {
    id: number
    status: string
    verificationStatus: string
    message: string
}

const rejectResellerVerification = async (
    resellerId: number,
    reason: string
): Promise<RejectResellerVerificationResponse> => {
    const {
        data: { data },
    } = await http.post(`/api/admin/resellers/${resellerId}/verification/reject`, {
        reason,
    })

    return {
        id: Number(data.id),
        status: String(data.status),
        verificationStatus: String(data.verification_status),
        message: String(data.message ?? 'Reseller verification rejected.'),
    }
}

export default rejectResellerVerification

