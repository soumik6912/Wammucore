import {
    Reseller,
    ResellerStatus,
    rawDataToReseller,
} from '@/api/admin/resellers/getResellers'
import http from '@/api/http'

export interface CreateResellerPayload {
    displayName: string
    status: ResellerStatus
    parentResellerId?: number | null
    domain: string | null
    logoUrl: string | null
    backendDomain: string | null
    liveDataDomain: string | null
    novncDomain: string | null
    cdnDomain: string | null
    maxRamMb: number
    maxCpuCores: number
    maxDiskGb: number
    maxVms: number
}

export default async (payload: CreateResellerPayload): Promise<Reseller> => {
    const {
        data: { data },
    } = await http.post('/api/admin/resellers', {
        display_name: payload.displayName,
        status: payload.status,
        parent_reseller_id: payload.parentResellerId ?? null,
        domain: payload.domain,
        logo_url: payload.logoUrl,
        backend_domain: payload.backendDomain,
        live_data_domain: payload.liveDataDomain,
        novnc_domain: payload.novncDomain,
        cdn_domain: payload.cdnDomain,
        max_ram_mb: payload.maxRamMb,
        max_cpu_cores: payload.maxCpuCores,
        max_disk_gb: payload.maxDiskGb,
        max_vms: payload.maxVms,
    })

    return rawDataToReseller(data)
}
