import http from '@/api/http'

export interface CreateResellerOnboardingPayload {
    displayName: string
    logoUrl: string
    domain: string
    panelDomain?: string | null
    parentResellerId?: number | null
    maxRamMb?: number | null
    maxCpuCores?: number | null
    maxDiskGb?: number | null
    maxVms?: number | null
    autoActivateIfDnsPasses?: boolean
    adminEmail: string
    adminName: string
    adminPassword: string
    adminPasswordConfirmation: string
}

export interface DnsVerificationDomainResult {
    hostname: string
    probeHostname: string
    edgeGatewayHost: string
    directCnameVerified: boolean
    ownershipVerified: boolean
    cloudflareDetected: boolean
    dnsStatus: string
    sslStatus: string
    routingStatus: string
    passed: boolean
    errors: string[]
    instructions: {
        edgeGatewayHost: string
        cnameHost: string
        cnameType: string
        cnameTarget: string
        ownershipHost: string
        ownershipType: string
        ownershipValue: string
        probeHostname: string
        wildcard: boolean
    }
}

export interface CreateResellerOnboardingResponse {
    resellerId: number
    status: string
    panelDomain: string
    customDomain: {
        id: number
        hostname: string
        isPrimary: boolean
        dnsStatus: string
        sslStatus: string
        routingStatus: string
        verificationHost: string
        verificationToken: string | null
        verificationValue: string | null
        cnameTarget: string
        edgeGatewayHost: string
        probeHostname: string
    }
    defaultApiKey: string
    defaultApiKeyPrefix: string
    dnsVerification: DnsVerificationDomainResult
    message: string
}

const createResellerOnboarding = async (
    payload: CreateResellerOnboardingPayload
): Promise<CreateResellerOnboardingResponse> => {
    const {
        data: { data },
    } = await http.post('/api/admin/resellers/onboarding', {
        display_name: payload.displayName,
        logo_url: payload.logoUrl || null,
        domain: payload.domain,
        panel_domain: payload.panelDomain || null,
        parent_reseller_id: payload.parentResellerId ?? null,
        max_ram_mb: payload.maxRamMb ?? null,
        max_cpu_cores: payload.maxCpuCores ?? null,
        max_disk_gb: payload.maxDiskGb ?? null,
        max_vms: payload.maxVms ?? null,
        auto_activate_if_dns_passes: payload.autoActivateIfDnsPasses ?? false,
        admin_email: payload.adminEmail,
        admin_name: payload.adminName || null,
        admin_password: payload.adminPassword,
        admin_password_confirmation: payload.adminPasswordConfirmation,
    })

    return {
        resellerId: data.reseller_id,
        status: data.status,
        panelDomain: data.panel_domain,
        customDomain: {
            id: Number(data.custom_domain?.id),
            hostname: String(data.custom_domain?.hostname ?? ''),
            isPrimary: Boolean(data.custom_domain?.is_primary),
            dnsStatus: String(data.custom_domain?.dns_status ?? 'pending'),
            sslStatus: String(data.custom_domain?.ssl_status ?? 'pending'),
            routingStatus: String(data.custom_domain?.routing_status ?? 'pending'),
            verificationHost: String(
                data.custom_domain?.verification_host ?? ''
            ),
            verificationToken:
                typeof data.custom_domain?.verification_token === 'string'
                    ? data.custom_domain.verification_token
                    : null,
            verificationValue:
                typeof data.custom_domain?.verification_value === 'string'
                    ? data.custom_domain.verification_value
                    : null,
            cnameTarget: String(
                data.custom_domain?.cname_target ??
                    data.custom_domain?.edge_gateway_host ??
                    'edge.wammuhost.com'
            ),
            edgeGatewayHost: String(
                data.custom_domain?.edge_gateway_host ?? 'edge.wammuhost.com'
            ),
            probeHostname: String(
                data.custom_domain?.probe_hostname ??
                    data.custom_domain?.hostname ??
                    ''
            ),
        },
        defaultApiKey: data.default_api_key,
        defaultApiKeyPrefix: data.default_api_key_prefix,
        dnsVerification: {
            hostname: String(data.dns_verification?.hostname ?? ''),
            probeHostname: String(data.dns_verification?.probe_hostname ?? ''),
            edgeGatewayHost: String(
                data.dns_verification?.edge_gateway_host ??
                    'edge.wammuhost.com'
            ),
            directCnameVerified: Boolean(
                data.dns_verification?.direct_cname_verified
            ),
            ownershipVerified: Boolean(
                data.dns_verification?.ownership_verified
            ),
            cloudflareDetected: Boolean(
                data.dns_verification?.cloudflare_detected
            ),
            dnsStatus: String(data.dns_verification?.dns_status ?? 'pending'),
            sslStatus: String(data.dns_verification?.ssl_status ?? 'pending'),
            routingStatus: String(
                data.dns_verification?.routing_status ?? 'pending'
            ),
            passed: Boolean(data.dns_verification?.passed),
            instructions: {
                edgeGatewayHost: String(
                    data.dns_verification?.instructions?.edge_gateway_host ??
                        'edge.wammuhost.com'
                ),
                cnameHost: String(
                    data.dns_verification?.instructions?.cname_host ?? ''
                ),
                cnameType: String(
                    data.dns_verification?.instructions?.cname_type ?? 'CNAME'
                ),
                cnameTarget: String(
                    data.dns_verification?.instructions?.cname_target ??
                        'edge.wammuhost.com'
                ),
                ownershipHost: String(
                    data.dns_verification?.instructions?.ownership_host ?? ''
                ),
                ownershipType: String(
                    data.dns_verification?.instructions?.ownership_type ?? 'TXT'
                ),
                ownershipValue: String(
                    data.dns_verification?.instructions?.ownership_value ?? ''
                ),
                probeHostname: String(
                    data.dns_verification?.instructions?.probe_hostname ?? ''
                ),
                wildcard: Boolean(
                    data.dns_verification?.instructions?.wildcard
                ),
            },
            errors: data.dns_verification?.errors ?? [],
        },
        message: data.message,
    }
}

export default createResellerOnboarding
