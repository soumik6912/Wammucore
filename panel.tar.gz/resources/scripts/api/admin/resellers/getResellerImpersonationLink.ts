import http from '@/api/http'

export interface ResellerImpersonationLink {
    resellerId: number
    displayName: string
    impersonationUrl: string
    resellerAdminPath: string
    expiresAt: string
    message: string
}

const getResellerImpersonationLink = async (
    resellerId: number
): Promise<ResellerImpersonationLink> => {
    const {
        data: { data },
    } = await http.post(`/api/admin/resellers/${resellerId}/impersonation-link`)

    return {
        resellerId: data.reseller_id,
        displayName: data.display_name,
        impersonationUrl: data.impersonation_url,
        resellerAdminPath: data.reseller_admin_path,
        expiresAt: data.expires_at,
        message: data.message,
    }
}

export default getResellerImpersonationLink
