import http from '@/api/http'

export interface ResellerPoolData {
    resellerId: number
    displayName: string
    limits: {
        maxRamMb: number
        maxCpuCores: number
        maxDiskGb: number
        maxVms: number
    }
    usage: {
        usedRamMb: number
        usedCpuCores: number
        usedDiskGb: number
        usedVms: number
    }
    percentages: {
        ram: number
        cpu: number
        disk: number
        vms: number
    }
}

export interface UpdateResellerPoolPayload {
    maxRamMb: number
    maxCpuCores: number
    maxDiskGb: number
    maxVms: number
}

const rawPoolToData = (data: any): ResellerPoolData => ({
    resellerId: data.reseller_id,
    displayName: data.display_name,
    limits: {
        maxRamMb: data.limits.max_ram_mb,
        maxCpuCores: data.limits.max_cpu_cores,
        maxDiskGb: data.limits.max_disk_gb,
        maxVms: data.limits.max_vms,
    },
    usage: {
        usedRamMb: data.usage.used_ram_mb,
        usedCpuCores: data.usage.used_cpu_cores,
        usedDiskGb: data.usage.used_disk_gb,
        usedVms: data.usage.used_vms,
    },
    percentages: {
        ram: data.percentages.ram,
        cpu: data.percentages.cpu,
        disk: data.percentages.disk,
        vms: data.percentages.vms,
    },
})

export const getResellerPool = async (resellerId: number): Promise<ResellerPoolData> => {
    const {
        data: { data },
    } = await http.get(`/api/admin/resellers/${resellerId}/pool`)

    return rawPoolToData(data)
}

export const updateResellerPool = async (
    resellerId: number,
    payload: UpdateResellerPoolPayload
): Promise<ResellerPoolData> => {
    const {
        data: { data },
    } = await http.put(`/api/admin/resellers/${resellerId}/pool`, {
        max_ram_mb: payload.maxRamMb,
        max_cpu_cores: payload.maxCpuCores,
        max_disk_gb: payload.maxDiskGb,
        max_vms: payload.maxVms,
    })

    return rawPoolToData(data)
}

export const refreshResellerPool = async (
    resellerId: number
): Promise<ResellerPoolData> => {
    const {
        data: { data },
    } = await http.post(`/api/admin/resellers/${resellerId}/usage/refresh`)

    return rawPoolToData(data)
}
