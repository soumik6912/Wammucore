import http from '@/api/http'

interface ApproveResellerVerificationResponse {
    id: number
    status: string
    verificationStatus: string
    message: string
}

const approveResellerVerification = async (
    resellerId: number
): Promise<ApproveResellerVerificationResponse> => {
    const {
        data: { data },
    } = await http.post(`/api/admin/resellers/${resellerId}/verification/approve`)

    return {
        id: Number(data.id),
        status: String(data.status),
        verificationStatus: String(data.verification_status),
        message: String(data.message ?? 'Reseller verification approved.'),
    }
}

export default approveResellerVerification

