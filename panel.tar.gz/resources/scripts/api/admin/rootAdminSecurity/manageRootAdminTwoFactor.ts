import http from '@/api/http'

export interface RootAdminTwoFactorStatus {
    required: boolean
    configured: boolean
    confirmed: boolean
    confirmedAt: string | null
    setupRequired: boolean
}

export interface RootAdminTwoFactorSetupData extends RootAdminTwoFactorStatus {
    secret: string
    qrCodeUrl: string
    recoveryCodes: string[]
}

const mapStatus = (data: any): RootAdminTwoFactorStatus => ({
    required: Boolean(data.required),
    configured: Boolean(data.configured),
    confirmed: Boolean(data.confirmed),
    confirmedAt: data.confirmed_at ?? null,
    setupRequired: Boolean(data.setup_required),
})

const mapSetupData = (data: any): RootAdminTwoFactorSetupData => ({
    ...mapStatus(data),
    secret: String(data.secret ?? ''),
    qrCodeUrl: String(data.qr_code_url ?? ''),
    recoveryCodes: Array.isArray(data.recovery_codes)
        ? data.recovery_codes.map((code: unknown) => String(code))
        : [],
})

export const getRootAdminTwoFactorStatus = async (): Promise<RootAdminTwoFactorStatus> => {
    const {
        data: { data },
    } = await http.get('/api/admin/root-admin-security/two-factor')

    return mapStatus(data)
}

export const setupRootAdminTwoFactor = async (force: boolean = false): Promise<RootAdminTwoFactorSetupData> => {
    const {
        data: { data },
    } = await http.post('/api/admin/root-admin-security/two-factor/setup', {
        force,
    })

    return mapSetupData(data)
}

export const confirmRootAdminTwoFactor = async (code: string): Promise<RootAdminTwoFactorStatus> => {
    const {
        data: { data },
    } = await http.post('/api/admin/root-admin-security/two-factor/confirm', {
        code,
    })

    return mapStatus(data)
}

export const regenerateRootAdminRecoveryCodes = async (): Promise<string[]> => {
    const {
        data: { data },
    } = await http.post('/api/admin/root-admin-security/two-factor/recovery-codes')

    return Array.isArray(data.recovery_codes)
        ? data.recovery_codes.map((code: unknown) => String(code))
        : []
}

export const disableRootAdminTwoFactor = async (): Promise<RootAdminTwoFactorStatus> => {
    const {
        data: { data },
    } = await http.delete('/api/admin/root-admin-security/two-factor')

    return mapStatus(data)
}
