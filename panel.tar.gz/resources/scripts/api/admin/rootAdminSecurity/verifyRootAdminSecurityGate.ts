import http from '@/api/http'

interface VerifyPayload {
    password: string
    remember: boolean
    twoFactorCode?: string
    recoveryCode?: string
}

const verifyRootAdminSecurityGate = async ({
    password,
    remember,
    twoFactorCode,
    recoveryCode,
}: VerifyPayload): Promise<void> => {
    await http.post('/api/admin/root-admin-security/verify', {
        password,
        remember,
        two_factor_code: twoFactorCode,
        recovery_code: recoveryCode,
    })
}

export default verifyRootAdminSecurityGate
