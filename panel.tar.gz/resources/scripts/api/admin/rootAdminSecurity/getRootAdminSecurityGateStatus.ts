import http from '@/api/http'

export interface RootAdminSecurityGateStatus {
    enabled: boolean
    required: boolean
    verified: boolean
    verifiedUntil: string | null
    sessionTtlMinutes: number
    rememberTtlMinutes: number
    twoFactor: {
        required: boolean
        configured: boolean
        confirmed: boolean
        confirmedAt: string | null
        setupRequired: boolean
    }
}

const rawDataToStatus = (data: any): RootAdminSecurityGateStatus => ({
    enabled: Boolean(data.enabled),
    required: Boolean(data.required),
    verified: Boolean(data.verified),
    verifiedUntil: data.verified_until ?? null,
    sessionTtlMinutes: Number(data.session_ttl_minutes ?? 30),
    rememberTtlMinutes: Number(data.remember_ttl_minutes ?? 10080),
    twoFactor: {
        required: Boolean(data.two_factor?.required),
        configured: Boolean(data.two_factor?.configured),
        confirmed: Boolean(data.two_factor?.confirmed),
        confirmedAt: data.two_factor?.confirmed_at ?? null,
        setupRequired: Boolean(data.two_factor?.setup_required),
    },
})

const getRootAdminSecurityGateStatus =
    async (): Promise<RootAdminSecurityGateStatus> => {
        const {
            data: { data },
        } = await http.get('/api/admin/root-admin-security/status', {
            showProgress: false,
        } as any)

        return rawDataToStatus(data)
    }

export default getRootAdminSecurityGateStatus
