import http from '@/api/http'
import {
    NotificationTemplate,
    PanelSettings,
    rawDataToPanelSettings,
} from '@/api/admin/settings/getPanelSettings'

interface UpdatePanelSettingsPayload {
    panelName: string
    logoUrl: string
    loginBackgroundImage: string
    bannerImageUrl: string
    faviconUrl: string
    loadingLogoUrl: string
    billingUrl: string
    platformStoreRedirectUrl: string
    platformUpgradeEnabled: boolean
    platformUpgradeUrlTemplate: string
    apiDocsUrl: string
    tutorialUrl: string
    resellerRegistrationTermsUrl: string
    resellerRegistrationPrivacyUrl: string
    resellerRegistrationEnabled: boolean
    resellerKyc?: {
        aadhaarEnabled: boolean
        panEnabled: boolean
        digilockerEnabled: boolean
        digilockerUrl: string
    }
    resellerEmailVerificationEnabled: boolean
    passwordResetEnabled: boolean
    resourceGuard: {
        enabled: boolean
        thresholdPercent: number
    }
    trustpilotReview: {
        enabled: boolean
        url: string
        viewThreshold: number
        delayDays: number
    }
    logRetention: {
        defaultDays: number
        adminDays: number
        userActivityDays: number
        authDays: number
        securityDays: number
        billingDays: number
        applicationDays: number
    }
    customDomains: {
        edgeGatewayHost: string
        verificationPrefix: string
        autoSslEnabled: boolean
        sslContactEmail: string
    }
    defaultPlanCurrency: string
    platformMail: {
        enabled: boolean
        host: string
        port: string
        encryption: 'tls' | 'ssl' | 'none'
        username: string
        password?: string
        fromEmail: string
        fromName: string
        replyToEmail: string
        ehloDomain: string
    }
    notificationEmailEnabled: boolean
    notificationTemplates: NotificationTemplate[]
    licenseCatalog: {
        id?: string
        name: string
        description?: string | null
        startsAt?: string | null
        priceDisplay?: string | null
        learnMoreUrl?: string | null
        purchaseUrl?: string | null
        iconUrl?: string | null
    }[]
    footerText: string
    footerUrl: string
    brandPrimaryColor?: string | null
    brandSecondaryColor?: string | null
    brandAccentColor?: string | null
    customCss?: string | null
    tenantThemeKey?: string | null
}

export interface UpdatePanelEmailSettingsPayload {
    resellerEmailVerificationEnabled: boolean
    passwordResetEnabled: boolean
    platformMail: {
        enabled: boolean
        host: string
        port: string
        encryption: 'tls' | 'ssl' | 'none'
        username: string
        password?: string
        fromEmail: string
        fromName: string
        replyToEmail: string
        ehloDomain: string
    }
    notificationEmailEnabled: boolean
    notificationTemplates: NotificationTemplate[]
}

export interface UpdatePanelResellerSettingsPayload {
    resellerRegistrationTermsUrl: string
    resellerRegistrationPrivacyUrl: string
    resellerRegistrationEnabled: boolean
    resellerKyc: {
        aadhaarEnabled: boolean
        panEnabled: boolean
        digilockerEnabled: boolean
        digilockerUrl: string
    }
}

const updatePanelSettings = async (payload: UpdatePanelSettingsPayload): Promise<PanelSettings> => {
    const {
        data: { data },
    } = await http.patch('/api/admin/settings/panel', {
        panel_name: payload.panelName.trim(),
        logo_url: payload.logoUrl.trim() || null,
        login_background_image: payload.loginBackgroundImage.trim() || null,
        banner_image_url: payload.bannerImageUrl.trim() || null,
        favicon_url: payload.faviconUrl.trim() || null,
        loading_logo_url: payload.loadingLogoUrl.trim() || null,
        billing_url: payload.billingUrl.trim() || null,
        platform_store_redirect_url:
            payload.platformStoreRedirectUrl.trim() || null,
        platform_upgrade_enabled: payload.platformUpgradeEnabled,
        platform_upgrade_url_template:
            payload.platformUpgradeUrlTemplate.trim() || null,
        api_docs_url: payload.apiDocsUrl.trim() || null,
        tutorial_url: payload.tutorialUrl.trim() || null,
        reseller_registration_terms_url:
            payload.resellerRegistrationTermsUrl.trim() || null,
        reseller_registration_privacy_url:
            payload.resellerRegistrationPrivacyUrl.trim() || null,
        reseller_registration_enabled: payload.resellerRegistrationEnabled,
        ...(payload.resellerKyc
            ? {
                  reseller_kyc_aadhaar_enabled:
                      payload.resellerKyc.aadhaarEnabled,
                  reseller_kyc_pan_enabled: payload.resellerKyc.panEnabled,
                  reseller_kyc_digilocker_enabled:
                      payload.resellerKyc.digilockerEnabled,
                  reseller_kyc_digilocker_url:
                      payload.resellerKyc.digilockerUrl.trim() || null,
              }
            : {}),
        reseller_email_verification_enabled:
            payload.resellerEmailVerificationEnabled,
        password_reset_enabled: payload.passwordResetEnabled,
        resource_guard_enabled: payload.resourceGuard.enabled,
        resource_guard_threshold_percent: payload.resourceGuard.thresholdPercent,
        trustpilot_review_enabled: payload.trustpilotReview.enabled,
        trustpilot_review_url: payload.trustpilotReview.url.trim() || null,
        trustpilot_review_prompt_view_threshold:
            payload.trustpilotReview.viewThreshold,
        trustpilot_review_prompt_delay_days: payload.trustpilotReview.delayDays,
        log_retention_default_days: payload.logRetention.defaultDays,
        log_retention_admin_days: payload.logRetention.adminDays,
        log_retention_user_activity_days:
            payload.logRetention.userActivityDays,
        log_retention_auth_days: payload.logRetention.authDays,
        log_retention_security_days: payload.logRetention.securityDays,
        log_retention_billing_days: payload.logRetention.billingDays,
        log_retention_application_days:
            payload.logRetention.applicationDays,
        custom_domain_edge_gateway_host:
            payload.customDomains.edgeGatewayHost.trim() ||
            'edge.wammuhost.com',
        custom_domain_verification_prefix:
            payload.customDomains.verificationPrefix.trim() ||
            '_wammuhost-verify',
        custom_domain_auto_ssl_enabled:
            payload.customDomains.autoSslEnabled,
        custom_domain_ssl_contact_email:
            payload.customDomains.sslContactEmail.trim() || null,
        default_plan_currency:
            payload.defaultPlanCurrency.trim().toUpperCase() || 'USD',
        platform_mail_enabled: payload.platformMail.enabled,
        platform_mail_host: payload.platformMail.host.trim() || null,
        platform_mail_port:
            payload.platformMail.port.trim() === ''
                ? null
                : Number(payload.platformMail.port),
        platform_mail_encryption:
            payload.platformMail.encryption === 'none'
                ? 'none'
                : payload.platformMail.encryption,
        platform_mail_username:
            payload.platformMail.username.trim() || null,
        ...(payload.platformMail.password !== undefined
            ? {
                  platform_mail_password:
                      payload.platformMail.password.trim() || null,
              }
            : {}),
        platform_mail_from_address:
            payload.platformMail.fromEmail.trim() || null,
        platform_mail_from_name: payload.platformMail.fromName.trim() || null,
        platform_mail_reply_to_email:
            payload.platformMail.replyToEmail.trim() || null,
        platform_mail_ehlo_domain:
            payload.platformMail.ehloDomain.trim() || null,
        notification_email_enabled: payload.notificationEmailEnabled,
        notification_templates: Object.fromEntries(
            payload.notificationTemplates.map(template => [
                template.key,
                {
                    enabled: template.enabled,
                    subject: template.subject,
                    heading: template.heading,
                    body: template.body,
                },
            ])
        ),
        license_catalog: payload.licenseCatalog.map(item => ({
            id: item.id || null,
            name: item.name,
            description: item.description || null,
            starts_at: item.startsAt || null,
            price_display: item.priceDisplay || null,
            learn_more_url: item.learnMoreUrl || null,
            purchase_url: item.purchaseUrl || null,
            icon_url: item.iconUrl || null,
        })),
        footer_text: payload.footerText.trim() || 'WammuCore',
        footer_url: payload.footerUrl.trim() || 'https://wammuhost.com',
        brand_primary_color: payload.brandPrimaryColor?.trim() || null,
        brand_secondary_color: payload.brandSecondaryColor?.trim() || null,
        brand_accent_color: payload.brandAccentColor?.trim() || null,
        custom_css: payload.customCss?.trim() || null,
        tenant_theme_key: payload.tenantThemeKey?.trim() || 'wammuhost',
    })

    return rawDataToPanelSettings(data)
}

export const updatePanelEmailSettings = async (
    payload: UpdatePanelEmailSettingsPayload
): Promise<PanelSettings> => {
    const {
        data: { data },
    } = await http.patch('/api/admin/settings/panel', {
        reseller_email_verification_enabled:
            payload.resellerEmailVerificationEnabled,
        password_reset_enabled: payload.passwordResetEnabled,
        platform_mail_enabled: payload.platformMail.enabled,
        platform_mail_host: payload.platformMail.host.trim() || null,
        platform_mail_port:
            payload.platformMail.port.trim() === ''
                ? null
                : Number(payload.platformMail.port),
        platform_mail_encryption:
            payload.platformMail.encryption === 'none'
                ? 'none'
                : payload.platformMail.encryption,
        platform_mail_username:
            payload.platformMail.username.trim() || null,
        ...(payload.platformMail.password !== undefined
            ? {
                  platform_mail_password:
                      payload.platformMail.password.trim() || null,
              }
            : {}),
        platform_mail_from_address:
            payload.platformMail.fromEmail.trim() || null,
        platform_mail_from_name: payload.platformMail.fromName.trim() || null,
        platform_mail_reply_to_email:
            payload.platformMail.replyToEmail.trim() || null,
        platform_mail_ehlo_domain:
            payload.platformMail.ehloDomain.trim() || null,
        notification_email_enabled: payload.notificationEmailEnabled,
        notification_templates: Object.fromEntries(
            payload.notificationTemplates.map(template => [
                template.key,
                {
                    enabled: template.enabled,
                    subject: template.subject,
                    heading: template.heading,
                    body: template.body,
                },
            ])
        ),
    })

    return rawDataToPanelSettings(data)
}

export const updatePanelResellerSettings = async (
    payload: UpdatePanelResellerSettingsPayload
): Promise<PanelSettings> => {
    const {
        data: { data },
    } = await http.patch('/api/admin/settings/panel', {
        reseller_registration_terms_url:
            payload.resellerRegistrationTermsUrl.trim() || null,
        reseller_registration_privacy_url:
            payload.resellerRegistrationPrivacyUrl.trim() || null,
        reseller_registration_enabled:
            payload.resellerRegistrationEnabled,
        reseller_kyc_aadhaar_enabled: payload.resellerKyc.aadhaarEnabled,
        reseller_kyc_pan_enabled: payload.resellerKyc.panEnabled,
        reseller_kyc_digilocker_enabled: payload.resellerKyc.digilockerEnabled,
        reseller_kyc_digilocker_url:
            payload.resellerKyc.digilockerUrl.trim() || null,
    })

    return rawDataToPanelSettings(data)
}

export const sendPanelTestMail = async (
    recipient?: string | null,
    templateKey?: string | null
): Promise<string> => {
    const {
        data: { data },
    } = await http.post('/api/admin/settings/panel/test-mail', {
        recipient: recipient && recipient.trim() !== '' ? recipient.trim() : null,
        template_key:
            templateKey && templateKey.trim() !== '' ? templateKey.trim() : null,
    })

    return data.recipient
}

export default updatePanelSettings


