import http from '@/api/http'

export interface NotificationTemplate {
    key: string
    label: string
    description: string
    enabled: boolean
    subject: string
    heading: string
    body: string
}

export interface PanelSettings {
    panelName: string
    logoUrl: string | null
    loginBackgroundImage: string | null
    bannerImageUrl: string | null
    faviconUrl: string | null
    loadingLogoUrl: string | null
    billingUrl: string | null
    platformStoreRedirectUrl: string | null
    effectiveStorefrontUrl: string | null
    platformUpgradeEnabled: boolean
    platformUpgradeUrlTemplate: string | null
    upgradeButtonEnabled: boolean
    upgradeUrlTemplate: string | null
    apiDocsUrl: string | null
    tutorialUrl: string | null
    resellerRegistrationTermsUrl: string | null
    resellerRegistrationPrivacyUrl: string | null
    resellerRegistrationEnabled: boolean
    resellerKyc: {
        aadhaarEnabled: boolean
        panEnabled: boolean
        digilockerEnabled: boolean
        digilockerUrl: string | null
    }
    resellerEmailVerificationEnabled: boolean
    resellerEmailVerificationAvailable: boolean
    resellerEmailVerificationEffective: boolean
    passwordResetEnabled: boolean
    passwordResetAvailable: boolean
    passwordResetEffective: boolean
    resourceGuard: {
        enabled: boolean
        thresholdPercent: number
    }
    trustpilotReview: {
        enabled: boolean
        url: string | null
        viewThreshold: number
        delayDays: number
    }
    logRetention: {
        defaultDays: number
        adminDays: number
        userActivityDays: number
        authDays: number
        securityDays: number
        billingDays: number
        applicationDays: number
    }
    customDomains: {
        edgeGatewayHost: string
        verificationPrefix: string
        autoSslEnabled: boolean
        sslContactEmail: string | null
    }
    defaultPlanCurrency: string
    platformMail: {
        enabled: boolean
        configured: boolean
        source: 'panel' | 'env' | 'none'
        host: string | null
        port: number | null
        encryption: 'tls' | 'ssl' | 'none'
        username: string | null
        passwordSet: boolean
        fromEmail: string | null
        fromName: string | null
        replyToEmail: string | null
        ehloDomain: string | null
    }
    notificationEmailEnabled: boolean
    notificationEmailAvailable: boolean
    notificationEmailEffective: boolean
    notificationTemplates: NotificationTemplate[]
    licenseCatalog: {
        id?: string
        name: string
        description?: string | null
        startsAt?: string | null
        priceDisplay?: string | null
        learnMoreUrl?: string | null
        purchaseUrl?: string | null
        iconUrl?: string | null
    }[]
    footerText: string
    footerUrl: string
    brandPrimaryColor: string | null
    brandSecondaryColor: string | null
    brandAccentColor: string | null
    customCss: string | null
    tenantThemeKey: string
}

const rawDataToPanelSettings = (data: any): PanelSettings => ({
    panelName: data.panel_name || 'WammuCore',
    logoUrl: data.logo_url || null,
    loginBackgroundImage: data.login_background_image || null,
    bannerImageUrl: data.banner_image_url || null,
    faviconUrl: data.favicon_url || null,
    loadingLogoUrl: data.loading_logo_url || null,
    billingUrl: data.billing_url || null,
    platformStoreRedirectUrl: data.platform_store_redirect_url || null,
    effectiveStorefrontUrl: data.effective_storefront_url || null,
    platformUpgradeEnabled: Boolean(data.platform_upgrade_enabled ?? true),
    platformUpgradeUrlTemplate: data.platform_upgrade_url_template || null,
    upgradeButtonEnabled: Boolean(data.upgrade_button_enabled ?? true),
    upgradeUrlTemplate: data.upgrade_url_template || null,
    apiDocsUrl: data.api_docs_url || null,
    tutorialUrl: data.tutorial_url || null,
    resellerRegistrationTermsUrl:
        data.reseller_registration_terms_url || null,
    resellerRegistrationPrivacyUrl:
        data.reseller_registration_privacy_url || null,
    resellerRegistrationEnabled: Boolean(data.reseller_registration_enabled),
    resellerKyc: {
        aadhaarEnabled: Boolean(data.reseller_kyc_aadhaar_enabled ?? true),
        panEnabled: Boolean(data.reseller_kyc_pan_enabled ?? true),
        digilockerEnabled: Boolean(data.reseller_kyc_digilocker_enabled),
        digilockerUrl: data.reseller_kyc_digilocker_url || null,
    },
    resellerEmailVerificationEnabled: Boolean(
        data.reseller_email_verification_enabled
    ),
    resellerEmailVerificationAvailable: Boolean(
        data.reseller_email_verification_available
    ),
    resellerEmailVerificationEffective: Boolean(
        data.reseller_email_verification_effective
    ),
    passwordResetEnabled: Boolean(data.password_reset_enabled),
    passwordResetAvailable: Boolean(data.password_reset_available),
    passwordResetEffective: Boolean(data.password_reset_effective),
    resourceGuard: {
        enabled: Boolean(data.resource_guard_enabled ?? true),
        thresholdPercent: Number(data.resource_guard_threshold_percent ?? 98),
    },
    trustpilotReview: {
        enabled: Boolean(data.trustpilot_review_enabled),
        url: data.trustpilot_review_url || null,
        viewThreshold: Number(
            data.trustpilot_review_prompt_view_threshold ?? 10
        ),
        delayDays: Number(data.trustpilot_review_prompt_delay_days ?? 1),
    },
    logRetention: {
        defaultDays: Number(data.log_retention_default_days ?? 10),
        adminDays: Number(data.log_retention_admin_days ?? 10),
        userActivityDays: Number(
            data.log_retention_user_activity_days ?? 10
        ),
        authDays: Number(data.log_retention_auth_days ?? 10),
        securityDays: Number(data.log_retention_security_days ?? 10),
        billingDays: Number(data.log_retention_billing_days ?? 10),
        applicationDays: Number(
            data.log_retention_application_days ?? 10
        ),
    },
    customDomains: {
        edgeGatewayHost:
            data.custom_domain_edge_gateway_host || 'edge.wammuhost.com',
        verificationPrefix:
            data.custom_domain_verification_prefix || '_wammuhost-verify',
        autoSslEnabled: Boolean(data.custom_domain_auto_ssl_enabled ?? true),
        sslContactEmail: data.custom_domain_ssl_contact_email || null,
    },
    defaultPlanCurrency: data.default_plan_currency || 'USD',
    platformMail: {
        enabled: Boolean(data.platform_mail_enabled),
        configured: Boolean(data.platform_mail_configured),
        source: (data.platform_mail_source || 'none') as
            | 'panel'
            | 'env'
            | 'none',
        host: data.platform_mail_host || null,
        port:
            typeof data.platform_mail_port === 'number'
                ? data.platform_mail_port
                : null,
        encryption:
            data.platform_mail_encryption === 'ssl' ||
            data.platform_mail_encryption === 'tls'
                ? data.platform_mail_encryption
                : 'none',
        username: data.platform_mail_username || null,
        passwordSet: Boolean(data.platform_mail_password_set),
        fromEmail: data.platform_mail_from_address || null,
        fromName: data.platform_mail_from_name || null,
        replyToEmail: data.platform_mail_reply_to_email || null,
        ehloDomain: data.platform_mail_ehlo_domain || null,
    },
    notificationEmailEnabled: Boolean(data.notification_email_enabled),
    notificationEmailAvailable: Boolean(data.notification_email_available),
    notificationEmailEffective: Boolean(data.notification_email_effective),
    notificationTemplates: Object.entries(
        data.notification_templates || {}
    ).map(([key, item]: [string, any]) => ({
        key: item.key || key,
        label: item.label || key,
        description: item.description || '',
        enabled: Boolean(item.enabled ?? true),
        subject: item.subject || '',
        heading: item.heading || '',
        body: item.body || '',
    })),
    licenseCatalog: (data.license_catalog || []).map((item: any) => ({
        id: item.id,
        name: item.name,
        description: item.description || null,
        startsAt: item.starts_at || null,
        priceDisplay: item.price_display || null,
        learnMoreUrl: item.learn_more_url || null,
        purchaseUrl: item.purchase_url || null,
        iconUrl: item.icon_url || null,
    })),
    footerText: data.footer_text || 'WammuCore',
    footerUrl: data.footer_url || 'https://wammuhost.com',
    brandPrimaryColor: data.brand_primary_color || null,
    brandSecondaryColor: data.brand_secondary_color || null,
    brandAccentColor: data.brand_accent_color || null,
    customCss: data.custom_css || null,
    tenantThemeKey: data.tenant_theme_key || 'wammuhost',
})

const getPanelSettings = async (): Promise<PanelSettings> => {
    const {
        data: { data },
    } = await http.get('/api/admin/settings/panel')

    return rawDataToPanelSettings(data)
}

export { rawDataToPanelSettings }
export default getPanelSettings


