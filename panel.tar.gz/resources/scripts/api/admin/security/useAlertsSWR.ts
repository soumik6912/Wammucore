import useSWR from 'swr'

import getAlerts, {
    SecurityAlertsResponse,
} from '@/api/admin/security/getAlerts'
import { SecurityAlertsQuery } from '@/api/admin/security/types'

const useAlertsSWR = (params: SecurityAlertsQuery) => {
    return useSWR<SecurityAlertsResponse>(
        [
            'admin:security:alerts',
            params.page,
            params.perPage,
            params.query,
            params.status,
            params.severity,
        ],
        () => getAlerts(params, { showProgress: false }),
        {
            refreshInterval: 30000,
            revalidateOnFocus: false,
            refreshWhenHidden: false,
            refreshWhenOffline: false,
        }
    )
}

export default useAlertsSWR
