import useSWR from 'swr'

import getOverview from '@/api/admin/security/getOverview'
import { SecurityOverview } from '@/api/admin/security/types'

const useOverviewSWR = () => {
    return useSWR<SecurityOverview>(
        'admin:security:overview',
        () => getOverview({ showProgress: false }),
        {
            refreshInterval: 30000,
            revalidateOnFocus: false,
            refreshWhenHidden: false,
            refreshWhenOffline: false,
        }
    )
}

export default useOverviewSWR
