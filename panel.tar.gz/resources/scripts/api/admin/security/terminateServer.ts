import http from '@/api/http'

const terminateServer = async (serverUuid: string) => {
    await http.post(`/api/admin/security/servers/${serverUuid}/terminate`)
}

export default terminateServer
