import http from '@/api/http'

const suspendServer = async (serverUuid: string) => {
    await http.post(`/api/admin/security/servers/${serverUuid}/suspend`)
}

export default suspendServer
