import http, { WammuCoreRequestConfig } from '@/api/http'
import {
    rawDataToSecurityPolicySettings,
    SecurityPolicySettings,
} from '@/api/admin/security/types'

const getSettings = async (
    options?: WammuCoreRequestConfig
): Promise<SecurityPolicySettings> => {
    const { data } = await http.get('/api/admin/security/settings', options)

    return rawDataToSecurityPolicySettings(data.data)
}

export default getSettings
