import { PaginationDataSet } from '@/api/http'

export type SecurityRiskStatus = 'normal' | 'warning' | 'high' | 'suspended'
export type SecurityAlertStatus = 'open' | 'resolved'
export type SecuritySeverity = 'info' | 'warning' | 'high' | 'critical'

export interface SecurityOverview {
    activeServers: number
    suspendedServers: number
    openAlerts: number
    criticalAlerts: number
    highRiskServers: number
    platformHardening: SecurityPlatformHardening
}

export interface SecurityPlatformHardeningNodeWarning {
    name: string
    fqdn: string
    reason: string
    resolvedIps: string[]
}

export interface SecurityPlatformHardening {
    rbacEnabled: boolean
    tenantIsolationEnabled: boolean
    csrfEnabled: boolean
    jwtRotationEnabled: boolean
    apiScopesEnabled: boolean
    trustedEdgeEnabled: boolean
    cloudflareValidationEnabled: boolean
    trustedEdgeCount: number
    trustedProxyCount: number
    botProtectionEnabled: boolean
    internalServicesPrivate: boolean
    internalSecretConfigured: boolean
    rateLimitStore: string
    redisRateLimits: boolean
    secureSessionCookie: boolean
    sessionDriver: string
    proxmoxPrivateOnly: boolean
    publicProxmoxNodes: SecurityPlatformHardeningNodeWarning[]
    wafCompatible: boolean
    recommendedActions: string[]
}

export interface SecurityPolicySettings {
    ddosMonitorEnabled: boolean
    autoSuspendEnabled: boolean
    suspendCriticalImmediately: boolean
    warningAfterViolations: number
    suspendAfterViolations: number
    violationDecayMinutes: number
    incomingAlertWebhookUrl: string | null
    outgoingAlertWebhookUrl: string | null
    discordWebhookUrl: string | null
    webhookOnWarning: boolean
    webhookOnSuspend: boolean
    webhookOnTerminate: boolean
}

export interface SecurityTrafficItem {
    serverId: number | null
    serverUuid: string | null
    serverName: string | null
    resellerId: number | null
    resellerName: string | null
    ownerId: number | null
    owner: string | null
    ip: string | null
    allIps: string[]
    outboundMbps: number
    score: number
    consecutiveViolations: number
    status: SecurityRiskStatus
    serverStatus: string | null
    autoSuspendEnabled: boolean
    lastEvaluatedAt: Date | null
}

export interface SecurityScoreItem {
    serverId: number | null
    serverUuid: string | null
    serverName: string | null
    resellerId: number | null
    resellerName: string | null
    ownerId: number | null
    owner: string | null
    ip: string | null
    allIps: string[]
    score: number
    consecutiveViolations: number
    status: SecurityRiskStatus
    serverStatus: string | null
    openAlertsCount: number
    outboundMbpsLimit: number
    lastOutboundMbps: number
    warningThreshold: number
    throttleThreshold: number
    suspendThreshold: number
    autoSuspendEnabled: boolean
    lastEvaluatedAt: Date | null
    lastViolationAt: Date | null
    lastWarningAt: Date | null
    suspendedBySecurityAt: Date | null
}

export interface SecurityAlertItem {
    id: number
    serverId: number | null
    serverUuid: string | null
    serverName: string | null
    resellerId: number | null
    resellerName: string | null
    ownerId: number | null
    owner: string | null
    allIps: string[]
    type: string
    severity: SecuritySeverity
    title: string
    message: string | null
    status: SecurityAlertStatus
    createdAt: Date | null
    resolvedAt: Date | null
}

export interface SecurityListQuery {
    page?: number
    perPage?: number
    query?: string | null
    status?: string | null
}

export interface SecurityAlertsQuery extends SecurityListQuery {
    severity?: string | null
}

export const mapSecurityPagination = (
    meta: any,
    count: number
): PaginationDataSet => ({
    total: Number(meta?.total ?? count),
    count,
    perPage: Number(meta?.per_page ?? count),
    currentPage: Number(meta?.current_page ?? 1),
    totalPages: Number(meta?.last_page ?? 1),
})

export const rawDataToSecurityOverview = (data: any): SecurityOverview => ({
    activeServers: Number(data.active_servers ?? 0),
    suspendedServers: Number(data.suspended_servers ?? 0),
    openAlerts: Number(data.open_alerts ?? 0),
    criticalAlerts: Number(data.critical_alerts ?? 0),
    highRiskServers: Number(data.high_risk_servers ?? 0),
    platformHardening: {
        rbacEnabled: Boolean(data.platform_hardening?.rbac_enabled),
        tenantIsolationEnabled: Boolean(data.platform_hardening?.tenant_isolation_enabled),
        csrfEnabled: Boolean(data.platform_hardening?.csrf_enabled),
        jwtRotationEnabled: Boolean(data.platform_hardening?.jwt_rotation_enabled),
        apiScopesEnabled: Boolean(data.platform_hardening?.api_scopes_enabled),
        trustedEdgeEnabled: Boolean(data.platform_hardening?.trusted_edge_enabled),
        cloudflareValidationEnabled: Boolean(
            data.platform_hardening?.cloudflare_validation_enabled
        ),
        trustedEdgeCount: Number(data.platform_hardening?.trusted_edge_count ?? 0),
        trustedProxyCount: Number(data.platform_hardening?.trusted_proxy_count ?? 0),
        botProtectionEnabled: Boolean(data.platform_hardening?.bot_protection_enabled),
        internalServicesPrivate: Boolean(
            data.platform_hardening?.internal_services_private
        ),
        internalSecretConfigured: Boolean(
            data.platform_hardening?.internal_secret_configured
        ),
        rateLimitStore: String(data.platform_hardening?.rate_limit_store ?? 'file'),
        redisRateLimits: Boolean(data.platform_hardening?.redis_rate_limits),
        secureSessionCookie: Boolean(data.platform_hardening?.secure_session_cookie),
        sessionDriver: String(data.platform_hardening?.session_driver ?? 'file'),
        proxmoxPrivateOnly: Boolean(data.platform_hardening?.proxmox_private_only),
        publicProxmoxNodes: Array.isArray(data.platform_hardening?.public_proxmox_nodes)
            ? data.platform_hardening.public_proxmox_nodes.map((node: any) => ({
                  name: String(node?.name ?? ''),
                  fqdn: String(node?.fqdn ?? ''),
                  reason: String(node?.reason ?? ''),
                  resolvedIps: Array.isArray(node?.resolved_ips) ? node.resolved_ips : [],
              }))
            : [],
        wafCompatible: Boolean(data.platform_hardening?.waf_compatible),
        recommendedActions: Array.isArray(data.platform_hardening?.recommended_actions)
            ? data.platform_hardening.recommended_actions.map((item: any) => String(item))
            : [],
    },
})

export const rawDataToSecurityPolicySettings = (
    data: any
): SecurityPolicySettings => ({
    ddosMonitorEnabled: Boolean(data.ddos_monitor_enabled),
    autoSuspendEnabled: Boolean(data.auto_suspend_enabled),
    suspendCriticalImmediately: Boolean(data.suspend_critical_immediately),
    warningAfterViolations: Number(data.warning_after_violations ?? 1),
    suspendAfterViolations: Number(data.suspend_after_violations ?? 3),
    violationDecayMinutes: Number(data.violation_decay_minutes ?? 20),
    incomingAlertWebhookUrl: data.incoming_alert_webhook_url ?? null,
    outgoingAlertWebhookUrl: data.outgoing_alert_webhook_url ?? null,
    discordWebhookUrl: data.discord_webhook_url ?? null,
    webhookOnWarning: Boolean(data.webhook_on_warning),
    webhookOnSuspend: Boolean(data.webhook_on_suspend),
    webhookOnTerminate: Boolean(data.webhook_on_terminate),
})

export const rawDataToSecurityTrafficItem = (data: any): SecurityTrafficItem => ({
    serverId: data.server_id ?? null,
    serverUuid: data.server_uuid ?? null,
    serverName: data.server_name ?? null,
    resellerId: data.reseller_id ?? null,
    resellerName: data.reseller_name ?? null,
    ownerId: data.owner_id ?? null,
    owner: data.owner ?? null,
    ip: data.ip ?? null,
    allIps: Array.isArray(data.all_ips) ? data.all_ips : [],
    outboundMbps: Number(data.outbound_mbps ?? 0),
    score: Number(data.score ?? 0),
    consecutiveViolations: Number(data.consecutive_violations ?? 0),
    status: data.status ?? 'normal',
    serverStatus: data.server_status ?? null,
    autoSuspendEnabled: Boolean(data.auto_suspend_enabled),
    lastEvaluatedAt: data.last_evaluated_at
        ? new Date(data.last_evaluated_at)
        : null,
})

export const rawDataToSecurityScoreItem = (data: any): SecurityScoreItem => ({
    serverId: data.server_id ?? null,
    serverUuid: data.server_uuid ?? null,
    serverName: data.server_name ?? null,
    resellerId: data.reseller_id ?? null,
    resellerName: data.reseller_name ?? null,
    ownerId: data.owner_id ?? null,
    owner: data.owner ?? null,
    ip: data.ip ?? null,
    allIps: Array.isArray(data.all_ips) ? data.all_ips : [],
    score: Number(data.score ?? 0),
    consecutiveViolations: Number(data.consecutive_violations ?? 0),
    status: data.status ?? 'normal',
    serverStatus: data.server_status ?? null,
    openAlertsCount: Number(data.open_alerts_count ?? 0),
    outboundMbpsLimit: Number(data.outbound_mbps_limit ?? 0),
    lastOutboundMbps: Number(data.last_outbound_mbps ?? 0),
    warningThreshold: Number(data.warning_threshold ?? 0),
    throttleThreshold: Number(data.throttle_threshold ?? 0),
    suspendThreshold: Number(data.suspend_threshold ?? 0),
    autoSuspendEnabled: Boolean(data.auto_suspend_enabled),
    lastEvaluatedAt: data.last_evaluated_at
        ? new Date(data.last_evaluated_at)
        : null,
    lastViolationAt: data.last_violation_at
        ? new Date(data.last_violation_at)
        : null,
    lastWarningAt: data.last_warning_at
        ? new Date(data.last_warning_at)
        : null,
    suspendedBySecurityAt: data.suspended_by_security_at
        ? new Date(data.suspended_by_security_at)
        : null,
})

export const rawDataToSecurityAlertItem = (data: any): SecurityAlertItem => ({
    id: Number(data.id),
    serverId: data.server_id ?? null,
    serverUuid: data.server_uuid ?? null,
    serverName: data.server_name ?? null,
    resellerId: data.reseller_id ?? null,
    resellerName: data.reseller_name ?? null,
    ownerId: data.owner_id ?? null,
    owner: data.owner ?? null,
    allIps: Array.isArray(data.all_ips) ? data.all_ips : [],
    type: data.type ?? '',
    severity: data.severity ?? 'warning',
    title: data.title ?? '',
    message: data.message ?? null,
    status: data.status ?? 'open',
    createdAt: data.created_at ? new Date(data.created_at) : null,
    resolvedAt: data.resolved_at ? new Date(data.resolved_at) : null,
})
