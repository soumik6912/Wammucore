import http from '@/api/http'

const resolveAlert = async (alertId: number) => {
    const { data } = await http.patch(`/api/admin/security/alerts/${alertId}/resolve`)

    return data.data
}

export default resolveAlert
