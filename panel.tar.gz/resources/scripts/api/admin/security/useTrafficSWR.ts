import useSWR from 'swr'

import getTraffic, {
    SecurityTrafficResponse,
} from '@/api/admin/security/getTraffic'
import { SecurityListQuery } from '@/api/admin/security/types'

const useTrafficSWR = (params: SecurityListQuery) => {
    return useSWR<SecurityTrafficResponse>(
        [
            'admin:security:traffic',
            params.page,
            params.perPage,
            params.query,
            params.status,
        ],
        () => getTraffic(params, { showProgress: false }),
        {
            refreshInterval: 30000,
            revalidateOnFocus: false,
            refreshWhenHidden: false,
            refreshWhenOffline: false,
        }
    )
}

export default useTrafficSWR
