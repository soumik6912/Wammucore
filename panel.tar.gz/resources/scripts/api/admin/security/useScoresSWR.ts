import useSWR from 'swr'

import getScores, {
    SecurityScoreResponse,
} from '@/api/admin/security/getScores'
import { SecurityListQuery } from '@/api/admin/security/types'

const useScoresSWR = (params: SecurityListQuery) => {
    return useSWR<SecurityScoreResponse>(
        [
            'admin:security:scores',
            params.page,
            params.perPage,
            params.query,
            params.status,
        ],
        () => getScores(params, { showProgress: false }),
        {
            refreshInterval: 30000,
            revalidateOnFocus: false,
            refreshWhenHidden: false,
            refreshWhenOffline: false,
        }
    )
}

export default useScoresSWR
