import http, { PaginatedResult, WammuCoreRequestConfig } from '@/api/http'
import {
    SecurityAlertItem,
    SecurityAlertsQuery,
    mapSecurityPagination,
    rawDataToSecurityAlertItem,
} from '@/api/admin/security/types'

export type SecurityAlertsResponse = PaginatedResult<SecurityAlertItem>

const getAlerts = async ({
    page,
    perPage = 25,
    query,
    status = 'open',
    severity = 'all',
}: SecurityAlertsQuery, options?: WammuCoreRequestConfig): Promise<SecurityAlertsResponse> => {
    const { data } = await http.get('/api/admin/security/alerts', {
        params: {
            page,
            per_page: perPage,
            query: query || undefined,
            status: status || undefined,
            severity: severity || undefined,
        },
        ...options,
    })

    const items = (data.data?.items || []).map(rawDataToSecurityAlertItem)

    return {
        items,
        pagination: mapSecurityPagination(data.data?.meta, items.length),
    }
}

export default getAlerts
