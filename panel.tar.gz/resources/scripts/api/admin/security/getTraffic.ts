import http, { PaginatedResult, WammuCoreRequestConfig } from '@/api/http'
import {
    SecurityListQuery,
    SecurityTrafficItem,
    mapSecurityPagination,
    rawDataToSecurityTrafficItem,
} from '@/api/admin/security/types'

export type SecurityTrafficResponse = PaginatedResult<SecurityTrafficItem>

const getTraffic = async ({
    page,
    perPage = 25,
    query,
    status = 'all',
}: SecurityListQuery, options?: WammuCoreRequestConfig): Promise<SecurityTrafficResponse> => {
    const { data } = await http.get('/api/admin/security/traffic', {
        params: {
            page,
            per_page: perPage,
            query: query || undefined,
            status: status || undefined,
        },
        ...options,
    })

    const items = (data.data?.items || []).map(rawDataToSecurityTrafficItem)

    return {
        items,
        pagination: mapSecurityPagination(data.data?.meta, items.length),
    }
}

export default getTraffic
