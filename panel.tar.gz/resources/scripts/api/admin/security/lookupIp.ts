import http from '@/api/http'

export interface SecurityIpLookupResult {
    ip: string
    type: string
    cidr: number
    server: {
        id: number
        uuid: string
        name: string
        hostname: string
        status: string
    } | null
    owner: {
        id: number
        name: string
        email: string
    } | null
    reseller: {
        id: number
        displayName: string
        status: string
    } | null
}

const lookupIp = async (ip: string): Promise<SecurityIpLookupResult | null> => {
    const {
        data: { data },
    } = await http.get('/api/admin/security/ip-lookup', {
        params: { ip },
    })

    if (!data) {
        return null
    }

    return {
        ip: data.ip,
        type: data.type,
        cidr: data.cidr,
        server: data.server
            ? {
                  id: data.server.id,
                  uuid: data.server.uuid,
                  name: data.server.name,
                  hostname: data.server.hostname,
                  status: data.server.status,
              }
            : null,
        owner: data.owner
            ? {
                  id: data.owner.id,
                  name: data.owner.name,
                  email: data.owner.email,
              }
            : null,
        reseller: data.reseller
            ? {
                  id: data.reseller.id,
                  displayName: data.reseller.display_name,
                  status: data.reseller.status,
              }
            : null,
    }
}

export default lookupIp
