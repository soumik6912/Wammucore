import http, { WammuCoreRequestConfig } from '@/api/http'
import {
    SecurityOverview,
    rawDataToSecurityOverview,
} from '@/api/admin/security/types'

const getOverview = async (
    options?: WammuCoreRequestConfig
): Promise<SecurityOverview> => {
    const { data } = await http.get('/api/admin/security/overview', options)

    return rawDataToSecurityOverview(data.data)
}

export default getOverview
