import http from '@/api/http'
import {
    rawDataToSecurityPolicySettings,
    SecurityPolicySettings,
} from '@/api/admin/security/types'

export interface UpdateSecurityPolicyPayload {
    ddosMonitorEnabled?: boolean
    autoSuspendEnabled?: boolean
    suspendCriticalImmediately?: boolean
    warningAfterViolations?: number
    suspendAfterViolations?: number
    violationDecayMinutes?: number
    incomingAlertWebhookUrl?: string | null
    outgoingAlertWebhookUrl?: string | null
    discordWebhookUrl?: string | null
    webhookOnWarning?: boolean
    webhookOnSuspend?: boolean
    webhookOnTerminate?: boolean
}

const updateSettings = async (
    payload: UpdateSecurityPolicyPayload
): Promise<SecurityPolicySettings> => {
    const {
        data: { data },
    } = await http.patch('/api/admin/security/settings', {
        ddos_monitor_enabled: payload.ddosMonitorEnabled,
        auto_suspend_enabled: payload.autoSuspendEnabled,
        suspend_critical_immediately: payload.suspendCriticalImmediately,
        warning_after_violations: payload.warningAfterViolations,
        suspend_after_violations: payload.suspendAfterViolations,
        violation_decay_minutes: payload.violationDecayMinutes,
        incoming_alert_webhook_url: payload.incomingAlertWebhookUrl,
        outgoing_alert_webhook_url: payload.outgoingAlertWebhookUrl,
        discord_webhook_url: payload.discordWebhookUrl,
        webhook_on_warning: payload.webhookOnWarning,
        webhook_on_suspend: payload.webhookOnSuspend,
        webhook_on_terminate: payload.webhookOnTerminate,
    })

    return rawDataToSecurityPolicySettings(data)
}

export default updateSettings
