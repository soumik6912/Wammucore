import http, { PaginatedResult, WammuCoreRequestConfig } from '@/api/http'
import {
    SecurityListQuery,
    SecurityScoreItem,
    mapSecurityPagination,
    rawDataToSecurityScoreItem,
} from '@/api/admin/security/types'

export type SecurityScoreResponse = PaginatedResult<SecurityScoreItem>

const getScores = async ({
    page,
    perPage = 12,
    query,
    status = 'all',
}: SecurityListQuery, options?: WammuCoreRequestConfig): Promise<SecurityScoreResponse> => {
    const { data } = await http.get('/api/admin/security/scores', {
        params: {
            page,
            per_page: perPage,
            query: query || undefined,
            status: status || undefined,
        },
        ...options,
    })

    const items = (data.data?.items || []).map(rawDataToSecurityScoreItem)

    return {
        items,
        pagination: mapSecurityPagination(data.data?.meta, items.length),
    }
}

export default getScores
