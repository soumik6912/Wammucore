import useSWR from 'swr'

import getLocations, {
    LocationResponse,
    QueryParams,
} from '@/api/admin/locations/getLocations'

const useLocationsSWR = ({ page, query, ...params }: QueryParams) => {
    return useSWR<LocationResponse>(
        ['admin:locations', page, query, params.perPage],
        () => getLocations({ page, query, ...params }),
        {
            dedupingInterval: 20000,
            keepPreviousData: true,
            revalidateOnFocus: false,
            revalidateOnReconnect: false,
        }
    )
}

export default useLocationsSWR
