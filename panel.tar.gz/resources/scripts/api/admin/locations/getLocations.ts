import http, {
    FractalResponseData,
    PaginatedResult,
    getPaginationSet,
} from '@/api/http'

export interface Location {
    id: number
    shortCode: string
    description: string | null
    showToUsers: boolean
    showToResellers: boolean
    enableForResellers: boolean
    nodesCount: number
    serversCount: number
}

export const rawDataToLocation = (data: FractalResponseData): Location => ({
    id: data.id,
    shortCode: data.short_code,
    description: data.description,
    showToUsers: Boolean(data.show_to_users ?? true),
    showToResellers: Boolean(
        data.show_to_resellers ?? data.enable_for_resellers ?? true
    ),
    enableForResellers: Boolean(data.enable_for_resellers ?? true),
    nodesCount: data.nodes_count,
    serversCount: data.servers_count,
})

export interface QueryParams {
    query?: string
    page?: number
    perPage?: number
}

export type LocationResponse = PaginatedResult<Location>

export default ({
    query,
    perPage = 50,
    ...params
}: QueryParams): Promise<PaginatedResult<Location>> => {
    return new Promise((resolve, reject) => {
        http.get('/api/admin/locations', {
            params: {
                'filter[*]': query,
                'per_page': perPage,
                ...params,
            },
            showProgress: false,
        })
            .then(({ data }) =>
                resolve({
                    items: (data.data || []).map((datum: any) =>
                        rawDataToLocation(datum)
                    ),
                    pagination: getPaginationSet(data.meta.pagination),
                })
            )
            .catch(reject)
    })
}
