import { Location, rawDataToLocation } from '@/api/admin/locations/getLocations'
import http from '@/api/http'

export default async (
    shortCode: string,
    description: string | null,
    showToUsers: boolean,
    showToResellers: boolean
): Promise<Location> => {
    const {
        data: { data },
    } = await http.post('/api/admin/locations', {
        short_code: shortCode,
        description,
        show_to_users: showToUsers,
        show_to_resellers: showToResellers,
        enable_for_resellers: showToResellers,
    })

    return rawDataToLocation(data)
}
