export interface CatalogPlan {
    id: number
    uuid: string
    name: string
    slug: string
    category: string
    description: string | null
    cpuCores: number
    cpuLimit: number
    cpuUnits: number
    cpuSockets: number
    ramMb: number
    diskGb: number
    bandwidthGb: number | null
    snapshotLimit: number
    backupLimit: number
    defaultIpQuantity: number
    sortOrder: number
    isActive: boolean
}

export interface ResellerPlanPricing {
    monthlyPrice: string | null
    currency: string
    ipQuantity: number
    ipPriceEach: string
    paymenterCheckoutUrl: string | null
    isVisible: boolean
}

export interface ResellerCatalogPlan extends CatalogPlan {
    pricing: ResellerPlanPricing
}

export interface ResellerPlanPricingResponse {
    resellerId: number | null
    items: ResellerCatalogPlan[]
}
