import http from '@/api/http'
import { CatalogPlan } from '@/api/admin/plans/types'

const rawDataToCatalogPlan = (data: any): CatalogPlan => ({
    id: Number(data.id),
    uuid: data.uuid,
    name: data.name,
    slug: data.slug,
    category: String(data.category ?? 'General'),
    description: data.description ?? null,
    cpuCores: Number(data.cpu_cores),
    cpuLimit: Number(data.cpu_limit ?? 0),
    cpuUnits: Number(data.cpu_units ?? 1024),
    cpuSockets: Number(data.cpu_sockets ?? 1),
    ramMb: Number(data.ram_mb),
    diskGb: Number(data.disk_gb),
    bandwidthGb: data.bandwidth_gb === null ? null : Number(data.bandwidth_gb),
    snapshotLimit: Number(data.snapshot_limit ?? 0),
    backupLimit: Number(data.backup_limit ?? 0),
    defaultIpQuantity: Number(data.default_ip_quantity ?? 0),
    sortOrder: Number(data.sort_order ?? 0),
    isActive: Boolean(data.is_active),
})

const getCatalogPlans = async (): Promise<CatalogPlan[]> => {
    const {
        data: { data },
    } = await http.get('/api/admin/plan-catalog')

    return Array.isArray(data) ? data.map(rawDataToCatalogPlan) : []
}

export default getCatalogPlans
export { rawDataToCatalogPlan }
