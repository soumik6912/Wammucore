import http from '@/api/http'
import {
    CatalogPlan,
    ResellerCatalogPlan,
    ResellerPlanPricing,
    ResellerPlanPricingResponse,
} from '@/api/admin/plans/types'
import { rawDataToCatalogPlan } from '@/api/admin/plans/getCatalogPlans'

const rawDataToPricing = (data: any): ResellerPlanPricing => ({
    monthlyPrice: data.monthly_price ?? null,
    currency: data.currency,
    ipQuantity: Number(data.ip_quantity ?? 0),
    ipPriceEach: data.ip_price_each ?? '0.00',
    paymenterCheckoutUrl: data.paymenter_checkout_url ?? null,
    isVisible: Boolean(data.is_visible ?? true),
})

const rawDataToResellerCatalogPlan = (data: any): ResellerCatalogPlan => {
    const basePlan: CatalogPlan = rawDataToCatalogPlan(data)

    return {
        ...basePlan,
        pricing: rawDataToPricing(data.pricing || {}),
    }
}

const getResellerPlanPrices = async (
    resellerId?: number | null
): Promise<ResellerPlanPricingResponse> => {
    const {
        data: { data },
    } = await http.get('/api/admin/reseller-plans', {
        params: resellerId ? { reseller_id: resellerId } : {},
    })

    return {
        resellerId:
            data.reseller_id === null || typeof data.reseller_id === 'undefined'
                ? null
                : Number(data.reseller_id),
        items: Array.isArray(data.items)
            ? data.items.map(rawDataToResellerCatalogPlan)
            : [],
    }
}

export default getResellerPlanPrices
export { rawDataToResellerCatalogPlan, rawDataToPricing }
