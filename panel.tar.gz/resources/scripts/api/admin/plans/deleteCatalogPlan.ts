import http from '@/api/http'

const deleteCatalogPlan = async (planId: number): Promise<void> => {
    await http.delete(`/api/admin/plan-catalog/${planId}`)
}

export default deleteCatalogPlan

