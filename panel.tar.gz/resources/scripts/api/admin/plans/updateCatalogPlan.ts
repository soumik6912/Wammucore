import http from '@/api/http'
import { CatalogPlan } from '@/api/admin/plans/types'
import { rawDataToCatalogPlan } from '@/api/admin/plans/getCatalogPlans'
import { CatalogPlanUpsertPayload } from '@/api/admin/plans/createCatalogPlan'

const updateCatalogPlan = async (
    planId: number,
    payload: CatalogPlanUpsertPayload
): Promise<CatalogPlan> => {
    const {
        data: { data },
    } = await http.put(`/api/admin/plan-catalog/${planId}`, {
        name: payload.name,
        slug: payload.slug,
        category: payload.category,
        description: payload.description,
        cpu_cores: payload.cpuCores,
        cpu_limit: payload.cpuLimit,
        cpu_units: payload.cpuUnits,
        cpu_sockets: payload.cpuSockets,
        ram_mb: payload.ramMb,
        disk_gb: payload.diskGb,
        bandwidth_gb: payload.bandwidthGb,
        snapshot_limit: payload.snapshotLimit,
        backup_limit: payload.backupLimit,
        default_ip_quantity: payload.defaultIpQuantity,
        sort_order: payload.sortOrder,
        is_active: payload.isActive,
    })

    return rawDataToCatalogPlan(data)
}

export default updateCatalogPlan
