import http from '@/api/http'
import { CatalogPlan } from '@/api/admin/plans/types'
import { rawDataToCatalogPlan } from '@/api/admin/plans/getCatalogPlans'

export interface CatalogPlanUpsertPayload {
    name: string
    slug: string
    category: string
    description: string | null
    cpuCores: number
    cpuLimit: number
    cpuUnits: number
    cpuSockets: number
    ramMb: number
    diskGb: number
    bandwidthGb: number | null
    snapshotLimit: number
    backupLimit: number
    defaultIpQuantity: number
    sortOrder: number
    isActive: boolean
}

const createCatalogPlan = async (
    payload: CatalogPlanUpsertPayload
): Promise<CatalogPlan> => {
    const {
        data: { data },
    } = await http.post('/api/admin/plan-catalog', {
        name: payload.name,
        slug: payload.slug,
        category: payload.category,
        description: payload.description,
        cpu_cores: payload.cpuCores,
        cpu_limit: payload.cpuLimit,
        cpu_units: payload.cpuUnits,
        cpu_sockets: payload.cpuSockets,
        ram_mb: payload.ramMb,
        disk_gb: payload.diskGb,
        bandwidth_gb: payload.bandwidthGb,
        snapshot_limit: payload.snapshotLimit,
        backup_limit: payload.backupLimit,
        default_ip_quantity: payload.defaultIpQuantity,
        sort_order: payload.sortOrder,
        is_active: payload.isActive,
    })

    return rawDataToCatalogPlan(data)
}

export default createCatalogPlan
