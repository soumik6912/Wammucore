import http from '@/api/http'
import { ResellerCatalogPlan } from '@/api/admin/plans/types'
import { rawDataToResellerCatalogPlan } from '@/api/admin/plans/getResellerPlanPrices'

export interface UpdateResellerPlanPricePayload {
    monthlyPrice: string | null
    currency: string
    ipQuantity: number
    ipPriceEach: string
    paymenterCheckoutUrl: string | null
    isVisible: boolean
    resellerId?: number | null
}

const updateResellerPlanPrice = async (
    planId: number,
    payload: UpdateResellerPlanPricePayload
): Promise<ResellerCatalogPlan> => {
    const {
        data: { data },
    } = await http.put(`/api/admin/reseller-plans/${planId}`, {
        monthly_price: payload.monthlyPrice,
        currency: payload.currency,
        ip_quantity: payload.ipQuantity,
        ip_price_each: payload.ipPriceEach,
        paymenter_checkout_url: payload.paymenterCheckoutUrl,
        is_visible: payload.isVisible,
        ...(typeof payload.resellerId === 'number'
            ? { reseller_id: payload.resellerId }
            : {}),
    })

    return rawDataToResellerCatalogPlan(data.item)
}

export default updateResellerPlanPrice
