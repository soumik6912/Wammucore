import useSWR from 'swr'

import getHorizon from '@/api/admin/horizon/getHorizon'
import { HorizonData } from '@/api/admin/horizon/types'

const useHorizonSWR = () => {
    return useSWR<HorizonData>(
        'admin:horizon',
        () => getHorizon({ showProgress: false }),
        {
            refreshInterval: 20000,
            revalidateOnFocus: false,
            refreshWhenHidden: false,
            refreshWhenOffline: false,
        }
    )
}

export default useHorizonSWR

