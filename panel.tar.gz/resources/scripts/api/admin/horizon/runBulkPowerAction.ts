import http from '@/api/http'

export type BulkPowerScope = 'all-vps' | 'reseller-vps'

export interface BulkPowerActionResult {
    message: string
    scope: BulkPowerScope
    queuedServers: number
    eligibleServers: number
    skippedServers: number
}

const runBulkPowerAction = async (scope: BulkPowerScope): Promise<BulkPowerActionResult> => {
    const { data } = await http.post(`/api/admin/core/bulk-power/${scope}`)

    return {
        message: data.data?.message ?? 'Bulk stop jobs queued.',
        scope: data.data?.scope ?? scope,
        queuedServers: Number(data.data?.queued_servers ?? 0),
        eligibleServers: Number(data.data?.eligible_servers ?? 0),
        skippedServers: Number(data.data?.skipped_servers ?? 0),
    }
}

export default runBulkPowerAction
