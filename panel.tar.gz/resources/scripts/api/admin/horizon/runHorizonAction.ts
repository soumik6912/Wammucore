import http from '@/api/http'

const runHorizonAction = async (action: string): Promise<{ message: string; output: string }> => {
    const { data } = await http.post(`/api/admin/core/actions/${action}`)

    return {
        message: data.data?.message ?? 'Action completed.',
        output: data.data?.output ?? '',
    }
}

export default runHorizonAction

