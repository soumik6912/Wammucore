export interface HorizonSummary {
    status: 'inactive' | 'paused' | 'running' | string
    masterSupervisors: number
    supervisors: number
    processes: number
    jobsPerMinute: number
    throughput: number
    pendingJobs: number
    completedJobs: number
    failedJobs: number
    silencedJobs: number
    recentJobs: number
    recentFailedJobs: number
    maxWait: number
    maxRuntime: number
    maxThroughput: number
}

export interface HorizonMaster {
    name: string
    environment: string
    pid: number | null
    status: string
    supervisors: number
}

export interface HorizonSupervisor {
    name: string
    master: string
    status: string
    processes: number[]
    processCount: number
    queue: string[]
    balance: string | null
}

export interface HorizonWorkload {
    name: string
    length: number
    wait: number
    processes: number
    runtime: number
    throughput: number
    splitQueues: Array<{
        name: string
        length: number
        wait: number
    }>
}

export interface HorizonQueueMetric {
    name: string
    runtime: number
    throughput: number
    snapshots: Array<Record<string, unknown>>
}

export interface HorizonTag {
    tag: string
    count: number
}

export interface HorizonJob {
    id: string
    name: string
    queue: string
    status: string
    completedAt: string
    reservedAt: string
    failedAt: string
    silenced: boolean
    tags: string[]
    exception: string
}

export interface HorizonAction {
    key: 'pause' | 'continue' | 'terminate' | 'snapshot' | 'clear-metrics' | string
    label: string
}

export interface HorizonData {
    summary: HorizonSummary
    masters: HorizonMaster[]
    supervisors: HorizonSupervisor[]
    workload: HorizonWorkload[]
    queues: HorizonQueueMetric[]
    monitoredTags: HorizonTag[]
    jobs: {
        failed: HorizonJob[]
        pending: HorizonJob[]
        completed: HorizonJob[]
    }
    links: {
        dashboard: string
    }
    actions: HorizonAction[]
    generatedAt: string
}

export const rawDataToHorizon = (data: any): HorizonData => ({
    summary: {
        status: String(data.summary?.status ?? 'inactive'),
        masterSupervisors: Number(data.summary?.master_supervisors ?? 0),
        supervisors: Number(data.summary?.supervisors ?? 0),
        processes: Number(data.summary?.processes ?? 0),
        jobsPerMinute: Number(data.summary?.jobs_per_minute ?? 0),
        throughput: Number(data.summary?.throughput ?? 0),
        pendingJobs: Number(data.summary?.pending_jobs ?? 0),
        completedJobs: Number(data.summary?.completed_jobs ?? 0),
        failedJobs: Number(data.summary?.failed_jobs ?? 0),
        silencedJobs: Number(data.summary?.silenced_jobs ?? 0),
        recentJobs: Number(data.summary?.recent_jobs ?? 0),
        recentFailedJobs: Number(data.summary?.recent_failed_jobs ?? 0),
        maxWait: Number(data.summary?.max_wait ?? 0),
        maxRuntime: Number(data.summary?.max_runtime ?? 0),
        maxThroughput: Number(data.summary?.max_throughput ?? 0),
    },
    masters: Array.isArray(data.masters)
        ? data.masters.map((item: any) => ({
              name: item.name ?? 'unknown',
              environment: item.environment ?? 'production',
              pid: item.pid ?? null,
              status: item.status ?? 'inactive',
              supervisors: Number(item.supervisors ?? 0),
          }))
        : [],
    supervisors: Array.isArray(data.supervisors)
        ? data.supervisors.map((item: any) => ({
              name: item.name ?? 'unknown',
              master: item.master ?? 'unknown',
              status: item.status ?? 'inactive',
              processes: Array.isArray(item.processes) ? item.processes.map((entry: any) => Number(entry ?? 0)) : [],
              processCount: Number(item.process_count ?? 0),
              queue: Array.isArray(item.queue) ? item.queue : [],
              balance: item.balance ?? null,
          }))
        : [],
    workload: Array.isArray(data.workload)
        ? data.workload.map((item: any) => ({
              name: item.name ?? 'redis:default',
              length: Number(item.length ?? 0),
              wait: Number(item.wait ?? 0),
              processes: Number(item.processes ?? 0),
              runtime: Number(item.runtime ?? 0),
              throughput: Number(item.throughput ?? 0),
              splitQueues: Array.isArray(item.split_queues)
                  ? item.split_queues.map((queue: any) => ({
                        name: queue.name ?? '',
                        length: Number(queue.length ?? 0),
                        wait: Number(queue.wait ?? 0),
                    }))
                  : [],
          }))
        : [],
    queues: Array.isArray(data.queues)
        ? data.queues.map((item: any) => ({
              name: item.name ?? 'default',
              runtime: Number(item.runtime ?? 0),
              throughput: Number(item.throughput ?? 0),
              snapshots: Array.isArray(item.snapshots) ? item.snapshots : [],
          }))
        : [],
    monitoredTags: Array.isArray(data.monitored_tags)
        ? data.monitored_tags.map((item: any) => ({
              tag: item.tag ?? '',
              count: Number(item.count ?? 0),
          }))
        : [],
    jobs: {
        failed: Array.isArray(data.jobs?.failed) ? data.jobs.failed.map(mapJob) : [],
        pending: Array.isArray(data.jobs?.pending) ? data.jobs.pending.map(mapJob) : [],
        completed: Array.isArray(data.jobs?.completed) ? data.jobs.completed.map(mapJob) : [],
    },
    links: {
        dashboard: data.links?.dashboard ?? '/core',
    },
    actions: Array.isArray(data.actions)
        ? data.actions.map((item: any) => ({
              key: item.key ?? '',
              label: item.label ?? 'Run',
          }))
        : [],
    generatedAt: data.generated_at ?? '',
})

const mapJob = (item: any): HorizonJob => ({
    id: item.id ?? '',
    name: item.name ?? 'Unknown job',
    queue: item.queue ?? 'default',
    status: item.status ?? 'processed',
    completedAt: item.completed_at ?? '',
    reservedAt: item.reserved_at ?? '',
    failedAt: item.failed_at ?? '',
    silenced: !!item.silenced,
    tags: Array.isArray(item.tags) ? item.tags : [],
    exception: item.exception ?? '',
})

