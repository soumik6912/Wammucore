import http, { WammuCoreRequestConfig } from '@/api/http'

import { HorizonData, rawDataToHorizon } from '@/api/admin/horizon/types'

const getHorizon = async (config?: WammuCoreRequestConfig): Promise<HorizonData> => {
    const { data } = await http.get('/api/admin/core', {
        ...(config ?? {}),
    })

    return rawDataToHorizon(data.data)
}

export default getHorizon

