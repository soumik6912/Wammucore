import http from '@/api/http'

export interface TenantContextReseller {
    id: number
    uuid: string | null
    slug: string | null
    displayName: string
    domain: string | null
    status: string
    verificationStatus:
        | 'pending'
        | 'under_review'
        | 'approved'
        | 'rejected'
        | 'suspended'
    verificationSubmittedAt: string | null
    verificationRejectionReason: string | null
    onboardingStatus: string
    onboardingCurrentStep: string | null
    isDefault: boolean
}

export interface TenantContextSnapshot {
    mode: 'all' | 'platform' | 'reseller'
    tenantId: number | null
    resellerId: number | null
    hostname: string | null
    selection: 'all' | 'platform' | number
    activeReseller: TenantContextReseller | null
    hostReseller: TenantContextReseller | null
    defaultResellerId: number | null
    global: {
        resellers: number
        users: number
        servers: number
        nodes: number
    }
    scoped: {
        users: number
        servers: number
        nodes: number
    }
}

const rawDataToReseller = (data: any): TenantContextReseller => ({
    id: data.id,
    uuid: data.uuid ?? null,
    slug: data.slug ?? null,
    displayName: data.display_name,
    domain: data.domain ?? null,
    status: data.status,
    verificationStatus: data.verification_status ?? 'approved',
    verificationSubmittedAt: data.verification_submitted_at ?? null,
    verificationRejectionReason: data.verification_rejection_reason ?? null,
    onboardingStatus: data.onboarding_status ?? 'pending',
    onboardingCurrentStep: data.onboarding_current_step ?? null,
    isDefault: data.is_default ?? false,
})

export const rawDataToTenantContext = (data: any): TenantContextSnapshot => ({
    mode: data.mode,
    tenantId: data.tenant_id === null || data.tenant_id === undefined ? null : Number(data.tenant_id),
    resellerId: data.reseller_id === null || data.reseller_id === undefined ? null : Number(data.reseller_id),
    hostname: data.hostname ?? null,
    selection:
        data.selection === 'all' || data.selection === 'platform'
            ? data.selection
            : Number(data.selection),
    activeReseller: data.active_reseller
        ? rawDataToReseller(data.active_reseller)
        : null,
    hostReseller: data.host_reseller ? rawDataToReseller(data.host_reseller) : null,
    defaultResellerId: data.default_reseller_id ?? null,
    global: {
        resellers: data.global?.resellers ?? 0,
        users: data.global?.users ?? 0,
        servers: data.global?.servers ?? 0,
        nodes: data.global?.nodes ?? 0,
    },
    scoped: {
        users: data.scoped?.users ?? 0,
        servers: data.scoped?.servers ?? 0,
        nodes: data.scoped?.nodes ?? 0,
    },
})

const getTenantContext = async (): Promise<TenantContextSnapshot> => {
    const {
        data: { data },
    } = await http.get('/api/admin/tenancy/context', {
        showProgress: false,
    } as any)

    return rawDataToTenantContext(data)
}

export default getTenantContext
