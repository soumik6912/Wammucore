import useSWR from 'swr'

import getTenantContext, {
    TenantContextSnapshot,
} from '@/api/admin/tenancy/getTenantContext'

const useTenantContextSWR = (enabled: boolean = true) => {
    return useSWR<TenantContextSnapshot>(
        enabled ? 'admin:tenancy:context' : null,
        () => getTenantContext(),
        {
            dedupingInterval: 45000,
            revalidateIfStale: false,
            revalidateOnFocus: false,
            revalidateOnReconnect: false,
        }
    )
}

export default useTenantContextSWR
