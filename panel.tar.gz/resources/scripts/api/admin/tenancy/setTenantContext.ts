import getTenantContext, {
    rawDataToTenantContext,
    TenantContextSnapshot,
} from '@/api/admin/tenancy/getTenantContext'
import http from '@/api/http'

interface SetTenantContextPayload {
    mode: 'all' | 'platform' | 'reseller'
    resellerId?: number
    resellerRef?: string
}

const setTenantContext = async ({
    mode,
    resellerId,
    resellerRef,
}: SetTenantContextPayload): Promise<TenantContextSnapshot> => {
    const {
        data: { data },
    } = await http.patch('/api/admin/tenancy/context', {
        mode,
        reseller_id: mode === 'reseller' ? resellerId : null,
        reseller_ref: mode === 'reseller' ? resellerRef : null,
    }, {
        showSuccessNotification: false,
    })

    if (!data) {
        return getTenantContext()
    }

    return rawDataToTenantContext(data)
}

export default setTenantContext
