import http, { PaginatedResult, getPaginationSet } from '@/api/http'

export interface User {
    id: number
    name: string
    email: string
    emailVerifiedAt: Date | null
    rootAdmin: boolean
    isPlatformAdmin: boolean
    resellerAdmin: boolean
    resellerId: number | null
    resellerDisplayName: string | null
    resellerIsDefault: boolean
    serversCount: number
}

export const rawDataToUser = (data: any): User => ({
    id: data.id,
    name: data.name,
    email: data.email,
    emailVerifiedAt: data.email_verified_at
        ? new Date(data.email_verified_at)
        : null,
    rootAdmin: data.root_admin,
    isPlatformAdmin: Boolean(data.is_platform_admin ?? data.root_admin ?? false),
    resellerAdmin: Boolean(data.reseller_admin ?? false),
    resellerId: data.reseller_id ?? null,
    resellerDisplayName: data.reseller?.display_name ?? null,
    resellerIsDefault: Boolean(data.reseller?.is_default ?? false),
    serversCount: data.servers_count,
})

export interface QueryParams {
    query?: string
    page?: number
    perPage?: number
    scope?: 'platform_users' | 'platform_staff' | 'reseller_admins' | 'reseller_customers' | 'all'
}

export type UserResponse = PaginatedResult<User>

const getUsers = async ({
    query,
    perPage = 50,
    ...params
}: QueryParams): Promise<UserResponse> => {
    const { data } = await http.get('/api/admin/users', {
        params: {
            'filter[*]': query,
            'per_page': perPage,
            'scope': params.scope,
            ...params,
        },
        showProgress: false,
    })

    return {
        items: data.data.map(rawDataToUser),
        pagination: getPaginationSet(data.meta.pagination),
    }
}

export default getUsers
