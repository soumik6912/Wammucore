import { rawDataToUser } from '@/api/admin/users/getUsers'
import http from '@/api/http'

interface CreateUserParameters {
    name: string
    email: string
    password: string
    rootAdmin: boolean
    resellerAdmin: boolean
    resellerId?: number
}

const createUser = async ({
    rootAdmin,
    resellerAdmin,
    resellerId,
    ...payload
}: CreateUserParameters) => {
    const {
        data: { data },
    } = await http.post(`/api/admin/users`, {
        root_admin: rootAdmin,
        reseller_admin: resellerAdmin,
        reseller_id: resellerId ?? null,
        ...payload,
    })

    return rawDataToUser(data)
}

export default createUser
