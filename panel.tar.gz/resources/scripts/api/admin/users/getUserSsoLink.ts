import http from '@/api/http'

export interface UserSsoLink {
    userId: number
    token: string
    ssoUrl: string
    expiresIn: number
    adminReturnUrl: string | null
    adminReturnExpiresAt: string | null
}

const getUserSsoLink = async (userId: number): Promise<UserSsoLink> => {
    const {
        data: { data },
    } = await http.post(`/api/admin/users/${userId}/sso-link`)

    return {
        userId: data.user_id,
        token: data.token,
        ssoUrl: data.sso_url,
        expiresIn: data.expires_in,
        adminReturnUrl:
            typeof data.admin_return_url === 'string' && data.admin_return_url.trim() !== ''
                ? data.admin_return_url.trim()
                : null,
        adminReturnExpiresAt:
            typeof data.admin_return_expires_at === 'string' && data.admin_return_expires_at.trim() !== ''
                ? data.admin_return_expires_at.trim()
                : null,
    }
}

export default getUserSsoLink
