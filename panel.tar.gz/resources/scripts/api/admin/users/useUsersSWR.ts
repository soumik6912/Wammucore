import useSWR from 'swr'

import getUsers, { QueryParams, UserResponse } from '@/api/admin/users/getUsers'

const useUsersSWR = ({ page, query, ...params }: QueryParams) => {
    return useSWR<UserResponse>(
        ['admin:users', page, query, params.perPage, params.scope],
        () => getUsers({ page, query, ...params }),
        {
            dedupingInterval: 20000,
            keepPreviousData: true,
            revalidateOnFocus: false,
            revalidateOnReconnect: false,
        }
    )
}

export default useUsersSWR
