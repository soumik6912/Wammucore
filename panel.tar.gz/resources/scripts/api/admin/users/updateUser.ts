import { rawDataToUser } from '@/api/admin/users/getUsers'
import http from '@/api/http'

interface UpdateUserParameters {
    name: string
    email: string
    password?: string | null
    rootAdmin: boolean
    resellerAdmin: boolean
    resellerId?: number
}

const updateUser = async (
    userId: number,
    { rootAdmin, resellerAdmin, resellerId, ...payload }: UpdateUserParameters
) => {
    const {
        data: { data },
    } = await http.patch(`/api/admin/users/${userId}`, {
        root_admin: rootAdmin,
        reseller_admin: resellerAdmin,
        reseller_id: resellerId ?? null,
        ...payload,
    })

    return rawDataToUser(data)
}

export default updateUser
